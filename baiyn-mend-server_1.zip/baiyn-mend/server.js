'use strict';
/* server.js — «Баярын мэнд»: Express + SQLite.
   Customers sign up, build a card, pay by bank transfer, the admin confirms, and the share link starts to work.
   The browser app in public/ is the very same code as the Claude artifact; only its storage adapter (backend-rest.js) differs. */
const fs = require('node:fs');
const path = require('node:path');
const bcrypt = require('bcryptjs');
const express = require('express');
const { open } = require('./lib/db');
const V = require('./lib/validate');
const S = require('./lib/security');
const { ensureAdmin } = require('./lib/users');
const { HttpError, bad } = V;

/* .env without a dependency: KEY=VALUE per line, real environment variables win */
function loadEnv(file) {
  let txt = ''; try { txt = fs.readFileSync(file, 'utf8'); } catch (e) { return; }
  for (const line of txt.split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line); if (!m || line.trim().startsWith('#')) continue;
    if (process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
}

const DAY = 86400000, SESSION_MS = 30 * DAY, MAX_CARDS = 80;
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const refCode = id => 'MN-' + String(id).slice(0, 6).toUpperCase();

/* what kind of file is this really? (the Content-Type the browser claims is never trusted) */
function sniff(b) {
  if (b.length < 12) return null;
  if (b[0] === 0x89 && b.toString('latin1', 1, 4) === 'PNG') return { mime: 'image/png', kind: 'image' };
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { mime: 'image/jpeg', kind: 'image' };
  if (b.toString('latin1', 0, 4) === 'GIF8') return { mime: 'image/gif', kind: 'image' };
  if (b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return { mime: 'image/webp', kind: 'image' };
  if (b.toString('latin1', 4, 8) === 'ftyp') return { mime: 'video/mp4', kind: 'video' };
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return { mime: 'video/webm', kind: 'video' };
  return null;
}

function createApp(o) {
  o = Object.assign({
    dataDir: process.env.DATA_DIR || path.join(__dirname, 'data'),
    baseUrl: (process.env.BASE_URL || '').replace(/\/+$/, ''),
    trustProxy: process.env.TRUST_PROXY || '',
    publicDir: path.join(__dirname, 'public')
  }, o);
  const ctx = open(o.dataDir), { db, q, kv, bump, rid } = ctx;
  const uploads = path.join(o.dataDir, 'uploads');
  const DUMMY = bcrypt.hashSync('dummy-password-for-timing', 10);

  const app = express();
  app.disable('x-powered-by');
  if (o.trustProxy) app.set('trust proxy', /^\d+$/.test(o.trustProxy) ? Number(o.trustProxy) : o.trustProxy);
  const secureEnv = /^https:/.test(o.baseUrl) || process.env.COOKIE_SECURE === '1';
  app.use(S.headers({ secure: secureEnv }));
  const cookieOpt = (req, maxAge) => ({ secure: secureEnv || req.secure, maxAge });
  const baseOf = req => o.baseUrl || `${req.protocol}://${req.get('host')}`;

  /* ---------- statements used by several routes ---------- */
  const st = {
    cardGet: db.prepare('SELECT * FROM cards WHERE id = ?'),
    cardCount: db.prepare('SELECT COUNT(*) n FROM cards WHERE uid = ?'),
    cardIns: db.prepare('INSERT INTO cards(id, uid, data, to_name, occ, fx, free, created, updated) VALUES (?,?,?,?,?,?,?,?,?)'),
    cardUpd: db.prepare('UPDATE cards SET data = ?, to_name = ?, occ = ?, fx = ?, updated = ? WHERE id = ?'),
    cardClaim: db.prepare('UPDATE cards SET claim = ? WHERE id = ? AND uid = ?'),
    cardDel: db.prepare('DELETE FROM cards WHERE id = ?'),
    cardView: db.prepare('UPDATE cards SET views = views + 1, last_view = ? WHERE id = ?'),
    mine: db.prepare('SELECT id, to_name, occ, fx, free, claim, views, created FROM cards WHERE uid = ? ORDER BY created DESC'),
    allCards: db.prepare('SELECT id, uid, to_name, occ, fx, free, claim, views, created FROM cards ORDER BY created DESC'),
    apGet: db.prepare('SELECT card_id, uid, st, at, note, amt FROM approvals WHERE card_id = ?'),
    apMine: db.prepare('SELECT card_id, uid, st, at, note, amt FROM approvals WHERE uid = ?'),
    apAll: db.prepare('SELECT card_id, uid, st, at, note, amt FROM approvals'),
    apSet: db.prepare('INSERT INTO approvals(card_id, uid, st, at, note, amt, by) VALUES (?,?,?,?,?,?,?) ON CONFLICT(card_id) DO UPDATE SET uid = excluded.uid, st = excluded.st, at = excluded.at, note = excluded.note, amt = excluded.amt, by = excluded.by'),
    apDel: db.prepare('DELETE FROM approvals WHERE card_id = ?'),
    items: db.prepare('SELECT id, data FROM items WHERE kind = ? ORDER BY ord, id'),
    itemSet: db.prepare('INSERT INTO items(kind, id, ord, data) VALUES (?,?,?,?) ON CONFLICT(kind, id) DO UPDATE SET ord = excluded.ord, data = excluded.data'),
    itemDel: db.prepare('DELETE FROM items WHERE kind = ? AND id = ?'),
    assetGet: db.prepare('SELECT * FROM assets WHERE id = ?'),
    assetIns: db.prepare('INSERT INTO assets(id, mime, size, created) VALUES (?,?,?,?)'),
    assetDel: db.prepare('DELETE FROM assets WHERE id = ?'),
    visGet: db.prepare('SELECT * FROM visitors WHERE vid = ?'),
    visIns: db.prepare('INSERT INTO visitors(vid, first, last, n, app_at, v) VALUES (?,?,?,?,?,?)'),
    visUpd: db.prepare('UPDATE visitors SET last = ?, n = ?, app_at = ?, v = ? WHERE vid = ?'),
    visAll: db.prepare('SELECT vid, first, last, n, v FROM visitors ORDER BY last DESC LIMIT 500'),
    visPrune: db.prepare("DELETE FROM visitors WHERE vid LIKE 'a_%' AND v = '[]' AND last < ?"),
    usersWithCards: db.prepare('SELECT id, ident, name, created, last FROM users WHERE id IN (SELECT DISTINCT uid FROM cards)'),
    namesOf: db.prepare('SELECT id, name, ident FROM users WHERE id = ?')
  };
  const parse = (s, d) => { try { return JSON.parse(s); } catch (e) { return d; } };
  const apOut = r => r ? { uid: r.uid, st: r.st, at: r.at, note: r.note, amt: r.amt } : null;
  const mainCfg = () => kv.get('main', {});

  /* ---------- who is asking ---------- */
  app.use((req, res, next) => {
    req.user = null; req.cookies = S.parseCookies(req); req.sid = '';
    const c = req.cookies.sid;
    if (c && typeof c === 'string' && c.length < 100) {
      const h = S.sha256(c), row = q.sessGet.get(h);
      if (row && row.exp > Date.now()) { req.user = { id: row.id, ident: row.ident, name: row.name, role: row.role }; req.sid = h; }
    }
    next();
  });
  const needUser = (req, res, next) => req.user ? next() : next(new HttpError(401, 'Нэвтэрнэ үү', 'unauthenticated'));
  const needAdmin = (req, res, next) => !req.user ? next(new HttpError(401, 'Нэвтэрнэ үү', 'unauthenticated')) : (req.user.role === 'admin' ? next() : next(new HttpError(403, 'Зөвхөн админ хийж чадна', 'forbidden')));
  const pub = u => u ? { uid: u.id, name: u.name, ident: u.ident, isAdmin: u.role === 'admin' } : { uid: null };
  function startSession(req, res, uid) {
    const tok = S.token(), t = Date.now();
    q.sessInsert.run(S.sha256(tok), uid, t, t + SESSION_MS); q.userTouch.run(t, uid);
    S.setCookie(res, 'sid', tok, cookieOpt(req, SESSION_MS / 1000));
  }

  /* ---------- API plumbing ---------- */
  const api = express.Router();
  api.use((req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
  api.use(S.csrf);
  const json = express.json({ limit: '1mb' });
  const ip = req => req.ip || 'x';

  api.get('/me', (req, res) => res.json(pub(req.user)));

  api.post('/register', S.limit('reg', 10, 3600000, ip), json, async (req, res) => {
    const b = req.body || {}, ident = V.ident(b.ident);
    if (!ident) throw bad('И-мэйл хаяг эсвэл утасны дугаараа зөв оруулна уу');
    const name = V.str(b.name, 60).trim(); if (!name) throw bad('Нэрээ оруулна уу');
    const pw = V.password(b.password);
    if (q.userByIdent.get(ident)) throw new HttpError(409, 'Энэ хаяг бүртгэлтэй байна. «Нэвтрэх» дээр дарна уу.', 'exists');
    const hash = await bcrypt.hash(pw, 10), id = 'u_' + rid(10);
    try { q.userInsert.run(id, ident, name, hash, 'user', Date.now(), 0); }
    catch (e) { if (String(e.code).startsWith('SQLITE_CONSTRAINT')) throw new HttpError(409, 'Энэ хаяг бүртгэлтэй байна.', 'exists'); throw e; }
    startSession(req, res, id);
    res.json(pub({ id, name, ident, role: 'user' }));
  });

  api.post('/login', S.limit('login-ip', 40, 900000, ip), json, async (req, res) => {
    const b = req.body || {}, ident = V.ident(b.ident) || '';
    if (!S.hit('login-id:' + ident, 10, 900000)) throw new HttpError(429, 'Хэт олон оролдлоо. 15 минутын дараа дахин оролдоно уу.', 'rate');
    const pw = typeof b.password === 'string' ? b.password.slice(0, 200) : '';
    const row = ident ? q.userByIdent.get(ident) : null;
    const ok = await bcrypt.compare(pw, row ? row.hash : DUMMY);
    if (!row || !ok) throw new HttpError(401, 'Нэвтрэх хаяг эсвэл нууц үг буруу байна', 'login_failed');
    startSession(req, res, row.id);
    res.json(pub(row));
  });

  api.post('/logout', (req, res) => {
    if (req.sid) q.sessDel.run(req.sid);
    S.clearCookie(res, 'sid', cookieOpt(req, 0)); res.json({ ok: true });
  });

  api.post('/password', needUser, S.limit('pw', 10, 3600000, req => req.user.id), json, async (req, res) => {
    const b = req.body || {}, row = q.userById.get(req.user.id);
    if (!(await bcrypt.compare(typeof b.old === 'string' ? b.old.slice(0, 200) : '', row.hash))) throw new HttpError(403, 'Одоогийн нууц үг буруу байна', 'bad_password');
    q.userPass.run(await bcrypt.hash(V.password(b.next), 10), row.id);
    q.sessDelUser.run(row.id, req.sid);               // every other device has to sign in again
    res.json({ ok: true });
  });

  /* ---------- settings, studio items ---------- */
  api.get('/config', (req, res) => {
    const rev = kv.get('rev', 0);
    if (String(req.query.rev) === String(rev)) return res.json({ same: true, rev });
    const main = Object.assign({}, mainCfg());
    if (!req.user) for (const k of V.PRIVATE_MAIN) delete main[k];
    const list = kind => st.items.all(kind).map(r => Object.assign({ id: r.id }, parse(r.data, {})));
    res.json({ rev, main, themes: list('themes'), sounds: list('sounds'), templates: list('templates'), media: list('media') });
  });

  /* ---------- cards (the signed-in customer) ---------- */
  api.get('/mine', needUser, (req, res) => {
    const aps = {}; st.apMine.all(req.user.id).forEach(r => { aps[r.card_id] = apOut(r); });
    res.json(st.mine.all(req.user.id).map(r => ({ id: r.id, to: r.to_name, occ: r.occ, fx: r.fx, at: r.created, free: !!r.free, claim: r.claim || 0, views: r.views, ap: aps[r.id] || null })));
  });

  api.post('/cards', needUser, S.limit('card', 120, 3600000, req => req.user.id), json, (req, res) => {
    const b = req.body || {}, data = V.card(b.card), t = Date.now(), user = req.user;
    const meta = [JSON.stringify(data), (data.to || '').trim().slice(0, 60), data.occ, data.fx];
    if (b.id != null) {
      const id = V.id(b.id, 'ID'), row = st.cardGet.get(id);
      if (!row || row.uid !== user.id) throw new HttpError(404, 'Карт олдсонгүй', 'not_found');
      st.cardUpd.run(...meta, t, id);
      return res.json({ id, free: !!row.free, created: row.created, updated: t });
    }
    if (st.cardCount.get(user.id).n >= MAX_CARDS) throw bad('Хадгалах карт ' + MAX_CARDS + ' хүрсэн. Хуучныг нь устгана уу.');
    let id; do { id = rid(8); } while (st.cardGet.get(id));
    const free = (!mainCfg().payRequired || user.role === 'admin') ? 1 : 0;   // decided here, never by the browser
    st.cardIns.run(id, user.id, ...meta, free, t, t);
    res.json({ id, free: !!free, created: t, updated: t });
  });

  api.post('/cards/:id/claim', needUser, S.limit('claim', 60, 3600000, req => req.user.id), (req, res) => {
    const r = st.cardClaim.run(Date.now(), V.id(req.params.id), req.user.id);
    if (!r.changes) throw new HttpError(404, 'Карт олдсонгүй', 'not_found');
    res.json({ ok: true });
  });

  api.delete('/cards/:id', needUser, (req, res) => {
    const row = st.cardGet.get(V.id(req.params.id));
    if (!row || (row.uid !== req.user.id && req.user.role !== 'admin')) throw new HttpError(404, 'Карт олдсонгүй', 'not_found');
    st.cardDel.run(row.id); res.json({ ok: true });
  });

  /* The link the recipient opens. Nothing but the theme leaves the server until the payment is confirmed. */
  api.get('/card/:uid/:id', (req, res) => {
    const uid = V.id(req.params.uid), id = V.id(req.params.id), row = st.cardGet.get(id);
    if (!row || row.uid !== uid) throw new HttpError(404, 'Карт олдсонгүй', 'not_found');
    const ap = st.apGet.get(id), data = parse(row.data, {});
    const mine = !!req.user && (req.user.id === uid || req.user.role === 'admin');
    const allowed = !!row.free || !mainCfg().payRequired || (ap && ap.st === 'ok');
    if (!mine && !allowed) return res.json({ card: { id, uid, occ: data.occ, theme: data.theme, free: false }, ap: null });
    res.json({
      card: Object.assign(data, { id, uid, free: !!row.free, created: row.created, updated: row.updated }),
      ap: mine ? apOut(ap) : (ap && ap.st === 'ok' ? { st: 'ok' } : null)
    });
  });

  /* who looked: signed-in people by account, everyone else by a random device id in a cookie */
  api.post('/visit', S.limit('visit', 120, 600000, ip), json, (req, res) => {
    const b = req.body || {}, t = Date.now(); let vid;
    if (req.user) vid = req.user.id;
    else {
      vid = req.cookies.vid;
      if (typeof vid !== 'string' || !/^a_[a-z0-9]{12}$/.test(vid)) { vid = 'a_' + rid(12); S.setCookie(res, 'vid', vid, cookieOpt(req, 63072000)); }
    }
    let v = st.visGet.get(vid);
    if (!v) { st.visIns.run(vid, t, t, 0, 0, '[]'); v = { vid, first: t, last: t, n: 0, app_at: 0, v: '[]' }; }
    let { n, app_at } = v, list = parse(v.v, []);
    if (b.o == null && b.c == null) {
      if (t - app_at > 30 * 60000) { n++; app_at = t; }
    } else {
      const owner = V.id(b.o, 'o'), cid = V.id(b.c, 'c'), row = st.cardGet.get(cid);
      if (row && row.uid === owner) {
        const dup = list[0] && list[0].c === cid && t - list[0].t < 60000;
        if (!dup) {
          list.unshift({ t, o: owner, c: cid }); list = list.slice(0, 20);
          if (vid !== owner) st.cardView.run(t, cid);
        }
      }
    }
    st.visUpd.run(t, n, app_at, JSON.stringify(list), vid);
    res.json({ ok: true });
  });

  /* ---------- admin ---------- */
  const adm = express.Router();
  adm.use(needAdmin);

  adm.get('/orders', (req, res) => {
    const aps = {}; st.apAll.all().forEach(r => { aps[r.card_id] = apOut(r); });
    const rows = st.allCards.all(), seen = new Set(), byUser = {};
    const list = rows.map(r => {
      seen.add(r.id);
      const m = { to: r.to_name, occ: r.occ, fx: r.fx, at: r.created, free: !!r.free, claim: r.claim || 0, views: r.views };
      (byUser[r.uid] = byUser[r.uid] || {})[r.id] = m;
      return Object.assign({ uid: r.uid, id: r.id, ref: refCode(r.id), ap: aps[r.id] && aps[r.id].uid === r.uid ? aps[r.id] : null }, m);
    });
    for (const id of Object.keys(aps)) if (!seen.has(id)) list.push({ uid: aps[id].uid, id, ref: refCode(id), to: '(устгагдсан)', at: aps[id].at, gone: true, ap: aps[id] });
    list.sort((a, b) => (b.claim || b.at || 0) - (a.claim || a.at || 0));
    const users = st.usersWithCards.all().map(u => ({ id: u.id, uid: u.id, first: u.created, last: u.last || u.created, cards: byUser[u.id] || {} }));
    res.json({ list, users });
  });

  adm.get('/visitors', (req, res) => {
    res.json(st.visAll.all().map(r => ({ uid: r.vid, first: r.first, last: r.last, n: r.n, v: parse(r.v, []) })));
  });

  adm.post('/names', json, (req, res) => {
    const ids = Array.isArray(req.body && req.body.ids) ? req.body.ids.slice(0, 500) : [], out = {};
    for (const id of ids) {
      if (typeof id !== 'string' || !V.ID.test(id)) continue;
      if (id.startsWith('a_')) out[id] = 'Зочин …' + id.slice(-4);
      else { const u = st.namesOf.get(id); if (u) out[id] = (u.name || 'Нэргүй') + ' · ' + u.ident; }
    }
    res.json(out);
  });

  adm.post('/approve', json, (req, res) => {
    const b = req.body || {}, id = V.id(b.id, 'ID'), uid = V.id(b.uid, 'uid');
    const row = st.cardGet.get(id); if (!row || row.uid !== uid) throw new HttpError(404, 'Карт олдсонгүй', 'not_found');
    if (b.st !== 'ok' && b.st !== 'no') throw bad('Төлөв буруу байна');
    st.apSet.run(id, uid, b.st, Date.now(), V.str(b.note, 200).trim(), Math.round(V.num(b.amt, 0, 100000000, 0)), req.user.id);
    res.json({ ok: true });
  });
  adm.delete('/approve/:id', (req, res) => { st.apDel.run(V.id(req.params.id)); res.json({ ok: true }); });

  adm.put('/main', json, (req, res) => {
    const next = Object.assign({}, mainCfg(), V.mainPatch(req.body && req.body.patch));
    if (next.payRequired && !(next.bank && next.account && next.holder && next.price > 0)) throw bad('Төлбөртэй горимд банк, данс, нэр, үнэ бүгд шаардлагатай');
    kv.set('main', next); bump(); res.json({ ok: true });
  });

  adm.put('/items/:kind/:id', json, (req, res) => {
    const kind = req.params.kind, id = V.id(req.params.id, 'ID');
    const d = V.item(kind, req.body, aid => !!st.assetGet.get(aid));
    st.itemSet.run(kind, id, d.order, JSON.stringify(d)); bump(); res.json({ id });
  });
  adm.delete('/items/:kind/:id', (req, res) => {
    if (!V.KINDS.includes(req.params.kind)) throw bad('Төрөл буруу байна');
    st.itemDel.run(req.params.kind, V.id(req.params.id)); bump(); res.json({ ok: true });
  });

  adm.post('/upload', express.raw({ type: () => true, limit: '21mb' }), (req, res) => {
    const buf = req.body;
    if (!Buffer.isBuffer(buf) || !buf.length) throw bad('Файл хоосон байна');
    const info = sniff(buf); if (!info) throw bad('Зөвхөн PNG, JPG, GIF, WebP зураг болон MP4, WebM видео оруулна');
    if (info.kind === 'image' && buf.length > 6 * 1024 * 1024) throw bad('Зураг 6MB-аас бага байх ёстой');
    if (info.kind === 'video' && buf.length > 20 * 1024 * 1024) throw bad('Видео 20MB-аас бага байх ёстой');
    let id; do { id = rid(16); } while (st.assetGet.get(id));
    fs.writeFileSync(path.join(uploads, id), buf, { flag: 'wx' });
    st.assetIns.run(id, info.mime, buf.length, Date.now());
    res.json({ assetId: id, src: '/_blob/' + id });
  });
  adm.delete('/assets/:id', (req, res) => {
    const id = V.id(req.params.id), a = st.assetGet.get(id);
    if (a) { st.assetDel.run(id); try { fs.unlinkSync(path.join(uploads, id)); } catch (e) { /* already gone */ } }
    res.json({ ok: true });
  });
  api.use('/admin', adm);
  api.use((req, res, next) => next(new HttpError(404, 'Олдсонгүй', 'not_found')));
  app.use('/api', api);

  /* ---------- pages and files ---------- */
  app.get('/healthz', (req, res) => { db.prepare('SELECT 1').get(); res.type('text').send('ok'); });

  app.get('/config.js', (req, res) => {
    res.set({ 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-store' });
    res.send(`window.APP_REST=true;window.APP_BASE=${JSON.stringify(baseOf(req) + '/')};`);
  });

  app.get('/_blob/:id', (req, res, next) => {
    const id = req.params.id, a = V.ID.test(id) ? st.assetGet.get(id) : null;
    if (!a) return next(new HttpError(404, 'Олдсонгүй', 'not_found'));
    res.set({ 'Content-Type': a.mime, 'Cache-Control': 'public, max-age=31536000, immutable', 'Content-Security-Policy': "default-src 'none'; sandbox", 'Cross-Origin-Resource-Policy': 'same-origin' });
    res.sendFile(path.join(uploads, id), { headers: { 'Content-Type': a.mime }, cacheControl: false }, err => { if (err && !res.headersSent) next(new HttpError(404, 'Олдсонгүй', 'not_found')); });
  });

  /* The address people actually share. Chat apps read the preview tags; browsers jump on into the app. */
  app.get('/c/:uid/:id', (req, res) => {
    const uid = V.ID.test(req.params.uid) ? req.params.uid : '', id = V.ID.test(req.params.id) ? req.params.id : '';
    const row = uid && id ? st.cardGet.get(id) : null, base = baseOf(req);
    const name = row && row.uid === uid ? (row.to_name || '').trim() : '';
    const title = name ? name + ', танд мэндчилгээ ирлээ' : 'Танд мэндчилгээ ирлээ';
    const dest = `/#k~${uid}~${id}`;
    res.set({ 'Cache-Control': 'no-cache', 'Referrer-Policy': 'no-referrer' }).type('html').send(`<!doctype html>
<html lang="mn"><head><meta charset="utf-8"><title>${esc(title)}</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta property="og:type" content="website"><meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="Нээгээд хараарай: танд зориулсан хөдөлгөөнт мэндчилгээ.">
<meta property="og:image" content="${esc(base)}/og.jpg"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<meta property="og:url" content="${esc(base)}/c/${esc(uid)}/${esc(id)}"><meta name="twitter:card" content="summary_large_image">
<meta http-equiv="refresh" content="0;url=${esc(dest)}"></head>
<body><p><a href="${esc(dest)}">Мэндчилгээг нээх</a></p></body></html>`);
  });

  const indexFile = path.join(o.publicDir, 'index.html');
  const sendIndex = (req, res, next) => {
    res.set('Cache-Control', 'no-cache');
    res.sendFile(indexFile, err => { if (err) next(new HttpError(500, 'Хуудас бэлэн биш байна. «npm run build» ажиллуулна уу.', 'no_build')); });
  };
  app.get('/', sendIndex);
  app.get('/index.html', sendIndex);
  app.use(express.static(o.publicDir, {
    index: false, dotfiles: 'ignore',
    setHeaders: (res, file) => { res.set('Cache-Control', /\.[0-9a-f]{8}\.(js|css)$/.test(file) ? 'public, max-age=31536000, immutable' : 'public, max-age=3600'); }
  }));

  /* ---------- errors ---------- */
  app.use((req, res, next) => next(new HttpError(404, 'Олдсонгүй', 'not_found')));
  app.use((err, req, res, next) => {          // eslint-disable-line no-unused-vars
    let status = err.status || err.statusCode || 500, msg = err.message, code = err.code || 'error';
    if (err.type === 'entity.too.large') { status = 413; msg = 'Илгээсэн өгөгдөл хэт том байна'; code = 'too_large'; }
    else if (err.type === 'entity.parse.failed') { status = 400; msg = 'Өгөгдөл буруу байна'; code = 'invalid'; }
    else if (!(err instanceof HttpError)) { if (status >= 500) { console.error(err); } else code = 'error'; }
    if (status >= 500) { msg = 'Серверт алдаа гарлаа. Дахин оролдоно уу.'; code = 'server'; }
    if (res.headersSent) return;
    if (req.path.startsWith('/api/')) res.status(status).json({ error: code, message: msg });
    else res.status(status).type('text').send(status === 404 ? 'Олдсонгүй' : msg);
  });

  /* ---------- housekeeping ---------- */
  const sweep = () => { const t = Date.now(); q.sessPrune.run(t); st.visPrune.run(t - 30 * DAY); };
  sweep(); const timer = setInterval(sweep, 3600000); timer.unref();

  return { app, ctx, close() { clearInterval(timer); db.close(); } };
}

module.exports = { createApp, loadEnv };

if (require.main === module) {
  loadEnv(path.join(__dirname, '.env'));
  (async () => {
    const srv = createApp();
    const email = process.env.ADMIN_EMAIL, pass = process.env.ADMIN_PASSWORD;
    if (email && pass && !srv.ctx.q.adminCount.get().n) {
      try { const r = await ensureAdmin(srv.ctx, email, pass, 'Админ'); console.log('Админ үүслээ:', r.ident); }
      catch (e) { console.error('Админ үүсгэж чадсангүй:', e.message); }
    }
    if (!srv.ctx.q.adminCount.get().n) console.warn('Анхаар: админ байхгүй байна. «npm run admin -- ИМЭЙЛ НУУЦ_ҮГ» гэж үүсгэнэ үү.');
    const port = Number(process.env.PORT) || 3000, host = process.env.HOST || '0.0.0.0';
    const server = srv.app.listen(port, host, () => console.log(`Баярын мэнд: http://${host === '0.0.0.0' ? 'localhost' : host}:${port}`));
    const stop = () => { server.close(() => { srv.close(); process.exit(0); }); setTimeout(() => process.exit(0), 5000).unref(); };
    process.on('SIGINT', stop); process.on('SIGTERM', stop);
  })();
}
