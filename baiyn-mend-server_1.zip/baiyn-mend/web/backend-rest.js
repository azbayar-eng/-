/* backend-rest.js — the server build keeps its data on the server (Express + SQLite) and talks to it over /api.
   It offers exactly the same methods as backend-artifact.js, so the rest of the app cannot tell the two apart.
   "Live" views are plain polling: every few seconds while the tab is visible, and straight away after the person's own changes. */
(function () {
'use strict';
const App = window.App, h = App.h;
const noop = App.noop, nav = App.hashNav;

App.restBackend = function () {
  let me = { uid: null, name: '', isAdmin: false, canWrite: false, canUpload: false };
  const refresh = {};                       // name -> function that re-reads that list right now

  async function call(method, url, body, raw) {
    const opt = { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'baiyn' } };
    if (raw) { opt.body = raw.blob; opt.headers['Content-Type'] = raw.type || 'application/octet-stream'; }
    else if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers['Content-Type'] = 'application/json'; }
    let r;
    try { r = await fetch(url, opt); } catch (e) { throw { code: 'unavailable', message: 'Сервертэй холбогдож чадсангүй. Интернэтээ шалгана уу.' }; }
    let j = null; try { j = await r.json(); } catch (e) { /* no body */ }
    if (!r.ok) throw { code: r.status === 401 ? 'unauthenticated' : 'unavailable', status: r.status, message: (j && j.message) || 'Алдаа гарлаа. Дахин оролдоно уу.' };
    return j;
  }
  const missing = e => e && (e.status === 404 || e.status === 400);

  /* call `get` every `ms` while the page is visible; hand the result on only when it changed */
  function poll(name, get, cb, ms) {
    let last = null, busy = false;
    const run = async () => {
      if (busy) return; busy = true;
      try { const d = await get(); const s = JSON.stringify(d); if (s !== last) { last = s; cb(d); } } catch (e) { if (e && e.status === 401 && me.uid) { me.uid = null; location.reload(); } /* otherwise: try again next time */ }
      busy = false;
    };
    refresh[name] = run;
    setInterval(() => { if (!document.hidden) run(); }, ms);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) run(); });
    run();
  }
  const again = (...names) => names.forEach(n => refresh[n] && refresh[n]());
  const done = (v, ...names) => { again(...names); return v; };

  const B = {
    kind: 'rest', nav: nav(),
    visitorsHint: 'Сайтад орсон, мэндчилгээний холбоос нээсэн хүмүүс. Бүртгэлтэй хүн нэр, утас/и-мэйлээрээ, бүртгэлгүй хүн «Зочин» нэрээр харагдана.',
    visitWord: 'орсон',

    async init() {
      try { const u = await call('GET', '/api/me'); me = { uid: u.uid || null, name: u.name || '', isAdmin: !!u.isAdmin, canWrite: !!u.uid, canUpload: !!u.isAdmin }; }
      catch (e) { /* offline: behave as signed out */ }
      return me;
    },

    /* ---- configuration ---- */
    onConfig(cb) {
      let rev = -1;
      poll('cfg', async () => call('GET', '/api/config?rev=' + rev), d => {
        if (d.same) return; rev = d.rev;
        const cfg = App.emptyCfg();
        cfg.main = d.main || {};
        const byOrder = (a, b) => (a.order || 0) - (b.order || 0) || String(a.id).localeCompare(String(b.id));
        ['themes', 'sounds', 'templates'].forEach(k => { cfg[k] = (d[k] || []).sort(byOrder); });
        cfg.media = (d.media || []).map(x => { x.src = x.data || (x.assetId ? '/_blob/' + x.assetId : ''); return x; }).sort(byOrder);
        cb(cfg, true);
      }, 20000);
    },

    /* ---- the signed-in customer ---- */
    onMine(cb) {
      if (!me.uid) { cb([]); return; }
      poll('mine', () => call('GET', '/api/mine'), cb, 8000);
    },
    async saveCard(card) {
      const r = await call('POST', '/api/cards', { id: card.id || undefined, card: App.cardFields(card) });
      return done(r, 'mine', 'orders');
    },
    async getCard(ouid, id) {
      try { return await call('GET', `/api/card/${encodeURIComponent(ouid)}/${encodeURIComponent(id)}`); }
      catch (e) { if (missing(e)) return null; throw e; }
    },
    async claim(id) { return done(await call('POST', `/api/cards/${encodeURIComponent(id)}/claim`), 'mine', 'orders'); },
    async deleteCard(id) { return done(await call('DELETE', `/api/cards/${encodeURIComponent(id)}`), 'mine', 'orders'); },
    /* open = null: this person opened the app. open = {o, c}: this person opened card c of owner o. */
    logVisit(open) { return call('POST', '/api/visit', open ? { o: open.o, c: open.c } : {}).catch(noop); },
    linkFor(card) { const base = window.APP_BASE || (location.origin + '/'); return me.uid && card && card.id ? `${base}c/${me.uid}/${card.id}` : ''; },
    async names(ids) { return ids.length ? call('POST', '/api/admin/names', { ids }) : {}; },
    /* no saveFile: App.saveFile falls back to an ordinary browser download */

    /* ---- the owner ---- */
    onOrders(cb) { poll('orders', () => call('GET', '/api/admin/orders'), d => cb(d.list, d.users), 6000); },
    onVisitors(cb) { poll('visitors', () => call('GET', '/api/admin/visitors'), cb, 12000); },
    async setApproval(ouid, id, st, note, amt) { return done(await call('POST', '/api/admin/approve', { uid: ouid, id, st, note: note || '', amt: amt || 0 }), 'orders'); },
    async clearApproval(id) { return done(await call('DELETE', '/api/admin/approve/' + encodeURIComponent(id)), 'orders'); },
    async saveMain(patch) { return done(await call('PUT', '/api/admin/main', { patch }), 'cfg'); },
    async saveItem(kind, item) {
      const id = item.id || App.newId(), d = Object.assign({}, item); delete d.id; delete d.src;
      await call('PUT', `/api/admin/items/${kind}/${encodeURIComponent(id)}`, d);
      return done(id, 'cfg');
    },
    async deleteItem(kind, id) { return done(await call('DELETE', `/api/admin/items/${kind}/${encodeURIComponent(id)}`), 'cfg'); },
    async upload(blob, type) { return call('POST', '/api/admin/upload', undefined, { blob, type: type || blob.type }); },
    async deleteAsset(id) { if (id) await call('DELETE', '/api/admin/assets/' + encodeURIComponent(id)); },

    /* ---- account: sign in / out, shown in the page header ---- */
    openLogin(mode) { loginDialog(mode); },
    mountAccount(el) {
      el.textContent = '';
      if (me.uid) {
        el.append(h('span', { class: 'nm', text: (me.name || 'Хэрэглэгч') + (me.isAdmin ? ' · Админ' : '') }),
          h('button', { class: 'ghost sm', type: 'button', text: 'Нууц үг', on: { click: passwordDialog } }),
          h('button', { class: 'ghost sm', type: 'button', text: 'Гарах', on: { click: async () => { try { await call('POST', '/api/logout'); } catch (e) { /* ignore */ } location.reload(); } } }));
      } else {
        el.append(h('button', { class: 'ghost sm', type: 'button', text: 'Нэвтрэх', on: { click: () => loginDialog('login') } }));
      }
    },
    reason: 'Холбоос авахын тулд нэвтэрсэн байх шаардлагатай. Одоогоор урьдчилан харах боломжтой.'
  };

  /* ---------- dialogs ---------- */
  function modal(...kids) {
    const m = h('div', { class: 'modal', on: { mousedown: e => { if (e.target === m) m.remove(); } } },
      h('div', { class: 'dlg', role: 'dialog', 'aria-modal': 'true' }, ...kids));
    document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { m.remove(); document.removeEventListener('keydown', esc); } });
    document.body.append(m); return m;
  }

  function loginDialog(mode) {
    let reg = mode === 'register';
    const box = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } });
    const draw = () => {
      const err = h('div', { class: 'stat bad err', role: 'alert', hidden: true });
      const name = h('input', { type: 'text', autocomplete: 'name', maxLength: 60, placeholder: 'Жишээ нь: Азаа' });
      const ident = h('input', { type: 'text', inputMode: 'email', autocomplete: 'username', maxLength: 120, placeholder: 'и-мэйл эсвэл утасны дугаар', 'aria-label': 'И-мэйл эсвэл утасны дугаар' });
      const pw = h('input', { type: 'password', autocomplete: reg ? 'new-password' : 'current-password', maxLength: 200, 'aria-label': 'Нууц үг', placeholder: reg ? 'дор хаяж 8 тэмдэгт' : '' });
      const go = h('button', { class: 'primary', type: 'submit', text: reg ? 'Бүртгүүлэх' : 'Нэвтрэх' });
      const form = h('form', { novalidate: true, on: { submit: async e => {
        e.preventDefault(); err.hidden = true; go.disabled = true;
        try {
          await call('POST', reg ? '/api/register' : '/api/login', reg ? { name: name.value, ident: ident.value, password: pw.value } : { ident: ident.value, password: pw.value });
          location.reload();
        } catch (ex) { err.textContent = ex.message || 'Алдаа гарлаа.'; err.hidden = false; go.disabled = false; }
      } } },
        reg && h('label', {}, 'Нэр', name),
        h('label', {}, 'И-мэйл эсвэл утас', ident),
        h('label', {}, 'Нууц үг', pw),
        err, go);
      box.textContent = '';
      box.append(
        h('div', { class: 'seg', role: 'group' }, [['login', 'Нэвтрэх'], ['register', 'Бүртгүүлэх']].map(([k, t]) =>
          h('button', { class: 'chip', type: 'button', 'aria-pressed': String((k === 'register') === reg), text: t, on: { click: () => { reg = k === 'register'; draw(); } } }))),
        form);
      setTimeout(() => (reg ? name : ident).focus(), 0);
    };
    const m = modal(h('h3', { text: 'Баярын мэнд' }), box, h('div', { class: 'btns' }, h('button', { class: 'ghost', type: 'button', text: 'Хаах', on: { click: () => m.remove() } })));
    draw();
  }

  function passwordDialog() {
    const err = h('div', { class: 'stat bad err', role: 'alert', hidden: true });
    const old = h('input', { type: 'password', autocomplete: 'current-password', maxLength: 200, 'aria-label': 'Одоогийн нууц үг' });
    const nw = h('input', { type: 'password', autocomplete: 'new-password', maxLength: 200, 'aria-label': 'Шинэ нууц үг', placeholder: 'дор хаяж 8 тэмдэгт' });
    const go = h('button', { class: 'primary', type: 'submit', text: 'Солих' });
    const m = modal(h('h3', { text: 'Нууц үг солих' }),
      h('form', { novalidate: true, on: { submit: async e => {
        e.preventDefault(); err.hidden = true; go.disabled = true;
        try { await call('POST', '/api/password', { old: old.value, next: nw.value }); m.remove(); App.toast('Нууц үг солигдлоо.'); }
        catch (ex) { err.textContent = ex.message || 'Алдаа гарлаа.'; err.hidden = false; go.disabled = false; }
      } } }, h('label', {}, 'Одоогийн нууц үг', old), h('label', {}, 'Шинэ нууц үг', nw), err, go),
      h('div', { class: 'btns' }, h('button', { class: 'ghost', type: 'button', text: 'Хаах', on: { click: () => m.remove() } })));
    old.focus();
  }

  return B;
};
})();
