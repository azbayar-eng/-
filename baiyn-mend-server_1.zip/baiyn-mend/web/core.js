/* core.js — shared helpers, config, card <-> render mapping. No backend knowledge in here. */
(function () {
'use strict';
const M = window.Mend;
const App = window.App = { M, backend: null, me: { uid: null, name: '', isAdmin: false, canWrite: false }, S: null, boot: { done: false } };

/* ---------- tiny emitter ---------- */
const subs = {};
App.on = (e, f) => { (subs[e] = subs[e] || []).push(f); };
App.emit = (e, a) => (subs[e] || []).slice().forEach(f => { try { f(a); } catch (err) { console.error(err); } });

/* ---------- DOM ---------- */
App.$ = id => document.getElementById(id);
App.h = function (tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const k in props) {
    const v = props[k];
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k === 'on') { for (const ev in v) e.addEventListener(ev, v[ev]); }
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k === 'for' || k.indexOf('-') > 0 || k === 'role') e.setAttribute(k, v === true ? '' : v);
    else if (k in e) e[k] = v;
    else e.setAttribute(k, v === true ? '' : v);
  }
  kids.flat(2).forEach(c => { if (c == null || c === false) return; e.append(c.nodeType ? c : document.createTextNode(String(c))); });
  return e;
};
const h = App.h;

App.toast = function (msg, ms) {
  let t = App.$('toast');
  if (!t) { t = h('div', { id: 'toast', role: 'status' }); document.body.append(t); }
  t.textContent = msg; t.hidden = false;
  clearTimeout(App.toast.h); App.toast.h = setTimeout(() => { t.hidden = true; }, ms || 3200);
};

/* in-page confirm (native dialogs are not reliable inside the artifact frame) */
App.confirm = function (msg, okText, danger) {
  return new Promise(res => {
    const done = v => { m.remove(); res(v); };
    const m = h('div', { class: 'modal', on: { click: e => { if (e.target === m) done(false); } } },
      h('div', { class: 'dlg', role: 'dialog', 'aria-modal': 'true' },
        h('p', { text: msg }),
        h('div', { class: 'btns' },
          h('button', { class: 'ghost', type: 'button', text: 'Болих', on: { click: () => done(false) } }),
          h('button', { class: danger ? 'danger' : 'primary', type: 'button', text: okText || 'Тийм', on: { click: () => done(true) } }))));
    document.body.append(m);
    m.querySelector('button').focus();
  });
};

App.prompt = function (msg, placeholder, okText) {
  return new Promise(res => {
    const done = v => { m.remove(); res(v); };
    const inp = h('input', { type: 'text', placeholder: placeholder || '', maxLength: 120, 'aria-label': msg, on: { keydown: e => { if (e.key === 'Enter') done(inp.value.trim()); if (e.key === 'Escape') done(null); } } });
    const m = h('div', { class: 'modal', on: { click: e => { if (e.target === m) done(null); } } },
      h('div', { class: 'dlg', role: 'dialog', 'aria-modal': 'true' }, h('p', { text: msg }), inp,
        h('div', { class: 'btns' },
          h('button', { class: 'ghost', type: 'button', text: 'Болих', on: { click: () => done(null) } }),
          h('button', { class: 'primary', type: 'button', text: okText || 'Болсон', on: { click: () => done(inp.value.trim()) } }))));
    document.body.append(m); inp.focus();
  });
};

/* ---------- formatting ---------- */
App.fmtT = ts => { if (!ts) return '—'; const d = new Date(ts), p = n => String(n).padStart(2, '0'); return `${d.getMonth() + 1}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; };
App.fmtMoney = n => (Math.round(n) || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '₮';
App.newId = () => { const a = 'abcdefghjkmnpqrstuvwxyz23456789'; const r = crypto.getRandomValues(new Uint8Array(8)); return Array.from(r, b => a[b % a.length]).join(''); };
App.refCode = id => 'MN-' + String(id).slice(0, 6).toUpperCase();
App.ST = { free: ['Үнэгүй', 'info'], ok: ['Төлөгдсөн', 'ok'], pending: ['Админ шалгаж байна', 'warn'], no: ['Татгалзсан', 'bad'], draft: ['Төлбөр хүлээгдэж байна', 'mute'] };
App.badge = st => { const [t, c] = App.ST[st] || ['—', 'mute']; return h('span', { class: 'badge ' + c, text: t }); };
App.copy = async function (text, okMsg, inputEl) {
  try { await navigator.clipboard.writeText(text); App.toast(okMsg || 'Хуулагдлаа'); }
  catch (e) { if (inputEl) { inputEl.focus(); inputEl.select(); } App.toast('Сонгосон. Хуулж аваарай.'); }
};

/* ---------- canvas ---------- */
App.fit = function (c) {
  const r = c.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = Math.max(1, Math.round(r.width)), hh = Math.max(1, Math.round(r.height));
  const pw = Math.round(w * dpr), ph = Math.round(hh * dpr);
  if (c.width !== pw || c.height !== ph) { c.width = pw; c.height = ph; }
  const ctx = c.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w, h: hh };
};

/* ---------- media elements (cached by source) ---------- */
const mcache = new Map();
App.media = {
  img(src) {
    if (!src) return null; let e = mcache.get(src);
    if (!e) { e = new Image(); e.decoding = 'async'; e.onload = () => App.emit('media'); e.src = src; mcache.set(src, e); }
    return e;
  },
  video(src) {
    if (!src) return null; let e = mcache.get(src);
    if (!e) {
      e = document.createElement('video'); e.muted = true; e.defaultMuted = true; e.loop = true; e.playsInline = true; e.setAttribute('playsinline', ''); e.preload = 'auto';
      e.addEventListener('loadeddata', () => App.emit('media')); e.src = src; mcache.set(src, e);
    }
    return e;
  },
  play(el) { if (el && el.tagName === 'VIDEO') { const p = el.play(); if (p && p.catch) p.catch(() => {}); } },
  pause(el) { if (el && el.tagName === 'VIDEO') el.pause(); }
};

/* A picture from the phone: shrink to fit a document (or an upload) and return a JPEG data URL. */
App.shrink = async function (file, max, targetKB) {
  let bmp;
  try { bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch (e) {
    bmp = await new Promise((res, rej) => { const i = new Image(), u = URL.createObjectURL(file); i.onload = () => { URL.revokeObjectURL(u); res(i); }; i.onerror = () => rej(new Error('bad image')); i.src = u; });
  }
  let sw = bmp.width || bmp.naturalWidth, sh = bmp.height || bmp.naturalHeight, k = Math.min(1, max / Math.max(sw, sh)), url = '', c;
  for (let round = 0; round < 4; round++) {
    c = document.createElement('canvas'); c.width = Math.max(1, Math.round(sw * k)); c.height = Math.max(1, Math.round(sh * k));
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    let q = 0.84; url = c.toDataURL('image/jpeg', q);
    while (url.length * 0.75 > targetKB * 1024 && q > 0.45) { q -= 0.07; url = c.toDataURL('image/jpeg', q); }
    if (url.length * 0.75 <= targetKB * 1024) break;
    k *= 0.8;
  }
  if (bmp.close) bmp.close();
  return { url, w: c.width, h: c.height, kb: Math.round(url.length * 0.75 / 1024) };
};
App.dataUrlToBlob = function (u) {
  const [head, b64] = u.split(','), mime = (/data:([^;]+)/.exec(head) || [])[1] || 'application/octet-stream';
  const bin = atob(b64), arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
};
App.fileToB64 = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(f); });

/* ---------- configuration (live, from the backend) ---------- */
App.DEFAULT_MAIN = { payRequired: false, price: 5000, bank: '', account: '', holder: '', note: '', offFx: [], offThemes: [], offOcc: [], sfx: {} };
App.emptyCfg = () => ({ main: Object.assign({}, App.DEFAULT_MAIN), themes: [], sounds: [], media: [], templates: [] });
App.cfg = App.emptyCfg();
App.applyConfig = function (cfg) {
  cfg.main = Object.assign({}, App.DEFAULT_MAIN, cfg.main || {});
  ['offFx', 'offThemes', 'offOcc'].forEach(k => { if (!Array.isArray(cfg.main[k])) cfg.main[k] = []; });
  if (!cfg.main.sfx || typeof cfg.main.sfx !== 'object') cfg.main.sfx = {};
  cfg.templates = M.BUILTIN_TPL.concat((cfg.templates || []).filter(t => !t.builtin));
  App.cfg = cfg;
  cfg.themes.forEach(t => { try { M.registerTheme(t.id, M.buildTheme(t)); } catch (e) { /* bad colours: skip */ } });
  M.Sound.setLibrary(cfg.sounds); M.Sound.setMap(cfg.main.sfx);
  M.resetTextCache();
  App.emit('config', cfg);
};
App.payReady = () => { const m = App.cfg.main; return !!(m.bank && m.account && m.holder && m.price > 0); };
App.occIds = () => M.OCC_ORDER.filter(o => !App.cfg.main.offOcc.includes(o));
App.fxIds = occ => M.occFx(occ).filter(f => !App.cfg.main.offFx.includes(f));
App.themeList = occ => {
  const hs = M.HALLOWEEN_THEMES || [], order = occ === 'halloween' ? M.THEME_ORDER : M.THEME_ORDER.filter(t => !hs.includes(t)).concat(hs);
  return order.filter(t => M.THEMES[t] && !App.cfg.main.offThemes.includes(t)).map(id => ({ id, name: M.THEMES[id].name }))
    .concat(App.cfg.themes.map(t => ({ id: t.id, name: t.name || 'Өнгө', custom: true })));
};
App.mediaList = role => App.cfg.media.filter(m => m.role === role);
App.mediaById = id => App.cfg.media.find(m => m.id === id) || null;
App.soundList = () => Object.keys(M.PRESETS).map(id => ({ id, name: M.PRESETS[id].name })).concat(App.cfg.sounds.map(s => ({ id: s.id, name: s.name + (s.file ? ' (файл)' : ''), custom: true })));

/* ---------- card model ---------- */
/* card = {id, occ, fx, theme, themeDef?, to, from, title, msg, photo, photoMode, bg, sticker, sfx, free, created, updated} */
App.blankCard = function (occ) {
  occ = occ || App.occIds()[0] || 'bday';
  const o = M.OCC[occ];
  return { id: null, occ, fx: App.fxIds(occ)[0], theme: o.theme, to: '', from: '', title: '', msg: '', photo: null, photoMode: 'circle', bg: null, sticker: null, sfx: null };
};
App.CARD_KEYS = ['occ', 'fx', 'theme', 'themeDef', 'motif', 'to', 'from', 'title', 'msg', 'photo', 'photoMode', 'bg', 'sticker', 'sfx'];
App.cardFields = c => { const o = {}; App.CARD_KEYS.forEach(k => { if (c[k] != null) o[k] = c[k]; }); return o; };
App.themeDefOf = id => { const t = App.cfg.themes.find(x => x.id === id); return t ? { name: t.name, bg0: t.bg0, bg1: t.bg1, glow: t.glow, ink: t.ink, a: t.a, b: t.b, c: t.c } : null; };
App.toR = function (c) {
  const o = M.OCC[c.occ] || M.OCC.other;
  if (c.themeDef && !M.THEMES[c.theme]) { try { M.registerTheme(c.theme, M.buildTheme(c.themeDef)); } catch (e) { /* ignore */ } }
  const bgM = c.bg && App.mediaById(c.bg), stM = c.sticker && App.mediaById(c.sticker);
  let photoEl = c.photo ? App.media.img(c.photo) : null, bgEl = null;
  if (photoEl && c.photoMode === 'bg') { bgEl = photoEl; photoEl = null; }
  else if (bgM) bgEl = bgM.kind === 'video' ? App.media.video(bgM.src) : App.media.img(bgM.src);
  return {
    occ: c.occ, motif: c.motif || null, fx: M.FXS[c.fx] ? c.fx : 'confetti', theme: M.THEMES[c.theme] ? c.theme : o.theme,
    name: (c.to || '').trim() || 'Найз минь', title: (c.title || '').trim() || o.title, msg: (c.msg || '').trim() || o.msg, from: (c.from || '').trim(),
    photoEl, bgEl, stickerEl: stM && stM.kind !== 'video' ? App.media.img(stM.src) : null, sfx: c.sfx || null
  };
};

/* ---------- links ---------- */
function decodeLegacy(tok) {
  try {
    let b = tok.replace(/-/g, '+').replace(/_/g, '/'); while (b.length % 4) b += '=';
    const bin = atob(b), bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
    const a = JSON.parse(new TextDecoder().decode(bytes));
    if (!Array.isArray(a) || a[0] !== 1) return null;
    const occ = M.OCC_IDS[a[1]], fx = M.FX_IDS[a[2]], theme = M.THEME_IDS[a[3]]; if (!occ || !fx || !theme) return null;
    const str = (v, n) => typeof v === 'string' ? v.slice(0, n) : '';
    return { occ, fx, theme, to: str(a[4], 24), from: str(a[5], 24), msg: str(a[6], 200), title: str(a[7], 40), free: true };
  } catch (e) { return null; }
}
/* What the address bar asks for: {type:'card',uid,id} | {type:'legacy',card} | null */
App.parseHash = function () {
  const s = (location.hash || '').replace(/^#/, '');
  if (s.startsWith('k~')) { const p = s.split('~'); if (p[1] && p[2]) return { type: 'card', uid: p[1], id: p[2] }; return null; }
  const d = s && decodeLegacy(s); return d ? { type: 'legacy', card: d } : null;
};

/* ---------- save a picture / file ---------- */
App.saveFile = async function (name, blob) {
  if (App.backend && App.backend.saveFile) return App.backend.saveFile(name, blob);
  const a = h('a', { href: URL.createObjectURL(blob), download: name }); document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  return 'saved';
};
App.renderPng = async function (card) {
  if (document.fonts && document.fonts.ready) await document.fonts.ready;
  const c = document.createElement('canvas'); c.width = 1000; c.height = 1600;
  const R = App.toR(card); M.resetTextCache();
  M.render(c.getContext('2d'), 1000, 1600, M.FINAL_T[R.fx], R); M.resetTextCache();
  return new Promise(r => c.toBlob(r, 'image/png'));
};

/* thumbnails: draw a card state onto a small canvas */
App.thumbDraw = function (canvas, card, fx) {
  const { ctx, w, h: hh } = App.fit(canvas); if (w < 8) return;
  const R = App.toR(card); if (fx) R.fx = fx;
  M.render(ctx, w, hh, M.THUMB_T[R.fx] || 1, R);
};

/* ---------- views ---------- */
App.views = {};
App.show = function (name) {
  App.view = name;
  Object.keys(App.views).forEach(k => { const el = App.$('v-' + k); if (el) el.hidden = k !== name; });
  document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', String(b.dataset.v === name)));
  const v = App.views[name]; if (v && v.enter) v.enter();
  window.scrollTo(0, 0);
};
})();
