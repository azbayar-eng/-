/* admin.js — the owner's panel: dashboard, orders, visitors, settings. The studio lives in studio.js. */
(function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$;
const A = App.A = { sub: 'dash', studio: 'themes', orders: [], users: [], visitors: [], names: {}, flt: 'pending', q: '', d: {}, started: false, busy: new Set() };

/* ---------- small form helpers (inputs bound to a draft object, so a re-render never loses typing) ---------- */
App.ui = {
  panel: (title, ...kids) => h('div', { class: 'panel' }, title && h('h3', { text: title }), ...kids),
  field(label, input, o) { o = o || {}; return h('label', { class: o.wide ? 'wide' : '' }, h('span', {}, label, o.hint && h('small', { text: o.hint })), input); },
  tin(obj, key, props) { return h('input', Object.assign({ type: 'text', value: obj[key] == null ? '' : obj[key], on: { input: e => { obj[key] = e.target.value; if (props && props.onInput) props.onInput(); } } }, props && { placeholder: props.placeholder, maxLength: props.maxLength, id: props.id })); },
  nin(obj, key, props) { return h('input', { type: 'number', min: (props && props.min) || 0, step: (props && props.step) || 1, value: obj[key] == null ? '' : obj[key], inputMode: 'numeric', on: { input: e => { obj[key] = e.target.value === '' ? '' : Number(e.target.value); } } }); },
  sel(obj, key, opts, props) {
    const s = h('select', { on: { change: e => { obj[key] = e.target.value; if (props && props.onChange) props.onChange(e.target.value); } } }, opts.map(([v, t]) => h('option', { value: v, text: t, selected: String(obj[key] == null ? '' : obj[key]) === String(v) })));
    return s;
  },
  chk(label, checked, on) { return h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!checked, on: { change: e => on(e.target.checked) } }), h('span', { text: label })); },
  busy(key, fn) { return async (...a) => { if (A.busy.has(key)) return; A.busy.add(key); try { return await fn(...a); } catch (e) { App.toast(failMsg(e), 5000); } finally { A.busy.delete(key); } }; }
};
const U = App.ui;
function failMsg(e) {
  const c = e && e.code;
  if (c === 'invalid_argument' || c === 'not_granted') return 'Таны эрх хүрэхгүй байна. Зөвхөн админ (Editor) өөрчилж чадна.';
  if (c === 'quota_exceeded' || c === 'quota_or_state') return 'Хадгалах багтаамж дүүрсэн байна.';
  if (c === 'too_large') return 'Файл хэт том байна.';
  if (c === 'unsupported_type') return 'Энэ төрлийн файл дэмжигдэхгүй.';
  return (e && e.message && e.code === 'unavailable') ? e.message : 'Хадгалж чадсангүй. Дахин оролдоно уу.';
}
App.failMsg = failMsg;

/* ---------- names (opaque ids -> display names, resolved at render time) ---------- */
const nm = uid => A.names[uid] || 'Нэргүй хэрэглэгч';
async function resolveNames() {
  const ids = new Set(); A.orders.forEach(o => o.uid && ids.add(o.uid)); A.visitors.forEach(v => { ids.add(v.uid); (v.v || []).forEach(x => x.o && ids.add(x.o)); });
  const miss = [...ids].filter(i => !(i in A.names)); if (!miss.length) return;
  try { const r = await App.backend.names(miss); miss.forEach(i => { A.names[i] = r[i] || ''; }); rerender(['orders', 'visitors', 'dash']); } catch (e) { /* names stay generic */ }
}

/* ---------- data ---------- */
const stOf = o => o.gone ? 'ok' : App.statusOf(o, o.ap);
const money = () => A.orders.filter(o => o.ap && o.ap.st === 'ok').reduce((s, o) => s + (Number(o.ap.amt) || 0), 0);
const pendingList = () => A.orders.filter(o => stOf(o) === 'pending');
function rerender(subs) { if (App.view === 'admin' && (!subs || subs.includes(A.sub))) render(); }
function updateBadge() {
  const n = pendingList().length, tab = document.querySelector('.tab[data-v="admin"]'); if (!tab) return;
  let d = tab.querySelector('.dot'); if (!n) { if (d) d.remove(); return; }
  if (!d) { d = h('span', { class: 'dot' }); tab.append(d); } d.textContent = String(n);
}

/* ---------- order actions ---------- */
const approve = U.busy('act', async o => { await App.backend.setApproval(o.uid, o.id, 'ok', '', Number(App.cfg.main.price) || 0); App.toast('Баталгаажлаа. Холбоос нээгдлээ.'); });
const reject = U.busy('act', async o => { const note = await App.prompt('Татгалзах шалтгаан (захиалагчид харагдана):', 'Жишээ нь: шилжүүлэг ирээгүй', 'Татгалзах'); if (note === null) return; await App.backend.setApproval(o.uid, o.id, 'no', note, 0); App.toast('Татгалзлаа.'); });
const undo = U.busy('act', async o => { if (!(await App.confirm('Баталгаажуулалтыг цуцлах уу? Холбоос дахин хаагдана.', 'Цуцлах', true))) return; await App.backend.clearApproval(o.id); App.toast('Цуцлагдлаа.'); });
const viewCard = U.busy('view', async o => {
  const r = await App.backend.getCard(o.uid, o.id); if (!r) { App.toast('Карт олдсонгүй.'); return; }
  App.openViewer({ card: r.card, test: true, back: 'admin' });
});

function orderRow(o) {
  const stt = stOf(o), canv = h('canvas', { 'aria-hidden': 'true' }), isMe = o.uid === App.me.uid;
  const acts = [];
  if (!o.gone) acts.push(h('button', { class: 'ghost sm', type: 'button', text: 'Харах', on: { click: () => viewCard(o) } }));
  if (stt === 'pending' || stt === 'no' || stt === 'draft') acts.push(h('button', { class: 'okbtn', type: 'button', text: stt === 'draft' ? 'Гараар батлах' : 'Батлах', on: { click: () => approve(o) } }));
  if (stt === 'pending') acts.push(h('button', { class: 'danger', type: 'button', text: 'Татгалзах', on: { click: () => reject(o) } }));
  if (o.ap && o.ap.st === 'ok') acts.push(h('button', { class: 'ghost sm', type: 'button', text: 'Цуцлах', on: { click: () => undo(o) } }));
  const row = h('div', { class: 'row', 'data-id': o.id },
    canv,
    h('div', { class: 'grow' },
      h('div', { class: 't', text: (o.to || 'Нэргүй') + ' · ' + (M.OCC[o.occ] ? M.OCC[o.occ].name : '—') }),
      h('div', { class: 's', text: 'Захиалагч: ' + (isMe ? 'та өөрөө' : nm(o.uid)) + ' · ' + (M.FXS[o.fx] ? M.FXS[o.fx].name : '—') + ' · ' + App.fmtT(o.claim || o.at) }),
      h('div', { class: 's', text: 'Утга: ' + o.ref + (o.ap && o.ap.st === 'ok' ? ' · ' + App.fmtMoney(o.ap.amt) : '') + (o.ap && o.ap.st === 'no' && o.ap.note ? ' · «' + o.ap.note + '»' : '') })),
    App.badge(stt), h('div', { class: 'acts' }, acts));
  requestAnimationFrame(() => App.thumbDraw(canv, { occ: o.occ, fx: o.fx, theme: (M.OCC[o.occ] || M.OCC.other).theme, to: o.to || 'Нэр' }, o.fx));
  return row;
}

/* ---------- sections ---------- */
function dash() {
  const m = App.cfg.main, pend = pendingList(), cards = A.orders.filter(o => !o.gone).length;
  const tile = (v, l) => h('div', { class: 'tile' }, h('b', { text: String(v) }), h('span', { text: l }));
  const go = (sub, studio) => () => { A.sub = sub; if (studio) A.studio = studio; render(); };
  const step = (done, text, btn, fn) => h('li', {}, h('span', { class: 'b' + (done ? ' done' : ''), text: done ? '✓' : '·' }), h('span', { style: { flex: '1' } }, text), !done && btn && h('button', { class: 'ghost sm', type: 'button', text: btn, on: { click: fn } }));
  const out = [
    h('div', { class: 'tiles' }, tile(App.fmtMoney(money()), 'Нийт орлого'), tile(pend.length, 'Шалгах төлбөр'), tile(cards, 'Мэндчилгээ'), tile(A.visitors.length, 'Хандсан хүн')),
    U.panel('Эхлэх алхмууд', h('ul', { class: 'checklist' },
      step(App.payReady(), 'Банкны данс, үнээ оруулах', 'Тохиргоо', go('settings')),
      step(!!m.payRequired, 'Төлбөртэй горимыг асаах (одоо: ' + (m.payRequired ? 'төлбөртэй' : 'үнэгүй') + ')', 'Асаах', go('settings')),
      step(App.cfg.themes.length > 0, 'Өөрийн өнгө нэмэх', 'Студи', go('studio', 'themes')),
      step(App.cfg.media.length > 0, 'Арын зураг, видео оруулах', 'Студи', go('studio', 'media')),
      step(App.cfg.templates.length > 0, 'Бэлэн загвар үүсгэх', 'Студи', go('studio', 'tpl')))),
    U.panel('Шалгах төлбөр', pend.length ? h('div', { class: 'rows' }, pend.slice(0, 5).map(orderRow)) : h('p', { class: 'hint', text: 'Одоогоор шалгах төлбөр алга.' }),
      pend.length > 5 && h('p', { style: { marginTop: '10px' } }, h('button', { class: 'ghost sm', type: 'button', text: 'Бүгдийг харах (' + pend.length + ')', on: { click: () => { A.flt = 'pending'; A.sub = 'orders'; render(); } } }))),
    U.panel('Сүүлд хандсан', A.visitors.length ? h('div', { class: 'rows' }, [...A.visitors].sort((a, b) => (b.last || 0) - (a.last || 0)).slice(0, 5).map(visitorRow)) : h('p', { class: 'hint', text: 'Одоогоор хандсан хүн алга.' }))
  ];
  return out;
}

const FILTERS = [['pending', 'Шалгах'], ['ok', 'Төлөгдсөн'], ['no', 'Татгалзсан'], ['draft', 'Төлбөр хүлээгдэж буй'], ['free', 'Үнэгүй'], ['all', 'Бүгд']];
function orders() {
  const cnt = k => k === 'all' ? A.orders.length : A.orders.filter(o => stOf(o) === k).length;
  const list = A.orders.filter(o => A.flt === 'all' || stOf(o) === A.flt);
  return [
    h('div', { class: 'chips', style: { marginBottom: '16px' }, role: 'group', 'aria-label': 'Шүүлтүүр' }, FILTERS.map(([k, t]) => h('button', { class: 'chip', type: 'button', 'aria-pressed': String(A.flt === k), text: t + ' (' + cnt(k) + ')', on: { click: () => { A.flt = k; render(); } } }))),
    list.length ? h('div', { class: 'rows' }, list.map(orderRow)) : h('div', { class: 'empty', text: 'Энэ ангилалд захиалга алга.' })
  ];
}

function visitorRow(v) {
  const idx = {}; A.users.forEach(u => Object.keys(u.cards || {}).forEach(id => { idx[id] = Object.assign({ uid: u.uid || u.id }, u.cards[id]); }));
  const own = A.users.find(u => (u.uid || u.id) === v.uid), ownN = own ? Object.keys(own.cards || {}).length : 0;
  const opens = (v.v || []).slice(0, 4).map(x => { const c = idx[x.c]; return (c ? '«' + (c.to || 'Нэргүй') + '»' : 'устгагдсан карт') + ' (' + (x.o === v.uid ? 'өөрийнх' : nm(x.o)) + ') ' + App.fmtT(x.t); });
  return h('div', { class: 'row' },
    h('div', { class: 'grow' },
      h('div', { class: 't', text: v.uid === App.me.uid ? 'Та өөрөө' : nm(v.uid) }),
      h('div', { class: 's', text: 'Анх: ' + App.fmtT(v.first) + ' · Сүүлд: ' + App.fmtT(v.last) + ' · ' + (v.n || 0) + ' удаа ' + (App.backend.visitWord || 'нэвтэрсэн') + (ownN ? ' · ' + ownN + ' карт хийсэн' : '') }),
      opens.length > 0 && h('div', { class: 's', text: 'Нээсэн: ' + opens.join(' · ') })));
}
function visitors() {
  const q = A.q.trim().toLowerCase();
  const list = [...A.visitors].filter(v => !q || nm(v.uid).toLowerCase().includes(q)).sort((a, b) => (b.last || 0) - (a.last || 0));
  return [
    h('p', { class: 'hint', style: { marginBottom: '12px' }, text: App.backend.visitorsHint || 'Энэ хуудсыг нээсэн, холбоос дээр дарсан нэвтэрсэн хүмүүс. Хүн бүрийн нэр claude.ai-ийн бүртгэлээс харагдана.' }),
    h('input', { class: 'search', type: 'search', placeholder: 'Нэрээр хайх', 'aria-label': 'Нэрээр хайх', value: A.q, on: { input: e => { A.q = e.target.value; const keep = e.target.selectionStart; render(); const i = $('v-admin').querySelector('.search'); if (i) { i.focus(); i.setSelectionRange(keep, keep); } } } }),
    list.length ? h('div', { class: 'rows' }, list.map(visitorRow)) : h('div', { class: 'empty', text: 'Хандсан хүн олдсонгүй.' })
  ];
}

function settings() {
  const m = App.cfg.main;
  const d = A.d.pay = A.d.pay || { payRequired: !!m.payRequired, price: m.price, bank: m.bank, account: m.account, holder: m.holder, note: m.note };
  const av = A.d.av = A.d.av || { offOcc: [...m.offOcc], offFx: [...m.offFx], offThemes: [...m.offThemes] };
  const ready = () => !!(d.bank && d.account && d.holder && Number(d.price) > 0);
  const savePay = U.busy('savePay', async () => {
    if (d.payRequired && !ready()) { App.toast('Төлбөртэй горимд банк, данс, нэр, үнэ бүгд шаардлагатай.'); return; }
    await App.backend.saveMain({ payRequired: !!d.payRequired, price: Number(d.price) || 0, bank: (d.bank || '').trim(), account: (d.account || '').trim(), holder: (d.holder || '').trim(), note: (d.note || '').trim() });
    A.d.pay = null; App.toast('Төлбөрийн тохиргоо хадгалагдлаа.');
  });
  const saveAv = U.busy('saveAv', async () => { await App.backend.saveMain({ offOcc: av.offOcc, offFx: av.offFx, offThemes: av.offThemes }); A.d.av = null; App.toast('Хадгалагдлаа.'); });
  const toggle = (arr, id) => on => { const i = arr.indexOf(id); if (on && i >= 0) arr.splice(i, 1); if (!on && i < 0) arr.push(id); };
  const group = (title, ids, name, arr) => h('div', {}, h('div', { class: 'sub', text: title }), h('div', { class: 'checks' }, ids.map(id => U.chk(name(id), !arr.includes(id), toggle(arr, id)))));
  const payChk = h('input', { type: 'checkbox', checked: !!d.payRequired, on: { change: e => { if (e.target.checked && !ready()) { e.target.checked = false; App.toast('Эхлээд банк, данс, нэр, үнийг бөглөнө үү.'); return; } d.payRequired = e.target.checked; } } });
  return [
    U.panel('Төлбөр (банкны шилжүүлэг, гараар баталгаажуулна)',
      h('div', { class: 'frm' },
        h('label', { class: 'check wide' }, payChk, h('span', { text: 'Төлбөртэй горим: холбоос авахын өмнө төлбөр шаардана' })),
        U.field('Үнэ (₮)', U.nin(d, 'price', { min: 0, step: 100 })),
        U.field('Банкны нэр', U.tin(d, 'bank', { placeholder: 'Жишээ нь: Хаан банк', maxLength: 40 })),
        U.field('Дансны дугаар', U.tin(d, 'account', { maxLength: 40 })),
        U.field('Хүлээн авагчийн нэр', U.tin(d, 'holder', { maxLength: 60 })),
        U.field('Нэмэлт тайлбар', U.tin(d, 'note', { placeholder: 'Жишээ нь: Шилжүүлсний дараа «Төлсөн» товчийг дарна', maxLength: 140 }), { wide: true, hint: 'заавал биш' })),
      h('p', { class: 'hint', style: { margin: '12px 0' }, text: 'Захиалагч шилжүүлэг хийгээд «Төлсөн» дарахад «Захиалга» хэсэгт шалгах жагсаалтад гарна. Та банкаа шалгаад «Батлах» дарна. Түүнээс хойш холбоос нээгдэнэ. Энэ хувилбар мөнгө хөдөлгөдөггүй.' }),
      h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: savePay } })),
    U.panel('Хэрэглэгчид юу харагдах вэ',
      h('p', { class: 'hint', style: { marginBottom: '8px' }, text: 'Тэмдэглэгдсэн зүйл л хэрэглэгчийн сонголтод гарна. Илгээгдсэн картууд өөрчлөлтөд нөлөөлөхгүй.' }),
      group('Баярууд', M.OCC_IDS, id => M.OCC[id].name, av.offOcc),
      group('Хөдөлгөөн', M.FX_IDS, id => M.FXS[id].name + (M.FXS[id].scare ? ' (айлгана)' : ''), av.offFx),
      group('Үндсэн өнгө', M.THEME_IDS, id => M.THEMES[id].name, av.offThemes),
      h('p', { style: { marginTop: '14px' } }, h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveAv } })))
  ];
}

/* ---------- chrome ---------- */
const SUBS = [['dash', 'Самбар'], ['orders', 'Захиалга'], ['visitors', 'Хандсан хүмүүс'], ['settings', 'Тохиргоо'], ['studio', 'Студи']];
function render() {
  const root = $('v-admin'); if (!root) return;
  const body = h('div', {});
  const f = { dash, orders, visitors, settings, studio: () => App.renderStudio() }[A.sub];
  let kids; try { kids = f(); } catch (e) { console.error(e); kids = [h('div', { class: 'stat bad', text: 'Алдаа гарлаа: ' + e.message })]; }
  body.append(...[].concat(kids));
  const pn = pendingList().length;
  const bar = h('div', { class: 'sub-tabs', role: 'tablist' }, SUBS.map(([k, t]) => h('button', { class: 'chip', type: 'button', role: 'tab', 'aria-pressed': String(A.sub === k), text: t + (k === 'orders' && pn ? ' (' + pn + ')' : ''), on: { click: () => { A.sub = k; render(); window.scrollTo(0, 0); } } })));
  const keepScroll = window.scrollY;
  root.textContent = ''; root.append(bar, body);
  window.scrollTo(0, keepScroll);
}
App.adminRender = render;
App.views.admin = { enter() { render(); } };
App.initAdmin = function () {
  if (A.started) return; A.started = true;
  App.backend.onOrders((list, users) => { A.orders = list; A.users = users || []; updateBadge(); resolveNames(); rerender(['dash', 'orders', 'visitors']); });
  App.backend.onVisitors(list => { A.visitors = list; resolveNames(); rerender(['dash', 'visitors']); });
  App.on('config', () => { updateBadge(); rerender(['dash', 'settings', 'studio']); });
};
})();
