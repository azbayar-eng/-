/* maker.js — build a card, pay, get the link. Also "Миний картууд". */
(function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$;
let S = App.S = App.blankCard();
let mine = [], snapshot = '', busy = false, uploading = false;
const pv = { t0: performance.now(), playing: true };
const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
if (reduce) pv.playing = false;
const fieldsOf = () => JSON.stringify(App.cardFields(S));
const entryOf = () => (S.id ? mine.find(x => x.id === S.id) : null) || null;

/* ---------- build ---------- */
function build() {
  const root = $('v-make');
  root.append(
    h('p', { class: 'lead', text: 'Нэрийг нь бичиж, загвараа сонгоод холбоосыг нь илгээ. Хүлээн авсан хүн нээхэд салют буудаж, цэцэг сарнина, эсвэл аалз, сүнс гэнэт гарч ирж айлгана.' }),
    h('div', { class: 'maker' },
      h('section', { class: 'b-tpl', id: 'sec-tpl', hidden: true, 'aria-labelledby': 'h-tpl' }, h('h2', { id: 'h-tpl', text: 'Бэлэн загвар' }), h('div', { id: 'tplThumbs', class: 'thumbs tpl' })),
      h('section', { class: 'b-occ', 'aria-labelledby': 'h-occ' }, h('h2', { id: 'h-occ' }, h('span', { class: 'n', text: '1' }), 'Ямар баяр вэ?'), h('div', { id: 'chips', class: 'chips', role: 'radiogroup', 'aria-labelledby': 'h-occ' })),
      h('section', { class: 'b-text', 'aria-labelledby': 'h-text' }, h('h2', { id: 'h-text' }, h('span', { class: 'n', text: '2' }), 'Хэнд, юу гэж бичих вэ?'),
        h('div', { class: 'fields' },
          h('label', { for: 'toName' }, 'Хэнд', h('input', { id: 'toName', type: 'text', maxLength: 24, placeholder: 'Жишээ нь: Болд', autocomplete: 'off' })),
          h('label', { for: 'fromName' }, 'Таны нэр', h('input', { id: 'fromName', type: 'text', maxLength: 24, placeholder: 'Жишээ нь: Азаа', autocomplete: 'off' })),
          h('label', { class: 'wide', for: 'titleIn' }, h('span', {}, 'Гарчиг', h('small', { text: 'заавал биш' })), h('input', { id: 'titleIn', type: 'text', maxLength: 40, autocomplete: 'off' })),
          h('label', { class: 'wide', for: 'msgIn' }, h('span', {}, 'Мэндчилгээний үг', h('small', { text: 'заавал биш' })), h('textarea', { id: 'msgIn', rows: 3, maxLength: 160 }), h('span', { class: 'count', id: 'msgCount' })))),
      h('section', { class: 'b-photo', 'aria-labelledby': 'h-photo' }, h('h2', { id: 'h-photo' }, h('span', { class: 'n', text: '3' }), 'Зураг нэмэх', h('small', { class: 'hint', text: 'заавал биш' })),
        h('div', { class: 'photo-row' },
          h('div', { class: 'ph-prev', id: 'phPrev', text: 'Зураг алга' }),
          h('div', { style: { flex: '1 1 220px', display: 'flex', flexDirection: 'column', gap: '10px', minWidth: 0 } },
            h('p', { class: 'hint', text: 'Утсаараа зураг авах эсвэл галерейгаас сонгоно. Зураг мэндчилгээний голд гарна.' }),
            h('div', { class: 'ph-btns' },
              h('label', { class: 'ghost file-btn', id: 'phPick' }, h('span', { id: 'phPickT', text: 'Зураг сонгох' }), h('input', { id: 'phFile', type: 'file', accept: 'image/*', 'aria-label': 'Зураг сонгох' })),
              h('button', { class: 'ghost', id: 'phDel', type: 'button', text: 'Устгах', hidden: true })),
            h('div', { class: 'chips', id: 'phMode', hidden: true, role: 'radiogroup', 'aria-label': 'Зургийн байрлал' },
              ...[['circle', 'Дугуй хүрээнд'], ['bg', 'Бүтэн арын зураг']].map(([v, t]) => h('button', { class: 'chip', type: 'button', role: 'radio', 'data-m': v, text: t, on: { click: () => { S.photoMode = v; changed(); } } })))))),
      h('div', { class: 'stage' },
        h('section', { class: 'pv', 'aria-label': 'Урьдчилан харах' },
          h('div', { class: 'cardbox' }, h('canvas', { id: 'pvCanvas', role: 'img', 'aria-label': 'Мэндчилгээний урьдчилсан харагдац' })),
          h('div', { class: 'pvbtns' },
            h('button', { id: 'replay', class: 'ghost', type: 'button', text: 'Дахин тоглуулах', on: { click: () => { pv.t0 = performance.now(); pv.playing = true; } } }),
            h('button', { id: 'testBtn', class: 'ghost', type: 'button', text: 'Хүлээн авагчийн нүдээр үзэх', on: { click: () => App.openViewer({ card: Object.assign({}, S), test: true }) } }))),
        h('section', { class: 'send', id: 'send', 'aria-labelledby': 'h-send' })),
      h('section', { class: 'b-design', 'aria-labelledby': 'h-design' }, h('h2', { id: 'h-design' }, h('span', { class: 'n', text: '4' }), 'Хөдөлгөөнөө сонго'), h('div', { id: 'thumbs', class: 'thumbs' })),
      h('section', { class: 'b-color', 'aria-labelledby': 'h-color' }, h('h2', { id: 'h-color' }, h('span', { class: 'n', text: '5' }), 'Өнгө'), h('div', { id: 'swatches', class: 'swatches' })),
      h('section', { class: 'b-extra', id: 'sec-extra', hidden: true, 'aria-labelledby': 'h-extra' }, h('h2', { id: 'h-extra' }, h('span', { class: 'n', text: '6' }), 'Дүрс, дэвсгэр, наалт'), h('div', { id: 'extra' }))));

  $('toName').addEventListener('input', e => { S.to = e.target.value; changed(); });
  $('fromName').addEventListener('input', e => { S.from = e.target.value; try { localStorage.setItem('mend.from', e.target.value); } catch (err) { /* private mode */ } changed(); });
  $('titleIn').addEventListener('input', e => { S.title = e.target.value; changed(); });
  $('msgIn').addEventListener('input', e => { S.msg = e.target.value; changed(); });
  $('phFile').addEventListener('change', async e => { const f = e.target.files && e.target.files[0]; e.target.value = ''; await onPhoto(f); });
  $('phDel').addEventListener('click', () => { S.photo = null; changed(); });
  try { const f = localStorage.getItem('mend.from'); if (f) { S.from = f.slice(0, 24); $('fromName').value = S.from; } } catch (e) { /* ignore */ }
}

async function onPhoto(f) {
  if (!f) return;
  if (!/^image\//.test(f.type) && !/\.(jpe?g|png|webp|heic|heif|gif)$/i.test(f.name || '')) { App.toast('Зураг сонгоно уу.'); return; }
  uploading = true; $('phPickT').textContent = 'Уншиж байна…';
  try { const r = await App.shrink(f, 720, 110); S.photo = r.url; changed(); }
  catch (e) { App.toast('Зургийг уншиж чадсангүй. Өөр зураг сонгоно уу.'); }
  uploading = false; $('phPickT').textContent = S.photo ? 'Солих' : 'Зураг сонгох';
}

/* ---------- lists that depend on configuration ---------- */
function setTheme(id) { S.theme = id; const d = App.themeDefOf(id); if (d) S.themeDef = d; else delete S.themeDef; }
function buildChips() {
  const box = $('chips'); box.textContent = '';
  const ids = App.occIds(); if (!ids.includes(S.occ) && !S.id) { S.occ = ids[0] || 'bday'; }
  ids.concat(ids.includes(S.occ) ? [] : [S.occ]).forEach(id => {
    box.append(h('button', {
      type: 'button', class: 'chip', role: 'radio', 'data-id': id, text: M.OCC[id].name,
      on: { click: () => { S.occ = id; S.motif = null; setTheme(M.OCC[id].theme); if (!App.fxIds(id).includes(S.fx)) S.fx = App.fxIds(id)[0]; buildThumbs(); buildSwatches(); buildExtra(); syncAll(); } }
    }));
  });
}
function buildSwatches() {
  const box = $('swatches'); box.textContent = '';
  App.themeList(S.occ).forEach(t => {
    const th = M.THEMES[t.id]; if (!th) return;
    const b = h('button', { type: 'button', class: 'sw', title: t.name, 'aria-label': 'Өнгө: ' + t.name, 'data-id': t.id, on: { click: () => { setTheme(t.id); syncAll(); } } });
    b.style.background = `linear-gradient(160deg,${th.bg[0]},${th.bg[1]})`; box.append(b);
  });
  if (M.THEMES[S.theme] && !App.themeList(S.occ).some(t => t.id === S.theme)) {
    const th = M.THEMES[S.theme], b = h('button', { type: 'button', class: 'sw', title: th.name, 'aria-label': 'Өнгө: ' + th.name, 'data-id': S.theme }); b.style.background = `linear-gradient(160deg,${th.bg[0]},${th.bg[1]})`; box.append(b);
  }
}
function buildThumbs() {
  const box = $('thumbs'); box.textContent = '';
  const ids = App.fxIds(S.occ); if (!ids.includes(S.fx) && M.FXS[S.fx]) ids.unshift(S.fx);
  ids.forEach(id => {
    const b = h('button', { type: 'button', class: 'thumb', 'data-fx': id, on: { click: () => { S.fx = id; pv.t0 = performance.now(); if (!reduce) pv.playing = true; syncAll(); } } },
      h('canvas', { 'aria-hidden': 'true' }), h('span', { text: M.FXS[id].name }), M.FXS[id].scare && h('em', { text: 'Айлгана' }));
    box.append(b);
  });
}
function buildTemplates() {
  const box = $('tplThumbs'), list = App.cfg.templates.filter(t => !App.cfg.main.offOcc.includes(t.occ));
  box.textContent = ''; $('sec-tpl').hidden = !list.length;
  list.forEach(t => {
    box.append(h('button', { type: 'button', class: 'thumb', 'data-tpl': t.id, on: { click: () => applyTemplate(t) } }, h('canvas', { 'aria-hidden': 'true' }), h('span', { text: t.name || 'Загвар' })));
  });
}
function mediaPicker(role, title) {
  const list = App.mediaList(role).filter(m => role !== 'sticker' || m.kind !== 'video'), key = role === 'bg' ? 'bg' : 'sticker';
  if (!list.length) return null;
  const items = [h('button', { type: 'button', class: 'mi', 'aria-pressed': String(!S[key]), 'data-id': '', 'data-key': key, on: { click: () => { S[key] = null; syncAll(); } } }, 'Алга')];
  list.forEach(m => {
    const media = m.kind === 'video' ? h('video', { src: m.src, muted: true, playsInline: true, preload: 'metadata' }) : h('img', { src: m.src, alt: m.name || '' });
    items.push(h('button', { type: 'button', class: 'mi', 'aria-pressed': String(S[key] === m.id), 'data-id': m.id, 'data-key': key, title: m.name || '', on: { click: () => { S[key] = m.id; syncAll(); } } }, media, m.kind === 'video' && h('span', { class: 'tag', text: 'видео' })));
  });
  return h('div', {}, h('div', { class: 'sub', text: title }), h('div', { class: 'mgrid' }, items));
}
function motifPicker() {
  const o = M.OCC[S.occ]; if (!o || !o.motifs || o.motifs.length < 2) return null;
  return h('div', {}, h('div', { class: 'sub', text: 'Гол дүрс' }),
    h('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Гол дүрс' }, o.motifs.map(id => h('button', { type: 'button', class: 'chip', role: 'radio', 'data-motif': id, text: M.MOTIF_NAMES[id] || id, on: { click: () => { S.motif = id; syncAll(); } } }))));
}
function buildExtra() {
  const box = $('extra'); box.textContent = '';
  const mp = motifPicker(), bg = mediaPicker('bg', 'Арын дэвсгэр'), st = mediaPicker('sticker', 'Голын наалт');
  [mp, bg, st].forEach(x => x && box.append(x)); $('sec-extra').hidden = !(mp || bg || st);
}
function applyTemplate(t) {
  S.occ = t.occ || S.occ; S.fx = t.fx || S.fx; S.motif = t.motif || null; setTheme(t.theme || S.theme);
  S.bg = t.bg && App.mediaById(t.bg) ? t.bg : null; S.sticker = t.sticker && App.mediaById(t.sticker) ? t.sticker : null; S.sfx = t.sfx || null;
  if (t.title) S.title = t.title; if (t.msg) S.msg = t.msg;
  pv.t0 = performance.now(); if (!reduce) pv.playing = true;
  syncFields(); buildThumbs(); buildSwatches(); buildExtra(); syncAll();
}
function syncFields() {
  $('toName').value = S.to || ''; $('fromName').value = S.from || ''; $('titleIn').value = S.title || ''; $('msgIn').value = S.msg || '';
}

/* ---------- state -> screen ---------- */
function syncAll() {
  document.querySelectorAll('#chips .chip').forEach(b => b.setAttribute('aria-checked', String(b.dataset.id === S.occ)));
  document.querySelectorAll('#swatches .sw').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.id === S.theme)));
  document.querySelectorAll('#thumbs .thumb').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.fx === S.fx)));
  document.querySelectorAll('#extra .mi').forEach(b => b.setAttribute('aria-pressed', String((S[b.dataset.key] || '') === b.dataset.id)));
  document.querySelectorAll('#extra [data-motif]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.motif === (S.motif || (M.OCC[S.occ] || {}).motif))));
  const o = M.OCC[S.occ] || M.OCC.other;
  $('titleIn').placeholder = o.title; $('msgIn').placeholder = o.msg;
  changed();
}
let thumbQ = 0;
function changed() {
  $('msgCount').textContent = ($('msgIn').value.length) + ' / 160';
  const ph = $('phPrev');
  ph.style.backgroundImage = S.photo ? `url("${S.photo}")` : ''; ph.textContent = S.photo ? '' : 'Зураг алга';
  $('phDel').hidden = !S.photo; $('phMode').hidden = !S.photo; $('phPickT').textContent = S.photo ? 'Солих' : 'Зураг сонгох';
  document.querySelectorAll('#phMode .chip').forEach(b => b.setAttribute('aria-checked', String(b.dataset.m === (S.photoMode || 'circle'))));
  const R = App.toR(S); App.media.play(R.bgEl);
  renderSend();
  if (!thumbQ) thumbQ = requestAnimationFrame(() => { thumbQ = 0; renderThumbs(); });
}
function renderThumbs() {
  document.querySelectorAll('#thumbs canvas').forEach(c => App.thumbDraw(c, S, c.parentElement.dataset.fx));
  const tpl = Object.fromEntries(App.cfg.templates.map(t => [t.id, t]));
  document.querySelectorAll('#tplThumbs .thumb').forEach(b => {
    const t = tpl[b.dataset.tpl]; if (!t) return;
    App.thumbDraw(b.querySelector('canvas'), { occ: t.occ, fx: t.fx, motif: t.motif, theme: t.theme, themeDef: App.themeDefOf(t.theme) || undefined, to: S.to || 'Азаа', from: S.from, title: t.title, msg: t.msg, bg: t.bg, sticker: t.sticker }, t.fx);
  });
}
function previewFrame(now) {
  requestAnimationFrame(previewFrame);
  if (App.view !== 'make' || document.hidden || App.viewerOpen) return;
  const c = $('pvCanvas'), { ctx, w, h: hh } = App.fit(c); if (w < 8) return;
  let t = M.THUMB_T[S.fx] || 1;
  if (pv.playing) { t = (now - pv.t0) / 1000; if (M.LOOP[S.fx]) t %= M.LOOP[S.fx]; }
  M.render(ctx, w, hh, t, App.toR(S));
}

/* ---------- send panel ---------- */
function errMsg(e) {
  const c = e && e.code;
  if (c === 'invalid_argument') return 'Таны эрх зөвхөн үзэх түвшинд байна. Админаас «Contributor» эрх авна уу.';
  if (c === 'quota_exceeded') return 'Хадгалах багтаамж дүүрсэн байна. Админд мэдэгдээрэй.';
  if (c === 'unavailable' && e.message) return e.message;
  return 'Хадгалж чадсангүй. Дахин оролдоно уу.';
}
async function save() {
  if (busy) return;
  if (!S.id && mine.length >= 80) { App.toast('Хадгалах карт 80 хүрсэн. Хуучныг нь устгана уу.'); return; }
  busy = true; renderSend();
  try {
    const free = S.id ? !!S.free : (!App.cfg.main.payRequired || App.me.isAdmin);
    const doc = await App.backend.saveCard(S, free);
    S.id = doc.id; S.free = doc.free; S.created = doc.created; if (doc.photo) S.photo = doc.photo;
    snapshot = fieldsOf(); App.toast('Хадгалагдлаа.');
  } catch (e) { App.toast(errMsg(e), 5000); }
  busy = false; renderSend();
}
async function claim() {
  if (busy) return; busy = true; renderSend();
  try { await App.backend.claim(S.id); App.toast('Админд мэдэгдлээ. Баталгаажихыг хүлээнэ үү.'); } catch (e) { App.toast(errMsg(e), 5000); }
  busy = false; renderSend();
}
function newCard() {
  const from = S.from; S = App.S = App.blankCard(); S.from = from; snapshot = '';
  buildChips(); buildThumbs(); buildSwatches(); buildExtra(); syncFields(); syncAll();
}
function kvRow(k, v, copy) {
  return h('div', { class: 'kvr' },
    h('div', { class: 'kvt' }, h('span', { class: 'kvk', text: k }), h('span', { class: 'kvv', text: v })),
    copy && h('button', { type: 'button', class: 'ghost sm', text: 'Хуулах', on: { click: () => App.copy(v, k + ' хуулагдлаа') } }));
}
function payBox(dirty) {
  const m = App.cfg.main, ok = App.payReady();
  return h('div', { class: 'pay' },
    h('div', { class: 'hint', text: 'Төлөх дүн' }), h('div', { class: 'amt', text: App.fmtMoney(m.price) }),
    ok ? h('div', { class: 'kv' }, kvRow('Банк', m.bank), kvRow('Данс', m.account, true), kvRow('Хүлээн авагч', m.holder), kvRow('Гүйлгээний утга', App.refCode(S.id), true))
       : h('div', { class: 'stat warn', text: 'Төлбөрийн мэдээллийг админ одоогоор оруулаагүй байна. Түр хүлээнэ үү.' }),
    m.note && h('p', { class: 'hint', text: m.note }),
    ok && h('p', { class: 'hint', text: 'Гүйлгээний утга дээр дээрх кодыг заавал бичнэ. Шилжүүлсний дараа «Төлсөн» товчийг дарна.' }),
    h('button', { class: 'primary', type: 'button', disabled: !ok || busy || dirty, text: 'Төлсөн', on: { click: claim } }),
    dirty && h('p', { class: 'hint', text: 'Эхлээд доорх «Өөрчлөлтийг хадгалах» товчийг дарна уу.' }));
}
function linkBox() {
  const link = App.backend.linkFor(S);
  if (!link) return h('div', { class: 'stat warn', text: 'Холбоос бэлэн болоогүй байна. Хуудсыг дахин нээгээд оролдоно уу.' });
  const inp = h('input', { class: 'ro', type: 'text', readOnly: true, value: link, 'aria-label': 'Мэндчилгээний холбоос' });
  const rows = [h('div', { class: 'linkrow' }, inp, h('button', { class: 'primary', type: 'button', text: 'Хуулах', on: { click: () => App.copy(link, 'Холбоос хуулагдлаа. Одоо найздаа илгээгээрэй.', inp) } }))];
  const acts = [];
  if (navigator.share) acts.push(h('button', { class: 'ghost', type: 'button', text: 'Хуваалцах', on: { click: async () => { try { await navigator.share({ title: 'Баярын мэнд', text: (S.to || 'Найз минь') + ' танд мэндчилгээ ирлээ', url: link }); } catch (e) { /* cancelled */ } } } }));
  if (App.backend.canDownload !== false) acts.push(h('button', { class: 'ghost', type: 'button', text: 'Зураг болгож хадгалах', on: { click: async () => {
    try { const b = await App.renderPng(S); const r = await App.saveFile('baiyn-mend.png', b); if (r) App.toast('Зураг хадгалагдлаа.'); } catch (e) { if (!e || e.code !== 'declined') App.toast('Зураг хадгалж чадсангүй.'); } } } }));
  if (acts.length) rows.push(h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start' } }, acts));
  rows.push(h('p', { class: 'hint', text: 'Холбоосыг Messenger, Viber, Facebook, Telegram-аар илгээнэ. Хүлээн авсан хүн нээгээд «Нээх» товчийг дарахад мэндчилгээ тоглоно.' }));
  return h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } }, rows);
}
const loginBtn = () => App.backend && App.backend.openLogin ? h('button', { class: 'primary', type: 'button', text: 'Нэвтрэх / бүртгүүлэх', on: { click: () => App.backend.openLogin() } }) : null;
function renderSend() {
  const box = $('send'); if (!box) return;
  const kids = [h('h2', { id: 'h-send', text: 'Илгээх' })];
  const entry = entryOf(), stt = entry ? App.statusOf(entry, entry.ap) : null, dirty = !!entry && snapshot !== fieldsOf();
  const m = App.cfg.main;
  if (!App.me.canWrite) {
    kids.push(h('div', { class: 'stat info', text: (App.backend && App.backend.reason) || 'Холбоос авахын тулд нэвтэрсэн байх шаардлагатай. Одоогоор урьдчилан харах боломжтой.' }), loginBtn());
  } else if (!entry) {
    const paid = m.payRequired && !App.me.isAdmin;
    if (paid) kids.push(h('div', { class: 'pay' }, h('div', { class: 'hint', text: 'Холбоос авахын үнэ' }), h('div', { class: 'amt', text: App.fmtMoney(m.price) }), h('p', { class: 'hint', text: 'Эхлээд картаа хадгална. Дараа нь банкны мэдээлэл гарч ирнэ. Шилжүүлгийг админ баталгаажуулмагц холбоос нээгдэнэ.' })));
    kids.push(h('button', { class: 'primary', type: 'button', disabled: busy, text: busy ? 'Хадгалж байна…' : (paid ? 'Хадгалаад төлбөр рүү' : 'Холбоос авах'), on: { click: save } }));
  } else {
    if (dirty) kids.push(h('button', { class: 'primary', type: 'button', disabled: busy, text: busy ? 'Хадгалж байна…' : 'Өөрчлөлтийг хадгалах', on: { click: save } }));
    if (stt === 'free' || stt === 'ok') {
      if (stt === 'ok') kids.push(h('div', { class: 'stat ok', text: 'Төлбөр баталгаажлаа. Холбоосоо илгээж болно.' }));
      kids.push(linkBox());
      if (dirty) kids.push(h('p', { class: 'hint', text: 'Хадгалахаас өмнө хийсэн өөрчлөлт холбоост ороогүй байна.' }));
    } else if (stt === 'pending') {
      kids.push(h('div', { class: 'stat warn' }, h('span', { class: 'sk', 'aria-hidden': 'true' }), h('span', { text: 'Админ таны шилжүүлгийг шалгаж байна. Баталгаажмагц энд холбоос гарч ирнэ. Гүйлгээний утга: ' + App.refCode(S.id) })));
    } else if (stt === 'no') {
      kids.push(h('div', { class: 'stat bad', text: 'Төлбөр баталгаажсангүй.' + (entry.ap && entry.ap.note ? ' Админы тайлбар: ' + entry.ap.note : '') }), payBox(dirty));
    } else {
      kids.push(payBox(dirty));
    }
    kids.push(h('button', { class: 'ghost', type: 'button', text: 'Шинэ мэндчилгээ эхлэх', on: { click: newCard } }));
  }
  box.textContent = ''; box.append(...kids);
}

/* ---------- my cards ---------- */
function mineView() {
  const root = $('v-mine'); root.textContent = '';
  root.append(h('p', { class: 'lead', text: 'Таны хадгалсан мэндчилгээнүүд. Төлбөрийн төлөв энд шууд шинэчлэгдэнэ.' }));
  if (!App.me.canWrite) { root.append(h('div', { class: 'stat info', text: (App.backend && App.backend.reason) || 'Картаа хадгалахын тулд нэвтэрсэн байх шаардлагатай.' }), loginBtn()); return; }
  if (!mine.length) { root.append(h('div', { class: 'empty' }, h('p', { text: 'Одоогоор хадгалсан мэндчилгээ алга.' }), h('p', { style: { marginTop: '10px' } }, h('button', { class: 'primary', type: 'button', text: 'Шинээр бүтээх', on: { click: () => App.show('make') } })))); return; }
  const rows = h('div', { class: 'rows' });
  mine.forEach(e => {
    const stt = App.statusOf(e, e.ap), canv = h('canvas', { 'aria-hidden': 'true' });
    rows.append(h('div', { class: 'row', 'data-id': e.id },
      canv,
      h('div', { class: 'grow' }, h('div', { class: 't', text: (e.to || 'Нэргүй') + ' · ' + (M.OCC[e.occ] ? M.OCC[e.occ].name : '') }), h('div', { class: 's', text: (M.FXS[e.fx] ? M.FXS[e.fx].name : '') + ' · ' + App.fmtT(e.at) + (stt === 'draft' || stt === 'no' ? ' · Утга: ' + App.refCode(e.id) : '') + (e.views ? ' · ' + e.views + ' удаа нээгдсэн' : '') })),
      App.badge(stt),
      h('div', { class: 'acts' },
        h('button', { class: 'ghost sm', type: 'button', text: 'Нээх', on: { click: () => openMine(e.id) } }),
        h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: async () => { if (await App.confirm('Энэ мэндчилгээг устгах уу? Илгээсэн холбоос ажиллахаа болино.', 'Устгах', true)) { try { await App.backend.deleteCard(e.id); if (S.id === e.id) newCard(); App.toast('Устгагдлаа.'); } catch (er) { App.toast(errMsg(er)); } } } } }))));
    requestAnimationFrame(() => App.thumbDraw(canv, { occ: e.occ, fx: e.fx, theme: (M.OCC[e.occ] || M.OCC.other).theme, to: e.to || 'Нэр' }, e.fx));
  });
  root.append(rows);
}
async function openMine(id) {
  try {
    const r = await App.backend.getCard(App.me.uid, id);
    if (!r) { App.toast('Карт олдсонгүй.'); return; }
    S = App.S = Object.assign(App.blankCard(r.card.occ), r.card);
    snapshot = fieldsOf(); buildChips(); buildThumbs(); buildSwatches(); buildExtra(); syncFields(); syncAll(); App.show('make');
  } catch (e) { App.toast('Нээж чадсангүй.'); }
}

/* ---------- wire up ---------- */
function rebuild() { buildChips(); buildSwatches(); buildThumbs(); buildTemplates(); buildExtra(); syncAll(); }
App.views.make = { enter() { changed(); } };
App.views.mine = { enter: mineView };
App.initMaker = function () {
  build(); rebuild(); syncFields();
  requestAnimationFrame(previewFrame);
  App.on('config', () => { rebuild(); if (App.view === 'mine') mineView(); });
  App.on('media', () => { if (!thumbQ) thumbQ = requestAnimationFrame(() => { thumbQ = 0; renderThumbs(); }); });
  App.backend.onMine(list => { mine = list; const e = entryOf(); if (e && !busy && snapshot === '') snapshot = fieldsOf(); renderSend(); if (App.view === 'mine') mineView(); App.emit('mine', list); });
  window.addEventListener('resize', () => { if (App.view === 'make') changed(); });
  if (document.fonts) {
    const sample = 'Өө Үү Аа Бб Хх 0123 БҮҮҮ! Айсан уу?';
    const refresh = () => { M.resetTextCache(); if (App.view === 'make') changed(); };
    Promise.all(['800 40px Rubik', '600 40px Rubik', '400 40px Pacifico', '600 40px Nunito', '500 16px Nunito'].map(f => document.fonts.load(f, sample).catch(() => {}))).then(refresh);
    if (document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', refresh);
  }
};
})();
