#!/bin/sh
# Баярын мэнд: шинэ Ubuntu/Debian серверт нэг командаар суулгаж, https-тэй нийтэд нээнэ.
#
#   1. Домэйныхаа DNS дээр A бичлэг үүсгэж серверийн IP руу заана (жишээ нь card.example.mn -> 203.0.113.10).
#   2. Серверт нэвтэрч, энэ хавтсыг (zip-ийг задалсан) байрлуулна.
#   3. sudo sh deploy/vps-install.sh card.example.mn таны@имэйл.mn
#
# Docker байхгүй бол (Ubuntu 24.04) apt-аар суулгана. Өөр хувилбар дээр Docker суулгалт өөр байж болно: тэгвэл
# https://docs.docker.com/engine/install/ заавраар Docker ба «compose» нэмэлтийг суулгаад энэ скриптийг дахин ажиллуулна.
# Скрипт дахин ажиллахад одоо байгаа .env болон өгөгдлийг ӨӨРЧЛӨХГҮЙ.
set -eu

DOMAIN="${1:-}"; ADMIN_EMAIL="${2:-}"
die() { echo "АЛДАА: $*" >&2; exit 1; }
say() { echo "==> $*"; }

[ -n "$DOMAIN" ] && [ -n "$ADMIN_EMAIL" ] || die "Хэрэглээ: sudo sh deploy/vps-install.sh card.example.mn admin@example.mn"
echo "$DOMAIN" | grep -Eq '^[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$' || die "Домэйн буруу байна: $DOMAIN (жишээ нь card.example.mn, жижиг үсгээр, https:// -гүй)"
echo "$ADMIN_EMAIL" | grep -Eq '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' || die "И-мэйл хаяг буруу байна: $ADMIN_EMAIL"
DRY="${DRY_RUN:-}"
[ -n "$DRY" ] || [ "$(id -u)" = 0 ] || die "root эрхтэй ажиллуулна: sudo sh deploy/vps-install.sh $DOMAIN $ADMIN_EMAIL"
cd "$(dirname "$0")/.."
[ -f Dockerfile ] && [ -f docker-compose.public.yml ] || die "Төслийн хавтас буруу байна (Dockerfile олдсонгүй)"

# ---------- 1. Docker ----------
if [ -z "$DRY" ]; then
  if ! command -v docker >/dev/null 2>&1; then
    say "Docker суулгаж байна"
    apt-get update -y && apt-get install -y docker.io openssl || die "Docker суулгаж чадсангүй. docs.docker.com заавраар гараар суулгаад дахин ажиллуулна уу."
  fi
  if ! docker compose version >/dev/null 2>&1; then
    say "Docker Compose нэмэлт суулгаж байна"
    apt-get install -y docker-compose-v2 >/dev/null 2>&1 || apt-get install -y docker-compose-plugin >/dev/null 2>&1 || die "Docker Compose нэмэлт суулгаж чадсангүй. docs.docker.com/compose/install заавраар суулгаад дахин ажиллуулна уу."
  fi
  systemctl enable --now docker >/dev/null 2>&1 || true
fi
command -v openssl >/dev/null 2>&1 || die "openssl байхгүй байна (apt-get install openssl)"

# ---------- 2. .env (байхгүй үед л үүсгэнэ) ----------
NEW_ENV=""
if [ -f .env ]; then
  say ".env аль хэдийн байна: өөрчлөхгүй"
  grep -q '^DOMAIN=' .env || die ".env дотор DOMAIN=$DOMAIN мөр нэмнэ үү (docker-compose.public.yml шаардана)"
else
  NEW_ENV=1
  ADMIN_PASSWORD="$(openssl rand -base64 24 | tr -d '/+=\n' | cut -c1-16)"
  APP_SECRET="$(openssl rand -hex 32)"
  BANK_WEBHOOK_SECRET="$(openssl rand -hex 24)"
  umask 077
  cat > .env <<ENVEOF
DOMAIN=$DOMAIN
BASE_URL=https://$DOMAIN
TRUST_PROXY=1
DATA_DIR=/data
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_PASSWORD=$ADMIN_PASSWORD
APP_SECRET=$APP_SECRET
BANK_WEBHOOK_SECRET=$BANK_WEBHOOK_SECRET
ENVEOF
  chmod 600 .env
  say ".env үүслээ (эрх 600: зөвхөн root уншина)"
fi

[ -z "$DRY" ] || { say "DRY_RUN: Docker, DNS, асаалтыг алгассан"; exit 0; }

# ---------- 3. DNS ----------
RESOLVED="$(getent hosts "$DOMAIN" 2>/dev/null | awk '{print $1}' | head -n1 || true)"
if [ -z "$RESOLVED" ]; then
  echo "АНХААР: $DOMAIN-ийн DNS бичлэг одоогоор олдсонгүй. A бичлэгийг энэ серверийн IP руу зааж өгөөгүй бол https авч чадахгүй." >&2
elif ! hostname -I 2>/dev/null | tr ' ' '\n' | grep -qx "$RESOLVED"; then
  echo "АНХААР: $DOMAIN нь $RESOLVED руу заасан байна, энэ серверийн хаяг биш (Cloudflare, NAT, floating IP бол хэвийн)." >&2
fi

# ---------- 4. Асаах ----------
say "Апп бүтээж, асааж байна (анх удаа 2-5 минут)"
docker compose -f docker-compose.public.yml up -d --build || die "docker compose асаж чадсангүй"
say "Апп хариулахыг хүлээж байна"
i=0; until docker compose -f docker-compose.public.yml exec -T baiyn-mend node -e "fetch('http://127.0.0.1:3000/healthz').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))" >/dev/null 2>&1; do
  i=$((i+1)); [ "$i" -le 40 ] || die "Апп ассангүй. 'docker compose -f docker-compose.public.yml logs baiyn-mend' ажиллуулж алдааг харна уу."
  sleep 2
done

echo
echo "=============================================================="
echo " Бэлэн боллоо: https://$DOMAIN"
echo " (https гэрчилгээг Caddy анхны хандалтаар авна, 1 минут болж магадгүй. 80, 443 портыг хаалтнаас нээлттэй байлгана.)"
if [ -n "$NEW_ENV" ]; then
  echo
  echo " Админ нэвтрэх хаяг : $ADMIN_EMAIL"
  echo " Админ нууц үг      : $ADMIN_PASSWORD   (нэвтэрсний дараа «Нууц үг» товчоор солино)"
  echo " Gmail-ийн нууц түлхүүр (Apps Script-ийн SECRET): $BANK_WEBHOOK_SECRET"
  echo " Эдгээр нь .env файлд хадгалагдсан. Нууц үгээ тэмдэглээд ADMIN_PASSWORD мөрийг .env-ээс устгаж болно."
fi
echo
echo " Нөөцлөлт  : docker compose -f docker-compose.public.yml exec baiyn-mend npm run backup"
echo " Шинэчлэх  : шинэ файлуудаа байрлуулаад ижил 'docker compose ... up -d --build'"
echo "=============================================================="
