/* Баярын мэнд: Gmail-ээс банкны орлогын мэдэгдлийг серверт дамжуулагч (Google Apps Script)

   Энэ скрипт ТАНЫ Google хаягт ажиллана. Үүнийг л хийнэ:
     - М банкнаас ирсэн «Гүйлгээний мэдэгдэл» имэйлээс ОРЛОГЫН мэдэгдлийг шүүнэ (зарлага, бусад имэйл серверт огт явахгүй),
     - Gmail-ийн өөрийнх нь хийсэн DMARC / SPF / DKIM шалгалтын үр дүнг хамт серверт илгээнэ (хуурамч имэйлийг сервер татгалзана),
     - Gmail дээр юу ч илгээхгүй, устгахгүй, шошго тавихгүй, өөрчлөхгүй: зөвхөн уншина.

   ТОХИРУУЛАХ (нэг удаа, ойролцоогоор 3 минут):
     1. https://script.google.com дээр өөрийн Gmail хаягаараа нэвтэрч «Шинэ төсөл» үүсгэнэ.
     2. Энэ файлын бүх текстийг Code.gs-ийн оронд буулгана.
     3. Доорх SERVER_URL, SECRET-ийг бөглөнө (SECRET нь серверийн .env дахь BANK_WEBHOOK_SECRET-тэй ЯГ ИЖИЛ).
     4. Дээд талын жагсаалтаас «doTest»-ийг сонгоод ▶ Ажиллуулна. Эхний удаа зөвшөөрөл асууна: «Gmail унших», «гаднах хаягт хандах».
        Лог (Ctrl+Enter) дээр сүүлийн банкны имэйлүүд, баталгаажуулалтын үр дүн, серверийн хариу гарна.
     5. Бүгд зөв байвал «install»-ыг нэг удаа ажиллуулна. Тэр минут тутам ажиллах хуваарийг үүсгэнэ.
     Зогсоох бол «uninstall»-ыг ажиллуулна. */

var SERVER_URL = 'https://card.example.mn';   // серверийн BASE_URL, төгсгөлд "/" бүү тавь
var SECRET = '';                               // серверийн .env дахь BANK_WEBHOOK_SECRET (24+ тэмдэгт)

var SENDER = /^smartinfo\d*@m-bank\.mn$/i;      // М банкны илгээгч (smartinfo3@, smartinfo14@ ...)
var SUBJECT = /Гүйлгээний\s+мэдэгдэл/i;
var BASE_QUERY = 'from:m-bank.mn subject:"Гүйлгээний мэдэгдэл"';
var FIRST_RUN_DAYS = 2;       // анх асахад хэдэн хоногийн өмнөх имэйлээс эхлэх
var OVERLAP_SEC = 3600;       // хайлтын цонхыг 1 цагаар нөөцлөнө (имэйл хоцорч ирэх, цагийн зөрүү). Сервер ижил имэйлийг дахин боловсруулахгүй
var MAX_ITEMS = 50;           // нэг удаад илгээх дээд хэмжээ (серверийн хязгаартай ижил)

/* ====================== цэвэр функцүүд (Gmail-ээс хамааралгүй, Node дээр шалгагдсан) ====================== */

/* толгойн мөрүүдийг нэгтгэнэ ("\r\n " гэж үргэлжилсэн мөр) */
function unfoldHeaders(h) { return String(h || '').replace(/\r?\n[ \t]+/g, ' '); }

/* Gmail-ийн ӨӨРИЙН Authentication-Results толгой: authserv-id нь яг «mx.google.com» байх хамгийн ДЭЭРХ мөр.
   Gmail өөрийн толгойг хамгийн дээр нэмдэг, илгээгчийн хуурамчаар бичсэн мөр доор үлддэг тул эхнийхийг нь авна.
   «ARC-Authentication-Results» нь ойлголтын хувьд өөр толгой тул тоодоггүй. */
function pickAuthResults(rawHeaders) {
  var lines = unfoldHeaders(headerBlock(rawHeaders)).split(/\r?\n/);      // имэйлийн бие хэсэг хэзээ ч тооцогдохгүй
  for (var i = 0; i < lines.length; i++) {
    var m = /^Authentication-Results:\s*(.*)$/i.exec(lines[i]);
    if (m && /^mx\.google\.com\s*(;|$)/i.test(m[1])) return m[1];
  }
  return '';
}

function tokenOf(clause, name) {
  var m = new RegExp('(?:^|\\s)' + name.replace(/\./g, '\\.') + '=([^\\s;()]+)', 'i').exec(clause);
  return m ? m[1].toLowerCase() : '';
}

/* "dkim=pass header.i=@m-bank.mn; spf=pass ... smtp.mailfrom=a@m-bank.mn; dmarc=pass ... header.from=m-bank.mn"
   -> { dmarc, from, spf, spfDom, dkim, dkimDom }. Хэд хэдэн DKIM гарын үсэг байвал «pass» болсныг нь авна. */
function parseAuthResults(value) {
  var out = { dmarc: '', from: '', spf: '', spfDom: '', dkim: '', dkimDom: '' };
  var clauses = String(value || '').split(';');
  for (var i = 0; i < clauses.length; i++) {
    var c = clauses[i].trim(), m;
    if ((m = /^dmarc=(\w+)/i.exec(c))) {
      if (!out.dmarc) { out.dmarc = m[1].toLowerCase(); out.from = tokenOf(c, 'header.from'); }
    } else if ((m = /^spf=(\w+)/i.exec(c))) {
      if (!out.spf) { out.spf = m[1].toLowerCase(); out.spfDom = tokenOf(c, 'smtp.mailfrom') || tokenOf(c, 'smtp.helo'); }
    } else if ((m = /^dkim=(\w+)/i.exec(c))) {
      var res = m[1].toLowerCase(), dom = tokenOf(c, 'header.d') || tokenOf(c, 'header.i');
      if (!out.dkim || (out.dkim !== 'pass' && res === 'pass')) { out.dkim = res; out.dkimDom = dom; }
    }
  }
  return out;
}

/* имэйлийн толгойн хэсэг: эхний хоосон мөр хүртэл */
function headerBlock(raw) {
  var s = String(raw || ''), i = s.search(/\r?\n\r?\n/);
  return i < 0 ? s : s.slice(0, i);
}

/* «Таны дансанд орлого нэмэгдлээ» гэж ЭХЭЛСЭН имэйл үү? (зарлага болон бусад нь серверт явахгүй) */
function isIncome(text) {
  var t = String(text || '').replace(/[*•·▪◦_]+/g, ' ').replace(/\s+/g, ' ').trim();
  return /^.{0,80}?Таны\s+дансанд\s+орлого\s+нэмэгдлээ/i.test(t);
}
function senderAddr(from) {
  var m = /<([^<>\s]+@[^<>\s]+)>/.exec(String(from || ''));
  return (m ? m[1] : String(from || '').trim()).toLowerCase();
}

/* Нэг имэйлээс серверт илгээх зүйл (эсвэл null). msg нь GmailMessage эсвэл түүнтэй адил объект. */
function itemFrom(msg) {
  var from = msg.getFrom(), subject = msg.getSubject();
  if (!SENDER.test(senderAddr(from)) || !SUBJECT.test(subject)) return null;
  var body = msg.getPlainBody() || '';
  if (!/Гүйлгээний/.test(body)) body = String(msg.getBody() || '').replace(/<img\b[^>]*>/gi, '');   // HTML-only имэйл: зургийг хасна
  body = body.slice(0, 20000);
  if (!isIncome(body.replace(/<[^>]*>/g, ' '))) return null;
  var auth = parseAuthResults(pickAuthResults(headerBlock(msg.getRawContent())));
  return { id: msg.getId(), date: msg.getDate().toISOString(), from: from, subject: subject, body: body, auth: auth };
}

/* ====================== Gmail, сервертэй холбогдох хэсэг ====================== */

var props = function () { return PropertiesService.getScriptProperties(); };
function getCursor() {
  var v = Number(props().getProperty('cursor'));
  return v > 0 ? v : Date.now() - FIRST_RUN_DAYS * 86400000;
}
function setCursor(ms) { props().setProperty('cursor', String(Math.floor(ms))); }
/* сервер хүлээн авсан (алдаагүй) имэйлийн ID-ууд: хамгийн сүүлийн 300. Алдагдсан ч болно: сервер ижил ID-г дахин боловсруулахгүй. */
function getDone() { try { var a = JSON.parse(props().getProperty('done') || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
function setDone(list) { props().setProperty('done', JSON.stringify(list.slice(-300))); }

/* cursor-оос хойш ирсэн банкны имэйлүүд, түүний дотроос сервер хүлээн аваагүй нь. Thread дотор хэд хэдэн имэйл байж болох
   тул (ижил гарчигтай мэдэгдлүүд нэг thread-д орно) имэйл бүрийг тусад нь шалгана. */
function collect(sinceMs, isDone) {
  var threads = GmailApp.search(BASE_QUERY + ' after:' + Math.floor(sinceMs / 1000), 0, 30), items = [];
  for (var i = 0; i < threads.length; i++) {
    var msgs = threads[i].getMessages();
    for (var j = 0; j < msgs.length; j++) {
      var id = msgs[j].getId();
      if (isDone[id]) continue;
      var it = itemFrom(msgs[j]);
      if (it) items.push(it);
    }
  }
  items.sort(function (a, b) { return a.date < b.date ? -1 : (a.date > b.date ? 1 : 0); });
  return { items: items.slice(0, MAX_ITEMS), more: items.length > MAX_ITEMS };
}

function post(items) {
  if (!SECRET || SECRET.length < 24) throw new Error('SECRET бөглөгдөөгүй байна (серверийн BANK_WEBHOOK_SECRET-ийг хуулна).');
  var r = UrlFetchApp.fetch(String(SERVER_URL).replace(/\/+$/, '') + '/api/bank/notify', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true, followRedirects: false,
    headers: { Authorization: 'Bearer ' + SECRET }, payload: JSON.stringify({ items: items })
  });
  var code = r.getResponseCode(), text = r.getContentText();
  if (code !== 200) throw new Error('Сервер ' + code + ' гэж хариулав: ' + String(text).slice(0, 200));
  return JSON.parse(text).results || {};
}

/* Минут тутам ажиллана. Банкны имэйл байхгүй байсан ч сервертэй холбогдож «Gmail ажиллаж байна» гэсэн дохио өгнө.
   Сервер имэйлийг амжилттай хүлээн авсан бол ID-г нь «done»-д тэмдэглэнэ. Алдаа гарвал cursor урагшлахгүй: дараагийн минутад дахин оролдоно. */
function run() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) return;                      // өмнөх ажиллагаа дуусаагүй бол алгасна
  try {
    var since = getCursor(), done = getDone(), seen = {};
    done.forEach(function (id) { seen[id] = 1; });
    var got = collect(since, seen), results = post(got.items), failed = 0;
    got.items.forEach(function (it) {
      var r = results[it.id];
      if (r && r.st !== 'error') done.push(it.id); else failed++;
    });
    setDone(done);
    if (!failed && !got.more) setCursor(Math.max(since, Date.now() - OVERLAP_SEC * 1000));   // бүгд боловсрогдсон: цонх урагшилна (1 цагийн нөөцтэй)
    Logger.log('илгээсэн: ' + got.items.length + (failed ? ', алдаатай: ' + failed + ' (дараа дахин оролдоно)' : ''));
  } finally { lock.releaseLock(); }
}

/* ====================== суулгах, шалгах ====================== */

function install() {
  uninstall();
  ScriptApp.newTrigger('run').timeBased().everyMinutes(1).create();
  Logger.log('Минут тутам ажиллах хуваарь үүслээ.');
}
function uninstall() {
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'run') ScriptApp.deleteTrigger(t); });
}

/* Юу ч өөрчлөхгүй: сүүлийн банкны имэйлүүд, скриптийн харж буй баталгаажуулалт, серверийн хариуг лог дээр харуулна. */
function doTest() {
  var threads = GmailApp.search(BASE_QUERY, 0, 5), shown = 0;
  Logger.log('SERVER_URL = ' + SERVER_URL + ' · SECRET ' + (SECRET && SECRET.length >= 24 ? 'бөглөгдсөн' : 'ДУТУУ (24+ тэмдэгт хэрэгтэй)'));
  for (var i = 0; i < threads.length; i++) {
    var msgs = threads[i].getMessages();
    for (var j = Math.max(0, msgs.length - 2); j < msgs.length; j++) {
      var m = msgs[j], from = m.getFrom(), it = itemFrom(m), a = parseAuthResults(pickAuthResults(headerBlock(m.getRawContent())));
      shown++;
      Logger.log([m.getDate().toISOString(), from, '«' + m.getSubject() + '»', it ? 'ОРЛОГО: серверт явна' : 'орлого биш: серверт явахгүй',
        'dmarc=' + a.dmarc + ' (' + a.from + ') spf=' + a.spf + ' (' + a.spfDom + ') dkim=' + a.dkim + ' (' + a.dkimDom + ')'].join(' | '));
    }
  }
  if (!shown) Logger.log('М банкны «Гүйлгээний мэдэгдэл» имэйл олдсонгүй (Gmail дээр нэг орлого хүлээж аваад дахин ажиллуулна).');
  Logger.log('Серверийн хариу (хоосон жагсаалт): ' + JSON.stringify(post([])));
  Logger.log('Хэрэв дээр dmarc=pass, spf=pass эсвэл dkim=pass ба банкны домэйн (m-bank.mn) харагдаж байвал бүх зүйл зөв.');
}
