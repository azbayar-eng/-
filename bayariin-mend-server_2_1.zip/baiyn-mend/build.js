'use strict';
/* build.js — joins the browser sources in web/ into public/ (one script, one stylesheet, index.html).
   File names carry a hash of their content, so browsers keep them for a year and still pick up every new build.
   Run:  npm run build                                                                                  */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const web = path.join(__dirname, 'web'), out = path.join(__dirname, 'public');
const SCRIPTS = ['engine.js', 'halloween.js', 'core.js', 'backend-common.js', 'backend-rest.js', 'maker.js', 'viewer.js', 'admin.js', 'studio.js', 'main.js'];
const read = f => fs.readFileSync(path.join(web, f), 'utf8');
const hash = s => crypto.createHash('sha1').update(s).digest('hex').slice(0, 8);

const js = SCRIPTS.map(read).join('\n;\n'), css = read('style.css');
const jsName = `app.${hash(js)}.js`, cssName = `app.${hash(css)}.css`;

fs.mkdirSync(out, { recursive: true });
for (const f of fs.readdirSync(out)) if (/^app\.[0-9a-f]{8}\.(js|css)$/.test(f)) fs.unlinkSync(path.join(out, f));
fs.writeFileSync(path.join(out, jsName), js);
fs.writeFileSync(path.join(out, cssName), css);
fs.writeFileSync(path.join(out, 'index.html'), read('index.template.html').replace('__JS__', jsName).replace('__CSS__', cssName));

const stat = path.join(web, 'static');
if (fs.existsSync(stat)) for (const f of fs.readdirSync(stat)) fs.copyFileSync(path.join(stat, f), path.join(out, f));
console.log('Бэлэн боллоо:', jsName, `(${Math.round(js.length / 1024)} KB)`, cssName, `(${Math.round(css.length / 1024)} KB)`);
