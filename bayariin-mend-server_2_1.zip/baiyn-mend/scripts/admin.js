'use strict';
/* Админ үүсгэх эсвэл нууц үгийг нь шинээр тохируулах:
     npm run admin -- azaa@example.mn МиниНууцҮг123
     npm run admin -- 99112233 МиниНууцҮг123 "Азаа"                                             */
const path = require('node:path');
const { loadEnv } = require('../server');
loadEnv(path.join(__dirname, '..', '.env'));
const { open } = require('../lib/db');
const { ensureAdmin } = require('../lib/users');

const [ident, password, name] = process.argv.slice(2);
if (!ident || !password) { console.error('Хэрэглээ: npm run admin -- <и-мэйл эсвэл утас> <нууц үг, 8+ тэмдэгт> [нэр]'); process.exit(1); }
const ctx = open(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
ensureAdmin(ctx, ident, password, name).then(r => {
  console.log(r.created ? 'Админ үүслээ:' : 'Админ болгож, нууц үгийг шинэчиллээ:', r.ident);
  ctx.db.close();
}).catch(e => { console.error(e.message); process.exit(1); });
