'use strict';
/* Өгөгдлийн сангийн найдвартай хуулбар (сервер ажиллаж байхад ч болно): npm run backup
   data/backups/app-ОГНОО.db файл үүснэ. Зураг, видео нь data/uploads хавтсанд байгаа тул тэр хавтсыг бас хуулна. */
const fs = require('node:fs');
const path = require('node:path');
const { loadEnv } = require('../server');
loadEnv(path.join(__dirname, '..', '.env'));
const { open } = require('../lib/db');

const dir = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const ctx = open(dir);
const out = path.join(dir, 'backups'); fs.mkdirSync(out, { recursive: true });
const file = path.join(out, 'app-' + new Date().toISOString().slice(0, 10) + '.db');
ctx.db.backup(file).then(() => { console.log('Хадгаллаа:', file); ctx.db.close(); })
  .catch(e => { console.error(e.message); process.exit(1); });
