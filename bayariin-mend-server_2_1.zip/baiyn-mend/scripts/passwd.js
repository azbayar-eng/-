'use strict';
/* Хэрэглэгч нууц үгээ мартсан үед шинэ нууц үг тохируулах (бүх төхөөрөмжөөс гаргана):
     npm run passwd -- 99112233 ШинэНууцҮг123                                                */
const path = require('node:path');
const bcrypt = require('bcryptjs');
const { loadEnv } = require('../server');
loadEnv(path.join(__dirname, '..', '.env'));
const { open } = require('../lib/db');
const V = require('../lib/validate');

(async () => {
  const [identRaw, pw] = process.argv.slice(2), ident = V.ident(identRaw || '');
  if (!ident || !pw || pw.length < 8) { console.error('Хэрэглээ: npm run passwd -- <и-мэйл эсвэл утас> <шинэ нууц үг, 8+ тэмдэгт>'); process.exit(1); }
  const ctx = open(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
  const row = ctx.q.userByIdent.get(ident);
  if (!row) { console.error('Ийм хэрэглэгч олдсонгүй:', ident); process.exit(1); }
  ctx.q.userPass.run(await bcrypt.hash(pw, 10), row.id); ctx.q.sessDelUser.run(row.id, '');
  console.log('Нууц үг солигдлоо:', row.name || '', ident); ctx.db.close();
})();
