/* Баярын мэнд: card engine. Pure canvas, no network, no framework.
   Shared by the artifact build and the server build.
   Everything is a deterministic function of time t, so previews, thumbnails and saved pictures all use the same code. */
(function (root) {
'use strict';
const TAU = Math.PI * 2;
const clamp = (x, a = 0, b = 1) => x < a ? a : x > b ? b : x;
const mix = (a, b, k) => a + (b - a) * k;
const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
const easeOut = x => 1 - Math.pow(1 - clamp(x), 3);
const easeIn = x => { x = clamp(x); return x * x * x; };
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; };
const hexMix = (h1, h2, k) => { const a = parseInt(h1.slice(1), 16), b = parseInt(h2.slice(1), 16); const c = s => Math.round(mix(a >> s & 255, b >> s & 255, k)); return '#' + ((1 << 24) | (c(16) << 16) | (c(8) << 8) | c(0)).toString(16).slice(1); };
const lum = hex => { const n = parseInt(hex.slice(1), 16); return (0.2126 * (n >> 16 & 255) + 0.7152 * (n >> 8 & 255) + 0.0722 * (n & 255)) / 255; };

/* ---------- Data. Order of THEME_IDS / FX_IDS / OCC_IDS is part of old share links: only append. ---------- */
const THEME_IDS = ['blush', 'gold', 'sky', 'night', 'green', 'sun'];
const THEMES = {
  blush: { name: 'Ягаан', bg: ['#FFE3EC', '#FF9EBB'], glow: '#FFFFFF', ink: '#4A1230', soft: '#6E2A49', a: '#E8336D', b: '#FFFFFF', c: '#F2A93B', light: true, pal: ['#E8336D', '#FFFFFF', '#F2A93B', '#B5179E', '#FF6F9C', '#7C3AED'] },
  gold: { name: 'Улаан алт', bg: ['#8E1030', '#D8284B'], glow: '#FF9A6B', ink: '#FFE9B8', soft: '#FFD58A', a: '#FFC857', b: '#FFF1CF', c: '#FF6B6B', light: false, pal: ['#FFC857', '#FFF1CF', '#FF6B6B', '#FFFFFF', '#FF9A3C', '#FFD9A0'] },
  sky: { name: 'Хөх тэнгэр', bg: ['#0B3C8C', '#47B0FF'], glow: '#BFE6FF', ink: '#FFFFFF', soft: '#DCF0FF', a: '#FFD35C', b: '#FFFFFF', c: '#FF8FB1', light: false, pal: ['#FFFFFF', '#FFD35C', '#8FD3FF', '#FFB3C7', '#C8F0FF', '#5DE0B0'] },
  night: { name: 'Шөнө', bg: ['#160C3A', '#5B2A9E'], glow: '#B07CFF', ink: '#FFF3D6', soft: '#E6D4FF', a: '#FFC857', b: '#FF6FB5', c: '#7FD6FF', light: false, pal: ['#FFC857', '#FF6FB5', '#7FD6FF', '#FFFFFF', '#B07CFF', '#7DFFB8'] },
  green: { name: 'Ногоон', bg: ['#12301F', '#4F7F3A'], glow: '#C2E59A', ink: '#FFF2C9', soft: '#E1EDC8', a: '#F2C14E', b: '#FFF2C9', c: '#E0603A', light: false, pal: ['#F2C14E', '#FFF2C9', '#9BD16B', '#FFFFFF', '#E0603A', '#CFE8A8'] },
  sun: { name: 'Наран', bg: ['#FFD54A', '#FF7A3D'], glow: '#FFF3B0', ink: '#3B1708', soft: '#5E250C', a: '#D6246E', b: '#FFFFFF', c: '#3FA9F5', light: true, pal: ['#D6246E', '#FFFFFF', '#3FA9F5', '#7ED957', '#8E44AD', '#FFF3B0'] }
};
/* A custom theme is stored as seven colours; the rest is derived. */
function buildTheme(d) {
  const light = lum(d.bg0) * 0.5 + lum(d.bg1) * 0.5 > 0.6;
  return {
    name: d.name || 'Өнгө', bg: [d.bg0, d.bg1], glow: d.glow, ink: d.ink, soft: hexMix(d.ink, d.bg0, light ? 0.18 : 0.12),
    a: d.a, b: d.b, c: d.c, light,
    pal: [d.a, d.b, d.c, hexMix(d.a, d.b, 0.5), hexMix(d.b, d.c, 0.5), hexMix(d.c, d.a, 0.5)]
  };
}
function registerTheme(id, def) { THEMES[id] = def; }
function unregisterThemes(keepIds) { Object.keys(THEMES).forEach(k => { if (!THEME_IDS.includes(k) && !keepIds.includes(k)) delete THEMES[k]; }); }

const FX_IDS = ['fireworks', 'confetti', 'balloons', 'hearts', 'petals', 'snow', 'spider', 'ghost',
  'cannon', 'stars', 'lanterns', 'bubbles', 'fireflies', 'aurora', 'coins', 'disco', 'ribbons', 'bats', 'eyes'];
const FXS = {
  fireworks: { name: 'Салют' }, confetti: { name: 'Конфетти' }, balloons: { name: 'Бөмбөлөг' }, hearts: { name: 'Зүрх' },
  petals: { name: 'Цэцгийн дэлбээ' }, snow: { name: 'Цас' }, cannon: { name: 'Конфетти буу' }, stars: { name: 'Одод буух' },
  lanterns: { name: 'Тэнгэрийн дэнлүү' }, bubbles: { name: 'Хөөс' }, fireflies: { name: 'Галт хорхой' }, aurora: { name: 'Туяа' },
  coins: { name: 'Алтан зоос' }, disco: { name: 'Диско гэрэл' }, ribbons: { name: 'Тууз' },
  spider: { name: 'Аалз', scare: true }, ghost: { name: 'Сүнс', scare: true }, bats: { name: 'Сарьсан багваахай', scare: true }, eyes: { name: 'Харанхуйн нүд', scare: true }
};
const OCC_IDS = ['bday', 'wed', 'women', 'army', 'tsagaan', 'newyear', 'friend', 'other'];
const OCC = {
  bday: { name: 'Төрсөн өдөр', title: 'Төрсөн өдрийн мэнд!', theme: 'sun', motif: 'cake',
    msg: 'Төрсөн өдрийн чинь мэнд хүргэе! Амьдралд чинь аз жаргал, эрүүл энх, хүссэн бүхэн чинь биелж байх болтугай.',
    fx: ['confetti', 'balloons', 'cannon', 'fireworks', 'spider', 'ghost', 'hearts', 'disco'] },
  wed: { name: 'Гэрлэсний ой', title: 'Гэрлэсний ойн мэнд!', theme: 'gold', motif: 'rings',
    msg: 'Гэрлэсний ойн мэнд хүргэе! Хайр сэтгэл тань жил ирэх тусам улам гүнзгийрч, гэр бүл тань аз жаргалаар дүүрэн байх болтугай.',
    fx: ['hearts', 'petals', 'lanterns', 'fireworks', 'confetti', 'fireflies', 'bubbles', 'stars'] },
  women: { name: '3-р сарын 8', title: 'Эмэгтэйчүүдийн баярын мэнд!', theme: 'blush', motif: 'tulips',
    msg: 'Гурван сарын 8-ны баярын мэнд хүргэе! Таны инээмсэглэл, дулаан сэтгэл эргэн тойрныхоо хүн бүрт гэрэл болдог. Үргэлж жаргалтай байгаарай.',
    fx: ['petals', 'hearts', 'bubbles', 'ribbons', 'confetti', 'balloons', 'fireworks', 'fireflies'] },
  army: { name: 'Цэргийн баяр', title: 'Цэргийн баярын мэнд!', theme: 'green', motif: 'star',
    msg: 'Цэргийн баярын мэнд хүргэе! Эх орноо хамгаалагчдын зориг, хүч чадал, нэр төрийг хүндэлнэ. Эрүүл энх, амжилт дагуулах болтугай.',
    fx: ['fireworks', 'cannon', 'confetti', 'stars', 'balloons', 'aurora', 'snow', 'ribbons'] },
  tsagaan: { name: 'Цагаан сар', title: 'Цагаан сарын мэнд!', theme: 'sky', motif: 'ugalz',
    msg: 'Амар байна уу? Цагаан сарын мэнд хүргэе! Шинэ жилдээ тавтай морилно уу. Идээ ундаа цагаан, ерөөл сайхан, гэр бүл амгалан байх болтугай.',
    fx: ['snow', 'aurora', 'lanterns', 'fireworks', 'coins', 'stars', 'petals', 'confetti'] },
  newyear: { name: 'Шинэ жил', title: 'Шинэ жилийн мэнд!', theme: 'night', motif: 'tree',
    msg: 'Шинэ жилийн мэнд хүргэе! Шинэ онд хүссэн бүхэн чинь биелж, аз жаргал, эрүүл энх, амжилт дагуулах болтугай.',
    fx: ['fireworks', 'snow', 'stars', 'cannon', 'aurora', 'disco', 'coins', 'confetti'] },
  friend: { name: 'Найздаа', title: 'Сайхан өдрийн мэнд!', theme: 'blush', motif: 'gift',
    msg: 'Чам шиг сайхан найзтай болсондоо баяртай байна. Өнөөдөр инээмсэглэл дүүрэн, сайхан өдөр байх болтугай!',
    fx: ['spider', 'ghost', 'bats', 'eyes', 'confetti', 'cannon', 'hearts', 'disco'] },
  other: { name: 'Өөр баяр', title: 'Баярын мэнд!', theme: 'night', motif: 'burst',
    msg: 'Баярын мэнд хүргэе! Сайхан сэтгэл, эрүүл энх, аз жаргал дүүрэн өдрүүд дагуулах болтугай.',
    fx: ['fireworks', 'confetti', 'cannon', 'hearts', 'stars', 'balloons', 'spider', 'ghost'] }
};
function occFx(occ) {
  const top = (OCC[occ] || OCC.other).fx;
  const rest = FX_IDS.filter(x => !top.includes(x));
  return [...top, ...rest.filter(x => !FXS[x].scare), ...rest.filter(x => FXS[x].scare)];
}
/* Frame (seconds) used for small previews and for the saved picture. */
const THUMB_T = { fireworks: 2.3, confetti: 1, balloons: 1, hearts: 1, petals: 1, snow: 1, spider: 3.9, ghost: 3.9, cannon: 1.0, stars: 2.0, lanterns: 1, bubbles: 1, fireflies: 1, aurora: 1, coins: 1, disco: 1, ribbons: 1, bats: 3.9, eyes: 4.5 };
const FINAL_T = Object.assign({}, THUMB_T, { spider: 7.9, ghost: 7.9, bats: 7.9, eyes: 7.9 });
const LOOP = { spider: 10, ghost: 10, bats: 10, eyes: 10 };

/* ---------- Drawing helpers ---------- */
function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
function heart(ctx, x, y, s) { ctx.beginPath(); ctx.moveTo(x, y + s * 0.9); ctx.bezierCurveTo(x - s * 1.5, y - s * 0.1, x - s * 0.7, y - s * 1.1, x, y - s * 0.35); ctx.bezierCurveTo(x + s * 0.7, y - s * 1.1, x + s * 1.5, y - s * 0.1, x, y + s * 0.9); ctx.closePath(); }
function sparkle(ctx, x, y, r) { ctx.beginPath(); ctx.moveTo(x, y - r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.quadraticCurveTo(x, y, x, y + r); ctx.quadraticCurveTo(x, y, x - r, y); ctx.quadraticCurveTo(x, y, x, y - r); ctx.fill(); }
function star5(ctx, x, y, R, r, rot) { rot = rot === undefined ? -Math.PI / 2 : rot; ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = rot + i * Math.PI / 5, d = i % 2 ? r : R; const px = x + Math.cos(a) * d, py = y + Math.sin(a) * d; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.closePath(); }
function petal(ctx, s) { ctx.beginPath(); ctx.moveTo(0, -s); ctx.bezierCurveTo(s * 0.9, -s * 0.5, s * 0.7, s * 0.6, 0, s); ctx.bezierCurveTo(-s * 0.7, s * 0.6, -s * 0.9, -s * 0.5, 0, -s); ctx.closePath(); }
function icing(ctx, x, y, wd, n) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + wd, y); const st = wd / n; for (let i = n; i > 0; i--) ctx.arc(x + st * (i - 0.5), y, st / 2, 0, Math.PI); ctx.closePath(); ctx.fill(); }
function ready(el) { if (!el) return false; if (el.tagName === 'VIDEO') return el.readyState >= 2 && el.videoWidth > 0; return !!(el.complete && el.naturalWidth > 0); }
function srcSize(el) { return el.tagName === 'VIDEO' ? [el.videoWidth, el.videoHeight] : [el.naturalWidth, el.naturalHeight]; }
function drawCover(ctx, el, x, y, w, h) { const [sw, sh] = srcSize(el); const k = Math.max(w / sw, h / sh); const dw = sw * k, dh = sh * k; ctx.drawImage(el, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh); }
function drawContain(ctx, el, cx, cy, size) { const [sw, sh] = srcSize(el); const k = Math.min(size / sw, size / sh); ctx.drawImage(el, cx - sw * k / 2, cy - sh * k / 2, sw * k, sh * k); }

/* ---------- Background ---------- */
function drawBg(ctx, w, h, u, th, t, R) {
  const g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, th.bg[0]); g.addColorStop(1, th.bg[1]);
  ctx.fillStyle = g; ctx.fillRect(-40, -40, w + 80, h + 80);
  if (R && R.bgEl && ready(R.bgEl)) {
    ctx.save(); drawCover(ctx, R.bgEl, -20, -20, w + 40, h + 40); ctx.restore();
    const sg = ctx.createLinearGradient(0, 0, 0, h); sg.addColorStop(0, rgba(th.bg[0], 0.5)); sg.addColorStop(1, rgba(th.bg[1], 0.62));
    ctx.fillStyle = sg; ctx.fillRect(-40, -40, w + 80, h + 80);
  }
  const rg = ctx.createRadialGradient(w / 2, h * 0.3, 0, w / 2, h * 0.3, u * 1.05); rg.addColorStop(0, rgba(th.glow, 0.5)); rg.addColorStop(1, rgba(th.glow, 0));
  ctx.fillStyle = rg; ctx.fillRect(-40, -40, w + 80, h + 80);
  const r = rng(5);
  for (let i = 0; i < 16; i++) { const x = r() * w + Math.sin(t * 0.25 + i) * u * 0.02, y = r() * h + Math.cos(t * 0.2 + i * 2) * u * 0.02, rad = u * (0.03 + r() * 0.09); ctx.fillStyle = rgba(th.glow, 0.05 + r() * 0.09); ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.fill(); }
  const m = Math.min(w, h) * 0.035;
  ctx.lineWidth = Math.max(1, u * 0.0045); ctx.strokeStyle = rgba(th.ink, 0.4); rr(ctx, m, m, w - 2 * m, h - 2 * m, u * 0.05); ctx.stroke();
  ctx.lineWidth = Math.max(1, u * 0.002); ctx.strokeStyle = rgba(th.ink, 0.2); rr(ctx, m * 1.7, m * 1.7, w - 3.4 * m, h - 3.4 * m, u * 0.04); ctx.stroke();
}
function drawTwinkles(ctx, w, h, u, th, t) {
  const r = rng(21);
  for (let i = 0; i < 26; i++) { const x = r() * w, y = r() * h, ph = r() * TAU, sz = u * (0.008 + r() * 0.014), sp = 1.2 + r(); const a = Math.pow(Math.max(0, Math.sin(t * sp + ph)), 2); ctx.fillStyle = rgba(i % 3 ? '#FFFFFF' : th.a, a * 0.9); sparkle(ctx, x, y, sz * 3); }
}

/* ---------- Motifs, photo, sticker (about s wide and tall, centred at cx,cy) ---------- */
const MOTIFS = {
  cake(ctx, cx, cy, s, th, t) {
    cy += Math.sin(t * 1.6) * s * 0.015;
    ctx.fillStyle = 'rgba(0,0,0,.16)'; ctx.beginPath(); ctx.ellipse(cx, cy + s * 0.46, s * 0.52, s * 0.07, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = th.a; rr(ctx, cx - s * 0.46, cy + s * 0.12, s * 0.92, s * 0.33, s * 0.06); ctx.fill();
    ctx.fillStyle = th.b; rr(ctx, cx - s * 0.32, cy - s * 0.12, s * 0.64, s * 0.26, s * 0.06); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; icing(ctx, cx - s * 0.46, cy + s * 0.12, s * 0.92, 7);
    ctx.fillStyle = th.c; icing(ctx, cx - s * 0.32, cy - s * 0.12, s * 0.64, 5);
    ctx.fillStyle = th.c; for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.arc(cx - s * 0.36 + i * s * 0.18, cy + s * 0.33, s * 0.022, 0, TAU); ctx.fill(); }
    for (let i = 0; i < 3; i++) {
      const x = cx + (i - 1) * s * 0.17, by = cy - s * 0.12, hh = s * 0.19;
      ctx.fillStyle = i === 1 ? th.a : '#FFFFFF'; ctx.fillRect(x - s * 0.025, by - hh, s * 0.05, hh);
      ctx.fillStyle = th.c; for (let k = 0; k < 3; k++) ctx.fillRect(x - s * 0.025, by - hh + k * hh / 3 + hh / 12, s * 0.05, hh / 9);
      const f = 1 + 0.18 * Math.sin(t * 9 + i * 2), fy = by - hh - s * 0.05;
      const gl = ctx.createRadialGradient(x, fy, 0, x, fy, s * 0.18); gl.addColorStop(0, 'rgba(255,200,80,.5)'); gl.addColorStop(1, 'rgba(255,200,80,0)');
      ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, fy, s * 0.18, 0, TAU); ctx.fill();
      ctx.fillStyle = '#FFB02E'; ctx.beginPath(); ctx.ellipse(x, fy, s * 0.032, s * 0.058 * f, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#FFF3B0'; ctx.beginPath(); ctx.ellipse(x, fy + s * 0.012, s * 0.016, s * 0.03 * f, 0, 0, TAU); ctx.fill();
    }
  },
  rings(ctx, cx, cy, s, th, t) {
    cy += Math.sin(t * 1.5) * s * 0.015;
    const r = s * 0.25, dx = s * 0.14, y = cy + s * 0.1;
    ctx.lineCap = 'round'; ctx.lineWidth = s * 0.065;
    ctx.strokeStyle = th.a; ctx.beginPath(); ctx.arc(cx - dx, y, r, 0, TAU); ctx.stroke();
    ctx.strokeStyle = th.b; ctx.beginPath(); ctx.arc(cx + dx, y, r, 0, TAU); ctx.stroke();
    ctx.strokeStyle = th.a; ctx.beginPath(); ctx.arc(cx - dx, y, r, -1.3, -0.7); ctx.stroke();
    const gx = cx - dx, gy = y - r - s * 0.07;
    ctx.fillStyle = '#FFFFFF'; ctx.beginPath(); ctx.moveTo(gx - s * 0.07, gy); ctx.lineTo(gx - s * 0.04, gy - s * 0.06); ctx.lineTo(gx + s * 0.04, gy - s * 0.06); ctx.lineTo(gx + s * 0.07, gy); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#BFE3FF'; ctx.beginPath(); ctx.moveTo(gx - s * 0.07, gy); ctx.lineTo(gx + s * 0.07, gy); ctx.lineTo(gx, gy + s * 0.07); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, gx + s * 0.1, gy - s * 0.1, s * (0.07 + 0.04 * Math.sin(t * 3)));
    ctx.fillStyle = rgba(th.ink, 0.9); ctx.globalAlpha = 0.55; heart(ctx, cx, y - r * 1.55, s * 0.05); ctx.fill(); ctx.globalAlpha = 1;
  },
  tulips(ctx, cx, cy, s, th, t) {
    const base = cy + s * 0.48, cols = [th.a, th.b, th.c], xs = [-0.21, 0, 0.21], hs = [0.0, -0.14, 0.0];
    ctx.lineCap = 'round'; ctx.fillStyle = '#34B067';
    for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx, base); ctx.bezierCurveTo(cx + sd * s * 0.12, base - s * 0.5, cx + sd * s * 0.38, base - s * 0.34, cx + sd * s * 0.38, base - s * 0.12); ctx.bezierCurveTo(cx + sd * s * 0.28, base - s * 0.26, cx + sd * s * 0.12, base - s * 0.12, cx, base); ctx.fill(); }
    for (let i = 0; i < 3; i++) {
      const sway = Math.sin(t * 1.4 + i * 1.3) * s * 0.02, hx = cx + xs[i] * s + sway, hy = cy + s * (hs[i] - 0.06), r = s * 0.14;
      ctx.strokeStyle = '#2E9B58'; ctx.lineWidth = s * 0.03; ctx.beginPath(); ctx.moveTo(cx + xs[i] * s * 0.3, base); ctx.quadraticCurveTo(cx + xs[i] * s * 0.9, base - s * 0.35, hx, hy + r * 0.9); ctx.stroke();
      ctx.fillStyle = cols[i]; ctx.beginPath(); ctx.moveTo(hx - r, hy - r * 0.9); ctx.quadraticCurveTo(hx - r * 1.2, hy + r * 0.6, hx, hy + r * 1.0); ctx.quadraticCurveTo(hx + r * 1.2, hy + r * 0.6, hx + r, hy - r * 0.9); ctx.lineTo(hx + r * 0.5, hy - r * 0.3); ctx.lineTo(hx, hy - r * 1.2); ctx.lineTo(hx - r * 0.5, hy - r * 0.3); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.28)'; ctx.beginPath(); ctx.moveTo(hx, hy - r * 1.2); ctx.quadraticCurveTo(hx - r * 0.55, hy + r * 0.1, hx, hy + r * 1.0); ctx.quadraticCurveTo(hx + r * 0.55, hy + r * 0.1, hx, hy - r * 1.2); ctx.fill();
    }
    ctx.fillStyle = th.a; ctx.beginPath(); ctx.ellipse(cx, base - s * 0.1, s * 0.07, s * 0.035, 0, 0, TAU); ctx.fill();
  },
  star(ctx, cx, cy, s, th, t) {
    const R = s * 0.4, p = 1 + 0.03 * Math.sin(t * 2.2);
    ctx.fillStyle = rgba(th.ink, 0.1); ctx.beginPath(); ctx.arc(cx, cy, R * 1.02, 0, TAU); ctx.fill();
    ctx.strokeStyle = th.b; ctx.lineWidth = s * 0.012; ctx.lineCap = 'round';
    for (const sd of [-1, 1]) {
      ctx.beginPath();
      for (let i = 0; i <= 8; i++) { const b = 0.12 + i * 0.2, px = cx + sd * Math.sin(b) * R, py = cy + Math.cos(b) * R; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
      ctx.stroke(); ctx.fillStyle = th.b;
      for (let i = 0; i <= 8; i++) { const b = 0.12 + i * 0.2, px = cx + sd * Math.sin(b) * R * 1.04, py = cy + Math.cos(b) * R * 1.04; const rot = Math.atan2(-Math.sin(b), sd * Math.cos(b)) + sd * 0.55; ctx.beginPath(); ctx.ellipse(px, py, s * 0.075, s * 0.03, rot, 0, TAU); ctx.fill(); }
    }
    ctx.save(); ctx.translate(cx, cy + s * 0.01); ctx.scale(p, p);
    ctx.fillStyle = th.a; star5(ctx, 0, 0, s * 0.26, s * 0.105); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.3)'; star5(ctx, 0, 0, s * 0.12, s * 0.05); ctx.fill(); ctx.restore();
  },
  ugalz(ctx, cx, cy, s, th, t) {
    const r = s * 0.17; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const spiral = (x0, y0, phase, sc) => { ctx.beginPath(); const N = 80; for (let i = 0; i <= N; i++) { const q = i / N * 3.3 * Math.PI, rad = r * sc * (1 - q / (3.8 * Math.PI)), ang = phase + q; const px = x0 + Math.cos(ang) * rad, py = y0 + Math.sin(ang) * rad; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke(); };
    for (const sg of [-1, 1]) {
      const y0 = cy + sg * s * 0.2; ctx.lineWidth = s * 0.055; ctx.strokeStyle = th.a;
      spiral(cx - r, y0, 0, 1); spiral(cx + r, y0, Math.PI, 1);
      ctx.fillStyle = th.b; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.arc(cx + sx * r, y0, s * 0.02, 0, TAU); ctx.fill(); }
    }
    ctx.fillStyle = th.b; sparkle(ctx, cx, cy, s * 0.07 * (1 + 0.15 * Math.sin(t * 2.5)));
    ctx.fillStyle = th.a; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx + sx * s * 0.46, cy - s * 0.06); ctx.lineTo(cx + sx * s * 0.5, cy); ctx.lineTo(cx + sx * s * 0.46, cy + s * 0.06); ctx.lineTo(cx + sx * s * 0.42, cy); ctx.closePath(); ctx.fill(); }
  },
  tree(ctx, cx, cy, s, th, t) {
    cy += Math.sin(t * 1.3) * s * 0.012;
    ctx.fillStyle = '#8A4B25'; ctx.fillRect(cx - s * 0.05, cy + s * 0.37, s * 0.1, s * 0.12);
    const tiers = [[cy + s * 0.4, s * 0.7, s * 0.3, '#1F9D5C'], [cy + s * 0.16, s * 0.56, s * 0.28, '#27B26A'], [cy - s * 0.06, s * 0.42, s * 0.26, '#2FC37A']];
    for (const [y, w, h, c] of tiers) { ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(cx, y - h); ctx.lineTo(cx + w / 2, y); ctx.lineTo(cx - w / 2, y); ctx.closePath(); ctx.fill(); }
    [[-0.2, 0.34], [0.15, 0.37], [0.0, 0.2], [-0.14, 0.12], [0.18, 0.14], [-0.06, -0.02], [0.09, -0.06]].forEach((b, i) => { ctx.fillStyle = th.pal[i % th.pal.length]; ctx.beginPath(); ctx.arc(cx + b[0] * s, cy + b[1] * s - s * 0.02, s * 0.03, 0, TAU); ctx.fill(); });
    const p = 1 + 0.1 * Math.sin(t * 3); ctx.fillStyle = th.a; star5(ctx, cx, cy - s * 0.37, s * 0.075 * p, s * 0.032 * p); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, cx + s * 0.09, cy - s * 0.42, s * 0.05 * (0.6 + 0.4 * Math.sin(t * 4)));
  },
  gift(ctx, cx, cy, s, th, t) {
    const hop = Math.abs(Math.sin(t * 2.4)) * s * 0.05;
    ctx.fillStyle = 'rgba(0,0,0,.15)'; ctx.beginPath(); ctx.ellipse(cx, cy + s * 0.46, s * 0.4 * (1 - hop / s * 2), s * 0.05, 0, 0, TAU); ctx.fill();
    cy -= hop;
    ctx.fillStyle = th.a; rr(ctx, cx - s * 0.34, cy + s * 0.02, s * 0.68, s * 0.42, s * 0.04); ctx.fill();
    ctx.fillStyle = th.b; rr(ctx, cx - s * 0.39, cy - s * 0.12, s * 0.78, s * 0.16, s * 0.04); ctx.fill();
    ctx.fillStyle = th.c; ctx.fillRect(cx - s * 0.05, cy - s * 0.12, s * 0.1, s * 0.56);
    for (const sd of [-1, 1]) { ctx.save(); ctx.translate(cx + sd * s * 0.1, cy - s * 0.2); ctx.rotate(sd * 0.55); ctx.fillStyle = th.c; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.13, s * 0.075, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(0,0,0,.14)'; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.06, s * 0.035, 0, 0, TAU); ctx.fill(); ctx.restore(); }
    ctx.fillStyle = th.c; ctx.beginPath(); ctx.arc(cx, cy - s * 0.17, s * 0.05, 0, TAU); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, cx + s * 0.34, cy - s * 0.22, s * 0.06 * (0.6 + 0.4 * Math.sin(t * 3.5)));
  },
  burst(ctx, cx, cy, s, th, t) {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * 0.25);
    for (let i = 0; i < 12; i++) { ctx.rotate(TAU / 12); ctx.fillStyle = i % 2 ? th.a : th.b; ctx.beginPath(); ctx.moveTo(s * 0.15, -s * 0.03); ctx.lineTo(i % 2 ? s * 0.38 : s * 0.46, 0); ctx.lineTo(s * 0.15, s * 0.03); ctx.closePath(); ctx.fill(); }
    ctx.restore();
    ctx.fillStyle = th.a; ctx.beginPath(); ctx.arc(cx, cy, s * 0.15, 0, TAU); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, cx, cy, s * (0.14 + 0.02 * Math.sin(t * 3)));
  }
};
function drawPhoto(ctx, cx, cy, s, th, img, t) {
  const r = s * 0.42;
  ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = s * 0.08; ctx.shadowOffsetY = s * 0.02; ctx.fillStyle = '#FFFFFF'; ctx.beginPath(); ctx.arc(cx, cy, r + s * 0.03, 0, TAU); ctx.fill(); ctx.restore();
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.clip(); drawCover(ctx, img, cx - r, cy - r, r * 2, r * 2); ctx.restore();
  ctx.strokeStyle = th.a; ctx.lineWidth = s * 0.03; ctx.beginPath(); ctx.arc(cx, cy, r + s * 0.045, 0, TAU); ctx.stroke();
  ctx.save(); ctx.strokeStyle = th.b; ctx.lineWidth = s * 0.016; ctx.lineCap = 'round'; ctx.setLineDash([s * 0.02, s * 0.065]); ctx.lineDashOffset = -t * s * 0.1; ctx.beginPath(); ctx.arc(cx, cy, r + s * 0.1, 0, TAU); ctx.stroke(); ctx.restore();
  for (let k = 0; k < 6; k++) { const a = t * 0.6 + k * TAU / 6, rad = r + s * 0.17; ctx.fillStyle = k % 2 ? '#FFFFFF' : th.a; sparkle(ctx, cx + Math.cos(a) * rad, cy + Math.sin(a) * rad, s * (0.035 + 0.02 * Math.sin(t * 3 + k))); }
}
function drawSticker(ctx, cx, cy, s, el, t) { cy += Math.sin(t * 1.6) * s * 0.02; ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.28)'; ctx.shadowBlur = s * 0.06; drawContain(ctx, el, cx, cy, s * 1.0); ctx.restore(); }

/* ---------- Effects ---------- */
const FW_P = 1.05;
function fxFireworks(ctx, w, h, u, th, t) {
  const kMin = Math.max(0, Math.floor((t - 2.4) / FW_P)), kMax = Math.floor(t / FW_P);
  for (let k = kMin; k <= kMax; k++) {
    const r = rng(k * 7919 + 17), tau = t - k * FW_P;
    const x = w * (0.16 + 0.68 * r()), ay = h * (0.1 + 0.28 * r()), c1 = th.pal[(r() * th.pal.length) | 0], c2 = th.pal[(r() * th.pal.length) | 0];
    const rise = 0.72;
    if (tau < rise) { const p = easeOut(tau / rise), y = mix(h * 1.02, ay, p); ctx.strokeStyle = rgba('#FFFFFF', 0.9); ctx.lineWidth = u * 0.008; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + u * 0.1 * (1 - p * 0.6)); ctx.stroke(); continue; }
    const b = tau - rise; if (b > 2.1) continue;
    const life = clamp(1 - b / 1.9);
    if (b < 0.14) { const gl = ctx.createRadialGradient(x, ay, 0, x, ay, u * 0.2); gl.addColorStop(0, rgba('#FFFFFF', 0.8 * (1 - b / 0.14))); gl.addColorStop(1, rgba('#FFFFFF', 0)); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, ay, u * 0.2, 0, TAU); ctx.fill(); }
    const n = 56;
    for (let i = 0; i < n; i++) {
      const inner = i % 2, ang = i / n * TAU + (r() - 0.5) * 0.12, rad = u * ((inner ? 0.2 : 0.34) * (0.85 + 0.2 * r()));
      const pos = bb => { const d = rad * (1 - Math.exp(-3.2 * bb)); return [x + Math.cos(ang) * d, ay + Math.sin(ang) * d + u * 0.16 * bb * bb]; };
      const [px, py] = pos(b), [qx, qy] = pos(Math.max(0, b - 0.06));
      const al = Math.pow(life, 1.3) * (0.7 + 0.3 * Math.sin(b * 38 + i));
      ctx.strokeStyle = rgba(inner ? c2 : c1, al * 0.7); ctx.lineWidth = u * 0.006; ctx.beginPath(); ctx.moveTo(qx, qy); ctx.lineTo(px, py); ctx.stroke();
      ctx.fillStyle = rgba(inner ? c2 : c1, al); ctx.beginPath(); ctx.arc(px, py, u * 0.0075, 0, TAU); ctx.fill();
    }
  }
}
function fxConfetti(ctx, w, h, u, th, t, opt) {
  const fromTop = opt && opt.fromTop, r = rng(11), n = 70;
  for (let i = 0; i < n; i++) {
    const x0 = r(), sp = 0.15 + r() * 0.22, ph = r() * TAU, sz = u * (0.016 + r() * 0.02), col = th.pal[(r() * th.pal.length) | 0], rs = 2 + r() * 4, o = r(), pad = sz * 6;
    let f; if (fromTop) { f = t * sp - o * 0.5; if (f < 0) continue; } else f = o + t * sp;
    const y = (f % 1) * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 1.3 + ph) * u * 0.04, rot = t * rs + ph, flip = Math.cos(t * rs * 1.3 + ph);
    ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(1, flip); ctx.fillStyle = col; ctx.fillRect(-sz, -sz * 0.5, sz * 2, sz); ctx.restore();
  }
}
function fxBalloons(ctx, w, h, u, th, t) {
  const r = rng(31), n = 9;
  for (let i = 0; i < n; i++) {
    const sp = 0.05 + r() * 0.045, o = r(), rad = u * (0.06 + r() * 0.04), ph = r() * TAU, col = th.pal[i % th.pal.length];
    const f = (o + t * sp) % 1, y = h * 1.12 - f * (h * 1.4), x = w * ((i + 0.5) / n) + Math.sin(t * 0.9 + ph) * u * 0.05;
    ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = Math.max(1, u * 0.004);
    ctx.beginPath(); ctx.moveTo(x, y + rad * 1.25); ctx.quadraticCurveTo(x + Math.sin(t * 2 + ph) * rad * 0.5, y + rad * 2.3, x, y + rad * 3.2); ctx.stroke();
    ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(x, y, rad, rad * 1.2, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(x - rad * 0.35, y - rad * 0.45, rad * 0.2, rad * 0.32, 0.5, 0, TAU); ctx.fill();
    ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x, y + rad * 1.17); ctx.lineTo(x - rad * 0.14, y + rad * 1.4); ctx.lineTo(x + rad * 0.14, y + rad * 1.4); ctx.closePath(); ctx.fill();
  }
}
function fxHearts(ctx, w, h, u, th, t) {
  const r = rng(41), n = 22, cols = [th.a, th.b, th.c, '#FF5C8E'];
  for (let i = 0; i < n; i++) {
    const sp = 0.08 + r() * 0.1, o = r(), sz = u * (0.025 + r() * 0.04), ph = r() * TAU, col = cols[i % cols.length];
    const f = (o + t * sp) % 1, y = h * 1.08 - f * (h * 1.2), x = r() * w + Math.sin(t * 1.1 + ph) * u * 0.05;
    ctx.globalAlpha = clamp(y / (h * 0.3)) * 0.92; ctx.fillStyle = col; heart(ctx, x, y, sz); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.beginPath(); ctx.ellipse(x - sz * 0.5, y - sz * 0.45, sz * 0.18, sz * 0.1, -0.6, 0, TAU); ctx.fill();
  }
  ctx.globalAlpha = 1;
}
function fxPetals(ctx, w, h, u, th, t) {
  const r = rng(51), n = 40;
  for (let i = 0; i < n; i++) {
    const sp = 0.1 + r() * 0.14, o = r(), sz = u * (0.02 + r() * 0.025), ph = r() * TAU, col = th.pal[(r() * th.pal.length) | 0], rs = 1 + r() * 2.2, x0 = r();
    const pad = sz * 4, f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 0.9 + ph) * u * 0.07;
    ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(t * rs + ph) * 0.9 + ph); ctx.scale(0.45 + 0.55 * Math.abs(Math.cos(t * rs * 0.9 + ph)), 1); ctx.globalAlpha = 0.92; ctx.fillStyle = col; petal(ctx, sz); ctx.fill(); ctx.restore();
  }
}
function fxSnow(ctx, w, h, u, th, t) {
  const r = rng(61);
  for (let i = 0; i < 80; i++) { const sp = 0.07 + r() * 0.14, o = r(), sz = u * (0.004 + r() * 0.01), ph = r() * TAU, x0 = r(), pad = sz * 4; const f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 0.8 + ph) * u * 0.04; ctx.fillStyle = 'rgba(255,255,255,.88)'; ctx.beginPath(); ctx.arc(x, y, sz, 0, TAU); ctx.fill(); }
  for (let i = 0; i < 7; i++) {
    const sp = 0.05 + r() * 0.05, o = r(), sz = u * (0.02 + r() * 0.02), ph = r() * TAU, x0 = r(), pad = sz * 4;
    const f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 0.7 + ph) * u * 0.05;
    ctx.save(); ctx.translate(x, y); ctx.rotate(t * 0.5 + ph); ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = Math.max(1, sz * 0.14); ctx.lineCap = 'round';
    for (let k = 0; k < 3; k++) { ctx.rotate(Math.PI / 3); ctx.beginPath(); ctx.moveTo(-sz, 0); ctx.lineTo(sz, 0); ctx.stroke(); }
    ctx.restore();
  }
}
const CAN_P = 2.6;
function fxCannon(ctx, w, h, u, th, t) {
  const kMin = Math.max(0, Math.floor((t - 2.7) / CAN_P)), kMax = Math.floor(t / CAN_P);
  for (let k = kMin; k <= kMax; k++) {
    const tau = t - (k * CAN_P + 0.35); if (tau < 0 || tau > 2.5) continue;
    const r = rng(k * 313 + 7);
    for (const sd of [-1, 1]) {
      const ox = sd < 0 ? w * 0.05 : w * 0.95, oy = h * 0.97;
      if (tau < 0.2) { const gl = ctx.createRadialGradient(ox, oy, 0, ox, oy, u * 0.25); gl.addColorStop(0, rgba('#FFFFFF', 0.85 * (1 - tau / 0.2))); gl.addColorStop(1, rgba('#FFFFFF', 0)); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(ox, oy, u * 0.25, 0, TAU); ctx.fill(); }
      for (let i = 0; i < 42; i++) {
        const a = 0.2 + 0.55 * r(), ang = -Math.PI / 2 - sd * a, sp = u * (1.1 + 0.9 * r()), col = th.pal[(r() * th.pal.length) | 0], sz = u * (0.012 + 0.014 * r()), rs = 4 + 8 * r(), ph = r() * TAU;
        const d = (1 - Math.exp(-2.2 * tau)) / 2.2;
        const x = ox + Math.cos(ang) * sp * d, y = oy + Math.sin(ang) * sp * d + 0.5 * u * 1.1 * tau * tau;
        const al = clamp(1 - Math.max(0, tau - 1.6) / 0.9);
        ctx.save(); ctx.translate(x, y); ctx.rotate(tau * rs + ph); ctx.scale(1, Math.cos(tau * 7 + i)); ctx.globalAlpha = al; ctx.fillStyle = col; ctx.fillRect(-sz, -sz * 0.5, sz * 2, sz); ctx.restore();
      }
    }
  }
  ctx.globalAlpha = 1;
}
function fxStars(ctx, w, h, u, th, t) {
  const r = rng(71);
  for (let i = 0; i < 7; i++) {
    const P = 2.2 + r() * 2.6, o = r() * P, x0 = w * (0.35 + 0.75 * r()), y0 = h * (-0.05 + 0.45 * r()), len = u * (0.28 + 0.2 * r()), ang = Math.PI * 0.78;
    const f = ((t + o) % P) / P; if (f > 0.3) continue;
    const p = f / 0.3, x = x0 + Math.cos(ang) * u * 1.1 * p, y = y0 + Math.sin(ang) * u * 1.1 * p, tx = x - Math.cos(ang) * len, ty = y - Math.sin(ang) * len;
    const g = ctx.createLinearGradient(x, y, tx, ty); g.addColorStop(0, 'rgba(255,255,255,' + (0.95 * (1 - p * 0.4)) + ')'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.strokeStyle = g; ctx.lineWidth = u * 0.009; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(tx, ty); ctx.stroke();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, x, y, u * 0.022);
  }
  const r2 = rng(72);
  for (let i = 0; i < 12; i++) { const x = r2() * w, y = r2() * h, ph = r2() * TAU, sz = u * (0.025 + r2() * 0.03); const a = 0.35 + 0.65 * Math.pow(Math.max(0, Math.sin(t * 1.5 + ph)), 2); ctx.fillStyle = rgba(i % 2 ? '#FFFFFF' : th.a, a); sparkle(ctx, x, y, sz); }
}
function fxLanterns(ctx, w, h, u, th, t) {
  const r = rng(81), n = 8;
  for (let i = 0; i < n; i++) {
    const sp = 0.035 + r() * 0.03, o = r(), sz = u * (0.07 + r() * 0.04), ph = r() * TAU;
    const f = (o + t * sp) % 1, y = h * 1.1 - f * (h * 1.3), x = w * ((i + 0.6) / n) + Math.sin(t * 0.7 + ph) * u * 0.05, fl = 0.85 + 0.15 * Math.sin(t * 6 + ph);
    const gl = ctx.createRadialGradient(x, y, 0, x, y, sz * 2.6); gl.addColorStop(0, 'rgba(255,190,90,' + (0.55 * fl) + ')'); gl.addColorStop(1, 'rgba(255,190,90,0)');
    ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y, sz * 2.6, 0, TAU); ctx.fill();
    const g = ctx.createLinearGradient(x, y - sz, x, y + sz); g.addColorStop(0, '#FFD27A'); g.addColorStop(1, '#F2762E');
    ctx.fillStyle = g; rr(ctx, x - sz * 0.62, y - sz * 0.8, sz * 1.24, sz * 1.6, sz * 0.3); ctx.fill();
    ctx.fillStyle = 'rgba(120,40,10,.55)'; ctx.fillRect(x - sz * 0.62, y - sz * 0.8, sz * 1.24, sz * 0.12); ctx.fillRect(x - sz * 0.62, y + sz * 0.68, sz * 1.24, sz * 0.12);
    ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(x, y, sz * 0.22, sz * 0.5, 0, 0, TAU); ctx.fill();
  }
}
function fxBubbles(ctx, w, h, u, th, t) {
  const r = rng(91);
  for (let i = 0; i < 26; i++) {
    const sp = 0.05 + r() * 0.08, o = r(), rad = u * (0.015 + r() * 0.05), ph = r() * TAU, x0 = r();
    const f = (o + t * sp) % 1, y = h * 1.05 - f * (h * 1.15), x = x0 * w + Math.sin(t * 1.3 + ph) * u * 0.04;
    ctx.fillStyle = 'rgba(255,255,255,.1)'; ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = Math.max(1, rad * 0.08); ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = Math.max(1, rad * 0.12); ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(x, y, rad * 0.72, -2.5, -1.7); ctx.stroke();
  }
}
function fxFireflies(ctx, w, h, u, th, t) {
  const r = rng(101);
  for (let i = 0; i < 44; i++) {
    const cx = r() * w, cy = h * (0.25 + 0.7 * r()), ax = u * (0.05 + 0.12 * r()), ay = u * (0.04 + 0.1 * r()), fx = 0.2 + r() * 0.5, fy = 0.25 + r() * 0.5, ph = r() * TAU, ps = 1.5 + r() * 2.5;
    const x = cx + Math.sin(t * fx + ph) * ax, y = cy + Math.cos(t * fy + ph * 1.3) * ay, a = 0.25 + 0.75 * Math.pow(Math.max(0, Math.sin(t * ps + ph)), 2);
    const col = th.light ? (i % 3 ? '#FF9A1F' : '#E0701A') : (i % 3 ? '#FFF3A0' : '#C8FF7A');
    const g = ctx.createRadialGradient(x, y, 0, x, y, u * 0.05); g.addColorStop(0, rgba(col, a)); g.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, u * 0.05, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,230,' + a + ')'; ctx.beginPath(); ctx.arc(x, y, u * 0.0055, 0, TAU); ctx.fill();
  }
}
function fxAurora(ctx, w, h, u, th, t) {
  const cols = [th.a, th.c, th.b];
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let k = 0; k < 3; k++) {
    const base = h * (0.13 + 0.09 * k), amp = u * (0.06 + 0.03 * k), hh = u * 0.42;
    const yAt = x => base + Math.sin(x / u * 3.1 + t * 0.6 + k * 1.7) * amp + Math.sin(x / u * 1.7 - t * 0.4 + k) * amp * 0.6;
    const g = ctx.createLinearGradient(0, base - amp * 2, 0, base + hh); g.addColorStop(0, rgba(cols[k], 0)); g.addColorStop(0.25, rgba(cols[k], 0.4)); g.addColorStop(1, rgba(cols[k], 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(0, yAt(0));
    for (let x = 0; x <= w; x += w / 28) ctx.lineTo(x, yAt(x));
    ctx.lineTo(w, yAt(w) + hh); for (let x = w; x >= 0; x -= w / 28) ctx.lineTo(x, yAt(x) + hh * (0.8 + 0.2 * Math.sin(x / u * 8 + t))); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
}
function fxCoins(ctx, w, h, u, th, t) {
  const r = rng(111);
  for (let i = 0; i < 30; i++) {
    const sp = 0.12 + r() * 0.16, o = r(), sz = u * (0.02 + r() * 0.02), ph = r() * TAU, x0 = r(), rs = 3 + r() * 4, pad = sz * 4;
    const f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t + ph) * u * 0.03, sx = Math.max(0.1, Math.abs(Math.cos(t * rs + ph)));
    ctx.save(); ctx.translate(x, y); ctx.scale(sx, 1);
    const g = ctx.createLinearGradient(-sz, -sz, sz, sz); g.addColorStop(0, '#FFF2A8'); g.addColorStop(0.5, '#FFC940'); g.addColorStop(1, '#C98A12');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, sz, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(140,90,10,.7)'; ctx.lineWidth = Math.max(1, sz * 0.14); ctx.beginPath(); ctx.arc(0, 0, sz * 0.72, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.ellipse(-sz * 0.3, -sz * 0.3, sz * 0.18, sz * 0.1, -0.7, 0, TAU); ctx.fill();
    ctx.restore();
  }
}
function fxDisco(ctx, w, h, u, th, t) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 6; i++) {
    const ang = Math.PI / 2 + Math.sin(t * 0.9 + i * 1.3) * 0.75 + (i - 2.5) * 0.26, len = h * 1.15, x0 = w * 0.5, y0 = u * 0.09, sp = 0.1, col = th.pal[i % th.pal.length];
    const g = ctx.createLinearGradient(x0, y0, x0 + Math.cos(ang) * len, y0 + Math.sin(ang) * len); g.addColorStop(0, rgba(col, 0.55)); g.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + Math.cos(ang - sp) * len, y0 + Math.sin(ang - sp) * len); ctx.lineTo(x0 + Math.cos(ang + sp) * len, y0 + Math.sin(ang + sp) * len); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
  const bx = w / 2, by = u * 0.09, br = u * 0.07;
  ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = Math.max(1, u * 0.003); ctx.beginPath(); ctx.moveTo(bx, -10); ctx.lineTo(bx, by - br); ctx.stroke();
  const g = ctx.createRadialGradient(bx - br * 0.3, by - br * 0.3, br * 0.1, bx, by, br); g.addColorStop(0, '#FFFFFF'); g.addColorStop(1, '#8E96B5');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.fill();
  ctx.save(); ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.clip(); ctx.strokeStyle = 'rgba(60,70,100,.45)'; ctx.lineWidth = Math.max(1, br * 0.05);
  for (let k = -3; k <= 3; k++) { ctx.beginPath(); ctx.moveTo(bx - br, by + k * br / 3.5); ctx.lineTo(bx + br, by + k * br / 3.5); ctx.stroke(); const dx = ((k * br / 3.5 + t * br * 0.5) % (br * 0.6)); for (let m = -4; m <= 4; m++) { ctx.beginPath(); ctx.moveTo(bx + m * br * 0.3 + dx, by - br); ctx.lineTo(bx + m * br * 0.3 + dx, by + br); ctx.stroke(); } }
  ctx.restore();
  ctx.fillStyle = '#FFFFFF'; for (let k = 0; k < 4; k++) sparkle(ctx, bx + Math.cos(t * 2 + k * 1.6) * br * 1.5, by + Math.sin(t * 2 + k * 1.6) * br * 1.5, br * 0.35 * Math.max(0, Math.sin(t * 5 + k)));
}
function fxRibbons(ctx, w, h, u, th, t) {
  const r = rng(121);
  for (let i = 0; i < 14; i++) {
    const x0 = r() * w, sp = 0.1 + r() * 0.12, o = r(), len = u * (0.3 + 0.3 * r()), ph = r() * TAU, col = th.pal[(r() * th.pal.length) | 0];
    const f = (o + t * sp) % 1, head = f * (h + len * 1.3) - len * 0.2;
    ctx.strokeStyle = col; ctx.lineWidth = u * 0.012; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.globalAlpha = 0.92; ctx.beginPath();
    for (let j = 0; j <= 18; j++) { const yy = head - j / 18 * len, xx = x0 + Math.sin(j * 0.5 + t * 3 + ph) * u * 0.035 * (1 + j / 18); j ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy); }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}
const FXR = {
  fireworks: { fn: fxFireworks, front: true }, confetti: { fn: fxConfetti, front: true }, balloons: { fn: fxBalloons, front: false },
  hearts: { fn: fxHearts, front: true }, petals: { fn: fxPetals, front: true }, snow: { fn: fxSnow, front: true },
  cannon: { fn: fxCannon, front: true }, stars: { fn: fxStars, front: false }, lanterns: { fn: fxLanterns, front: false },
  bubbles: { fn: fxBubbles, front: true }, fireflies: { fn: fxFireflies, front: true }, aurora: { fn: fxAurora, front: false },
  coins: { fn: fxCoins, front: true }, disco: { fn: fxDisco, front: false }, ribbons: { fn: fxRibbons, front: true },
  spider: {}, ghost: {}, bats: {}, eyes: {}
};

/* ---------- Creatures ---------- */
function drawSpider(ctx, x, y, s, t) {
  ctx.save(); ctx.translate(x, y); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const wig = (i, k) => Math.sin(t * 9 + i * 1.7 + k) * s * 0.07;
  for (const sd of [-1, 1]) for (let i = 0; i < 4; i++) {
    const ay = -s * 0.25 + i * s * 0.28, mid = (i === 1 || i === 2);
    const kx = sd * s * (mid ? 1.5 : 1.2), ky = ay - s * (1.0 - i * 0.12) + wig(i, sd), fx = sd * s * (mid ? 2.25 : 2.0) + wig(i, 2), fy = ay + s * (0.9 + i * 0.35) + wig(i, 5);
    ctx.beginPath(); ctx.moveTo(sd * s * 0.35, ay); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy);
    ctx.strokeStyle = '#0E0712'; ctx.lineWidth = s * 0.13; ctx.stroke(); ctx.strokeStyle = 'rgba(150,90,180,.35)'; ctx.lineWidth = s * 0.03; ctx.stroke();
  }
  const g = ctx.createRadialGradient(-s * 0.25, s * 0.25, s * 0.1, 0, s * 0.65, s * 1.1); g.addColorStop(0, '#40254F'); g.addColorStop(1, '#0B0510');
  ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, s * 0.65, s * 0.85, s * 1.0, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#D62839';
  ctx.beginPath(); ctx.moveTo(-s * 0.2, s * 0.35); ctx.lineTo(s * 0.2, s * 0.35); ctx.lineTo(0, s * 0.66); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(-s * 0.22, s * 1.0); ctx.lineTo(s * 0.22, s * 1.0); ctx.lineTo(0, s * 0.66); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#1A0D22'; ctx.beginPath(); ctx.arc(0, -s * 0.35, s * 0.55, 0, TAU); ctx.fill();
  ctx.shadowColor = '#FF2B2B'; ctx.shadowBlur = s * 0.35; ctx.fillStyle = '#FF3B3B';
  for (const sd of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sd * s * 0.2, -s * 0.45, s * 0.13, s * 0.17, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(sd * s * 0.36, -s * 0.28, s * 0.05, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(sd * s * 0.1, -s * 0.68, s * 0.05, 0, TAU); ctx.fill(); }
  ctx.shadowBlur = 0; ctx.fillStyle = '#FFE6E6'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.arc(sd * s * 0.17, -s * 0.5, s * 0.04, 0, TAU); ctx.fill(); }
  ctx.fillStyle = '#F4F0E6'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * s * 0.08, -s * 0.02); ctx.lineTo(sd * s * 0.24, -s * 0.02); ctx.lineTo(sd * s * 0.14, s * 0.24); ctx.closePath(); ctx.fill(); }
  ctx.restore();
}
function drawGhost(ctx, x, y, s, t, mouth, alpha) {
  ctx.save(); ctx.translate(x, y); ctx.globalAlpha = alpha;
  ctx.shadowColor = 'rgba(180,205,255,.95)'; ctx.shadowBlur = s * 0.4;
  const g = ctx.createLinearGradient(0, -s, 0, s * 1.1); g.addColorStop(0, '#FFFFFF'); g.addColorStop(1, '#C9D6FF'); ctx.fillStyle = g;
  for (const sd of [-1, 1]) { ctx.save(); ctx.translate(sd * s * 0.88, s * 0.1 + Math.sin(t * 5 + sd) * s * 0.06); ctx.rotate(sd * (0.7 + Math.sin(t * 5 + sd) * 0.15)); ctx.beginPath(); ctx.ellipse(0, 0, s * 0.3, s * 0.13, 0, 0, TAU); ctx.fill(); ctx.restore(); }
  ctx.beginPath(); ctx.moveTo(-s * 0.8, s * 0.95); ctx.lineTo(-s * 0.8, -s * 0.2); ctx.arc(0, -s * 0.2, s * 0.8, Math.PI, 0, false); ctx.lineTo(s * 0.8, s * 0.95);
  const n = 4, st = s * 1.6 / n; for (let i = 0; i < n; i++) { const x1 = s * 0.8 - st * i; ctx.quadraticCurveTo(x1 - st / 2, s * 0.95 + (i % 2 ? -1 : 1) * s * 0.22 + Math.sin(t * 6 + i) * s * 0.04, x1 - st, s * 0.95); }
  ctx.closePath(); ctx.fill(); ctx.shadowBlur = 0;
  ctx.fillStyle = '#1B1030'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sd * s * 0.28, -s * 0.28, s * 0.12, s * 0.2, 0, 0, TAU); ctx.fill(); }
  ctx.beginPath(); ctx.ellipse(0, s * 0.2, s * 0.17 * (0.8 + 0.5 * mouth), s * 0.26 * (0.6 + 0.7 * mouth), 0, 0, TAU); ctx.fill();
  ctx.restore();
}
function drawMoon(ctx, cx, cy, r) {
  const g = ctx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 2.4); g.addColorStop(0, 'rgba(255,244,200,.55)'); g.addColorStop(1, 'rgba(255,244,200,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r * 2.4, 0, TAU); ctx.fill();
  const g2 = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r); g2.addColorStop(0, '#FFFBE8'); g2.addColorStop(1, '#F4DC8C');
  ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(180,150,70,.22)'; [[-0.3, -0.2, 0.2], [0.35, 0.1, 0.14], [-0.1, 0.4, 0.12]].forEach(c => { ctx.beginPath(); ctx.arc(cx + c[0] * r, cy + c[1] * r, c[2] * r, 0, TAU); ctx.fill(); });
}
function drawBat(ctx, x, y, s, flap) {
  ctx.save(); ctx.translate(x, y); ctx.fillStyle = '#0A0510'; ctx.strokeStyle = 'rgba(170,110,220,.55)'; ctx.lineWidth = Math.max(1, s * 0.03); ctx.lineJoin = 'round';
  for (const sd of [-1, 1]) {
    const lift = flap * s * 0.55;
    ctx.beginPath(); ctx.moveTo(sd * s * 0.1, -s * 0.12);
    ctx.bezierCurveTo(sd * s * 0.5, -s * 0.55 - lift, sd * s * 0.95, -s * 0.35 - lift, sd * s * 1.15, -s * 0.05 - lift * 0.5);
    ctx.lineTo(sd * s * 0.9, s * 0.1 - lift * 0.3); ctx.lineTo(sd * s * 0.72, s * 0.02); ctx.lineTo(sd * s * 0.55, s * 0.24); ctx.lineTo(sd * s * 0.34, s * 0.06); ctx.lineTo(sd * s * 0.12, s * 0.2); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  ctx.beginPath(); ctx.ellipse(0, 0, s * 0.17, s * 0.28, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, -s * 0.3, s * 0.13, 0, TAU); ctx.fill();
  for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * s * 0.04, -s * 0.38); ctx.lineTo(sd * s * 0.14, -s * 0.52); ctx.lineTo(sd * s * 0.14, -s * 0.34); ctx.closePath(); ctx.fill(); }
  ctx.fillStyle = '#FF3B3B'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.arc(sd * s * 0.055, -s * 0.31, s * 0.03, 0, TAU); ctx.fill(); }
  ctx.restore();
}
function drawBats(ctx, w, h, u, top, ch, t) {
  const r = rng(131);
  for (let i = 0; i < 18; i++) {
    const ti = 2.65 + r() * 1.0, x1 = w * (0.2 + 0.6 * r()), y0 = h * (0.1 + 0.8 * r()), y1 = top + ch * (0.12 + 0.55 * r()), ph = r() * TAU, big = 0.6 + r() * 0.8;
    const p = (t - ti) / 1.7; if (p < 0 || p > 1.4) continue;
    const e = smooth(Math.min(p, 1)), sx = (i % 2 ? -0.12 : 1.12) * w, ex = Math.max(0, p - 1);
    const x = mix(sx, x1, e) + (x1 - sx) * ex * 1.1 + Math.sin(t * 3 + ph) * u * 0.03, y = mix(y0, y1, e) + Math.sin(t * 4 + ph) * u * 0.03 - ex * h * 0.7;
    drawBat(ctx, x, y, u * (0.05 + 0.09 * e) * big, Math.sin(t * 16 + ph));
  }
}
function drawEyePair(ctx, x, y, s, open, col, look) {
  if (open <= 0.01) return;
  for (const sd of [-1, 1]) {
    ctx.save(); ctx.translate(x + sd * s * 0.62, y);
    const gl = ctx.createRadialGradient(0, 0, 0, 0, 0, s * 1.2); gl.addColorStop(0, rgba(col, 0.45 * open)); gl.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(0, 0, s * 1.2, 0, TAU); ctx.fill();
    ctx.scale(1, Math.max(0.04, open));
    const g = ctx.createRadialGradient(0, 0, s * 0.05, 0, 0, s * 0.5); g.addColorStop(0, '#FFFFD0'); g.addColorStop(0.5, col); g.addColorStop(1, rgba(col, 0.3));
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.48, s * 0.34, sd * -0.22, 0, TAU); ctx.fill();
    ctx.fillStyle = '#0A0510'; ctx.beginPath(); ctx.ellipse(look * s * 0.1, 0, s * 0.07, s * 0.3, 0, 0, TAU); ctx.fill();
    ctx.restore();
  }
}
function drawEyes(ctx, w, h, u, top, ch, t) {
  const r = rng(141);
  for (let i = 0; i < 9; i++) {
    const ti = 2.7 + i * 0.16 + r() * 0.1, x = w * (0.14 + 0.72 * r()), y = top + ch * (0.1 + 0.8 * r()), s = u * (0.035 + 0.05 * r()), col = (i % 3 === 0) ? '#FF3B3B' : '#C6FF3B', ph = r() * TAU;
    const a = clamp((t - ti) / 0.25), fade = 1 - clamp((t - 4.9) / 0.35), bl = Math.sin(t * 1.9 + ph);
    drawEyePair(ctx, x, y, s, a * fade * (bl > 0.93 ? 1 - (bl - 0.93) / 0.07 * 0.95 : 1), col, Math.sin(t + ph));
  }
  if (t >= 4.1 && t < 5.4) {
    const p = easeIn((t - 4.1) / 0.5), open = t < 4.8 ? 1 : 1 - smooth((t - 4.8) / 0.3);
    drawEyePair(ctx, w / 2, top + ch * 0.45, u * (0.06 + 0.42 * p), open, '#FF3B3B', 0);
  }
}

/* ---------- Scare timeline (spider, ghost, bats, eyes) ---------- */
const SCARE_AT = 2.4;
function scareState(t, kind) {
  const a = SCARE_AT, R = { dark: 0, shake: 0, flash: 0, flashCol: '#FF1E1E', cr: null, shout: '', shoutY: 0.2, asan: 0, confetti: 0, moon: 0 };
  if (t >= a && t < a + 0.25) R.dark = (Math.floor((t - a) * 30) % 2) ? 0.92 : 0.3;
  else if (t >= a + 0.25 && t < 5.0) R.dark = kind === 'bats' ? 0.88 : 0.92;
  else if (t >= 5.0 && t < 5.6) R.dark = (kind === 'bats' ? 0.88 : 0.92) * (1 - smooth((t - 5.0) / 0.6));
  if (kind === 'spider') {
    if (t >= 2.65 && t < 5.5) {
      let y, sc;
      if (t < 3.2) { const p = easeIn((t - 2.65) / 0.55); y = mix(-0.25, 0.46, p); sc = mix(0.5, 1.5, p); }
      else if (t < 4.8) { y = 0.46 + Math.sin(t * 3.2) * 0.012; sc = 1.5 + Math.sin(t * 5) * 0.03; }
      else { const p = easeIn((t - 4.8) / 0.7); y = mix(0.46, -0.4, p); sc = 1.5; }
      R.cr = { kind: 'spider', y, sc };
    }
    if (t >= 3.2 && t < 4.2) R.shake = Math.exp(-(t - 3.2) * 5); else if (t >= 4.2 && t < 4.8) R.shake = 0.08;
    if (t >= 3.2) R.flash = 0.4 * Math.exp(-(t - 3.2) * 8);
  } else if (kind === 'ghost') {
    if (t >= 2.65 && t < 5.6) {
      let y = 0.46, sc, al = 1, mo = 0.5;
      if (t < 3.25) { const p = easeIn((t - 2.65) / 0.6); sc = mix(0.03, 1.0, p); mo = 0.2; }
      else if (t < 4.7) { sc = 1.0 + Math.sin(t * 4) * 0.03; mo = 0.5 + 0.5 * Math.sin(t * 9); }
      else { const p = easeIn((t - 4.7) / 0.9); sc = 1.0 + p * 0.3; y = mix(0.46, -0.45, p); al = 1 - smooth((t - 4.9) / 0.6); }
      R.cr = { kind: 'ghost', y, sc, al, mo, sway: (t >= 3.25 && t < 4.7) ? Math.sin(t * 2.1) : 0 };
    }
    if (t >= 3.25 && t < 4.7) { R.shout = 'БҮҮҮ!'; R.shake = 0.12; }
    if (t >= 3.25) R.flash = 0.55 * Math.exp(-(t - 3.25) * 9);
    R.flashCol = '#FFFFFF';
  } else if (kind === 'bats') {
    if (t >= 2.65 && t < 5.6) { R.cr = { kind: 'bats' }; R.moon = smooth((t - 2.65) / 0.5) * (1 - smooth((t - 5.0) / 0.6)); }
    if (t >= 2.9) R.flash = 0.3 * Math.exp(-(t - 2.9) * 8);
    R.flashCol = '#FFFFFF';
    if (t >= 3.4 && t < 4.6) R.shake = 0.05;
  } else if (X.HSCARE[kind]) {
    X.HSCARE[kind](t, R);
  } else {
    if (t >= 2.65 && t < 5.5) R.cr = { kind: 'eyes' };
    if (t >= 4.1) R.flash = 0.4 * Math.exp(-(t - 4.1) * 7);
    if (t >= 4.1 && t < 4.8) R.shake = 0.1;
  }
  if (R.darkK != null) R.dark *= R.darkK;
  if (t >= 5.5) R.asan = clamp((t - 5.5) / 0.35) * (t < 6.8 ? 1 : 1 - clamp((t - 6.8) / 0.4));
  R.confetti = t - 5.5;
  return R;
}
/* Sound cues fired between times a and b. */
function events(fx, a, b) {
  const out = [], cross = x => a < x && b >= x;
  if (fx === 'fireworks') { for (let k = Math.max(0, Math.floor((a - 0.72) / FW_P)); k <= Math.floor((b - 0.72) / FW_P); k++) if (cross(k * FW_P + 0.72)) out.push('burst'); }
  else if (fx === 'cannon') { for (let k = Math.max(0, Math.floor((a - 0.35) / CAN_P)); k <= Math.floor((b - 0.35) / CAN_P); k++) if (cross(k * CAN_P + 0.35)) out.push('burst'); }
  else if (fx === 'spider') { if (cross(2.45)) out.push('riser'); if (cross(3.2)) out.push('impact'); if (cross(5.5)) out.push('end'); }
  else if (fx === 'ghost') { if (cross(2.45)) out.push('riser'); if (cross(3.25)) out.push('boo'); if (cross(5.5)) out.push('end'); }
  else if (fx === 'bats') { if (cross(2.45)) out.push('riser'); if (cross(2.9)) out.push('impact'); if (cross(5.5)) out.push('end'); }
  else if (fx === 'eyes') { if (cross(2.45)) out.push('riser'); if (cross(4.1)) out.push('boo'); if (cross(5.5)) out.push('end'); }
  else if (X.EVENTS[fx]) return X.EVENTS[fx](cross);
  return out;
}

/* ---------- Text ---------- */
let TL = { key: '', v: null };
const F_NAME = 'Rubik,"Noto Sans",system-ui,sans-serif', F_TITLE = 'Pacifico,cursive', F_MSG = 'Nunito,"Noto Sans",system-ui,sans-serif';
function fitFont(ctx, str, fam, wt, maxW, start, min) { let s = start; const step = Math.max(0.5, start * 0.04); while (s > min) { ctx.font = `${wt} ${s}px ${fam}`; if (ctx.measureText(str).width <= maxW) break; s -= step; } return s; }
function wrapText(ctx, text, maxW) { const words = text.split(/\s+/).filter(Boolean), lines = []; let cur = ''; for (const wd of words) { const test = cur ? cur + ' ' + wd : wd; if (ctx.measureText(test).width <= maxW || !cur) cur = test; else { lines.push(cur); cur = wd; } } if (cur) lines.push(cur); return lines; }
function textLayout(ctx, w, h, u, R) {
  const key = [w | 0, h | 0, R.name, R.title, R.msg, R.from].join('|');
  if (TL.key === key) return TL.v;
  const v = {};
  v.nameSz = fitFont(ctx, R.name, F_NAME, 800, w * 0.84, u * 0.17, u * 0.06);
  v.titleSz = fitFont(ctx, R.title, F_TITLE, 400, w * 0.86, u * 0.09, u * 0.04);
  let sz = u * 0.046, lines;
  for (; ;) { ctx.font = `600 ${sz}px ${F_MSG}`; lines = wrapText(ctx, R.msg, w * 0.78); if (lines.length <= 5 || sz < u * 0.032) break; sz *= 0.93; }
  v.msgSz = sz; v.lines = lines;
  TL = { key, v }; return v;
}
function drawTexts(ctx, w, h, u, ch, top, th, R) {
  const v = textLayout(ctx, w, h, u, R);
  ctx.save(); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  ctx.shadowColor = th.light ? 'rgba(255,255,255,.6)' : 'rgba(0,0,0,.35)'; ctx.shadowBlur = u * 0.02; ctx.shadowOffsetY = u * 0.006;
  ctx.fillStyle = th.ink; ctx.font = `800 ${v.nameSz}px ${F_NAME}`; ctx.fillText(R.name, w / 2, top + ch * 0.565);
  ctx.fillStyle = th.a; ctx.font = `400 ${v.titleSz}px ${F_TITLE}`; ctx.fillText(R.title, w / 2, top + ch * 0.655);
  ctx.fillStyle = th.soft; ctx.font = `600 ${v.msgSz}px ${F_MSG}`;
  const lh = v.msgSz * 1.42; v.lines.forEach((ln, i) => ctx.fillText(ln, w / 2, top + ch * 0.725 + i * lh));
  if (R.from) { ctx.fillStyle = th.ink; ctx.font = `400 ${u * 0.05}px ${F_TITLE}`; ctx.fillText('— ' + R.from, w / 2, top + ch * 0.955); }
  ctx.restore();
}

/* ---------- Scene ---------- */
function render(ctx, w, h, t, R) {
  const th = THEMES[R.theme] || THEMES.sun, u = Math.min(w, h * 0.64), ch = Math.min(h, w * 1.8), top = (h - ch) / 2;
  const fxd = FXS[R.fx] || FXS.confetti, scare = !!fxd.scare, T = scare ? scareState(t, R.fx) : null, fx = FXR[R.fx] || {};
  ctx.save(); ctx.clearRect(0, 0, w, h);
  if (T && T.shake) ctx.translate(Math.sin(t * 83) * T.shake * u * 0.03, Math.cos(t * 67) * T.shake * u * 0.03);
  drawBg(ctx, w, h, u, th, t, R); drawTwinkles(ctx, w, h, u, th, t);
  if (fx.fn && !fx.front) fx.fn(ctx, w, h, u, th, t);
  const mcx = w / 2, mcy = top + ch * 0.25, ms = u * 0.5;
  if (R.photoEl && ready(R.photoEl)) drawPhoto(ctx, mcx, mcy, ms, th, R.photoEl, t);
  else if (R.stickerEl && ready(R.stickerEl)) drawSticker(ctx, mcx, mcy, ms, R.stickerEl, t);
  else (MOTIFS[R.motif && MOTIFS[R.motif] ? R.motif : (OCC[R.occ] || OCC.other).motif] || MOTIFS.burst)(ctx, mcx, mcy, ms, th, t);
  drawTexts(ctx, w, h, u, ch, top, th, R);
  if (fx.fn && fx.front) fx.fn(ctx, w, h, u, th, t);
  if (T) {
    if (T.confetti > 0) { ctx.globalAlpha = clamp(T.confetti / 0.3); fxConfetti(ctx, w, h, u, th, T.confetti, { fromTop: true }); ctx.globalAlpha = 1; }
    if (T.dark > 0) { ctx.fillStyle = `rgba(4,2,10,${T.dark})`; ctx.fillRect(-40, -40, w + 80, h + 80); }
    if (T.moon > 0) { ctx.save(); ctx.globalAlpha = T.moon; drawMoon(ctx, w / 2, top + ch * 0.3, u * 0.3); ctx.restore(); }
    if (T.cr) {
      const c = T.cr, cx = w / 2;
      if (c.kind === 'spider') { const s = u * 0.14 * c.sc, cy = top + ch * c.y; ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = Math.max(1.5, u * 0.005); ctx.beginPath(); ctx.moveTo(cx, -40); ctx.lineTo(cx, cy - s * 0.6); ctx.stroke(); drawSpider(ctx, cx, cy, s, t); }
      else if (c.kind === 'ghost') drawGhost(ctx, cx + c.sway * u * 0.07, top + ch * c.y, u * 0.34 * c.sc, t, c.mo, c.al);
      else if (c.kind === 'bats') drawBats(ctx, w, h, u, top, ch, t);
      else if (X.HDRAW[c.kind]) X.HDRAW[c.kind](ctx, w, h, u, top, ch, t, c);
      else drawEyes(ctx, w, h, u, top, ch, t);
    }
    if (T.shout) { ctx.save(); ctx.textAlign = 'center'; ctx.lineJoin = 'round'; const fs = fitFont(ctx, T.shout, F_NAME, 800, w * 0.88, u * 0.22, u * 0.08); ctx.translate(w / 2 + Math.sin(t * 60) * u * 0.01, top + ch * T.shoutY + Math.cos(t * 47) * u * 0.01); ctx.font = `800 ${fs}px ${F_NAME}`; ctx.lineWidth = u * 0.02; ctx.strokeStyle = '#1B0B3A'; ctx.strokeText(T.shout, 0, 0); ctx.fillStyle = '#FFFFFF'; ctx.fillText(T.shout, 0, 0); ctx.restore(); }
    if (T.flash > 0.01) { const g = ctx.createRadialGradient(w / 2, h / 2, u * 0.1, w / 2, h / 2, Math.max(w, h) * 0.8); g.addColorStop(0, rgba(T.flashCol, T.flash * 0.35)); g.addColorStop(1, rgba(T.flashCol, T.flash)); ctx.fillStyle = g; ctx.fillRect(-40, -40, w + 80, h + 80); }
    if (T.asan > 0) { const p = T.asan, sc = 0.5 + 0.5 * easeOut(p) + 0.06 * Math.sin(p * Math.PI); ctx.save(); ctx.globalAlpha = clamp(p * 1.4); ctx.translate(w / 2, top + ch * 0.5); ctx.scale(sc, sc); ctx.textAlign = 'center'; ctx.font = `400 ${u * 0.17}px ${F_TITLE}`; ctx.lineWidth = u * 0.025; ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(20,8,40,.85)'; ctx.strokeText('Айсан уу?', 0, 0); ctx.fillStyle = th.a; ctx.fillText('Айсан уу?', 0, 0); ctx.restore(); }
  }
  ctx.restore();
}
function resetTextCache() { TL.key = ''; }

/* ---------- Sound ---------- */
const PRESETS = {
  tada: { name: 'Тада', ops: [{ t: 'tone', f: 523, d: .45, w: 'triangle', v: .12, at: 0 }, { t: 'tone', f: 659, d: .45, w: 'triangle', v: .12, at: .09 }, { t: 'tone', f: 784, d: .45, w: 'triangle', v: .12, at: .18 }, { t: 'tone', f: 1047, d: .6, w: 'triangle', v: .12, at: .27 }] },
  pop: { name: 'Паф', ops: [{ t: 'noise', d: .3, v: .12, hp: 1500 }, { t: 'tone', f: 200, d: .25, w: 'sine', v: .1, to: 60 }] },
  riser: { name: 'Өсөх дуу', ops: [{ t: 'tone', f: 120, d: .6, w: 'sawtooth', v: .08, to: 700 }] },
  sting: { name: 'Айлгах цохилт', ops: [{ t: 'tone', f: 90, d: .9, w: 'sawtooth', v: .22, to: 40 }, { t: 'tone', f: 1500, d: .5, w: 'square', v: .06, to: 300 }, { t: 'noise', d: .7, v: .25, hp: 200 }] },
  boo: { name: 'Бүү', ops: [{ t: 'tone', f: 230, d: 1.0, w: 'sawtooth', v: .2, to: 70 }, { t: 'noise', d: .5, v: .16, hp: 300 }] },
  chime: { name: 'Хонх', ops: [{ t: 'tone', f: 880, d: .8, w: 'sine', v: .12 }, { t: 'tone', f: 1320, d: .9, w: 'sine', v: .08, at: .12 }, { t: 'tone', f: 1760, d: 1, w: 'sine', v: .05, at: .24 }] },
  whoosh: { name: 'Сэвшээ', ops: [{ t: 'noise', d: .9, v: .14, hp: 400 }, { t: 'tone', f: 300, d: .8, w: 'sine', v: .04, to: 900 }] },
  drum: { name: 'Бөмбөр', ops: [{ t: 'tone', f: 140, d: .35, w: 'sine', v: .3, to: 45 }, { t: 'noise', d: .15, v: .15, hp: 2500 }] },
  zap: { name: 'Цахилгаан', ops: [{ t: 'tone', f: 1800, d: .25, w: 'square', v: .08, to: 120 }] },
  fanfare: { name: 'Фанфар', ops: [{ t: 'tone', f: 392, d: .25, w: 'square', v: .07, at: 0 }, { t: 'tone', f: 523, d: .25, w: 'square', v: .07, at: .18 }, { t: 'tone', f: 659, d: .25, w: 'square', v: .07, at: .36 }, { t: 'tone', f: 784, d: .6, w: 'square', v: .07, at: .54 }] },
  bell: { name: 'Хонхны дуу', ops: [{ t: 'tone', f: 660, d: 1.2, w: 'sine', v: .12 }, { t: 'tone', f: 1320, d: 1.0, w: 'sine', v: .06 }] },
  silence: { name: 'Дуугүй', ops: [] }
};
const CUES = { open: 'Нээгдэх үед', burst: 'Салют, буу', riser: 'Айлгахын өмнө', impact: 'Цохилт', boo: 'Бүү', end: 'Айсан уу?' };
const DEFAULT_SFX = { open: 'tada', burst: 'pop', riser: 'riser', impact: 'sting', boo: 'boo', end: 'tada' };
const Sound = {
  ac: null, muted: false, vol: 1, map: {}, lib: {}, files: {},
  init() { try { Sound.ac = Sound.ac || new (root.AudioContext || root.webkitAudioContext)(); if (Sound.ac.state === 'suspended') Sound.ac.resume(); } catch (e) { Sound.ac = null; } },
  setLibrary(docs) { Sound.lib = {}; (docs || []).forEach(d => { Sound.lib[d.id] = d; }); },
  setMap(m) { Sound.map = m || {}; },
  tone(f, d, type, vol, delay, to) {
    const ac = Sound.ac; if (!ac || Sound.muted) return; const n = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.setValueAtTime(f, n); if (to) o.frequency.exponentialRampToValueAtTime(Math.max(1, to), n + d);
    g.gain.setValueAtTime(0.0001, n); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), n + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, n + d);
    o.connect(g); g.connect(ac.destination); o.start(n); o.stop(n + d + 0.05);
  },
  noise(d, vol, delay, hp) {
    const ac = Sound.ac; if (!ac || Sound.muted) return; const n = ac.currentTime + (delay || 0), len = Math.max(1, Math.floor(ac.sampleRate * d)), buf = ac.createBuffer(1, len, ac.sampleRate), da = buf.getChannelData(0);
    for (let i = 0; i < len; i++) da[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = ac.createBufferSource(); s.buffer = buf; const f = ac.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp || 600; const g = ac.createGain(); g.gain.value = vol;
    s.connect(f); f.connect(g); g.connect(ac.destination); s.start(n);
  },
  runOps(ops, vol, pitch) {
    ops.forEach(o => { if (o.t === 'tone') Sound.tone(o.f * pitch, o.d, o.w, o.v * vol, o.at, o.to ? o.to * pitch : 0); else Sound.noise(o.d, o.v * vol, o.at, o.hp); });
  },
  async playFile(doc, vol, pitch) {
    const ac = Sound.ac; if (!ac || Sound.muted || !doc.file) return;
    try {
      let buf = Sound.files[doc.id];
      if (!buf) {
        let ab;
        if (doc.file.url) ab = await (await fetch(doc.file.url)).arrayBuffer();
        else { const bin = atob(doc.file.data), arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i); ab = arr.buffer; }
        buf = await ac.decodeAudioData(ab); Sound.files[doc.id] = buf;
      }
      const s = ac.createBufferSource(); s.buffer = buf; s.playbackRate.value = pitch; const g = ac.createGain(); g.gain.value = vol; s.connect(g); g.connect(ac.destination); s.start();
    } catch (e) { /* unplayable file: stay silent */ }
  },
  playPreset(id) {
    const vol = Sound.vol;
    let doc = Sound.lib[id];
    if (doc) { const v = (doc.vol == null ? 1 : doc.vol) * vol, p = doc.pitch || 1; if (doc.file) return Sound.playFile(doc, v, p); const base = PRESETS[doc.base] || PRESETS.pop; return Sound.runOps(base.ops, v, p); }
    const b = PRESETS[id]; if (b) Sound.runOps(b.ops, vol, 1);
  },
  play(cue, ovr) { const id = (ovr && ovr[cue]) || Sound.map[cue] || DEFAULT_SFX[cue]; if (id) Sound.playPreset(id); }
};

/* Extension point: packs (see halloween.js) add themes, effects, creatures, motifs and sounds through this object. */
const X = {
  TAU, clamp, mix, smooth, easeOut, easeIn, rng, rgba, hexMix, rr, heart, sparkle, drawGhost, drawBats, fitFont, F_NAME, F_TITLE, F_MSG,
  THEMES, THEME_IDS, FXS, FX_IDS, FXR, OCC, OCC_IDS, THUMB_T, FINAL_T, LOOP, PRESETS, CUES, DEFAULT_SFX, MOTIFS,
  OCC_ORDER: OCC_IDS.slice(), THEME_ORDER: THEME_IDS.slice(), MOTIF_NAMES: {}, BUILTIN_TPL: [],
  HSCARE: {}, HDRAW: {}, EVENTS: {}
};
root.Mend = {
  THEMES, THEME_IDS, FXS, FX_IDS, OCC, OCC_IDS, THUMB_T, FINAL_T, LOOP, PRESETS, CUES, DEFAULT_SFX,
  OCC_ORDER: X.OCC_ORDER, THEME_ORDER: X.THEME_ORDER, MOTIF_NAMES: X.MOTIF_NAMES, BUILTIN_TPL: X.BUILTIN_TPL, ext: X,
  render, events, occFx, buildTheme, registerTheme, unregisterThemes, resetTextCache, Sound, lum, hexMix, ready
};
})(typeof window !== 'undefined' ? window : globalThis);
