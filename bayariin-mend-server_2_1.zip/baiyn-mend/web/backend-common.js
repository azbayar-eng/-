/* backend-common.js — pieces every backend shares: payment status, address handling, the no-storage fallback. */
(function () {
'use strict';
const App = window.App;

App.statusOf = function (m, ap) {
  const pay = App.cfg.main.payRequired;
  if (ap && ap.st === 'ok') return 'ok';
  if (m && m.free) return 'free';
  if (!pay) return 'free';
  if (ap && ap.st === 'no' && !(m && m.claim && m.claim > ap.at)) return 'no';
  if (m && m.claim) return 'pending';
  return 'draft';
};

App.noop = () => {};
App.hashNav = () => ({ current: () => App.parseHash(), clear() { if (location.hash) location.hash = ''; }, listen(fn) { window.addEventListener('hashchange', fn); } });
const noop = App.noop, nav = App.hashNav;

/* Works without any storage: preview, templates and old self-contained links still run. */
App.nullBackend = function (reason) {
  const fail = () => Promise.reject({ code: 'unavailable', message: reason || 'Хадгалах боломжгүй' });
  return {
    kind: 'null', reason, nav: nav(),
    async init() { return { uid: null, name: '', isAdmin: false, canWrite: false, canUpload: false }; },
    onConfig(cb) { cb(App.emptyCfg(), true); }, onMine(cb) { cb([]); },
    saveCard: fail, getCard: fail, claim: fail, deleteCard: fail, logVisit: noop,
    linkFor: () => '', names: async () => ({})
  };
};
})();
