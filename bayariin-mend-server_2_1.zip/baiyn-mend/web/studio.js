/* studio.js — the owner's studio: colours, sounds, pictures and video, ready-made templates. */
(function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$, A = App.A, U = App.ui;
const T0 = performance.now();

/* A live preview card; stops by itself when it leaves the page. */
function miniPreview(getCard) {
  const canvas = h('canvas', { 'aria-hidden': 'true' }), box = h('div', { class: 'mini' }, canvas);
  const step = now => {
    if (!box.isConnected) return; requestAnimationFrame(step);
    if (App.viewerOpen || document.hidden || App.view !== 'admin') return;
    const { ctx, w, h: hh } = App.fit(canvas); if (w < 8) return;
    const c = getCard(), R = App.toR(c); let t = (performance.now() - T0) / 1000; if (M.LOOP[R.fx]) t %= M.LOOP[R.fx];
    App.media.play(R.bgEl); M.render(ctx, w, hh, t, R);
  };
  requestAnimationFrame(step); return box;
}
const sub = (k, t) => h('button', { class: 'chip', type: 'button', role: 'tab', 'aria-pressed': String(A.studio === k), text: t, on: { click: () => { A.studio = k; App.adminRender(); } } });
const del = (what, fn) => async () => { if (await App.confirm(what, 'Устгах', true)) { try { await fn(); App.toast('Устгагдлаа.'); } catch (e) { App.toast(App.failMsg(e), 5000); } } };

/* ---------- colours ---------- */
const TF = [['bg0', 'Дэвсгэр дээд'], ['bg1', 'Дэвсгэр доод'], ['glow', 'Гэрэлтэлт'], ['ink', 'Үсэг'], ['a', 'Гол өнгө'], ['b', 'Хоёр дахь'], ['c', 'Гурав дахь']];
const newTheme = () => ({ id: null, name: '', bg0: '#160C3A', bg1: '#5B2A9E', glow: '#B07CFF', ink: '#FFF3D6', a: '#FFC857', b: '#FF6FB5', c: '#7FD6FF' });
function hex(hh, s, l) { s /= 100; l /= 100; const k = n => (n + hh / 30) % 12, a = s * Math.min(l, 1 - l), f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); return '#' + [f(0), f(8), f(4)].map(x => Math.round(x * 255).toString(16).padStart(2, '0')).join(''); }
function randomTheme(d) {
  const hue = Math.random() * 360, h2 = (hue + 30 + Math.random() * 70) % 360, dark = Math.random() < 0.7;
  Object.assign(d, dark
    ? { bg0: hex(hue, 55, 14), bg1: hex(h2, 55, 34), glow: hex(h2, 90, 72), ink: hex(hue, 70, 94), a: hex((hue + 180) % 360, 90, 62), b: hex((hue + 320) % 360, 90, 72), c: hex((hue + 90) % 360, 85, 66) }
    : { bg0: hex(hue, 95, 90), bg1: hex(h2, 85, 72), glow: '#FFFFFF', ink: hex(hue, 60, 16), a: hex((hue + 180) % 360, 80, 42), b: '#FFFFFF', c: hex((hue + 90) % 360, 80, 52) });
}
const contrast = d => { const l1 = M.lum(d.ink), l2 = (M.lum(d.bg0) + M.lum(d.bg1)) / 2, hi = Math.max(l1, l2), lo = Math.min(l1, l2); return (hi + 0.05) / (lo + 0.05); };
function themes() {
  const d = A.d.theme = A.d.theme || newTheme();
  const warn = h('p', { class: 'hint' });
  const upd = () => { const c = contrast(d); warn.textContent = c < 3.2 ? 'Анхаар: үсгийн өнгө дэвсгэртэй ойр байна, текст муу уншигдаж магадгүй.' : ''; };
  upd();
  const save = U.busy('saveTheme', async () => {
    if (!(d.name || '').trim()) { App.toast('Өнгөндөө нэр өгнө үү.'); return; }
    await App.backend.saveItem('themes', Object.assign({}, d, { name: d.name.trim(), order: d.order || Date.now() }));
    A.d.theme = null; App.toast('Өнгө хадгалагдлаа. Хэрэглэгчид сонгож чадна.');
  });
  const pickers = TF.map(([k, t]) => h('label', {}, h('input', { type: 'color', value: d[k], 'aria-label': t, on: { input: e => { d[k] = e.target.value; upd(); } } }), h('span', { text: t })));
  const list = App.cfg.themes.map(t => {
    const sw = h('span', { class: 'sw', style: { background: `linear-gradient(160deg,${t.bg0},${t.bg1})`, flex: 'none', cursor: 'default' } });
    return h('div', { class: 'row' }, sw, h('div', { class: 'grow' }, h('div', { class: 't', text: t.name })),
      h('div', { class: 'acts' }, h('button', { class: 'ghost sm', type: 'button', text: 'Засах', on: { click: () => { A.d.theme = Object.assign(newTheme(), t); App.adminRender(); } } }),
        h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: del('Энэ өнгийг устгах уу? Илгээсэн картууд өөрчлөгдөхгүй.', () => App.backend.deleteItem('themes', t.id)) } })));
  });
  return [
    U.panel(d.id ? 'Өнгө засах' : 'Шинэ өнгө',
      h('div', { class: 'split' },
        h('div', { style: { display: 'flex', flexDirection: 'column', gap: '14px' } },
          U.field('Нэр', U.tin(d, 'name', { placeholder: 'Жишээ нь: Алтан шөнө', maxLength: 24 })),
          h('div', { class: 'colors' }, pickers), warn,
          h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start' } },
            h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: save } }),
            h('button', { class: 'ghost', type: 'button', text: 'Санамсаргүй өнгө', on: { click: () => { randomTheme(d); App.adminRender(); } } }),
            d.id && h('button', { class: 'ghost', type: 'button', text: 'Шинээр эхлэх', on: { click: () => { A.d.theme = null; App.adminRender(); } } }))),
        miniPreview(() => { M.registerTheme('_prev', M.buildTheme(d)); return { occ: 'bday', fx: 'confetti', theme: '_prev', to: 'Азаа', from: 'Болд' }; }))),
    U.panel('Миний өнгөнүүд', list.length ? h('div', { class: 'rows' }, list) : h('p', { class: 'hint', text: 'Одоогоор өөрийн өнгө алга.' }))
  ];
}

/* ---------- sounds ---------- */
const cueIds = Object.keys(M.CUES);
function soundOpts(extra) { return (extra ? [['', extra]] : []).concat(App.soundList().map(s => [s.id, s.name])); }
function sounds() {
  const m = App.cfg.main, map = A.d.sfx = A.d.sfx || Object.assign({}, M.DEFAULT_SFX, m.sfx);
  const d = A.d.snd = A.d.snd || { id: null, name: '', base: 'pop', vol: 1, pitch: 1, file: null };
  const play = id => { M.Sound.init(); M.Sound.muted = false; M.Sound.playPreset(id); };
  const saveMap = U.busy('saveMap', async () => { await App.backend.saveMain({ sfx: map }); A.d.sfx = null; App.toast('Дууны тохиргоо хадгалагдлаа.'); });
  const cues = cueIds.map(c => h('div', { class: 'cue' }, h('span', { text: M.CUES[c] }), U.sel(map, c, soundOpts()), h('button', { class: 'ghost sm', type: 'button', text: '▶ Сонсох', on: { click: () => play(map[c]) } })));
  const saveSnd = U.busy('saveSnd', async () => {
    if (!(d.name || '').trim()) { App.toast('Дуундаа нэр өгнө үү.'); return; }
    const item = { name: d.name.trim(), base: d.base, vol: Number(d.vol) || 1, pitch: Number(d.pitch) || 1, order: d.order || Date.now() }; if (d.file) item.file = d.file;
    await App.backend.saveItem('sounds', Object.assign({ id: d.id }, item));
    A.d.snd = null; App.toast('Дуу хадгалагдлаа.');
  });
  const fileIn = h('input', { type: 'file', accept: 'audio/*', 'aria-label': 'Дууны файл', on: { change: async e => {
    const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
    if (f.size > 150 * 1024) { App.toast('Файл 150KB-аас бага (богино дуу) байх ёстой.'); return; }
    try { d.file = { data: await App.fileToB64(f), mime: f.type || 'audio/mpeg', name: f.name }; delete M.Sound.files._prev; if (!d.name) d.name = f.name.replace(/\.[^.]+$/, '').slice(0, 24); App.adminRender(); } catch (er) { App.toast('Файл уншиж чадсангүй.'); }
  } } });
  const list = App.cfg.sounds.map(s => h('div', { class: 'row' }, h('div', { class: 'grow' }, h('div', { class: 't', text: s.name }), h('div', { class: 's', text: s.file ? 'Файл: ' + (s.file.name || 'аудио') : 'Суурь: ' + (M.PRESETS[s.base] ? M.PRESETS[s.base].name : s.base) + ' · хэмжээ ' + (s.vol || 1) + ' · өндөр ' + (s.pitch || 1) })),
    h('div', { class: 'acts' }, h('button', { class: 'ghost sm', type: 'button', text: '▶', 'aria-label': 'Сонсох', on: { click: () => play(s.id) } }),
      h('button', { class: 'ghost sm', type: 'button', text: 'Засах', on: { click: () => { A.d.snd = Object.assign({ id: null, name: '', base: 'pop', vol: 1, pitch: 1, file: null }, s); App.adminRender(); } } }),
      h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: del('Энэ дууг устгах уу?', async () => {
        await App.backend.deleteItem('sounds', s.id);
        const fix = {}; let hit = false; cueIds.forEach(c => { fix[c] = (m.sfx[c] === s.id) ? M.DEFAULT_SFX[c] : (m.sfx[c] || M.DEFAULT_SFX[c]); if (m.sfx[c] === s.id) hit = true; });
        if (hit) await App.backend.saveMain({ sfx: fix }); A.d.sfx = null;
      }) } }))));
  return [
    U.panel('Хэзээ ямар дуу тоглох вэ',
      h('p', { class: 'hint', style: { marginBottom: '12px' }, text: 'Мэндчилгээ нээгдэх, салют буудах, айлгах мөчүүдэд тоглох дууг сонгоно. Өөрийн дуугаа доор нэмж болно.' }),
      cues, h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start' } },
        h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveMap } }),
        h('button', { class: 'ghost', type: 'button', text: 'Үндсэн болгох', on: { click: () => { A.d.sfx = Object.assign({}, M.DEFAULT_SFX); App.adminRender(); } } }))),
    U.panel(d.id ? 'Дуу засах' : 'Шинэ дуу',
      h('div', { class: 'frm' },
        U.field('Нэр', U.tin(d, 'name', { placeholder: 'Жишээ нь: Том цохилт', maxLength: 24 })),
        U.field('Суурь дуу', U.sel(d, 'base', Object.keys(M.PRESETS).map(k => [k, M.PRESETS[k].name])), { hint: d.file ? 'файл байгаа үед ашиглагдахгүй' : '' }),
        U.field('Хэмжээ', h('input', { type: 'range', min: 0.2, max: 2, step: 0.1, value: d.vol, 'aria-label': 'Хэмжээ', on: { input: e => { d.vol = Number(e.target.value); } } })),
        U.field('Өндөр, нам (хурд)', h('input', { type: 'range', min: 0.5, max: 2, step: 0.05, value: d.pitch, 'aria-label': 'Өндөр', on: { input: e => { d.pitch = Number(e.target.value); } } })),
        U.field('Эсвэл өөрийн дууны файл', fileIn, { wide: true, hint: 'mp3, wav, m4a · 150KB хүртэл' })),
      d.file && h('p', { class: 'hint', style: { marginTop: '8px' }, text: 'Сонгосон файл: ' + (d.file.name || 'аудио') }),
      h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start', marginTop: '12px' } },
        h('button', { class: 'ghost', type: 'button', text: '▶ Сонсох', on: { click: () => { M.Sound.lib._prev = { id: '_prev', base: d.base, vol: d.vol, pitch: d.pitch, file: d.file }; play('_prev'); } } }),
        h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveSnd } }),
        d.id && h('button', { class: 'ghost', type: 'button', text: 'Шинээр эхлэх', on: { click: () => { A.d.snd = null; App.adminRender(); } } }))),
    U.panel('Миний дуунууд', list.length ? h('div', { class: 'rows' }, list) : h('p', { class: 'hint', text: 'Одоогоор өөрийн дуу алга.' }))
  ];
}

/* ---------- pictures and video ---------- */
const MAXV = 15 * 1024 * 1024, MAXI = 3 * 1024 * 1024;
async function addMedia(files, role) {
  for (const f of files) {
    const isVid = /^video\/(mp4|webm)$/.test(f.type), isImg = /^image\//.test(f.type);
    try {
      if (!isVid && !isImg) { App.toast(f.name + ': зөвхөн зураг, mp4, webm.'); continue; }
      if (isVid && role !== 'bg') { App.toast('Видеог зөвхөн арын дэвсгэр болгоно.'); continue; }
      if (isVid && f.size > MAXV) { App.toast(f.name + ': видео 15MB-аас бага байх ёстой.'); continue; }
      let blob = f, type = f.type;
      if (isImg && role === 'bg') { const r = await App.shrink(f, 1600, 600); blob = App.dataUrlToBlob(r.url); type = 'image/jpeg'; }
      else if (isImg) { if (!/^image\/(png|webp|gif|svg\+xml)$/.test(f.type)) { App.toast('Наалтыг PNG эсвэл WebP (тунгалаг) оруулна уу.'); continue; } if (f.size > MAXI) { App.toast(f.name + ': 3MB-аас бага байх ёстой.'); continue; } }
      App.toast('Оруулж байна: ' + f.name, 8000);
      const up = await App.backend.upload(blob, type);
      await App.backend.saveItem('media', { kind: isVid ? 'video' : 'image', role, assetId: up.assetId, name: f.name.replace(/\.[^.]+$/, '').slice(0, 30), order: Date.now() });
      App.toast('Орууллаа: ' + f.name);
    } catch (e) { App.toast(App.failMsg(e), 5000); }
  }
}
function media() {
  const d = A.d.media = A.d.media || { role: 'bg' };
  const fileIn = h('input', { type: 'file', accept: 'image/*,video/mp4,video/webm', multiple: true, 'aria-label': 'Зураг, видео сонгох', on: { change: async e => { const fs = [...(e.target.files || [])]; e.target.value = ''; if (fs.length) await addMedia(fs, d.role); } } });
  const items = App.cfg.media.map(m => h('div', { class: 'mi', style: { cursor: 'default' } },
    m.kind === 'video' ? h('video', { src: m.src, muted: true, playsInline: true, preload: 'metadata' }) : h('img', { src: m.src, alt: m.name || '' }),
    h('span', { class: 'tag', text: (m.kind === 'video' ? 'видео · ' : '') + (m.role === 'bg' ? 'арын' : 'наалт') }),
    h('button', { class: 'x', type: 'button', 'aria-label': 'Устгах: ' + (m.name || ''), text: '×', on: { click: del('Энэ файлыг устгах уу? Үүнийг ашигласан бэлэн загвар хоосон болно.', async () => { await App.backend.deleteItem('media', m.id); await App.backend.deleteAsset(m.assetId); }) } })));
  return [
    U.panel('Зураг, видео оруулах',
      !App.me.canUpload && h('div', { class: 'stat warn', style: { marginBottom: '12px' }, text: 'Файл хадгалах эрх алга. Зөвхөн Editor эрхтэй хүн оруулж чадна.' }),
      h('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Төрөл', style: { marginBottom: '12px' } },
        [['bg', 'Арын дэвсгэр (зураг, видео)'], ['sticker', 'Голын наалт (тунгалаг PNG)']].map(([k, t]) => h('button', { class: 'chip', type: 'button', role: 'radio', 'aria-checked': String(d.role === k), text: t, on: { click: () => { d.role = k; App.adminRender(); } } }))),
      h('label', { class: 'ghost file-btn', style: { display: 'inline-flex', alignItems: 'center' } }, h('span', { text: 'Утаснаас эсвэл компьютероос сонгох' }), fileIn),
      h('p', { class: 'hint', style: { marginTop: '10px' }, text: d.role === 'bg' ? 'Зураг автоматаар жижгэрнэ. Видео mp4 эсвэл webm, 15MB хүртэл, дуугүй давтагдана.' : 'Наалт 3MB хүртэл. Тунгалаг дэвсгэртэй PNG хамгийн сайн харагдана.' })),
    U.panel('Миний файлууд', items.length ? h('div', { class: 'mgrid' }, items) : h('p', { class: 'hint', text: 'Одоогоор файл алга.' }))
  ];
}

/* ---------- templates ---------- */
const newTpl = () => ({ id: null, name: '', occ: 'bday', fx: 'confetti', theme: 'sun', motif: null, title: '', msg: '', bg: null, sticker: null, sfx: {} });
function templates() {
  const d = A.d.tpl = A.d.tpl || newTpl();
  if (!d.sfx) d.sfx = {};
  const bgs = [['', 'Алга']].concat(App.mediaList('bg').map(m => [m.id, (m.kind === 'video' ? '▶ ' : '') + (m.name || m.id)]));
  const sts = [['', 'Алга']].concat(App.mediaList('sticker').map(m => [m.id, m.name || m.id]));
  const themeOpts = M.THEME_IDS.map(id => [id, M.THEMES[id].name]).concat(App.cfg.themes.map(t => [t.id, t.name]));
  const save = U.busy('saveTpl', async () => {
    if (!(d.name || '').trim()) { App.toast('Загварт нэр өгнө үү.'); return; }
    const sfx = {}; cueIds.forEach(c => { if (d.sfx[c]) sfx[c] = d.sfx[c]; });
    const item = { name: d.name.trim(), occ: d.occ, fx: d.fx, theme: d.theme, motif: d.motif || null, title: (d.title || '').trim(), msg: (d.msg || '').trim(), bg: d.bg || null, sticker: d.sticker || null, sfx, order: d.order || Date.now() };
    await App.backend.saveItem('templates', Object.assign({ id: d.id }, item)); A.d.tpl = null; App.toast('Загвар хадгалагдлаа. Хэрэглэгчид «Бэлэн загвар»-аас сонгоно.');
  });
  const fromMaker = () => { const s = App.S || {}; Object.assign(d, { occ: s.occ || d.occ, fx: s.fx || d.fx, theme: s.theme || d.theme, motif: s.motif || null, title: s.title || '', msg: s.msg || '', bg: s.bg || null, sticker: s.sticker || null }); App.adminRender(); };
  const list = App.cfg.templates.map(t => {
    const canv = h('canvas', { 'aria-hidden': 'true' });
    requestAnimationFrame(() => App.thumbDraw(canv, { occ: t.occ, fx: t.fx, motif: t.motif, theme: t.theme, themeDef: App.themeDefOf(t.theme) || undefined, to: 'Нэр', title: t.title, msg: t.msg, bg: t.bg, sticker: t.sticker }, t.fx));
    return h('div', { class: 'row' }, canv, h('div', { class: 'grow' }, h('div', { class: 't', text: t.name }), h('div', { class: 's', text: (M.OCC[t.occ] ? M.OCC[t.occ].name : '') + ' · ' + (M.FXS[t.fx] ? M.FXS[t.fx].name : '') })),
      h('div', { class: 'acts' }, h('button', { class: 'ghost sm', type: 'button', text: t.builtin ? 'Хуулж засах' : 'Засах', on: { click: () => { A.d.tpl = Object.assign(newTpl(), t, t.builtin ? { id: null, builtin: false, name: t.name + ' (миний)', order: null } : {}, { sfx: Object.assign({}, t.sfx) }); App.adminRender(); } } }),
        !t.builtin && h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: del('Энэ загварыг устгах уу?', () => App.backend.deleteItem('templates', t.id)) } })));
  });
  return [
    U.panel(d.id ? 'Загвар засах' : 'Шинэ бэлэн загвар',
      h('div', { class: 'split' },
        h('div', {},
          h('div', { class: 'frm' },
            U.field('Загварын нэр', U.tin(d, 'name', { placeholder: 'Жишээ нь: Цагаан сарын алтан', maxLength: 30 }), { wide: true }),
            U.field('Баяр', U.sel(d, 'occ', M.OCC_IDS.map(k => [k, M.OCC[k].name]))),
            U.field('Хөдөлгөөн', U.sel(d, 'fx', M.FX_IDS.map(k => [k, M.FXS[k].name]))),
            U.field('Өнгө', U.sel(d, 'theme', themeOpts)),
            U.field('Гол дүрс', U.sel(d, 'motif', [['', 'Баяраар']].concat(Object.keys(M.MOTIF_NAMES).map(k => [k, M.MOTIF_NAMES[k]])))),
            U.field('Арын дэвсгэр', U.sel(d, 'bg', bgs)),
            U.field('Голын наалт', U.sel(d, 'sticker', sts)),
            U.field('Гарчиг', U.tin(d, 'title', { maxLength: 40 }), { wide: true, hint: 'заавал биш' }),
            h('label', { class: 'wide' }, h('span', {}, 'Мэндчилгээний үг', h('small', { text: 'заавал биш' })), h('textarea', { rows: 3, maxLength: 160, value: d.msg || '', on: { input: e => { d.msg = e.target.value; } } }))),
          h('details', { style: { margin: '14px 0' } }, h('summary', { text: 'Энэ загварт тусгай дуу сонгох', style: { cursor: 'pointer', font: '600 14px var(--f-body)' } }),
            h('div', { style: { marginTop: '12px' } }, cueIds.map(c => h('div', { class: 'cue' }, h('span', { text: M.CUES[c] }), U.sel(d.sfx, c, soundOpts('Үндсэн')))))),
          h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start' } },
            h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: save } }),
            h('button', { class: 'ghost', type: 'button', text: 'Одоо хийж буй картаас авах', on: { click: fromMaker } }),
            d.id && h('button', { class: 'ghost', type: 'button', text: 'Шинээр эхлэх', on: { click: () => { A.d.tpl = null; App.adminRender(); } } }))),
        miniPreview(() => ({ occ: d.occ, fx: d.fx, theme: d.theme, themeDef: App.themeDefOf(d.theme) || undefined, to: 'Азаа', from: 'Болд', title: d.title, msg: d.msg, bg: d.bg || null, sticker: d.sticker || null })))),
    U.panel('Миний бэлэн загварууд', list.length ? h('div', { class: 'rows' }, list) : h('p', { class: 'hint', text: 'Одоогоор загвар алга.' }))
  ];
}

App.renderStudio = function () {
  const f = { themes, sounds, media, tpl: templates }[A.studio] || themes;
  return [h('div', { class: 'chips', role: 'tablist', style: { marginBottom: '16px' } }, sub('themes', 'Өнгө'), sub('sounds', 'Дуу'), sub('media', 'Зураг, видео'), sub('tpl', 'Бэлэн загвар'))].concat(f());
};
})();
