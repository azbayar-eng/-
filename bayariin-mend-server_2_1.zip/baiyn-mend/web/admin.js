/* admin.js — the owner's panel: dashboard, orders, visitors, settings. The studio lives in studio.js. */
(function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$;
const A = App.A = { sub: 'dash', studio: 'themes', orders: [], users: [], visitors: [], names: {}, flt: 'pending', q: '', d: {}, started: false, busy: new Set(), bank: { status: {}, list: [], pending: [] }, bankSel: {}, qp: null, qpErr: false, qpLoading: false };

/* ---------- small form helpers (inputs bound to a draft object, so a re-render never loses typing) ---------- */
App.ui = {
  panel: (title, ...kids) => h('div', { class: 'panel' }, title && h('h3', { text: title }), ...kids),
  field(label, input, o) { o = o || {}; return h('label', { class: o.wide ? 'wide' : '' }, h('span', {}, label, o.hint && h('small', { text: o.hint })), input); },
  tin(obj, key, props) { return h('input', Object.assign({ type: 'text', value: obj[key] == null ? '' : obj[key], on: { input: e => { obj[key] = e.target.value; if (props && props.onInput) props.onInput(); } } }, props && { placeholder: props.placeholder, maxLength: props.maxLength, id: props.id })); },
  nin(obj, key, props) { return h('input', { type: 'number', min: (props && props.min) || 0, step: (props && props.step) || 1, value: obj[key] == null ? '' : obj[key], inputMode: 'numeric', on: { input: e => { obj[key] = e.target.value === '' ? '' : Number(e.target.value); } } }); },
  sel(obj, key, opts, props) {
    const s = h('select', { on: { change: e => { obj[key] = e.target.value; if (props && props.onChange) props.onChange(e.target.value); } } }, opts.map(([v, t]) => h('option', { value: v, text: t, selected: String(obj[key] == null ? '' : obj[key]) === String(v) })));
    return s;
  },
  chk(label, checked, on) { return h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!checked, on: { change: e => on(e.target.checked) } }), h('span', { text: label })); },
  busy(key, fn) { return async (...a) => { if (A.busy.has(key)) return; A.busy.add(key); try { return await fn(...a); } catch (e) { App.toast(failMsg(e), 5000); } finally { A.busy.delete(key); } }; }
};
const U = App.ui;
function failMsg(e) {
  const c = e && e.code;
  if (c === 'invalid_argument' || c === 'not_granted') return 'Таны эрх хүрэхгүй байна. Зөвхөн админ (Editor) өөрчилж чадна.';
  if (c === 'quota_exceeded' || c === 'quota_or_state') return 'Хадгалах багтаамж дүүрсэн байна.';
  if (c === 'too_large') return 'Файл хэт том байна.';
  if (c === 'unsupported_type') return 'Энэ төрлийн файл дэмжигдэхгүй.';
  return (e && e.message && e.code === 'unavailable') ? e.message : 'Хадгалж чадсангүй. Дахин оролдоно уу.';
}
App.failMsg = failMsg;

/* ---------- names (opaque ids -> display names, resolved at render time) ---------- */
const nm = uid => A.names[uid] || 'Нэргүй хэрэглэгч';
async function resolveNames() {
  const ids = new Set(); A.orders.forEach(o => o.uid && ids.add(o.uid)); A.visitors.forEach(v => { ids.add(v.uid); (v.v || []).forEach(x => x.o && ids.add(x.o)); });
  const miss = [...ids].filter(i => !(i in A.names)); if (!miss.length) return;
  try { const r = await App.backend.names(miss); miss.forEach(i => { A.names[i] = r[i] || ''; }); rerender(['orders', 'visitors', 'dash']); } catch (e) { /* names stay generic */ }
}

/* ---------- data ---------- */
const stOf = o => o.gone ? 'ok' : App.statusOf(o, o.ap);
const money = () => A.orders.filter(o => o.ap && o.ap.st === 'ok').reduce((s, o) => s + (Number(o.ap.amt) || 0), 0);
const pendingList = () => A.orders.filter(o => stOf(o) === 'pending');
function rerender(subs) { if (App.view === 'admin' && (!subs || subs.includes(A.sub))) render(); }
function updateBadge() {
  const n = pendingList().length, tab = document.querySelector('.tab[data-v="admin"]'); if (!tab) return;
  let d = tab.querySelector('.dot'); if (!n) { if (d) d.remove(); return; }
  if (!d) { d = h('span', { class: 'dot' }); tab.append(d); } d.textContent = String(n);
}

/* ---------- order actions ---------- */
const approve = U.busy('act', async o => { await App.backend.setApproval(o.uid, o.id, 'ok', '', Number(App.cfg.main.price) || 0); App.toast('Баталгаажлаа. Холбоос нээгдлээ.'); });
const reject = U.busy('act', async o => { const note = await App.prompt('Татгалзах шалтгаан (захиалагчид харагдана):', 'Жишээ нь: шилжүүлэг ирээгүй', 'Татгалзах'); if (note === null) return; await App.backend.setApproval(o.uid, o.id, 'no', note, 0); App.toast('Татгалзлаа.'); });
const undo = U.busy('act', async o => { if (!(await App.confirm('Баталгаажуулалтыг цуцлах уу? Холбоос дахин хаагдана.', 'Цуцлах', true))) return; await App.backend.clearApproval(o.id); App.toast('Цуцлагдлаа.'); });
const viewCard = U.busy('view', async o => {
  const r = await App.backend.getCard(o.uid, o.id); if (!r) { App.toast('Карт олдсонгүй.'); return; }
  App.openViewer({ card: r.card, test: true, back: 'admin' });
});

function orderRow(o) {
  const stt = stOf(o), canv = h('canvas', { 'aria-hidden': 'true' }), isMe = o.uid === App.me.uid;
  const acts = [];
  if (!o.gone) acts.push(h('button', { class: 'ghost sm', type: 'button', text: 'Харах', on: { click: () => viewCard(o) } }));
  if (stt === 'pending' || stt === 'no' || stt === 'draft') acts.push(h('button', { class: 'okbtn', type: 'button', text: stt === 'draft' ? 'Гараар батлах' : 'Батлах', on: { click: () => approve(o) } }));
  if (stt === 'pending') acts.push(h('button', { class: 'danger', type: 'button', text: 'Татгалзах', on: { click: () => reject(o) } }));
  if (o.ap && o.ap.st === 'ok') acts.push(h('button', { class: 'ghost sm', type: 'button', text: 'Цуцлах', on: { click: () => undo(o) } }));
  const row = h('div', { class: 'row', 'data-id': o.id },
    canv,
    h('div', { class: 'grow' },
      h('div', { class: 't', text: (o.to || 'Нэргүй') + ' · ' + (M.OCC[o.occ] ? M.OCC[o.occ].name : '—') }),
      h('div', { class: 's', text: 'Захиалагч: ' + (isMe ? 'та өөрөө' : nm(o.uid)) + ' · ' + (M.FXS[o.fx] ? M.FXS[o.fx].name : '—') + ' · ' + App.fmtT(o.claim || o.at) }),
      h('div', { class: 's', text: 'Утга: ' + o.ref + (o.ap && o.ap.st === 'ok' ? ' · ' + App.fmtMoney(o.ap.amt) + (o.ap.via === 'qpay' ? ' · QPay' : o.ap.auto ? ' · автомат' : '') : '') + (o.ap && o.ap.st === 'no' && o.ap.note ? ' · «' + o.ap.note + '»' : '') })),
    App.badge(stt), h('div', { class: 'acts' }, acts));
  requestAnimationFrame(() => App.thumbDraw(canv, { occ: o.occ, fx: o.fx, theme: (M.OCC[o.occ] || M.OCC.other).theme, to: o.to || 'Нэр' }, o.fx));
  return row;
}

/* ---------- sections ---------- */
function dash() {
  const m = App.cfg.main, pend = pendingList(), cards = A.orders.filter(o => !o.gone).length;
  const tile = (v, l) => h('div', { class: 'tile' }, h('b', { text: String(v) }), h('span', { text: l }));
  const go = (sub, studio) => () => { A.sub = sub; if (studio) A.studio = studio; render(); };
  const step = (done, text, btn, fn) => h('li', {}, h('span', { class: 'b' + (done ? ' done' : ''), text: done ? '✓' : '·' }), h('span', { style: { flex: '1' } }, text), !done && btn && h('button', { class: 'ghost sm', type: 'button', text: btn, on: { click: fn } }));
  const out = [
    h('div', { class: 'tiles' }, tile(App.fmtMoney(money()), 'Нийт орлого'), tile(pend.length, 'Шалгах төлбөр'), tile(cards, 'Мэндчилгээ'), tile(A.visitors.length, 'Хандсан хүн')),
    U.panel('Эхлэх алхмууд', h('ul', { class: 'checklist' },
      step(App.payReady(), (App.backend.qpayGet ? 'Үнээ оруулж, банкны данс эсвэл QPay тохируулах' : 'Банкны данс, үнээ оруулах'), 'Тохиргоо', go('settings')),
      step(!!m.payRequired, 'Төлбөртэй горимыг асаах (одоо: ' + (m.payRequired ? 'төлбөртэй' : 'үнэгүй') + ')', 'Асаах', go('settings')),
      App.backend.qpayGet && step(!!(A.qp && A.qp.on), 'QPay холбох (QPay-тэй гэрээ хийсний дараа)', 'Тохиргоо', go('settings')),
      App.backend.onBank && step(!!m.autoPay, 'Банкны мэдэгдлээр автомат батлалтыг асаах (Gmail)', 'Тохиргоо', go('settings')),
      step(App.cfg.themes.length > 0, 'Өөрийн өнгө нэмэх', 'Студи', go('studio', 'themes')),
      step(App.cfg.media.length > 0, 'Арын зураг, видео оруулах', 'Студи', go('studio', 'media')),
      step(App.cfg.templates.length > 0, 'Бэлэн загвар үүсгэх', 'Студи', go('studio', 'tpl')))),
    ...(App.backend.onBank ? [bankStatus(true)] : []),
    U.panel('Шалгах төлбөр', pend.length ? h('div', { class: 'rows' }, pend.slice(0, 5).map(orderRow)) : h('p', { class: 'hint', text: 'Одоогоор шалгах төлбөр алга.' }),
      pend.length > 5 && h('p', { style: { marginTop: '10px' } }, h('button', { class: 'ghost sm', type: 'button', text: 'Бүгдийг харах (' + pend.length + ')', on: { click: () => { A.flt = 'pending'; A.sub = 'orders'; render(); } } }))),
    U.panel('Сүүлд хандсан', A.visitors.length ? h('div', { class: 'rows' }, [...A.visitors].sort((a, b) => (b.last || 0) - (a.last || 0)).slice(0, 5).map(visitorRow)) : h('p', { class: 'hint', text: 'Одоогоор хандсан хүн алга.' }))
  ];
  return out;
}

const FILTERS = [['pending', 'Шалгах'], ['ok', 'Төлөгдсөн'], ['no', 'Татгалзсан'], ['draft', 'Төлбөр хүлээгдэж буй'], ['free', 'Үнэгүй'], ['all', 'Бүгд']];
function orders() {
  const cnt = k => k === 'all' ? A.orders.length : A.orders.filter(o => stOf(o) === k).length;
  const list = A.orders.filter(o => A.flt === 'all' || stOf(o) === A.flt);
  return [
    h('div', { class: 'chips', style: { marginBottom: '16px' }, role: 'group', 'aria-label': 'Шүүлтүүр' }, FILTERS.map(([k, t]) => h('button', { class: 'chip', type: 'button', 'aria-pressed': String(A.flt === k), text: t + ' (' + cnt(k) + ')', on: { click: () => { A.flt = k; render(); } } }))),
    list.length ? h('div', { class: 'rows' }, list.map(orderRow)) : h('div', { class: 'empty', text: 'Энэ ангилалд захиалга алга.' })
  ];
}

function visitorRow(v) {
  const idx = {}; A.users.forEach(u => Object.keys(u.cards || {}).forEach(id => { idx[id] = Object.assign({ uid: u.uid || u.id }, u.cards[id]); }));
  const own = A.users.find(u => (u.uid || u.id) === v.uid), ownN = own ? Object.keys(own.cards || {}).length : 0;
  const opens = (v.v || []).slice(0, 4).map(x => { const c = idx[x.c]; return (c ? '«' + (c.to || 'Нэргүй') + '»' : 'устгагдсан карт') + ' (' + (x.o === v.uid ? 'өөрийнх' : nm(x.o)) + ') ' + App.fmtT(x.t); });
  return h('div', { class: 'row' },
    h('div', { class: 'grow' },
      h('div', { class: 't', text: v.uid === App.me.uid ? 'Та өөрөө' : nm(v.uid) }),
      h('div', { class: 's', text: 'Анх: ' + App.fmtT(v.first) + ' · Сүүлд: ' + App.fmtT(v.last) + ' · ' + (v.n || 0) + ' удаа ' + (App.backend.visitWord || 'нэвтэрсэн') + (ownN ? ' · ' + ownN + ' карт хийсэн' : '') }),
      opens.length > 0 && h('div', { class: 's', text: 'Нээсэн: ' + opens.join(' · ') })));
}
function visitors() {
  const q = A.q.trim().toLowerCase();
  const list = [...A.visitors].filter(v => !q || nm(v.uid).toLowerCase().includes(q)).sort((a, b) => (b.last || 0) - (a.last || 0));
  return [
    h('p', { class: 'hint', style: { marginBottom: '12px' }, text: App.backend.visitorsHint || 'Энэ хуудсыг нээсэн, холбоос дээр дарсан нэвтэрсэн хүмүүс. Хүн бүрийн нэр claude.ai-ийн бүртгэлээс харагдана.' }),
    h('input', { class: 'search', type: 'search', placeholder: 'Нэрээр хайх', 'aria-label': 'Нэрээр хайх', value: A.q, on: { input: e => { A.q = e.target.value; const keep = e.target.selectionStart; render(); const i = $('v-admin').querySelector('.search'); if (i) { i.focus(); i.setSelectionRange(keep, keep); } } } }),
    list.length ? h('div', { class: 'rows' }, list.map(visitorRow)) : h('div', { class: 'empty', text: 'Хандсан хүн олдсонгүй.' })
  ];
}

function settings() {
  const m = App.cfg.main;
  const d = A.d.pay = A.d.pay || { payRequired: !!m.payRequired, autoPay: !!m.autoPay, price: m.price, bank: m.bank, account: m.account, holder: m.holder, note: m.note };
  const av = A.d.av = A.d.av || { offOcc: [...m.offOcc], offFx: [...m.offFx], offThemes: [...m.offThemes] };
  const ready = () => Number(d.price) > 0 && !!((d.bank && d.account && d.holder) || App.qpayReady());
  const savePay = U.busy('savePay', async () => {
    if (d.payRequired && !ready()) { App.toast('Төлбөртэй горимд үнэ, мөн банкны мэдээлэл (банк, данс, нэр) эсвэл QPay шаардлагатай.'); return; }
    await App.backend.saveMain(Object.assign({ payRequired: !!d.payRequired, price: Number(d.price) || 0, bank: (d.bank || '').trim(), account: (d.account || '').trim(), holder: (d.holder || '').trim(), note: (d.note || '').trim() }, App.backend.onBank ? { autoPay: !!d.autoPay } : {}));
    A.d.pay = null; App.toast('Төлбөрийн тохиргоо хадгалагдлаа.');
  });
  const saveAv = U.busy('saveAv', async () => { await App.backend.saveMain({ offOcc: av.offOcc, offFx: av.offFx, offThemes: av.offThemes }); A.d.av = null; App.toast('Хадгалагдлаа.'); });
  const toggle = (arr, id) => on => { const i = arr.indexOf(id); if (on && i >= 0) arr.splice(i, 1); if (!on && i < 0) arr.push(id); };
  const group = (title, ids, name, arr) => h('div', {}, h('div', { class: 'sub', text: title }), h('div', { class: 'checks' }, ids.map(id => U.chk(name(id), !arr.includes(id), toggle(arr, id)))));
  const payChk = h('input', { type: 'checkbox', checked: !!d.payRequired, on: { change: e => { if (e.target.checked && !ready()) { e.target.checked = false; App.toast('Эхлээд үнийг оруулаад банкны мэдээлэл (банк, данс, нэр) эсвэл QPay-г бүрдүүлнэ үү.'); return; } d.payRequired = e.target.checked; } } });
  return [
    U.panel(App.backend.onBank ? 'Төлбөр (банкны шилжүүлэг)' : 'Төлбөр (банкны шилжүүлэг, гараар баталгаажуулна)',
      h('div', { class: 'frm' },
        h('label', { class: 'check wide' }, payChk, h('span', { text: 'Төлбөртэй горим: холбоос авахын өмнө төлбөр шаардана' })),
        App.backend.onBank && U.chk('Банкны мэдэгдлээр автоматаар батлах: Gmail-д орлогын мэдэгдэл ирмэгц карт өөрөө нээгдэнэ', d.autoPay, on => { d.autoPay = on; }),
        U.field('Үнэ (₮)', U.nin(d, 'price', { min: 0, step: 100 })),
        U.field('Банкны нэр', U.tin(d, 'bank', { placeholder: 'Жишээ нь: Хаан банк', maxLength: 40 })),
        U.field('Дансны дугаар', U.tin(d, 'account', { maxLength: 40 })),
        U.field('Хүлээн авагчийн нэр', U.tin(d, 'holder', { maxLength: 60 })),
        U.field('Нэмэлт тайлбар', U.tin(d, 'note', { placeholder: 'Жишээ нь: Шилжүүлсний дараа «Төлсөн» товчийг дарна', maxLength: 140 }), { wide: true, hint: 'заавал биш' })),
      h('p', { class: 'hint', style: { margin: '12px 0' }, text: 'Захиалагч шилжүүлэг хийгээд «Төлсөн» дарахад «Захиалга» хэсэгт шалгах жагсаалтад гарна. Та банкаа шалгаад «Батлах» дарна. Түүнээс хойш холбоос нээгдэнэ. Энэ хувилбар мөнгө хөдөлгөдөггүй.' }),
      h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: savePay } })),
    qpayPanel(),
    U.panel('Хэрэглэгчид юу харагдах вэ',
      h('p', { class: 'hint', style: { marginBottom: '8px' }, text: 'Тэмдэглэгдсэн зүйл л хэрэглэгчийн сонголтод гарна. Илгээгдсэн картууд өөрчлөлтөд нөлөөлөхгүй.' }),
      group('Баярууд', M.OCC_IDS, id => M.OCC[id].name, av.offOcc),
      group('Хөдөлгөөн', M.FX_IDS, id => M.FXS[id].name + (M.FXS[id].scare ? ' (айлгана)' : ''), av.offFx),
      group('Үндсэн өнгө', M.THEME_IDS, id => M.THEMES[id].name, av.offThemes),
      h('p', { style: { marginTop: '14px' } }, h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveAv } })))
  ];
}

/* ---------- QPay холболт (server build only): гэрээний мэдээллийг энд оруулна, нууц үг хэзээ ч буцаж харагдахгүй ---------- */
const QERR = {
  INVOICE_CODE_INVALID: 'Invoice code буруу байна. QPay-ээс авсан кодоо шалгана уу.',
  AUTHENTICATION_FAILED: 'Нэвтрэх нэр эсвэл нууц үг буруу байна.',
  network: 'QPay сервертэй холбогдож чадсангүй.',
  SENDER_INVOICE_NO_DUPLICATED: 'Нэхэмжлэхийн дугаар давхцлаа (дахин оролдоход засарна).'
};
async function qpayLoad(force) {
  if (!App.backend.qpayGet || A.qpLoading || (A.qp && !force)) return;
  A.qpLoading = true; A.qpErr = false;
  try { A.qp = await App.backend.qpayGet(); } catch (e) { A.qpErr = true; }
  A.qpLoading = false; rerender(['settings', 'dash']);
}
function qpayPanel() {
  if (!App.backend.qpayGet) return null;
  const st = A.qp;
  if (!st) { qpayLoad(); return U.panel('QPay', h('p', { class: 'hint', text: A.qpErr ? 'QPay-ийн мэдээллийг ачаалж чадсангүй.' : 'Ачаалж байна…' }), A.qpErr && h('button', { class: 'ghost sm', type: 'button', text: 'Дахин оролдох', on: { click: () => qpayLoad(true) } })); }
  const env = st.source === 'env';
  const d = A.d.qp = A.d.qp || { env: st.env, id: st.id, secret: '', code: st.code };
  const took = (r, msg, ms) => { if (r) A.qp = r; A.d.qp = null; if (msg) App.toast(msg, ms); rerender(['settings', 'dash']); };
  const saveQ = U.busy('qpSave', async () => { took(await App.backend.qpaySave({ env: d.env, id: (d.id || '').trim(), secret: d.secret || '', code: (d.code || '').trim() }), 'Хадгалагдлаа. Одоо «Холболт шалгах» дарна уу.', 5000); });
  const testQ = U.busy('qpTest', async () => { const r = await App.backend.qpayTest(); took(r.status, r.ok ? 'QPay-тэй амжилттай холбогдлоо.' : r.msg, r.ok ? 3500 : 8000); });
  const clearQ = U.busy('qpClear', async () => { if (!(await App.confirm('QPay-ийн холболтыг устгах уу? Нууц үг серверээс арилж, QPay-ээр төлөх унтарна.', 'Устгах', true))) return; took(await App.backend.qpayClear(), 'Устгагдлаа.'); });
  const toggleQ = U.busy('qpToggle', async on => {
    try { await App.backend.saveMain({ qpay: !!on }); A.qp = await App.backend.qpayGet(); App.toast(on ? 'QPay-ээр төлөх идэвхжлээ.' : 'QPay-ээр төлөх унтарлаа.'); }
    finally { rerender(['settings', 'dash']); }
  });
  let box;
  if (!st.configured) box = h('div', { class: 'stat info', text: 'QPay-тэй гэрээ хийсний дараа QPay-ээс өгсөн нэвтрэх нэр, нууц үг, invoice code-оо доор оруулна. Гэрээ хараахан байхгүй бол энэ хэсгийг хоосон үлдээгээрэй: банкны шилжүүлгээр ажиллана.' });
  else if (!st.tested) box = h('div', { class: 'stat warn', text: 'Мэдээлэл хадгалагдсан, гэхдээ QPay-тэй холболт шалгагдаагүй байна. «Холболт шалгах» дарна уу.' });
  else if (!st.on) box = h('div', { class: 'stat info', text: 'Холболт амжилттай. Доорх сонголтыг тавьж хэрэглэгчдэд QPay-ээр төлөх боломжийг нээнэ.' });
  else box = h('div', { class: 'stat ok', text: 'QPay идэвхтэй: хэрэглэгч QR болон банкны апп-аар төлнө, төлмөгц карт өөрөө нээгдэнэ.' });
  const err = st.err ? h('div', { class: 'stat bad', role: 'alert', text: 'Сүүлийн алдаа (' + App.fmtT(st.err.at) + '): ' + (QERR[st.err.code] || ('QPay алдаа ' + (st.err.status || '') + ' ' + st.err.code)) }) : null;
  const secret = h('input', { type: 'password', autocomplete: 'new-password', maxLength: 200, value: d.secret, disabled: env, placeholder: st.hasSecret ? 'Хадгалагдсан (солихгүй бол хоосон үлдээнэ)' : '', 'aria-label': 'QPay нууц үг', on: { input: e => { d.secret = e.target.value; } } });
  return U.panel('QPay-ээр төлөх (автомат)',
    box, err,
    env && h('p', { class: 'hint', style: { margin: '10px 0' }, text: 'Эдгээр мэдээлэл серверийн .env файлаар (QPAY_CLIENT_ID гэх мэт) тохируулагдсан тул эндээс өөрчлөхгүй. Орчин: ' + (st.env === 'sandbox' ? 'туршилт' : 'жинхэнэ') + '.' }),
    !env && h('div', { class: 'frm', style: { marginTop: '12px' } },
      U.field('Орчин', U.sel(d, 'env', [['sandbox', 'Туршилт (sandbox)'], ['prod', 'Жинхэнэ (production)']])),
      U.field('Нэвтрэх нэр (client id)', h('input', { type: 'text', autocomplete: 'off', maxLength: 120, value: d.id || '', 'aria-label': 'QPay нэвтрэх нэр', on: { input: e => { d.id = e.target.value; } } })),
      U.field('Нууц үг (client secret)', secret),
      U.field('Invoice code', h('input', { type: 'text', autocomplete: 'off', maxLength: 80, value: d.code || '', 'aria-label': 'QPay invoice code', on: { input: e => { d.code = e.target.value; } } }), { hint: 'QPay-ээс өгсөн' })),
    h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start', margin: '12px 0' } },
      !env && h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveQ } }),
      st.configured && h('button', { class: 'ghost', type: 'button', text: 'Холболт шалгах', on: { click: testQ } }),
      st.configured && !env && h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: clearQ } })),
    st.configured && st.tested && U.chk('QPay-ээр төлөхийг идэвхжүүлэх', st.on, toggleQ),
    h('p', { class: 'hint', style: { marginTop: '12px' }, text: 'Хэрэглэгч төлөхөд мөнгө таны QPay гэрээнд заасан дансанд шууд орно, апп мөнгө хадгалдаггүй. Карт нээгдэхийн өмнө сервер QPay-ээс «төлөгдсөн» эсэхийг өөрөөс нь лавладаг тул хуурамч дохиогоор нээгдэхгүй. Нууц үг шифрлэгдэн хадгалагдаж, хэзээ ч дэлгэц дээр буцаж гарахгүй. Төлбөрийн дохио (callback) нь серверийн https хаягаар ирдэг тул «BASE_URL» зөв байх ёстой.' }));
}

/* ---------- bank income: read from the owner's Gmail (server build only) ---------- */
const WHY = {
  no_code: 'Гүйлгээний утганд код (MN-XXXXXX) байхгүй',
  unknown_code: 'Утга дахь код ямар ч картад таарсангүй',
  ambiguous: 'Утга дахь код хэд хэдэн картад таарч байна',
  already_paid: 'Карт аль хэдийн баталгаажсан: давхар төлбөр байж болно',
  was_rejected: 'Та өмнө нь энэ картыг татгалзсан',
  free_mode: 'Үнэгүй горимд байна',
  amount_low: 'Дүн үнээс бага',
  auto_off: 'Автомат батлалт унтраалттай',
  other_account: 'Өөр дансанд орсон мөнгө',
  auth: 'Банкнаас ирсэн гэдэг нь баталгаажсангүй: хуурамч имэйл байж болно',
  admin: 'Та хассан'
};
const BANK_BADGE = { matched: ['Батлагдсан', 'ok'], open: ['Шалгах', 'warn'], ignored: ['Хассан', 'mute'], rejected: ['Татгалзсан', 'bad'] };
const bankAssign = U.busy('bank', async (r, cardId) => {
  if (!cardId) { App.toast('Эхлээд холбох картаа сонгоно уу.'); return; }
  await App.backend.bankAssign(r.id, cardId); App.toast('Орлого картад холбогдож, карт нээгдлээ.');
});
const bankIgnore = U.busy('bank', async r => {
  if (!(await App.confirm('Энэ орлогыг шалгах жагсаалтаас хасах уу? Дараа нь доорх жагсаалтаас гараар холбож болно.', 'Хасах', true))) return;
  await App.backend.bankIgnore(r.id); App.toast('Хасагдлаа.');
});
function bankStatus(compact) {
  const s = A.bank.status || {}, m = App.cfg.main, open = s.open || 0;
  let box;
  if (!s.enabled) box = h('div', { class: 'stat warn', text: 'Gmail холболт серверт тохируулагдаагүй байна. README-ийн «Gmail-ээр автомат батлах» хэсгийн дагуу серверийн .env файлд BANK_WEBHOOK_SECRET нэмнэ.' });
  else if (!m.autoPay) box = h('div', { class: 'stat info', text: 'Автомат батлалт унтраалттай. Орлого бүртгэгдэнэ, гэхдээ та гараар баталгаажуулна. «Тохиргоо» хэсгээс асаана.' });
  else if (s.stale) box = h('div', { class: 'stat bad', role: 'alert', text: (s.lastRun ? 'Gmail-ээс сүүлд ' + App.fmtT(s.lastRun) + ' цагт дохио ирсэн.' : 'Gmail-ээс одоогоор дохио ирээгүй байна.') + ' Автомат батлалт түр зогссон тул төлбөрийг гараар шалгана уу. Gmail-ийн Apps Script ажиллаж байгаа эсэхийг шалгана.' });
  else box = h('div', { class: 'stat ok', text: 'Автомат батлалт ажиллаж байна. Gmail-ээс сүүлд шалгасан: ' + App.fmtT(s.lastRun) + (s.lastMail ? ' · Сүүлийн орлого: ' + App.fmtT(s.lastMail) : '') });
  return U.panel('Банкны автомат батлалт', box,
    open > 0 && h('p', { style: { marginTop: '10px' } }, h('span', { text: 'Шалгах орлого: ' + open + ' ' }), compact && h('button', { class: 'ghost sm', type: 'button', text: 'Харах', on: { click: () => { A.sub = 'bank'; render(); } } })));
}
function bankRow(r) {
  const [bt, bc] = BANK_BADGE[r.st] || ['—', 'mute'], acts = [];
  if (r.st !== 'matched') {
    const sel = h('select', { 'aria-label': 'Холбох карт', on: { change: e => { A.bankSel[r.id] = e.target.value; } } },
      h('option', { value: '', text: 'Карт сонгох…' }),
      (A.bank.pending || []).map(c => h('option', { value: c.id, selected: (A.bankSel[r.id] || r.card) === c.id, text: c.ref + ' · ' + (c.to || 'Нэргүй') + (c.claimed ? ' · «Төлсөн» дарсан' : '') })));
    acts.push(sel, h('button', { class: 'okbtn', type: 'button', text: 'Холбох', on: { click: () => bankAssign(r, sel.value) } }));
    if (r.st === 'open') acts.push(h('button', { class: 'ghost sm', type: 'button', text: 'Хасах', on: { click: () => bankIgnore(r) } }));
  }
  const why = r.st === 'matched' ? ('Карт: ' + (r.card_info ? r.card_info.ref + ' «' + (r.card_info.to || 'Нэргүй') + '»' : 'устгагдсан') + (r.auto ? ' · автоматаар' : ' · гараар холбосон')) : (WHY[r.why] || '');
  return h('div', { class: 'row', 'data-id': r.id },
    h('div', { class: 'grow' },
      h('div', { class: 't', text: App.fmtMoney(r.amount) + ' · ' + (r.payer || 'Төлөгч мэдэгдэхгүй') + (r.acct ? ' (…' + r.acct + ')' : '') }),
      h('div', { class: 's', text: 'Утга: ' + (r.note || '—') }),
      h('div', { class: 's', text: App.fmtT(r.at) + (why ? ' · ' + why : '') })),
    h('span', { class: 'badge ' + bc, text: bt }), acts.length > 0 && h('div', { class: 'acts' }, acts));
}
function bank() {
  const list = A.bank.list || [], open = list.filter(r => r.st === 'open'), rest = list.filter(r => r.st !== 'open');
  return [
    bankStatus(false),
    U.panel('Шалгах орлого', h('p', { class: 'hint', style: { marginBottom: '10px' }, text: 'Гүйлгээний утганд код байхгүй, дүн дутуу, эсвэл өөр шалтгаанаар автоматаар таарахгүй орлогууд. Банкаа шалгаад зөв картад «Холбох» дарна.' }),
      open.length ? h('div', { class: 'rows' }, open.map(bankRow)) : h('p', { class: 'hint', text: 'Таарахгүй орлого алга.' })),
    U.panel('Сүүлийн орлогууд', rest.length ? h('div', { class: 'rows' }, rest.map(bankRow)) : h('p', { class: 'hint', text: 'Банкнаас орлогын мэдэгдэл хараахан ирээгүй байна.' }))
  ];
}

/* ---------- chrome ---------- */
const subs = () => [['dash', 'Самбар'], ['orders', 'Захиалга']].concat(App.backend.onBank ? [['bank', 'Банкны орлого']] : [], [['visitors', 'Хандсан хүмүүс'], ['settings', 'Тохиргоо'], ['studio', 'Студи']]);
function render() {
  const root = $('v-admin'); if (!root) return;
  const body = h('div', {});
  const f = { dash, orders, bank, visitors, settings, studio: () => App.renderStudio() }[A.sub] || dash;
  let kids; try { kids = f(); } catch (e) { console.error(e); kids = [h('div', { class: 'stat bad', text: 'Алдаа гарлаа: ' + e.message })]; }
  body.append(...[].concat(kids));
  const pn = pendingList().length;
  const bar = h('div', { class: 'sub-tabs', role: 'tablist' }, subs().map(([k, t]) => h('button', { class: 'chip', type: 'button', role: 'tab', 'aria-pressed': String(A.sub === k), text: t + (k === 'orders' && pn ? ' (' + pn + ')' : '') + (k === 'bank' && A.bank.status && A.bank.status.open ? ' (' + A.bank.status.open + ')' : ''), on: { click: () => { A.sub = k; render(); window.scrollTo(0, 0); } } })));
  const keepScroll = window.scrollY;
  root.textContent = ''; root.append(bar, body);
  window.scrollTo(0, keepScroll);
}
App.adminRender = render;
App.views.admin = { enter() { render(); } };
App.initAdmin = function () {
  if (A.started) return; A.started = true;
  App.backend.onOrders((list, users) => { A.orders = list; A.users = users || []; updateBadge(); resolveNames(); rerender(['dash', 'orders', 'visitors']); });
  App.backend.onVisitors(list => { A.visitors = list; resolveNames(); rerender(['dash', 'visitors']); });
  if (App.backend.qpayGet) qpayLoad();
  if (App.backend.onBank) App.backend.onBank(d => {
    /* the server's "last checked" time moves every minute: redraw only when something you can act on changed */
    const sig = x => JSON.stringify([x.list, x.pending, x.status && [x.status.enabled, x.status.autoPay, x.status.stale, x.status.open, x.status.lastMail]]);
    const changed = sig(d) !== sig(A.bank); A.bank = d;
    if (changed) rerender(['dash', 'bank']);
  });
  App.on('config', () => { updateBadge(); rerender(['dash', 'settings', 'studio']); });
};
})();
