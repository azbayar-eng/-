/* halloween.js — the Halloween pack: cute-but-startling creatures, colours, motifs, sounds and ready-made designs.
   Everything is a pure function of time, like the rest of the engine. Registered through Mend.ext. */
(function () {
'use strict';
const M = window.Mend, X = M.ext;
const { TAU, clamp, mix, smooth, easeOut, easeIn, rng, rgba, rr, sparkle, heart } = X;
const easeBack = x => { x = clamp(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
const pulse = (q, a, b, f) => smooth((q - a) / f) * (1 - smooth((q - b) / f));
const A = 2.65;

/* ---------- small drawing helpers ---------- */
function disc(ctx, x, y, r, fill) { ctx.fillStyle = fill; ctx.beginPath(); ctx.arc(x, y, Math.max(0.01, r), 0, TAU); ctx.fill(); }
function oval(ctx, x, y, rx, ry, fill, rot) { ctx.fillStyle = fill; ctx.beginPath(); ctx.ellipse(x, y, Math.max(0.01, rx), Math.max(0.01, ry), rot || 0, 0, TAU); ctx.fill(); }
function googly(ctx, x, y, r, px, py) {
  disc(ctx, x, y, r, '#FFFFFF'); ctx.strokeStyle = 'rgba(30,10,50,.45)'; ctx.lineWidth = r * 0.14; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke();
  const ox = x + px * r * 0.42, oy = y + py * r * 0.42; disc(ctx, ox, oy, r * 0.46, '#170A22'); disc(ctx, ox - r * 0.14, oy - r * 0.16, r * 0.14, '#FFFFFF');
}
function blush(ctx, x, y, r) { oval(ctx, x, y, r, r * 0.6, 'rgba(255,92,150,.45)'); }
function tri(ctx, x1, y1, x2, y2, x3, y3, fill) { ctx.fillStyle = fill; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.lineTo(x3, y3); ctx.closePath(); ctx.fill(); }

/* ---------- Pumpkin ---------- */
function drawPumpkin(ctx, x, y, s, o) {
  o = o || {}; const glow = o.glow == null ? 1 : o.glow, mo = o.mouth || 0, tg = o.tongue || 0, wk = o.wink || 0;
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot || 0); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  const g = ctx.createRadialGradient(0, 0, s * 0.3, 0, 0, s * 2.2); g.addColorStop(0, rgba('#FFB000', 0.4 * glow)); g.addColorStop(1, rgba('#FFB000', 0));
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s * 2.2, 0, TAU); ctx.fill();
  [[-0.66, 0.5, 0.8, '#C24A07'], [0.66, 0.5, 0.8, '#C24A07'], [-0.33, 0.56, 0.88, '#E4620E'], [0.33, 0.56, 0.88, '#E4620E'], [0, 0.56, 0.93, '#FF8A1F']].forEach(l => {
    oval(ctx, l[0] * s, 0.04 * s, l[1] * s, l[2] * s, l[3]); ctx.strokeStyle = 'rgba(95,25,0,.45)'; ctx.lineWidth = s * 0.03; ctx.stroke();
  });
  oval(ctx, -0.52 * s, -0.5 * s, 0.16 * s, 0.26 * s, 'rgba(255,255,255,.17)', -0.5);
  ctx.fillStyle = '#5E7F2B'; ctx.beginPath(); ctx.moveTo(-0.15 * s, -0.78 * s); ctx.quadraticCurveTo(-0.1 * s, -1.14 * s, 0.14 * s, -1.26 * s); ctx.lineTo(0.32 * s, -1.14 * s); ctx.quadraticCurveTo(0.14 * s, -1.0 * s, 0.17 * s, -0.78 * s); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#86C443'; ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.moveTo(0.2 * s, -0.96 * s); ctx.bezierCurveTo(0.62 * s, -1.02 * s, 0.78 * s, -0.76 * s, 0.56 * s, -0.7 * s); ctx.stroke();
  ctx.shadowColor = '#FFB000'; ctx.shadowBlur = s * 0.32 * glow; ctx.fillStyle = '#FFE066'; ctx.strokeStyle = '#4A1500'; ctx.lineWidth = s * 0.035;
  const T3 = (cx, cy, w, hh) => { ctx.beginPath(); ctx.moveTo(cx, cy - hh / 2); ctx.lineTo(cx + w / 2, cy + hh / 2); ctx.lineTo(cx - w / 2, cy + hh / 2); ctx.closePath(); };
  T3(-0.52 * s, -0.24 * s, 0.4 * s, 0.4 * s); ctx.fill(); ctx.stroke();
  const rh = 0.4 * s * (1 - wk * 0.86); T3(0.52 * s, -0.24 * s + (0.4 * s - rh) / 2, 0.4 * s, rh); ctx.fill(); ctx.stroke();
  T3(0, 0.03 * s, 0.17 * s, 0.15 * s); ctx.fill(); ctx.stroke();
  const yb = 0.2 * s, ab = (0.22 + 0.34 * mo) * s;
  ctx.beginPath(); ctx.moveTo(-0.82 * s, yb); ctx.quadraticCurveTo(0, yb + 0.22 * s, 0.82 * s, yb); ctx.quadraticCurveTo(0, yb + 2 * ab, -0.82 * s, yb); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.save(); ctx.clip(); ctx.fillStyle = '#E4620E';
  for (const px of [-0.54, -0.13, 0.28]) { ctx.beginPath(); ctx.moveTo(px * s, yb - 0.06 * s); ctx.lineTo((px + 0.27) * s, yb - 0.06 * s); ctx.lineTo((px + 0.135) * s, yb + 0.3 * s); ctx.closePath(); ctx.fill(); }
  if (mo > 0.3) for (const px of [-0.36, 0.1]) { const u0 = (px * s + 0.82 * s) / (1.64 * s), ly = yb + 2 * ab * u0 * (1 - u0); ctx.beginPath(); ctx.moveTo(px * s, ly + 0.04 * s); ctx.lineTo((px + 0.24) * s, ly + 0.04 * s); ctx.lineTo((px + 0.12) * s, ly - 0.2 * s); ctx.closePath(); ctx.fill(); }
  ctx.restore();
  if (tg > 0.02) {
    const tx = 0.22 * s, u1 = (tx + 0.82 * s) / (1.64 * s), ly = yb + 2 * ab * u1 * (1 - u1);
    oval(ctx, tx, ly + 0.1 * s * tg, 0.2 * s * (0.5 + 0.5 * tg), 0.26 * s * tg, '#FF5C8A'); ctx.strokeStyle = 'rgba(120,10,50,.5)'; ctx.lineWidth = s * 0.025; ctx.beginPath(); ctx.moveTo(tx, ly); ctx.lineTo(tx, ly + 0.2 * s * tg); ctx.stroke();
  }
  blush(ctx, -0.86 * s, 0.06 * s, 0.13 * s); blush(ctx, 0.86 * s, 0.06 * s, 0.13 * s);
  ctx.restore();
}

/* ---------- Mummy ---------- */
function drawMummy(ctx, x, y, s, o) {
  const t = o.t || 0, arm = o.arms == null ? 1 : o.arms, cross = o.cross || 0, mo = o.mouth || 0, rg = rng(77);
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot || 0); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.fillStyle = '#E3D8BC'; rr(ctx, -0.62 * s, 0.5 * s, 1.24 * s, 2.6 * s, 0.35 * s); ctx.fill();
  ctx.save(); rr(ctx, -0.62 * s, 0.5 * s, 1.24 * s, 2.6 * s, 0.35 * s); ctx.clip(); ctx.strokeStyle = 'rgba(110,90,55,.35)'; ctx.lineWidth = s * 0.02;
  for (let i = 0; i < 6; i++) { const yy = (0.7 + i * 0.26) * s; ctx.beginPath(); ctx.moveTo(-0.7 * s, yy + (rg() - 0.5) * 0.1 * s); ctx.lineTo(0.7 * s, yy + (rg() - 0.5) * 0.1 * s); ctx.stroke(); } ctx.restore();
  for (const sd of [-1, 1]) {
    ctx.save(); ctx.translate(sd * 0.5 * s, 0.85 * s); ctx.scale(sd, 1); ctx.rotate(-0.5 - 0.62 * arm + Math.sin(t * 9 + sd) * 0.07 * arm);
    ctx.fillStyle = '#E3D8BC'; rr(ctx, 0, -0.19 * s, 1.0 * s, 0.38 * s, 0.19 * s); ctx.fill();
    ctx.strokeStyle = 'rgba(110,90,55,.45)'; ctx.lineWidth = s * 0.025; for (let k = 1; k < 5; k++) { ctx.beginPath(); ctx.moveTo(k * 0.2 * s, -0.19 * s); ctx.lineTo(k * 0.2 * s - 0.05 * s, 0.19 * s); ctx.stroke(); }
    ctx.restore();
  }
  ctx.fillStyle = '#EFE6CE'; rr(ctx, -0.8 * s, -0.95 * s, 1.6 * s, 1.7 * s, 0.72 * s); ctx.fill();
  ctx.save(); rr(ctx, -0.8 * s, -0.95 * s, 1.6 * s, 1.7 * s, 0.72 * s); ctx.clip();
  const rg2 = rng(78);
  for (let i = 0; i < 9; i++) {
    ctx.save(); ctx.translate(0, -0.98 * s + i * 0.21 * s); ctx.rotate((rg2() - 0.5) * 0.4); ctx.fillStyle = i % 2 ? '#E1D6BA' : '#F6EFDB'; ctx.fillRect(-1 * s, 0, 2 * s, 0.17 * s);
    ctx.fillStyle = 'rgba(90,70,40,.22)'; ctx.fillRect(-1 * s, 0.17 * s, 2 * s, 0.025 * s); ctx.restore();
  }
  ctx.restore();
  ctx.fillStyle = '#1B1030'; rr(ctx, -0.64 * s, -0.42 * s, 1.28 * s, 0.5 * s, 0.24 * s); ctx.fill();
  for (const sd of [-1, 1]) googly(ctx, sd * 0.29 * s, -0.17 * s, 0.21 * s, -sd * cross * 0.9 + Math.sin(t * 3 + sd) * 0.35 * (1 - cross), 0.15 * cross + Math.cos(t * 2.3) * 0.2 * (1 - cross));
  oval(ctx, 0, 0.4 * s, 0.14 * s * (0.65 + 0.55 * mo), 0.1 * s * (0.5 + 0.9 * mo), '#2A1020');
  ctx.strokeStyle = '#F6EFDB'; ctx.lineWidth = s * 0.15; ctx.beginPath(); ctx.moveTo(0.46 * s, -0.84 * s); ctx.bezierCurveTo(1.1 * s + Math.sin(t * 6) * 0.15 * s, -1.25 * s, 1.35 * s, -0.55 * s + Math.cos(t * 5) * 0.2 * s, 1.05 * s, -0.3 * s + Math.sin(t * 7) * 0.12 * s); ctx.stroke();
  ctx.strokeStyle = 'rgba(90,70,40,.3)'; ctx.lineWidth = s * 0.03; ctx.stroke();
  ctx.restore();
}

/* ---------- Skull and skeleton ---------- */
function drawSkull(ctx, x, y, s, o) {
  const bone = '#F6F1E2', edge = '#CBBFA2', jaw = (o.jaw || 0) * 0.22 * s, lk = o.look || 0;
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.tilt || 0); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.strokeStyle = edge; ctx.lineWidth = s * 0.04;
  ctx.fillStyle = bone; rr(ctx, -0.48 * s, 0.36 * s + jaw, 0.96 * s, 0.4 * s, 0.17 * s); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = 'rgba(80,60,40,.5)'; ctx.lineWidth = s * 0.03; for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(i * 0.16 * s, 0.45 * s + jaw); ctx.lineTo(i * 0.16 * s, 0.72 * s + jaw); ctx.stroke(); }
  ctx.strokeStyle = edge; ctx.lineWidth = s * 0.04; ctx.fillStyle = bone;
  ctx.beginPath(); ctx.ellipse(0, 0, 0.8 * s, 0.74 * s, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-0.55 * s, 0.3 * s); ctx.quadraticCurveTo(-0.5 * s, 0.52 * s, -0.4 * s, 0.5 * s); ctx.lineTo(0.4 * s, 0.5 * s); ctx.quadraticCurveTo(0.5 * s, 0.52 * s, 0.55 * s, 0.3 * s); ctx.fill();
  ctx.strokeStyle = 'rgba(80,60,40,.5)'; ctx.lineWidth = s * 0.03; for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(i * 0.16 * s, 0.4 * s); ctx.lineTo(i * 0.16 * s, 0.52 * s); ctx.stroke(); }
  for (const sd of [-1, 1]) {
    oval(ctx, sd * 0.3 * s, -0.04 * s, 0.22 * s, 0.26 * s, '#1B0F2A', sd * 0.12);
    ctx.shadowColor = '#FF9A2E'; ctx.shadowBlur = s * 0.2; disc(ctx, sd * 0.3 * s + lk * 0.05 * s, -0.02 * s, 0.075 * s, '#FFB347'); ctx.shadowBlur = 0;
  }
  tri(ctx, -0.07 * s, 0.26 * s, 0.07 * s, 0.26 * s, 0, 0.14 * s, '#1B0F2A');
  blush(ctx, -0.6 * s, 0.22 * s, 0.1 * s); blush(ctx, 0.6 * s, 0.22 * s, 0.1 * s);
  ctx.restore();
}
function drawSkeleton(ctx, x, y, s, o) {
  const bone = '#F6F1E2', edge = '#CBBFA2', sway = o.sway || 0, lift = (o.lift || 0) * s;
  ctx.save(); ctx.translate(x, y); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const stroke2 = (w) => { ctx.strokeStyle = edge; ctx.lineWidth = w + s * 0.04; ctx.stroke(); ctx.strokeStyle = bone; ctx.lineWidth = w; ctx.stroke(); };
  ctx.beginPath(); ctx.moveTo(sway * s * 0.2, 0.7 * s); ctx.lineTo(0, 2.6 * s); stroke2(s * 0.14);
  for (let i = 0; i < 3; i++) { const yy = (1.2 + i * 0.34) * s, w = (0.66 - i * 0.07) * s; ctx.beginPath(); ctx.moveTo(-w, yy - 0.1 * s); ctx.quadraticCurveTo(0, yy + 0.26 * s, w, yy - 0.1 * s); stroke2(s * 0.12); }
  for (const sd of [-1, 1]) {
    const a = (sd < 0 ? o.armL : o.armR) || 0, sx = sd * 0.7 * s, sy = 1.08 * s, f1 = 0.5 + a, ex = sx + sd * Math.sin(f1) * 0.95 * s, ey = sy + Math.cos(f1) * 0.95 * s, f2 = f1 + 0.5, hx = ex + sd * Math.sin(f2) * 0.8 * s, hy = ey + Math.cos(f2) * 0.8 * s;
    ctx.beginPath(); ctx.moveTo(sd * 0.1 * s, 1.0 * s); ctx.lineTo(sx, sy); ctx.lineTo(ex, ey); ctx.lineTo(hx, hy); stroke2(s * 0.12);
    disc(ctx, ex, ey, s * 0.11, bone); oval(ctx, hx, hy, 0.17 * s, 0.14 * s, bone);
  }
  drawSkull(ctx, sway * s * 0.25, -lift, s, { jaw: o.jaw, look: o.look, tilt: sway * 0.12 });
  ctx.restore();
}

/* ---------- Zombie hand ---------- */
function drawHand(ctx, x, y, s, o) {
  const skin = '#86C85A', dk = '#4F9232', curl = o.curl || 0, lk = o.look || 0;
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.wave || 0); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.fillStyle = skin; ctx.beginPath(); ctx.moveTo(-0.34 * s, 0); ctx.lineTo(-0.42 * s, 3.2 * s); ctx.lineTo(0.42 * s, 3.2 * s); ctx.lineTo(0.34 * s, 0); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#4B2A7A'; ctx.beginPath(); ctx.moveTo(-0.52 * s, 0.95 * s); for (let i = 0; i <= 6; i++) ctx.lineTo((-0.52 + i * 0.1733) * s, (i % 2 ? 0.78 : 0.97) * s); ctx.lineTo(0.55 * s, 3.2 * s); ctx.lineTo(-0.55 * s, 3.2 * s); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.moveTo(-0.2 * s, 1.1 * s); ctx.lineTo(-0.22 * s, 3 * s); ctx.stroke();
  ctx.strokeStyle = dk; ctx.lineWidth = s * 0.03; for (let i = 0; i < 4; i++) { const yy = (0.1 + i * 0.12) * s; ctx.beginPath(); ctx.moveTo(-0.2 * s, yy); ctx.lineTo(0.2 * s, yy + 0.04 * s); ctx.stroke(); }
  const fb = [-0.31, -0.1, 0.11, 0.31], fa = [-0.22, -0.07, 0.07, 0.22], fl = [0.62, 0.78, 0.72, 0.56];
  for (let i = 0; i < 4; i++) {
    const len = fl[i] * s * (1 - 0.62 * curl), bx = fb[i] * s, by = -0.5 * s, ang = fa[i], tx = bx + Math.sin(ang) * len, ty = by - Math.cos(ang) * len;
    ctx.strokeStyle = dk; ctx.lineWidth = s * 0.2; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(tx, ty); ctx.stroke(); ctx.strokeStyle = skin; ctx.lineWidth = s * 0.16; ctx.stroke();
    if (curl < 0.6) oval(ctx, tx, ty - s * 0.02, s * 0.06, s * 0.08, '#EFE6B8', ang);
  }
  ctx.fillStyle = skin; ctx.strokeStyle = dk; ctx.lineWidth = s * 0.03; rr(ctx, -0.44 * s, -0.66 * s, 0.88 * s, 0.82 * s, 0.3 * s); ctx.fill(); ctx.stroke();
  const ta = mix(-1.15, -0.1, curl), tb = { x: mix(-0.4, -0.38, curl) * s, y: mix(-0.06, -0.2, curl) * s }, tl = (0.52 + 0.34 * curl) * s, tx = tb.x + Math.sin(ta) * tl, ty = tb.y - Math.cos(ta) * tl;
  ctx.strokeStyle = dk; ctx.lineWidth = s * 0.22; ctx.beginPath(); ctx.moveTo(tb.x, tb.y); ctx.lineTo(tx, ty); ctx.stroke(); ctx.strokeStyle = skin; ctx.lineWidth = s * 0.18; ctx.stroke();
  oval(ctx, tx, ty - s * 0.02, s * 0.07, s * 0.09, '#EFE6B8', ta);
  if (curl > 0.4) { for (let i = 0; i < 4; i++) { const kx = fb[i] * s * 1.05, ky = -0.62 * s; oval(ctx, kx, ky, 0.13 * s, 0.11 * s, skin); ctx.strokeStyle = dk; ctx.lineWidth = s * 0.025; ctx.beginPath(); ctx.ellipse(kx, ky, 0.13 * s, 0.11 * s, 0, 0, TAU); ctx.stroke(); } }
  googly(ctx, 0.02 * s, -0.27 * s, 0.22 * s, Math.sin(lk * 2) * 0.8, Math.cos(lk * 1.7) * 0.6);
  ctx.strokeStyle = dk; ctx.lineWidth = s * 0.025; ctx.beginPath(); ctx.moveTo(0.18 * s, 0.02 * s); ctx.lineTo(0.34 * s, -0.1 * s); ctx.moveTo(0.22 * s, -0.04 * s); ctx.lineTo(0.2 * s, -0.12 * s); ctx.stroke();
  ctx.restore();
}
function drawMound(ctx, w, h, u, top, ch) {
  const y = top + ch;
  ctx.fillStyle = '#3A2315'; ctx.beginPath(); ctx.ellipse(w / 2, y + u * 0.02, w * 0.46, ch * 0.055, 0, Math.PI, TAU); ctx.fill();
  ctx.fillStyle = '#2C1A0F'; ctx.beginPath(); ctx.ellipse(w / 2, y + u * 0.02, w * 0.46, ch * 0.03, 0, Math.PI, TAU); ctx.fill();
  const r = rng(61); ctx.strokeStyle = '#5FAE3A'; ctx.lineWidth = Math.max(2, u * 0.012); ctx.lineCap = 'round';
  for (let i = 0; i < 12; i++) { const gx = w * (0.12 + 0.76 * r()), gh = u * (0.03 + 0.04 * r()); ctx.beginPath(); ctx.moveTo(gx, y - ch * 0.01); ctx.quadraticCurveTo(gx + gh * 0.3, y - gh * 0.7 - ch * 0.01, gx + (r() - 0.5) * gh, y - gh - ch * 0.01); ctx.stroke(); }
}

/* ---------- Cute monster ---------- */
function drawMonster(ctx, x, y, s, o) {
  const t = o.t || 0, mo = o.mouth || 0, hp = o.happy || 0, lk = o.look || 0, sq = o.squash || 0, arms = o.arms == null ? 1 : o.arms;
  ctx.save(); ctx.translate(x, y); ctx.scale(1 + sq, 1 - sq); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  for (const sd of [-1, 1]) { tri(ctx, sd * 0.38 * s, -0.8 * s, sd * 0.72 * s, -0.7 * s, sd * 0.62 * s, -1.3 * s, '#FFE0A0'); }
  for (const sd of [-1, 1]) {
    ctx.save(); ctx.translate(sd * 0.95 * s, 0.35 * s); ctx.rotate(sd * (0.6 + 0.7 * arms) + Math.sin(t * 14 + sd) * 0.12 * arms); oval(ctx, sd * 0.18 * s, -0.1 * s, 0.34 * s, 0.2 * s, '#7B3BC9');
    for (let k = 0; k < 3; k++) disc(ctx, sd * (0.46 + k * 0.01) * s, (-0.2 + k * 0.1) * s, 0.05 * s, '#FFF1D0'); ctx.restore();
  }
  const g = ctx.createRadialGradient(-0.3 * s, -0.4 * s, s * 0.1, 0, 0, s * 1.1); g.addColorStop(0, '#B672F2'); g.addColorStop(1, '#6A2BC0');
  ctx.fillStyle = '#7F39D1'; for (let i = 0; i < 40; i++) { const a = i * TAU / 40, r = s * (0.97 + 0.03 * Math.sin(a * 5 + t * 8)); ctx.beginPath(); ctx.arc(Math.cos(a) * r, Math.sin(a) * r, s * 0.13, 0, TAU); ctx.fill(); }
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s * 1.0, 0, TAU); ctx.fill();
  oval(ctx, 0, 0.5 * s, 0.62 * s, 0.4 * s, 'rgba(214,170,255,.35)');
  if (hp > 0.5) {
    ctx.strokeStyle = '#1B0B2E'; ctx.lineWidth = s * 0.08;
    [[0, -0.4, 0.26], [-0.56, -0.2, 0.16], [0.56, -0.2, 0.16]].forEach(e => { ctx.beginPath(); ctx.arc(e[0] * s, (e[1] + 0.08) * s, e[2] * s, Math.PI * 1.12, Math.PI * 1.88); ctx.stroke(); });
  } else {
    googly(ctx, 0, -0.4 * s, 0.3 * s, lk * 0.9, 0.2); googly(ctx, -0.56 * s, -0.2 * s, 0.17 * s, lk, -0.2); googly(ctx, 0.56 * s, -0.2 * s, 0.17 * s, -lk * 0.6, 0.3);
  }
  const yb = 0.2 * s, ab = (0.16 + 0.42 * mo) * s;
  ctx.fillStyle = '#2B0B3F'; ctx.beginPath(); ctx.moveTo(-0.66 * s, yb); ctx.quadraticCurveTo(0, yb + 0.12 * s, 0.66 * s, yb); ctx.quadraticCurveTo(0, yb + 2 * ab, -0.66 * s, yb); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.clip(); ctx.fillStyle = '#FFFFFF';
  for (let i = 0; i < 5; i++) { const px = (-0.5 + i * 0.25) * s; ctx.beginPath(); ctx.moveTo(px, yb - 0.04 * s); ctx.lineTo(px + 0.2 * s, yb - 0.04 * s); ctx.lineTo(px + 0.1 * s, yb + (0.2 + 0.04 * (i % 2)) * s); ctx.closePath(); ctx.fill(); }
  if (mo > 0.35) oval(ctx, 0, yb + ab * 1.05, 0.34 * s, 0.22 * s * (0.5 + mo), '#FF6FA3');
  ctx.restore();
  blush(ctx, -0.76 * s, 0.12 * s, 0.14 * s); blush(ctx, 0.76 * s, 0.12 * s, 0.14 * s);
  ctx.restore();
}

/* ---------- Black cat ---------- */
function drawCat(ctx, x, y, s, o) {
  const fl = o.fluff || 0, pu = o.pupil == null ? 1 : o.pupil, ht = o.heart || 0, mo = o.mouth || 0, t = o.t || 0, K = '#170D26';
  ctx.save(); ctx.translate(x, y); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.strokeStyle = K; ctx.lineWidth = s * (0.22 + 0.22 * fl); ctx.beginPath(); ctx.moveTo(0.7 * s, 1.5 * s); ctx.bezierCurveTo(1.7 * s, 1.5 * s, 1.5 * s + Math.sin(t * (fl > 0.5 ? 14 : 4)) * 0.1 * s, 0.4 * s, 1.1 * s, -0.25 * s + Math.sin(t * 4) * 0.1 * s); ctx.stroke();
  ctx.fillStyle = K; ctx.beginPath();
  const hw = yy => (0.74 + 0.42 * smooth((yy - 0.4) / 1.1) - 0.1 * smooth((yy - 1.8) / 0.8)) * s, N = 22;
  for (let i = 0; i <= N; i++) { const yy = 0.45 + i * (2.7 - 0.45) / N, sp = (i % 2 && fl > 0.02 && yy < 1.9) ? 0.16 * fl * s : 0; ctx.lineTo(-(hw(yy) + sp), yy * s); }
  for (let i = N; i >= 0; i--) { const yy = 0.45 + i * (2.7 - 0.45) / N, sp = (i % 2 && fl > 0.02 && yy < 1.9) ? 0.16 * fl * s : 0; ctx.lineTo(hw(yy) + sp, yy * s); }
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(176,124,255,.4)'; ctx.lineWidth = s * 0.035; ctx.beginPath(); for (let i = 0; i <= N; i++) { const yy = 0.5 + i * (1.9 - 0.5) / N; i ? ctx.lineTo(-hw(yy), yy * s) : ctx.moveTo(-hw(yy), yy * s); } ctx.stroke(); ctx.beginPath(); for (let i = 0; i <= N; i++) { const yy = 0.5 + i * (1.9 - 0.5) / N; i ? ctx.lineTo(hw(yy), yy * s) : ctx.moveTo(hw(yy), yy * s); } ctx.stroke();
  oval(ctx, 0, 1.55 * s, 0.55 * s, 0.7 * s, 'rgba(255,255,255,.04)');
  for (const sd of [-1, 1]) { tri(ctx, sd * 0.74 * s, -0.4 * s, sd * 0.66 * s, -1.32 * s, sd * 0.1 * s, -0.78 * s, K); tri(ctx, sd * 0.62 * s, -0.5 * s, sd * 0.58 * s, -1.05 * s, sd * 0.26 * s, -0.74 * s, '#FF9EBB'); }
  disc(ctx, 0, -0.05 * s, 0.8 * s, K); ctx.strokeStyle = 'rgba(176,124,255,.4)'; ctx.lineWidth = s * 0.04; ctx.beginPath(); ctx.arc(0, -0.05 * s, 0.8 * s, Math.PI * 1.05, Math.PI * 1.45); ctx.stroke();
  for (const sd of [-1, 1]) {
    const cx = sd * 0.36 * s, cy = -0.12 * s; ctx.shadowColor = '#E4FF3A'; ctx.shadowBlur = s * 0.22; oval(ctx, cx, cy, 0.27 * s, 0.3 * s, '#E4FF3A'); ctx.shadowBlur = 0;
    if (ht > 0.05) { ctx.fillStyle = '#FF3D7F'; heart(ctx, cx, cy - 0.04 * s, s * 0.17 * ht); ctx.fill(); }
    else oval(ctx, cx, cy, s * (0.05 + 0.17 * (1 - pu)), 0.28 * s, '#0B0614');
    disc(ctx, cx - 0.08 * s, cy - 0.12 * s, 0.06 * s, '#FFFFFF');
  }
  tri(ctx, -0.07 * s, 0.14 * s, 0.07 * s, 0.14 * s, 0, 0.23 * s, '#FF9EBB');
  if (mo > 0.05) {
    oval(ctx, 0, 0.42 * s, 0.27 * s * (0.6 + 0.4 * mo), 0.2 * s * mo, '#6B0F2A');
    tri(ctx, -0.17 * s, 0.3 * s, -0.07 * s, 0.3 * s, -0.12 * s, 0.4 * s, '#FFFFFF'); tri(ctx, 0.17 * s, 0.3 * s, 0.07 * s, 0.3 * s, 0.12 * s, 0.4 * s, '#FFFFFF');
    oval(ctx, 0, 0.5 * s, 0.1 * s * mo, 0.06 * s * mo, '#FF7AA5');
  } else { ctx.strokeStyle = '#FF9EBB'; ctx.lineWidth = s * 0.03; ctx.beginPath(); ctx.moveTo(0, 0.23 * s); ctx.lineTo(0, 0.3 * s); ctx.moveTo(-0.16 * s, 0.34 * s); ctx.quadraticCurveTo(-0.08 * s, 0.4 * s, 0, 0.3 * s); ctx.quadraticCurveTo(0.08 * s, 0.4 * s, 0.16 * s, 0.34 * s); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = s * 0.02;
  for (const sd of [-1, 1]) for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(sd * 0.46 * s, (0.2 + k * 0.08) * s); ctx.lineTo(sd * 1.3 * s, (0.02 + k * 0.2) * s - 0.1 * s); ctx.stroke(); }
  ctx.restore();
}

/* ---------- Vampire ---------- */
function drawVampire(ctx, x, y, s, o) {
  const cp = o.cape == null ? 1 : o.cape, fg = o.fang || 0, gl = o.glow == null ? 1 : o.glow, mo = o.mouth || 0, W = (0.85 + 0.95 * cp) * s;
  ctx.save(); ctx.translate(x, y); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  let g = ctx.createLinearGradient(0, 0, 0, 2.4 * s); g.addColorStop(0, '#A21233'); g.addColorStop(1, '#2A0716');
  ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-0.5 * s, 0.4 * s); ctx.quadraticCurveTo(-W, 0.9 * s, -W * 1.05, 2.6 * s); ctx.lineTo(W * 1.05, 2.6 * s); ctx.quadraticCurveTo(W, 0.9 * s, 0.5 * s, 0.4 * s); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#17082A'; rr(ctx, -0.62 * s, 0.7 * s, 1.24 * s, 2.0 * s, 0.4 * s); ctx.fill();
  tri(ctx, -0.3 * s, 0.75 * s, 0.3 * s, 0.75 * s, 0, 1.5 * s, '#F4EEF8'); disc(ctx, 0, 0.98 * s, 0.1 * s, '#E0183F');
  for (const sd of [-1, 1]) { ctx.fillStyle = '#17082A'; ctx.beginPath(); ctx.moveTo(sd * 0.3 * s, 0.55 * s); ctx.lineTo(sd * 1.0 * s, -0.15 * s); ctx.lineTo(sd * 0.9 * s, 1.0 * s); ctx.lineTo(sd * 0.25 * s, 0.9 * s); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#D01F48'; ctx.lineWidth = s * 0.05; ctx.stroke(); }
  for (const sd of [-1, 1]) tri(ctx, sd * 0.55 * s, -0.05 * s, sd * 0.9 * s, -0.5 * s, sd * 0.6 * s, -0.4 * s, '#E6DDF0');
  g = ctx.createRadialGradient(-0.2 * s, -0.3 * s, s * 0.1, 0, 0, s * 0.9); g.addColorStop(0, '#FBF7FF'); g.addColorStop(1, '#D8CCE8');
  ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, -0.02 * s, 0.64 * s, 0.74 * s, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#150A24'; ctx.beginPath(); ctx.moveTo(-0.66 * s, -0.05 * s); ctx.quadraticCurveTo(-0.78 * s, -0.95 * s, 0, -0.88 * s); ctx.quadraticCurveTo(0.78 * s, -0.95 * s, 0.66 * s, -0.05 * s); ctx.lineTo(0.42 * s, -0.45 * s); ctx.lineTo(0, -0.18 * s); ctx.lineTo(-0.42 * s, -0.45 * s); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#150A24'; ctx.lineWidth = s * 0.08; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * 0.46 * s, -0.3 * s); ctx.lineTo(sd * 0.12 * s, -0.17 * s); ctx.stroke(); }
  for (const sd of [-1, 1]) { ctx.shadowColor = '#FF2B4E'; ctx.shadowBlur = s * 0.25 * gl; oval(ctx, sd * 0.27 * s, -0.02 * s, 0.13 * s, 0.16 * s, '#FF2B4E'); ctx.shadowBlur = 0; disc(ctx, sd * 0.27 * s - 0.04 * s, -0.07 * s, 0.045 * s, '#FFFFFF'); }
  tri(ctx, -0.04 * s, 0.14 * s, 0.04 * s, 0.14 * s, 0, 0.22 * s, 'rgba(120,80,140,.6)');
  const yb = 0.3 * s; ctx.fillStyle = '#3A0A18'; ctx.beginPath(); ctx.moveTo(-0.3 * s, yb); ctx.quadraticCurveTo(0, yb + 0.16 * s + 0.4 * s * mo, 0.3 * s, yb); ctx.quadraticCurveTo(0, yb - 0.05 * s, -0.3 * s, yb); ctx.closePath(); ctx.fill();
  for (const sd of [-1, 1]) tri(ctx, sd * 0.2 * s, yb - 0.01 * s, sd * 0.07 * s, yb - 0.01 * s, sd * 0.14 * s, yb + (0.08 + 0.34 * fg) * s, '#FFFFFF');
  blush(ctx, -0.46 * s, 0.14 * s, 0.1 * s); blush(ctx, 0.46 * s, 0.14 * s, 0.1 * s);
  ctx.restore();
}

/* ---------- Witch on a broom (faces right) ---------- */
function drawWitch(ctx, x, y, s, o) {
  const t = o.t || 0;
  ctx.save(); ctx.translate(x, y); ctx.scale(o.dir || 1, 1); ctx.rotate(o.tilt || 0); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  for (let i = 0; i < 9; i++) { const k = i / 9; ctx.fillStyle = rgba(i % 2 ? '#B6FF5C' : '#E0A8FF', 0.9 * (1 - k)); sparkle(ctx, -2.5 * s - k * 2.4 * s, Math.sin(t * 8 + i * 1.3) * 0.28 * s + k * 0.3 * s, s * 0.2 * (1 - k * 0.7)); }
  ctx.strokeStyle = '#7A4A22'; ctx.lineWidth = s * 0.13; ctx.beginPath(); ctx.moveTo(-1.5 * s, 0.1 * s); ctx.lineTo(1.4 * s, -0.05 * s); ctx.stroke();
  ctx.fillStyle = '#E3B44E'; ctx.beginPath(); ctx.moveTo(-1.45 * s, 0.1 * s); ctx.lineTo(-2.3 * s, -0.3 * s); ctx.lineTo(-2.45 * s, 0.1 * s); ctx.lineTo(-2.3 * s, 0.5 * s); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#B07F26'; ctx.lineWidth = s * 0.03; for (let k = -2; k <= 2; k++) { ctx.beginPath(); ctx.moveTo(-1.5 * s, 0.1 * s); ctx.lineTo(-2.4 * s, 0.1 * s + k * 0.17 * s); ctx.stroke(); }
  ctx.fillStyle = '#C0392B'; ctx.fillRect(-1.58 * s, -0.08 * s, 0.14 * s, 0.4 * s);
  oval(ctx, -0.9 * s, -0.42 * s, 0.32 * s, 0.38 * s, '#170D26'); disc(ctx, -0.82 * s, -0.95 * s, 0.26 * s, '#170D26'); tri(ctx, -1.02 * s, -1.1 * s, -0.96 * s, -1.38 * s, -0.84 * s, -1.14 * s, '#170D26'); tri(ctx, -0.8 * s, -1.14 * s, -0.68 * s, -1.38 * s, -0.62 * s, -1.08 * s, '#170D26');
  disc(ctx, -0.9 * s, -0.98 * s, 0.05 * s, '#B6FF5C'); disc(ctx, -0.74 * s, -0.98 * s, 0.05 * s, '#B6FF5C');
  ctx.strokeStyle = '#170D26'; ctx.lineWidth = s * 0.12; ctx.beginPath(); ctx.moveTo(-1.15 * s, -0.1 * s); ctx.quadraticCurveTo(-1.6 * s, -0.5 * s, -1.4 * s, -0.95 * s + Math.sin(t * 5) * 0.1 * s); ctx.stroke();
  oval(ctx, 0.12 * s, -0.4 * s, 0.52 * s, 0.58 * s, '#6A33B5');
  ctx.strokeStyle = '#2A1347'; ctx.lineWidth = s * 0.17; for (const dx of [0.1, 0.4]) { ctx.beginPath(); ctx.moveTo(dx * s, 0.15 * s); ctx.lineTo((dx + 0.05) * s, 0.65 * s); ctx.stroke(); ctx.strokeStyle = dx < 0.2 ? '#FF8A1F' : '#FF8A1F'; ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.moveTo((dx - 0.07) * s, 0.3 * s); ctx.lineTo((dx + 0.07) * s, 0.3 * s); ctx.stroke(); ctx.strokeStyle = '#2A1347'; ctx.lineWidth = s * 0.17; }
  oval(ctx, 0.45 * s, 0.68 * s, 0.2 * s, 0.1 * s, '#170D26'); oval(ctx, 0.15 * s, 0.7 * s, 0.2 * s, 0.1 * s, '#170D26');
  ctx.strokeStyle = '#6A33B5'; ctx.lineWidth = s * 0.17; ctx.beginPath(); ctx.moveTo(0.3 * s, -0.7 * s); ctx.lineTo(0.95 * s, -0.12 * s); ctx.stroke(); disc(ctx, 1.0 * s, -0.08 * s, 0.12 * s, '#8FD14F');
  for (let k = 0; k < 5; k++) { ctx.strokeStyle = '#FF8A1F'; ctx.lineWidth = s * 0.09; ctx.beginPath(); ctx.moveTo(0.05 * s, (-1.2 + k * 0.08) * s); ctx.quadraticCurveTo(-0.5 * s, (-1.1 + k * 0.18) * s + Math.sin(t * 7 + k) * 0.1 * s, -0.95 * s - k * 0.08 * s, (-0.8 + k * 0.28) * s + Math.sin(t * 6 + k) * 0.12 * s); ctx.stroke(); }
  disc(ctx, 0.3 * s, -1.2 * s, 0.44 * s, '#8FD14F'); tri(ctx, 0.62 * s, -1.28 * s, 0.62 * s, -1.0 * s, 1.0 * s, -1.02 * s, '#8FD14F'); disc(ctx, 0.9 * s, -1.0 * s, 0.045 * s, '#4F8F2A');
  googly(ctx, 0.47 * s, -1.28 * s, 0.1 * s, 0.7, 0.1);
  ctx.strokeStyle = '#2A1347'; ctx.lineWidth = s * 0.04; ctx.beginPath(); ctx.arc(0.5 * s, -1.08 * s, 0.17 * s, 0.15, Math.PI - 0.2); ctx.stroke(); tri(ctx, 0.4 * s, -0.93 * s, 0.48 * s, -0.93 * s, 0.44 * s, -0.84 * s, '#FFFFFF');
  ctx.fillStyle = '#170D26'; ctx.beginPath(); ctx.ellipse(0.28 * s, -1.5 * s, 0.84 * s, 0.15 * s, -0.08, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.moveTo(-0.28 * s, -1.55 * s); ctx.quadraticCurveTo(0.1 * s, -2.1 * s, -0.25 * s + Math.sin(t * 5) * 0.06 * s, -2.9 * s); ctx.quadraticCurveTo(0.75 * s, -2.1 * s, 0.82 * s, -1.55 * s); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#8B3FD6'; ctx.beginPath(); ctx.moveTo(-0.25 * s, -1.6 * s); ctx.lineTo(0.8 * s, -1.6 * s); ctx.lineTo(0.78 * s, -1.78 * s); ctx.lineTo(-0.2 * s, -1.78 * s); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#FFC83D'; ctx.fillRect(0.2 * s, -1.8 * s, 0.2 * s, 0.22 * s); ctx.fillStyle = '#170D26'; ctx.fillRect(0.25 * s, -1.75 * s, 0.1 * s, 0.12 * s);
  ctx.restore();
}

/* ---------- Slime that covers the top of the card ---------- */
function drawSlime(ctx, w, h, u, top, ch, t, c) {
  const cov = c.cov, off = c.drop * (ch + 80), base = ch * 0.27 * cov, r = rng(123), n = 10;
  ctx.save(); ctx.translate(0, off);
  const g = ctx.createLinearGradient(0, 0, 0, base + ch * 0.25); g.addColorStop(0, '#5FD52B'); g.addColorStop(1, '#2FB84B');
  ctx.fillStyle = g; ctx.fillRect(-40, -40, w + 80, base + 40);
  for (let i = 0; i < n; i++) {
    const x = w * (i + 0.5) / n + (r() - 0.5) * w * 0.03, rad = w * (0.032 + 0.03 * r()), len = base + ch * (0.03 + 0.19 * r()) * cov + Math.sin(t * 2 + i) * ch * 0.012 * cov;
    ctx.fillRect(x - rad, base - 4, rad * 2, len - base + 4); ctx.beginPath(); ctx.arc(x, len, rad * 1.12, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.3)'; ctx.fillRect(x - rad * 0.55, base, rad * 0.28, Math.max(0, len - base - rad * 0.2)); ctx.fillStyle = g;
  }
  ctx.fillStyle = 'rgba(255,255,255,.22)'; ctx.beginPath(); ctx.ellipse(w * 0.3, base * 0.35, w * 0.16, base * 0.07, -0.1, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(w * 0.72, base * 0.5, w * 0.1, base * 0.05, 0.1, 0, TAU); ctx.fill();
  const lk = Math.sin(t * 3) * 0.7, ey = base * 0.62, er = w * 0.1;
  googly(ctx, w * 0.35, ey, er, lk, 0.2); googly(ctx, w * 0.65, ey, er, lk, 0.2);
  ctx.strokeStyle = '#0B5A25'; ctx.lineWidth = Math.max(2, w * 0.016); ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(w * 0.5, ey + er * 0.3, er * 1.2, 0.25, Math.PI - 0.25); ctx.stroke();
  ctx.restore();
}

/* ---------- Ambient effects ---------- */
function fxCandy(ctx, w, h, u, th, t) {
  const r = rng(91), cols = ['#FF6A00', '#FFD23F', '#B14CFF', '#4DE0A8', '#FF5C8E', '#FFFFFF'];
  for (let i = 0; i < 27; i++) {
    const sp = 0.08 + r() * 0.12, o = r(), sz = u * (0.028 + r() * 0.03), ph = r() * TAU, x0 = r(), kind = i % 3, col = cols[(r() * cols.length) | 0];
    const pad = sz * 4, f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 1.2 + ph) * u * 0.05;
    ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(t * 1.6 + ph) * 0.7);
    if (kind === 0) {
      ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(0, 0, sz * 0.8, sz * 0.5, 0, 0, TAU); ctx.fill();
      for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * sz * 0.7, 0); ctx.lineTo(sd * sz * 1.45, -sz * 0.55); ctx.lineTo(sd * sz * 1.45, sz * 0.55); ctx.closePath(); ctx.fill(); }
      ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.ellipse(-sz * 0.2, -sz * 0.15, sz * 0.35, sz * 0.12, 0, 0, TAU); ctx.fill();
    } else if (kind === 1) {
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = Math.max(1.5, sz * 0.18); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, sz * 2.3); ctx.stroke();
      disc(ctx, 0, 0, sz, col); ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = Math.max(1, sz * 0.16); ctx.beginPath(); ctx.arc(0, 0, sz * 0.62, 0, TAU * 0.8); ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, sz * 0.28, 0, TAU * 0.8); ctx.stroke();
    } else {
      oval(ctx, 0, 0, sz * 0.95, sz * 0.8, '#FF8A1F'); oval(ctx, -sz * 0.35, 0, sz * 0.5, sz * 0.78, '#E4620E'); oval(ctx, sz * 0.35, 0, sz * 0.5, sz * 0.78, '#E4620E'); ctx.fillStyle = '#5E7F2B'; ctx.fillRect(-sz * 0.08, -sz * 1.05, sz * 0.16, sz * 0.35);
      ctx.fillStyle = '#4A1500'; ctx.beginPath(); ctx.moveTo(-sz * 0.35, -sz * 0.15); ctx.lineTo(-sz * 0.15, -sz * 0.15); ctx.lineTo(-sz * 0.25, -sz * 0.4); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(sz * 0.35, -sz * 0.15); ctx.lineTo(sz * 0.15, -sz * 0.15); ctx.lineTo(sz * 0.25, -sz * 0.4); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.arc(0, sz * 0.15, sz * 0.3, 0.2, Math.PI - 0.2); ctx.fill();
    }
    ctx.restore();
  }
}
function fxFog(ctx, w, h, u, th, t) {
  for (let i = 0; i < 7; i++) {
    const x = (((i * 0.23 + t * 0.014 * (1 + i % 3)) % 1.5) - 0.25) * w, y = h * (0.66 + 0.07 * (i % 4)), rx = u * (0.45 + 0.1 * (i % 3)), ry = u * 0.09;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rx); g.addColorStop(0, rgba(th.glow, 0.2)); g.addColorStop(1, rgba(th.glow, 0)); ctx.fillStyle = g; ctx.save(); ctx.translate(0, y); ctx.scale(1, ry / rx); ctx.translate(0, -y); ctx.beginPath(); ctx.arc(x, y, rx, 0, TAU); ctx.fill(); ctx.restore();
  }
  [[0.14, 0.12], [0.86, 0.2], [0.8, 0.8], [0.18, 0.88]].forEach((p, k) => X.drawGhost(ctx, w * p[0] + Math.sin(t * 0.8 + k) * u * 0.05, h * p[1] + Math.sin(t * 1.4 + k * 2) * u * 0.03, u * (0.05 + 0.012 * (k % 2)), t + k, 0.3 + 0.3 * Math.sin(t * 2 + k), 0.9));
}

/* ---------- Motifs for the middle of the card (about s wide, centred at cx, cy) ---------- */
X.MOTIFS.pumpkin = (ctx, cx, cy, s, th, t) => {
  cy += Math.sin(t * 1.6) * s * 0.015; oval(ctx, cx, cy + s * 0.37, s * 0.42, s * 0.05, 'rgba(0,0,0,.2)');
  drawPumpkin(ctx, cx, cy + s * 0.02, s * 0.36, { mouth: 0.2 + 0.12 * Math.sin(t * 2), glow: 0.85 + 0.15 * Math.sin(t * 9), wink: Math.sin(t * 0.9 + 1) > 0.965 ? 1 : 0, rot: Math.sin(t * 1.3) * 0.03 });
};
X.MOTIFS.ghost = (ctx, cx, cy, s, th, t) => {
  const yy = cy + Math.sin(t * 2) * s * 0.03 - s * 0.02, k = s * 0.3; X.drawGhost(ctx, cx, yy, k, t, 0.15 + 0.15 * Math.sin(t * 3), 1);
  blush(ctx, cx - k * 0.52, yy + k * 0.05, k * 0.14); blush(ctx, cx + k * 0.52, yy + k * 0.05, k * 0.14);
  ctx.fillStyle = '#FFFFFF'; sparkle(ctx, cx + s * 0.42, yy - s * 0.3, s * 0.05 * (0.6 + 0.4 * Math.sin(t * 3)));
};
X.MOTIFS.cat = (ctx, cx, cy, s, th, t) => {
  const bl = Math.sin(t * 1.1) > 0.97;
  drawCat(ctx, cx, cy - s * 0.12, s * 0.3, { fluff: 0, pupil: bl ? 1 : 0.15 + 0.1 * Math.sin(t * 2), heart: 0, mouth: 0, t });
};
X.MOTIFS.skull = (ctx, cx, cy, s, th, t) => {
  oval(ctx, cx, cy + s * 0.43, s * 0.34, s * 0.04, 'rgba(0,0,0,.2)'); drawSkull(ctx, cx, cy + Math.sin(t * 1.8) * s * 0.015, s * 0.4, { jaw: 0.1 + 0.12 * Math.max(0, Math.sin(t * 2.2)), look: Math.sin(t), tilt: Math.sin(t * 1.2) * 0.06 });
};
X.MOTIFS.bucket = (ctx, cx, cy, s, th, t) => {
  cy += Math.sin(t * 1.6) * s * 0.012;
  oval(ctx, cx, cy + s * 0.46, s * 0.4, s * 0.05, 'rgba(0,0,0,.2)');
  const cols = ['#FF5C8E', '#FFD23F', '#4DE0A8', '#B14CFF', '#FFFFFF'];
  const r = rng(5); for (let i = 0; i < 9; i++) { const px = cx + (r() - 0.5) * s * 0.5, py = cy - s * 0.02 + (r() - 0.5) * s * 0.1 - Math.abs(Math.sin(t * 2.2 + i)) * s * 0.012; ctx.fillStyle = cols[i % 5]; ctx.beginPath(); ctx.ellipse(px, py, s * 0.06, s * 0.04, r() * 3, 0, TAU); ctx.fill(); }
  ctx.strokeStyle = '#170D26'; ctx.lineWidth = s * 0.03; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(cx, cy + s * 0.1, s * 0.4, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke();
  ctx.fillStyle = '#FF8A1F'; ctx.beginPath(); ctx.moveTo(cx - s * 0.36, cy + s * 0.05); ctx.lineTo(cx + s * 0.36, cy + s * 0.05); ctx.lineTo(cx + s * 0.28, cy + s * 0.44); ctx.quadraticCurveTo(cx, cy + s * 0.52, cx - s * 0.28, cy + s * 0.44); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#E4620E'; ctx.fillRect(cx - s * 0.38, cy + s * 0.02, s * 0.76, s * 0.06);
  ctx.fillStyle = '#4A1500'; tri(ctx, cx - s * 0.2, cy + s * 0.2, cx - s * 0.08, cy + s * 0.2, cx - s * 0.14, cy + s * 0.1, '#4A1500'); tri(ctx, cx + s * 0.2, cy + s * 0.2, cx + s * 0.08, cy + s * 0.2, cx + s * 0.14, cy + s * 0.1, '#4A1500');
  ctx.beginPath(); ctx.arc(cx, cy + s * 0.28, s * 0.14, 0.2, Math.PI - 0.2); ctx.fill();
};

/* ---------- Timelines: the creature's state at time t (q = seconds since it appeared) ---------- */
const flash = (R, t, t0, col, k, rate) => { if (t >= t0) { R.flash = k * Math.exp(-(t - t0) * (rate || 8)); R.flashCol = col; } };
const H = X.HSCARE;
H.pumpkin = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y, sc = 1;
  if (q < 0.45) { const p = easeBack(q / 0.45); y = mix(1.25, 0.5, p); sc = mix(0.55, 1, p); } else if (q < 2.0) y = 0.5 + Math.sin(q * 3) * 0.008; else y = mix(0.5, 1.4, easeIn((q - 2.0) / 0.5));
  R.cr = { kind: 'pumpkin', y, sc, rot: q > 0.45 && q < 2.0 ? Math.sin(q * 6) * 0.08 : 0, mouth: q < 0.45 ? q / 0.45 : 0.55 + 0.45 * Math.sin(q * 9), tongue: pulse(q, 1.05, 1.9, 0.25), wink: q > 1.45 && q < 1.85 ? 1 : 0, glow: 0.85 + 0.15 * Math.sin(q * 15) };
  if (q > 0.3 && q < 1.5) R.shout = 'БҮҮҮ!'; if (q > 0.3 && q < 1.0) R.shake = 0.5 * Math.exp(-(q - 0.3) * 4); flash(R, t, A + 0.3, '#FFB000', 0.4);
};
H.mummy = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let x, y = 0.5, rot = 0, hop = 0;
  if (q < 0.55) { x = mix(1.5, 0.5, easeBack(q / 0.55)); hop = Math.abs(Math.sin(q * 14)) * 0.05 * (1 - q / 0.55); } else if (q < 1.9) { x = 0.5; hop = Math.abs(Math.sin(q * 7)) * 0.045; } else { const p = (q - 1.9) / 0.6; x = 0.5 + p * 0.05; rot = easeIn(p) * 1.5; y = 0.5 + easeIn(p) * 0.9; }
  R.cr = { kind: 'mummy', x, y: y - hop, rot, arms: 1, cross: pulse(q, 0.9, 1.7, 0.25), mouth: q < 1.9 ? 0.5 + 0.5 * Math.sin(q * 10) : 1 };
  if (q > 0.5 && q < 1.5) R.shout = 'ӨӨӨӨӨ!'; flash(R, t, A + 0.45, '#FFFFFF', 0.3, 9); if (q > 2.35 && q < 2.8) R.shake = 0.12;
};
H.skeleton = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y;
  if (q < 0.5) y = mix(1.4, 0.34, easeBack(q / 0.5)); else if (q < 2.1) y = 0.34; else y = mix(0.34, 1.5, easeIn((q - 2.1) / 0.5));
  const dance = q > 0.5 && q < 2.1 ? Math.sin(q * 6) : 0, lift = clamp((q - 1.3) / 0.55);
  R.cr = { kind: 'skeleton', y, sway: dance, jaw: q > 0.5 && q < 1.3 ? Math.abs(Math.sin(q * 17)) : (q < 2.1 ? 0.15 : 0), look: Math.sin(q * 4), lift: lift > 0 && lift < 1 ? Math.sin(lift * Math.PI) * 0.95 : 0, armL: 1.5 + Math.sin(q * 9) * 0.45, armR: 1.1 + Math.sin(q * 9 + 2) * 0.45 };
  if (q > 0.5 && q < 1.3) R.shout = 'ХЭ-ХЭ-ХЭ!'; flash(R, t, A + 0.45, '#FFFFFF', 0.3, 9); R.darkK = 0.95;
};
H.hand = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y;
  if (q < 0.5) y = mix(1.55, 0.6, easeOut(q / 0.5)); else if (q < 2.5) y = 0.6 + Math.sin(q * 4) * 0.006; else y = mix(0.6, 1.7, easeIn((q - 2.5) / 0.5));
  const wave = q > 0.55 && q < 1.65 ? Math.sin((q - 0.55) * 9) * 0.34 : (q >= 1.65 && q < 2.5 ? Math.sin(q * 5) * 0.05 : 0);
  R.cr = { kind: 'hand', y, wave, curl: smooth((q - 1.7) / 0.25), look: q * 2.2 };
  if (q > 0.55 && q < 1.65) R.shout = 'САЙН УУ?'; if (q > 1.8 && q < 2.45) R.shout = 'ЗА!'; R.shoutY = 0.17;
  if (q > 0.2 && q < 0.7) R.shake = 0.3 * Math.exp(-(q - 0.2) * 5); flash(R, t, A + 0.3, '#86C85A', 0.3, 8);
};
H.monster = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y = 0.48, sc = 1, sq = 0, mouth = 0, happy = 0, arms = 1;
  if (q < 0.5) { const p = easeBack(q / 0.5); y = mix(1.35, 0.48, p); sq = -0.1 * (1 - p); }
  else if (q < 1.55) { mouth = 0.6 + 0.4 * Math.sin(q * 18); sq = 0.03 * Math.sin(q * 25); }
  else if (q < 2.4) { happy = 1; mouth = 0.18 + 0.1 * Math.sin(q * 22); sq = 0.05 * Math.sin(q * 20); arms = 0.4; y = 0.48 - Math.abs(Math.sin((q - 1.55) * 7)) * 0.03; }
  else { const p = easeIn((q - 2.4) / 0.5); sc = 1 - p * 0.95; happy = 1; arms = 0.3; }
  R.cr = { kind: 'monster', y, sc, squash: sq, mouth, happy, arms, look: Math.sin(q * 3) * 0.8 };
  if (q > 0.35 && q < 1.55) R.shout = 'РААААА!'; if (q > 0.35 && q < 1.0) R.shake = 0.6 * Math.exp(-(q - 0.35) * 4); flash(R, t, A + 0.35, '#B46BFF', 0.4); R.darkK = 0.95;
};
H.cat = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y = 0.46, fluff = 0, pupil = 1, heartV = 0, mouth = 0;
  if (q < 0.4) y = mix(1.3, 0.46, easeBack(q / 0.4));
  if (q >= 0.4 && q < 1.45) { fluff = 1; mouth = 1; pupil = 1; } else if (q >= 1.45 && q < 2.25) { fluff = 1 - smooth((q - 1.45) / 0.3); pupil = 1 - smooth((q - 1.5) / 0.3); heartV = smooth((q - 1.75) / 0.3); } else if (q >= 2.25) { pupil = 0; heartV = 1; y = mix(0.46, -0.6, easeIn((q - 2.25) / 0.45)); }
  R.cr = { kind: 'cat', y, fluff, pupil, heart: heartV, mouth, t };
  if (q > 0.4 && q < 1.45) R.shout = 'МЯУУУУ!'; if (q > 0.4 && q < 0.9) R.shake = 0.5 * Math.exp(-(q - 0.4) * 4); flash(R, t, A + 0.4, '#E4FF3A', 0.4);
};
H.vampire = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A;
  R.cr = { kind: 'vampire', y: 0.44, sc: mix(0.06, 1, easeOut(q / 0.55)), cape: easeOut(q / 0.8), fang: smooth((q - 0.5) / 0.4), mouth: q > 0.6 && q < 1.8 ? 0.5 + 0.5 * Math.sin(q * 8) : 0.1, glow: 0.8 + 0.2 * Math.sin(q * 12), al: 1 - smooth((q - 2.1) / 0.5) };
  if (q > 0.6 && q < 1.7) R.shout = 'БЛЭЭЭЭ!'; if (q > 0.5 && q < 1.0) R.shake = 0.3; flash(R, t, A + 0.5, '#FF2B4E', 0.35);
};
H.witch = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let x, y, dir, sc = 1;
  if (q < 1.55) { const p = q / 1.55; x = mix(-0.45, 1.45, p); y = 0.4 + Math.sin(q * 4.5) * 0.05; dir = 1; } else if (q < 1.7) { x = 1.6; y = 0.5; dir = -1; } else { const p = (q - 1.7) / 1.15; x = mix(1.5, -0.5, p); y = 0.54 + Math.sin(q * 4.5) * 0.04; dir = -1; sc = 1.2; }
  R.cr = { kind: 'witch', x, y, dir, sc, tilt: Math.sin(q * 4.5) * 0.1 };
  R.moon = smooth((t - A) / 0.5) * (1 - smooth((t - 5.0) / 0.6)); if ((q > 0.5 && q < 1.4) || (q > 1.9 && q < 2.7)) R.shout = 'ХИ-ХИ-ХИ!'; flash(R, t, A + 0.1, '#7CFF6B', 0.25); R.darkK = 0.93;
};
H.slime = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let cov = easeOut(q / 0.9), drop = 0;
  if (q >= 2.1) { cov = 1; drop = easeIn((q - 2.1) / 0.6); }
  R.cr = { kind: 'slime', cov, drop };
  if (q > 0.5 && q < 1.8) { R.shout = 'ЛИЖ!'; R.shoutY = 0.72; } if (q > 0.2 && q < 0.7) R.shake = 0.3; flash(R, t, A + 0.2, '#7CFF3B', 0.3, 8); R.darkK = 0.9;
};
const D = X.HDRAW;
D.pumpkin = (ctx, w, h, u, top, ch, t, c) => drawPumpkin(ctx, w / 2, top + ch * c.y, u * 0.3 * c.sc, c);
D.mummy = (ctx, w, h, u, top, ch, t, c) => drawMummy(ctx, w * c.x, top + ch * c.y, u * 0.3, Object.assign({ t }, c));
D.skeleton = (ctx, w, h, u, top, ch, t, c) => drawSkeleton(ctx, w / 2 + c.sway * u * 0.05, top + ch * c.y, u * 0.25, c);
D.hand = (ctx, w, h, u, top, ch, t, c) => { drawHand(ctx, w / 2, top + ch * c.y, u * 0.3, c); drawMound(ctx, w, h, u, top, ch); };
D.monster = (ctx, w, h, u, top, ch, t, c) => drawMonster(ctx, w / 2, top + ch * c.y, u * 0.28 * c.sc, Object.assign({ t }, c));
D.cat = (ctx, w, h, u, top, ch, t, c) => drawCat(ctx, w / 2, top + ch * c.y, u * 0.3, c);
D.vampire = (ctx, w, h, u, top, ch, t, c) => { ctx.save(); ctx.globalAlpha = clamp(c.al); drawVampire(ctx, w / 2, top + ch * c.y, u * 0.3 * c.sc, c); ctx.restore(); X.drawBats(ctx, w, h, u, top, ch, t); };
D.witch = (ctx, w, h, u, top, ch, t, c) => drawWitch(ctx, w * c.x, top + ch * c.y, u * 0.2 * c.sc, Object.assign({ t }, c));
D.slime = drawSlime;

/* ---------- Sound cues ---------- */
const ev = list => cross => { const out = []; list.forEach(p => { if (cross(p[0])) out.push(p[1]); }); return out; };
X.EVENTS.pumpkin = ev([[2.45, 'riser'], [2.95, 'boo'], [4.3, 'giggle'], [5.5, 'end']]);
X.EVENTS.mummy = ev([[2.45, 'riser'], [3.0, 'boo'], [4.55, 'thud'], [5.5, 'end']]);
X.EVENTS.skeleton = ev([[2.45, 'riser'], [3.0, 'rattle'], [4.0, 'rattle'], [5.5, 'end']]);
X.EVENTS.hand = ev([[2.65, 'burst'], [3.3, 'hello'], [4.5, 'hello'], [5.5, 'end']]);
X.EVENTS.monster = ev([[2.45, 'riser'], [3.0, 'roar'], [4.3, 'giggle'], [5.5, 'end']]);
X.EVENTS.cat = ev([[2.45, 'riser'], [3.05, 'meow'], [4.4, 'hello'], [5.5, 'end']]);
X.EVENTS.vampire = ev([[2.45, 'riser'], [3.25, 'cackle'], [5.5, 'end']]);
X.EVENTS.witch = ev([[2.45, 'riser'], [3.2, 'cackle'], [4.6, 'cackle'], [5.5, 'end']]);
X.EVENTS.slime = ev([[2.45, 'riser'], [2.95, 'splat'], [4.95, 'splat'], [5.5, 'end']]);
const op = (f, d, w, v, at, to) => ({ t: 'tone', f, d, w, v, at: at || 0, to });
Object.assign(X.PRESETS, {
  meow: { name: 'Мяу', ops: [op(520, .2, 'triangle', .14, 0, 920), op(920, .34, 'triangle', .14, .17, 430)] },
  cackle: { name: 'Шулмын инээд', ops: [0, .13, .26, .39].map((a, i) => op(520 + i * 40, .12, 'sawtooth', .09, a, 720 + i * 40)).concat([op(560, .3, 'sawtooth', .09, .54, 360)]) },
  rattle: { name: 'Яс шажигнах', ops: [0, .06, .12, .21, .27, .34].map(a => ({ t: 'noise', d: .05, v: .2, hp: 3200, at: a })) },
  splat: { name: 'Лиш цохих', ops: [{ t: 'noise', d: .28, v: .16, hp: 300 }, op(260, .26, 'sine', .22, 0, 55)] },
  roar: { name: 'Мангасын архирал', ops: [op(110, .8, 'sawtooth', .2, 0, 70), op(165, .7, 'square', .05, 0, 90), { t: 'noise', d: .5, v: .1, hp: 200 }] },
  giggle: { name: 'Инээх', ops: [0, .11, .22, .33].map((a, i) => op(700 + i * 40, .09, 'triangle', .12, a, 950 + i * 40)) },
  creak: { name: 'Хаалганы шаз', ops: [op(150, .9, 'sawtooth', .07, 0, 330), op(160, .9, 'square', .03, .05, 300), { t: 'noise', d: .8, v: .05, hp: 2500 }] },
  wail: { name: 'Сүнсний уйлаа', ops: [op(400, 1.2, 'sine', .1, 0, 900), op(404, 1.2, 'sine', .1, .06, 460)] }
});
Object.assign(X.CUES, { meow: 'Муур мяулах', cackle: 'Шулмын инээд', rattle: 'Яс шажигнах', splat: 'Лиш цохих', roar: 'Мангасын архирал', hello: 'Сайн уу (хонх)', thud: 'Унах цохилт', giggle: 'Инээх' });
Object.assign(X.DEFAULT_SFX, { meow: 'meow', cackle: 'cackle', rattle: 'rattle', splat: 'splat', roar: 'roar', hello: 'chime', thud: 'drum', giggle: 'giggle' });

/* ---------- Registration ---------- */
const NEW = { pumpkin: ['Хулуу', 3.95], mummy: ['Мөмми', 3.8], skeleton: ['Араг яс', 4.05], hand: ['Үхсэн гар', 3.5], monster: ['Хөөрхөн мангас', 3.75], cat: ['Хар муур', 3.7], vampire: ['Цуст', 4.0], witch: ['Шулам', 3.75], slime: ['Лиш', 3.95] };
Object.keys(NEW).forEach(k => { X.FX_IDS.push(k); X.FXS[k] = { name: NEW[k][0], scare: true }; X.FXR[k] = {}; X.THUMB_T[k] = NEW[k][1]; X.FINAL_T[k] = 7.9; X.LOOP[k] = 10; });
X.FX_IDS.push('candy', 'fog'); X.FXS.candy = { name: 'Чихрийн бороо' }; X.FXS.fog = { name: 'Манан, сүнснүүд' };
X.FXR.candy = { fn: fxCandy, front: true }; X.FXR.fog = { fn: fxFog, front: true }; X.THUMB_T.candy = 1.3; X.FINAL_T.candy = 1.3; X.THUMB_T.fog = 1.6; X.FINAL_T.fog = 1.6;

Object.assign(X.THEMES, {
  pumpkin: { name: 'Хулуу', bg: ['#34124F', '#FF7A1A'], glow: '#FFB347', ink: '#FFF4DC', soft: '#FFE3B8', a: '#FFC83D', b: '#FFFFFF', c: '#9BFF4D', light: false, pal: ['#FF8A1F', '#FFC83D', '#9BFF4D', '#FFFFFF', '#B07CFF', '#FF5A36'] },
  witch: { name: 'Шулам', bg: ['#22093C', '#0F6B45'], glow: '#7CFF6B', ink: '#F2FFE6', soft: '#D8F5C6', a: '#A8FF4F', b: '#D39BFF', c: '#FFB02E', light: false, pal: ['#A8FF4F', '#D39BFF', '#FFB02E', '#FFFFFF', '#6BE3FF', '#FF7AD9'] },
  slime: { name: 'Лиш', bg: ['#0D3A22', '#8BE02B'], glow: '#E8FF8A', ink: '#FBFFE6', soft: '#E6F8B8', a: '#FFE93B', b: '#FFFFFF', c: '#C77DFF', light: false, pal: ['#FFE93B', '#FFFFFF', '#C77DFF', '#7CFF3B', '#FF8A1F', '#6BE3FF'] },
  blood: { name: 'Цус', bg: ['#14030B', '#9A1426'], glow: '#FF5252', ink: '#FFEDED', soft: '#FFD0D0', a: '#FF6B6B', b: '#FFFFFF', c: '#FFC857', light: false, pal: ['#FF6B6B', '#FFFFFF', '#FFC857', '#FF3D7F', '#FFB3B3', '#B07CFF'] },
  bone: { name: 'Сарны гэрэл', bg: ['#0A1230', '#43569B'], glow: '#DDE8FF', ink: '#F6F2E4', soft: '#DCE4FF', a: '#FFE8A3', b: '#BFD0FF', c: '#FF9A5C', light: false, pal: ['#FFE8A3', '#BFD0FF', '#FF9A5C', '#FFFFFF', '#8FD3FF', '#D39BFF'] },
  candy: { name: 'Чихэр', bg: ['#FFB6E8', '#8F5BE8'], glow: '#FFFFFF', ink: '#2A0A4D', soft: '#4B1D7D', a: '#FF6A00', b: '#FFFFFF', c: '#00B386', light: true, pal: ['#FF6A00', '#FFFFFF', '#00B386', '#FFD23F', '#FF4D8D', '#6C3CE0'] }
});
const HT = ['pumpkin', 'witch', 'slime', 'blood', 'bone', 'candy'];
HT.forEach(id => X.THEME_IDS.push(id)); M.HALLOWEEN_THEMES = HT;
X.THEME_ORDER.length = 0; HT.concat(['blush', 'gold', 'sky', 'night', 'green', 'sun']).forEach(id => X.THEME_ORDER.push(id));

X.MOTIF_NAMES.pumpkin = 'Хулуу'; X.MOTIF_NAMES.ghost = 'Сүнс'; X.MOTIF_NAMES.cat = 'Хар муур'; X.MOTIF_NAMES.skull = 'Гавал'; X.MOTIF_NAMES.bucket = 'Чихрийн хувин';
X.OCC.halloween = {
  name: 'Хэллоуин', title: 'Хэллоуины мэнд!', theme: 'pumpkin', motif: 'pumpkin', motifs: ['pumpkin', 'ghost', 'cat', 'skull', 'bucket'],
  msg: 'Хэллоуины мэнд хүргэе! Өнөө орой хамгийн хөөрхөн мангасууд чамайг хайж явна. Чихрээ бэлд, үгүй бол инээлгэж орхино шүү!',
  fx: ['pumpkin', 'ghost', 'cat', 'monster', 'skeleton', 'hand', 'mummy', 'vampire', 'witch', 'slime', 'spider', 'bats', 'eyes', 'candy', 'fog', 'confetti']
};
X.OCC_IDS.push('halloween'); X.OCC_ORDER.unshift('halloween');
X.OCC.friend.fx = ['hand', 'monster', 'cat', 'pumpkin', 'spider', 'ghost', 'bats', 'eyes', 'confetti', 'cannon', 'hearts', 'disco'];
X.OCC.bday.fx = ['confetti', 'balloons', 'cannon', 'fireworks', 'monster', 'spider', 'ghost', 'hearts', 'disco'];

/* ---------- Ready-made designs ---------- */
const T = (n, name, fx, theme, motif, title, msg, open) => ({ id: 'h-' + n, builtin: true, name, occ: 'halloween', fx, theme, motif, title, msg, sfx: open ? { open } : {}, order: n });
[
  T(1, 'Хөөрхөн хулуу', 'pumpkin', 'pumpkin', 'pumpkin', 'Хулуу ирлээ!', 'Хулуу чамайг хараад инээмсэглэв. Хэллоуины мэнд хүргэе, өнөө орой чихэр элбэг байг!'),
  T(2, 'Инээдтэй сүнс', 'ghost', 'bone', 'ghost', 'Бүүү! Би сүнс байна', 'Айсан уу? Айгаагүй юм шиг дүр эсгэсэн ч зүгээр. Хэллоуины мэнд!', 'wail'),
  T(3, 'Хар муур', 'cat', 'witch', 'cat', 'Мяу, мяу!', 'Эхлээд сүртэй исгэрсэн ч дотроо зөөлөн зүрхтэй. Хэллоуины мэнд хүргэе!'),
  T(4, 'Шулам нисэв', 'witch', 'witch', 'pumpkin', 'Шулам нисэж ирлээ', 'Шулмын тогоо буцалж байна. Чихрээ бэлд, үгүй бол инээлгэж орхино шүү!', 'creak'),
  T(5, 'Араг яс бүжиглэв', 'skeleton', 'bone', 'skull', 'Шажигнаж ирлээ', 'Яс шажигнатал инээгээд толгойгоо ч мартчихлаа. Хэллоуины мэнд!', 'creak'),
  T(6, 'Мөмми гүйлээ', 'mummy', 'candy', 'ghost', 'Мөмми гүйж ирлээ', 'Уяа нь сулраад бүр бүдэрчихлээ. Чамд Хэллоуины мэнд хүргэе!'),
  T(7, 'Хөөрхөн мангас', 'monster', 'candy', 'pumpkin', 'Мангас найз', 'Архиран байгаад дараа нь өөрөө инээчихдэг хөөрхөн мангас чамайг хайж яваа шүү.'),
  T(8, 'Гар мэндэлж байна', 'hand', 'slime', 'skull', 'Газраас гар гарлаа', 'Айх хэрэггүй, зүгээр л мэндлэх гэсэн юм. Хэллоуины мэнд!'),
  T(9, 'Хөөрхөн цуст', 'vampire', 'blood', 'cat', 'Хөөрхөн цуст', 'Шүд нь урт ч сэтгэл нь дулаан. Хэллоуины мэнд хүргэе!', 'creak'),
  T(10, 'Лиж бороо', 'slime', 'slime', 'bucket', 'Лиж дусаллаа', 'Цэвэрлэхэд хэцүү ч инээхэд амархан. Хэллоуины мэнд хүргэе!'),
  T(11, 'Чихрийн бороо', 'candy', 'candy', 'bucket', 'Чихэр үү, зальжин уу?', 'Хувингаа бэлд! Өнөөдөр чихэр бороо шиг орно. Хэллоуины мэнд!'),
  T(12, 'Манан дахь сүнснүүд', 'fog', 'bone', 'ghost', 'Манан хөврөв', 'Харанхуйд гэрэл асаж, жижиг сүнснүүд бүжиглэж байна. Хэллоуины мэнд!', 'wail'),
  T(13, 'Аалз бууж ирэв', 'spider', 'pumpkin', 'pumpkin', 'Аалзнаас болгоомжил', 'Толгой дээр чинь юу байна вэ? Хэллоуины мэнд!', 'creak'),
  T(14, 'Харанхуйн нүд', 'eyes', 'blood', 'skull', 'Харж байна...', 'Харанхуйд хэдэн нүд чамайг ажиглаж байна. Хэллоуины мэнд!', 'wail')
].forEach(t => X.BUILTIN_TPL.push(t));
})();
