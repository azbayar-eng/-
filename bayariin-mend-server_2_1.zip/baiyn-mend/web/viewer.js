/* viewer.js — what the person who receives the link sees. */
(function () {
'use strict';
const App = window.App, M = App.M, $ = App.$;
const V = { card: null, R: null, owner: null, t0: 0, prev: 0, started: false, test: false, raf: 0, logged: false };
App.viewerOpen = false;

function gateTheme(th) {
  const g = $('gate');
  g.style.background = `linear-gradient(180deg,${th.bg[0]},${th.bg[1]})`;
  g.style.setProperty('--gink', th.ink); g.style.setProperty('--gacc', th.a);
}
function frame(show) {
  App.viewerOpen = show; $('viewer').hidden = !show; $('app').hidden = show;
  if (show) { $('vCanvas').getContext('2d').clearRect(0, 0, 9999, 9999); }
}
function gate(o) {
  $('gate').hidden = false; gateTheme(o.th || M.THEMES.night);
  $('gateK').textContent = o.k || ''; $('gateName').textContent = o.name || ''; $('gateMsg').textContent = o.msg || ''; $('gateMsg').hidden = !o.msg;
  $('gateOpen').hidden = !o.open; $('gateHome').hidden = !o.home; $('gateHome').textContent = o.homeText || 'Өөрөө мэндчилгээ бүтээх';
  $('vBack').hidden = !V.test; $('vMake').hidden = true;
}
/* kind: 'loading' | 'blocked' | 'missing' | 'login' */
App.viewerMessage = function (kind, th) {
  V.started = false; V.test = false; frame(true); cancelAnimationFrame(V.raf);
  const T = {
    loading: { k: 'Мэндчилгээг ачаалж байна…', name: '', msg: '' },
    blocked: { k: 'Түр хүлээнэ үү', name: 'Идэвхжээгүй байна', msg: 'Энэ мэндчилгээний төлбөр баталгаажаагүй байна. Илгээсэн хүнээсээ асууна уу.', home: true },
    missing: { k: 'Олдсонгүй', name: 'Мэндчилгээ олдсонгүй', msg: 'Холбоос буруу эсвэл мэндчилгээ устгагдсан байж магадгүй.', home: true },
    login: { k: 'Нэвтрэх шаардлагатай', name: 'Нэвтэрнэ үү', msg: 'Мэндчилгээг үзэхийн тулд нэвтэрсэн байх шаардлагатай.', home: true }
  }[kind];
  gate(Object.assign({ th }, T));
};
/* o: {card, test, owner:{uid,id}} */
App.openViewer = function (o) {
  V.card = o.card; V.test = !!o.test; V.owner = o.owner || null; V.back = o.back || (App.view !== 'viewer' && App.view) || 'make'; V.R = App.toR(o.card); V.started = false; V.logged = false;
  frame(true);
  gate({ th: M.THEMES[V.R.theme], k: 'Танд мэндчилгээ ирлээ', name: V.R.name, open: true });
  if (V.owner && !V.test && !V.logged) { V.logged = true; App.backend.logVisit({ o: V.owner.uid, c: V.owner.id }); }
  cancelAnimationFrame(V.raf); V.raf = requestAnimationFrame(loop);
};
function open() {
  if (!V.R) return;
  V.R = App.toR(V.card); M.Sound.init(); V.t0 = performance.now(); V.prev = -0.01; V.started = true;
  $('gate').hidden = true; $('vMake').hidden = true;
  App.media.play(V.R.bgEl);
  if (!M.FXS[V.R.fx].scare) M.Sound.play('open', V.R.sfx);
}
function loop(now) {
  V.raf = requestAnimationFrame(loop);
  if (!V.started || document.hidden) return;
  const t = (now - V.t0) / 1000, { ctx, w, h } = App.fit($('vCanvas'));
  M.events(V.R.fx, V.prev, t).forEach(c => M.Sound.play(c, V.R.sfx));
  V.prev = t; M.render(ctx, w, h, t, V.R);
  if (t > 7.8 && !V.test) $('vMake').hidden = false;
}
function close() {
  cancelAnimationFrame(V.raf); V.started = false; App.media.pause(V.R && V.R.bgEl);
  const wasTest = V.test; frame(false);
  if (!wasTest) App.backend.nav.clear();
  App.show(wasTest ? (V.back || 'make') : (App.view || 'make'));
}
App.closeViewer = close;

/* Decide what an address means and show it. */
App.route = async function () {
  const r = App.backend.nav.current();
  if (!r) { if (App.viewerOpen && !V.test) { cancelAnimationFrame(V.raf); frame(false); } return; }
  if (r.type === 'legacy') { App.openViewer({ card: r.card }); return; }
  App.viewerMessage('loading');
  if (!App.me.uid && App.backend.kind !== 'rest') { App.viewerMessage('login'); return; }
  let got = null;
  try { got = await App.backend.getCard(r.uid, r.id); } catch (e) { got = null; }
  if (!got) { App.viewerMessage('missing'); return; }
  const free = got.card.free || !App.cfg.main.payRequired, ok = (got.ap && got.ap.st === 'ok') || free;
  if (!ok) { App.viewerMessage('blocked', M.THEMES[got.card.theme] || M.THEMES[(M.OCC[got.card.occ] || M.OCC.other).theme]); return; }
  App.openViewer({ card: got.card, owner: { uid: r.uid, id: r.id } });
};

App.initViewer = function () {
  $('gateOpen').addEventListener('click', open);
  $('gateHome').addEventListener('click', close);
  $('vReplay').addEventListener('click', () => { if (!V.started) { open(); return; } M.Sound.init(); V.t0 = performance.now(); V.prev = -0.01; $('vMake').hidden = true; if (!M.FXS[V.R.fx].scare) M.Sound.play('open', V.R.sfx); });
  $('vBack').addEventListener('click', close);
  $('vMake').addEventListener('click', close);
  $('vMute').addEventListener('click', e => { M.Sound.muted = !M.Sound.muted; e.currentTarget.textContent = M.Sound.muted ? 'Дуугүй' : 'Дуутай'; e.currentTarget.setAttribute('aria-pressed', String(M.Sound.muted)); });
  App.backend.nav.listen(() => App.route());
  App.on('media', () => { /* the loop redraws every frame; nothing to do */ });
};
})();
