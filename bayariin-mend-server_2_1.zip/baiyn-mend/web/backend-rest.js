/* backend-rest.js — the server build keeps its data on the server (Express + SQLite) and talks to it over /api.
   It offers exactly the same methods as backend-artifact.js, so the rest of the app cannot tell the two apart.
   "Live" views are plain polling: every few seconds while the tab is visible, and straight away after the person's own changes. */
(function () {
'use strict';
const App = window.App, h = App.h;
const noop = App.noop, nav = App.hashNav;

App.restBackend = function () {
  /* Nobody has to sign up: anyone can make a card. The server hands out an anonymous "guest" account the first time
     something has to be saved (see ensure()); the person only pays for the card, never registers. */
  let me = { uid: null, name: '', isAdmin: false, canWrite: true, canUpload: false, guest: false };
  let cfgRev = -1, mineCb = null, guestP = null;
  const refresh = {};                       // name -> function that re-reads that list right now

  async function call(method, url, body, raw) {
    const opt = { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'baiyn' } };
    if (raw) { opt.body = raw.blob; opt.headers['Content-Type'] = raw.type || 'application/octet-stream'; }
    else if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers['Content-Type'] = 'application/json'; }
    let r;
    try { r = await fetch(url, opt); } catch (e) { throw { code: 'unavailable', message: 'Сервертэй холбогдож чадсангүй. Интернэтээ шалгана уу.' }; }
    let j = null; try { j = await r.json(); } catch (e) { /* no body */ }
    if (!r.ok) throw { code: r.status === 401 ? 'unauthenticated' : 'unavailable', status: r.status, message: (j && j.message) || 'Алдаа гарлаа. Дахин оролдоно уу.' };
    return j;
  }
  const missing = e => e && (e.status === 404 || e.status === 400);

  /* make sure there is an account (an anonymous guest one if the person never signed in) before saving anything */
  async function ensure() {
    if (me.uid) return me;
    if (!guestP) guestP = (async () => {
      const u = await call('POST', '/api/guest');
      me.uid = u.uid; me.name = u.name || 'Зочин'; me.guest = !!u.guest; me.isAdmin = !!u.isAdmin; me.canWrite = true;
      cfgRev = -1;                                            // the payment details are only sent to people who have an account
      try { if (refresh.cfg) await refresh.cfg(); } catch (e) { /* the next poll will do it */ }
      if (mineCb && !refresh.mine) poll('mine', () => call('GET', '/api/mine'), mineCb, 8000);
    })().finally(() => { guestP = null; });
    await guestP; return me;
  }

  /* call `get` every `ms` while the page is visible; hand the result on only when it changed.
     refresh[name]() re-reads right now (waiting for a read already under way, so the answer is never older than the call). */
  function poll(name, get, cb, ms) {
    let last = null, cur = null;
    const run = force => {
      if (cur) return force ? cur.then(() => run(true)) : cur;
      cur = (async () => {
        try { const d = await get(); const s = JSON.stringify(d); if (s !== last) { last = s; cb(d); } } catch (e) { if (e && e.status === 401 && me.uid) { me.uid = null; location.reload(); } /* otherwise: try again next time */ }
      })().finally(() => { cur = null; });
      return cur;
    };
    refresh[name] = () => run(true);
    setInterval(() => { if (!document.hidden) run(false); }, ms);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) run(false); });
    run(false);
  }
  const again = (...names) => names.forEach(n => refresh[n] && refresh[n]());
  const done = (v, ...names) => { again(...names); return v; };

  const B = {
    kind: 'rest', nav: nav(),
    visitorsHint: 'Сайтад орсон, мэндчилгээний холбоос нээсэн хүмүүс. Админ нэрээрээ, бусад нь «Зочин» нэрээр харагдана.',
    visitWord: 'орсон',

    async init() {
      try { const u = await call('GET', '/api/me'); me = { uid: u.uid || null, name: u.name || '', isAdmin: !!u.isAdmin, canWrite: true, canUpload: !!u.isAdmin, guest: !!u.guest }; }
      catch (e) { /* offline: behave as a visitor without an account yet */ }
      return me;
    },

    /* ---- configuration ---- */
    onConfig(cb) {
      poll('cfg', async () => call('GET', '/api/config?rev=' + cfgRev), d => {
        if (d.same) return; cfgRev = d.rev;
        const cfg = App.emptyCfg();
        cfg.main = d.main || {};
        const byOrder = (a, b) => (a.order || 0) - (b.order || 0) || String(a.id).localeCompare(String(b.id));
        ['themes', 'sounds', 'templates'].forEach(k => { cfg[k] = (d[k] || []).sort(byOrder); });
        cfg.media = (d.media || []).map(x => { x.src = x.data || (x.assetId ? '/_blob/' + x.assetId : ''); return x; }).sort(byOrder);
        cb(cfg, true);
      }, 20000);
    },

    /* ---- the signed-in customer ---- */
    onMine(cb) {
      mineCb = cb;
      if (!me.uid) { cb([]); return; }                         // no account yet: the list starts once the first card is saved
      poll('mine', () => call('GET', '/api/mine'), cb, 8000);
    },
    async saveCard(card) {
      await ensure();
      const r = await call('POST', '/api/cards', { id: card.id || undefined, card: App.cardFields(card) });
      return done(r, 'mine', 'orders');
    },
    async getCard(ouid, id) {
      try { return await call('GET', `/api/card/${encodeURIComponent(ouid)}/${encodeURIComponent(id)}`); }
      catch (e) { if (missing(e)) return null; throw e; }
    },
    async claim(id) { return done(await call('POST', `/api/cards/${encodeURIComponent(id)}/claim`), 'mine', 'orders'); },
    async deleteCard(id) { return done(await call('DELETE', `/api/cards/${encodeURIComponent(id)}`), 'mine', 'orders'); },
    /* open = null: this person opened the app. open = {o, c}: this person opened card c of owner o. */
    logVisit(open) { return call('POST', '/api/visit', open ? { o: open.o, c: open.c } : {}).catch(noop); },
    linkFor(card) { const base = window.APP_BASE || (location.origin + '/'); return me.uid && card && card.id ? `${base}c/${me.uid}/${card.id}` : ''; },
    async names(ids) { return ids.length ? call('POST', '/api/admin/names', { ids }) : {}; },
    /* no saveFile: App.saveFile falls back to an ordinary browser download */

    /* ---- the owner ---- */
    onOrders(cb) { poll('orders', () => call('GET', '/api/admin/orders'), d => cb(d.list, d.users), 6000); },
    onVisitors(cb) { poll('visitors', () => call('GET', '/api/admin/visitors'), cb, 12000); },
    async setApproval(ouid, id, st, note, amt) { return done(await call('POST', '/api/admin/approve', { uid: ouid, id, st, note: note || '', amt: amt || 0 }), 'orders', 'bank'); },
    async clearApproval(id) { return done(await call('DELETE', '/api/admin/approve/' + encodeURIComponent(id)), 'orders', 'bank'); },
    async saveMain(patch) { return done(await call('PUT', '/api/admin/main', { patch }), 'cfg', 'bank'); },

    /* QPay: the customer pays by QR / bank app; the card opens when QPay itself confirms (only this build has it) */
    async qpayStart(id) { return call('POST', `/api/cards/${encodeURIComponent(id)}/qpay`); },
    async qpayStatus(id) { const r = await call('GET', `/api/cards/${encodeURIComponent(id)}/qpay`); if (r && r.paid) again('mine', 'orders'); return r; },
    async qpayGet() { return call('GET', '/api/admin/qpay'); },
    async qpaySave(v) { return done(await call('PUT', '/api/admin/qpay', v), 'cfg'); },
    async qpayTest() { return call('POST', '/api/admin/qpay/test'); },
    async qpayClear() { return done(await call('DELETE', '/api/admin/qpay'), 'cfg'); },

    /* bank income read from the owner's Gmail (only this build has it; the admin panel shows the section when onBank exists) */
    onBank(cb) { poll('bank', () => call('GET', '/api/admin/bank'), cb, 8000); },
    async bankAssign(id, card) { return done(await call('POST', `/api/admin/bank/${encodeURIComponent(id)}/assign`, { card }), 'bank', 'orders'); },
    async bankIgnore(id) { return done(await call('POST', `/api/admin/bank/${encodeURIComponent(id)}/ignore`), 'bank'); },
    async saveItem(kind, item) {
      const id = item.id || App.newId(), d = Object.assign({}, item); delete d.id; delete d.src;
      await call('PUT', `/api/admin/items/${kind}/${encodeURIComponent(id)}`, d);
      return done(id, 'cfg');
    },
    async deleteItem(kind, id) { return done(await call('DELETE', `/api/admin/items/${kind}/${encodeURIComponent(id)}`), 'cfg'); },
    async upload(blob, type) { return call('POST', '/api/admin/upload', undefined, { blob, type: type || blob.type }); },
    async deleteAsset(id) { if (id) await call('DELETE', '/api/admin/assets/' + encodeURIComponent(id)); },

    /* ---- account: sign in / out, shown in the page header ---- */
    openLogin() { loginDialog(); },
    mountAccount(el) {
      el.textContent = '';
      if (me.uid && !me.guest) {
        el.append(h('span', { class: 'nm', text: (me.name || 'Хэрэглэгч') + (me.isAdmin ? ' · Админ' : '') }),
          h('button', { class: 'ghost sm', type: 'button', text: 'Нууц үг', on: { click: passwordDialog } }),
          h('button', { class: 'ghost sm', type: 'button', text: 'Гарах', on: { click: async () => { try { await call('POST', '/api/logout'); } catch (e) { /* ignore */ } location.reload(); } } }));
      } else {
        el.append(h('button', { class: 'ghost sm', type: 'button', text: 'Нэвтрэх', on: { click: () => loginDialog() } }));
      }
    },
    reason: 'Холбоос авахын тулд нэвтрэх шаардлагагүй. Картаа хадгалахад л болно.'
  };

  /* ---------- dialogs ---------- */
  function modal(...kids) {
    const m = h('div', { class: 'modal', on: { mousedown: e => { if (e.target === m) m.remove(); } } },
      h('div', { class: 'dlg', role: 'dialog', 'aria-modal': 'true' }, ...kids));
    document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { m.remove(); document.removeEventListener('keydown', esc); } });
    document.body.append(m); return m;
  }

  /* Signing in is only for the owner (and anyone who already has an account): making and paying for a card needs no account. */
  function loginDialog() {
    const err = h('div', { class: 'stat bad err', role: 'alert', hidden: true });
    const ident = h('input', { type: 'text', inputMode: 'email', autocomplete: 'username', maxLength: 120, placeholder: 'и-мэйл эсвэл утасны дугаар', 'aria-label': 'И-мэйл эсвэл утасны дугаар' });
    const pw = h('input', { type: 'password', autocomplete: 'current-password', maxLength: 200, 'aria-label': 'Нууц үг' });
    const go = h('button', { class: 'primary', type: 'submit', text: 'Нэвтрэх' });
    const form = h('form', { novalidate: true, on: { submit: async e => {
      e.preventDefault(); err.hidden = true; go.disabled = true;
      try { await call('POST', '/api/login', { ident: ident.value, password: pw.value }); location.reload(); }
      catch (ex) { err.textContent = ex.message || 'Алдаа гарлаа.'; err.hidden = false; go.disabled = false; }
    } } },
      h('label', {}, 'И-мэйл эсвэл утас', ident),
      h('label', {}, 'Нууц үг', pw),
      err, go);
    const m = modal(h('h3', { text: 'Нэвтрэх' }),
      h('p', { class: 'hint', text: 'Мэндчилгээ бүтээх, төлбөр төлөх, холбоос авахад нэвтрэх шаардлагагүй. Энэ нь зөвхөн админ болон өмнө нь бүртгэлтэй хүмүүст зориулагдсан.' }),
      form, h('div', { class: 'btns' }, h('button', { class: 'ghost', type: 'button', text: 'Хаах', on: { click: () => m.remove() } })));
    setTimeout(() => ident.focus(), 0);
  }

  function passwordDialog() {
    const err = h('div', { class: 'stat bad err', role: 'alert', hidden: true });
    const old = h('input', { type: 'password', autocomplete: 'current-password', maxLength: 200, 'aria-label': 'Одоогийн нууц үг' });
    const nw = h('input', { type: 'password', autocomplete: 'new-password', maxLength: 200, 'aria-label': 'Шинэ нууц үг', placeholder: 'дор хаяж 8 тэмдэгт' });
    const go = h('button', { class: 'primary', type: 'submit', text: 'Солих' });
    const m = modal(h('h3', { text: 'Нууц үг солих' }),
      h('form', { novalidate: true, on: { submit: async e => {
        e.preventDefault(); err.hidden = true; go.disabled = true;
        try { await call('POST', '/api/password', { old: old.value, next: nw.value }); m.remove(); App.toast('Нууц үг солигдлоо.'); }
        catch (ex) { err.textContent = ex.message || 'Алдаа гарлаа.'; err.hidden = false; go.disabled = false; }
      } } }, h('label', {}, 'Одоогийн нууц үг', old), h('label', {}, 'Шинэ нууц үг', nw), err, go),
      h('div', { class: 'btns' }, h('button', { class: 'ghost', type: 'button', text: 'Хаах', on: { click: () => m.remove() } })));
    old.focus();
  }

  return B;
};
})();
