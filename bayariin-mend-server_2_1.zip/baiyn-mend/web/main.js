/* main.js — start-up: pick the backend, build the tabs, wait for the settings, then show the right thing. */
(async function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$;
const sleep = ms => new Promise(r => setTimeout(r, ms));

let backend = null;
try {
  if (window.APP_REST && App.restBackend) backend = App.restBackend();
  else {
    for (let i = 0; i < 30 && !(window.claude && window.claude.use); i++) await sleep(100);
    if (window.claude && window.claude.use) backend = await App.artifactBackend(window.claude);
  }
} catch (e) { console.warn('backend:', e); }
if (!backend) backend = App.nullBackend('Энэ хуудсанд нэвтрээгүй эсвэл зөвхөн үзэх эрхтэй байна, тиймээс картыг хадгалах, холбоос авах боломжгүй. Урьдчилан харах нь ажиллана.');
App.backend = backend;
try { App.me = await backend.init(); } catch (e) { App.me = { uid: null, name: '', isAdmin: false, canWrite: false, canUpload: false }; }
const me = App.me;

/* tabs */
const tabs = [['make', 'Бүтээх'], ['mine', 'Миний картууд']]; if (me.isAdmin) tabs.push(['admin', 'Админ']);
App.views.make = App.views.make || {}; App.views.mine = App.views.mine || {}; App.views.admin = App.views.admin || {};
const tabBox = $('tabs');
tabs.forEach(([k, t]) => tabBox.append(h('button', { class: 'tab', type: 'button', role: 'tab', 'data-v': k, text: t, on: { click: () => App.show(k) } })));
$('who').textContent = me.isAdmin ? (me.name ? me.name + ' · Админ' : 'Админ') : (me.name || '');
if (backend.mountAccount) backend.mountAccount($('who'));

/* settings first: the first screen should already know which designs exist */
let cfgReady; const cfgP = new Promise(r => { cfgReady = r; });
backend.onConfig((cfg, ready) => { App.applyConfig(cfg); if (ready) cfgReady(); });
await Promise.race([cfgP, sleep(3000)]);

App.initMaker(); App.initViewer(); if (me.isAdmin) App.initAdmin();
App.show('make');
App.boot.done = true;
if (me.uid || backend.kind === 'rest') backend.logVisit(null);
await App.route();
})();
