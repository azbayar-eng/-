'use strict';
/* QPay холболтын шалгалт: хуурамч QPay сервертэй. Тохиргоо, нууц үгийн нууцлал, нэхэмжлэх, төлбөр шалгах, callback, эрх. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
process.env.BAIYN_NO_LIMITS = '1';
delete process.env.QPAY_CLIENT_ID; delete process.env.QPAY_CLIENT_SECRET; delete process.env.QPAY_INVOICE_CODE;
const { createApp } = require('../server');
const { ensureAdmin } = require('../lib/users');
const { cleanInvoice } = require('../lib/qpay');
const { fakeQpay } = require('./helpers/fake-qpay');

const SECRET = 'S3cretPass';
let fake, qurl, srv, httpd, base, tmp, owner;
const tmp2 = [];

async function boot(opts) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'baiyn-qpay-'));
  const s = createApp(Object.assign({ dataDir: dir, baseUrl: '' }, opts));
  const h = await new Promise(r => { const x = s.app.listen(0, '127.0.0.1', () => r(x)); });
  return { s, h, dir, url: 'http://127.0.0.1:' + h.address().port };
}
function client(url) {
  const jar = {};
  const f = async (method, u, body, headers) => {
    const hd = Object.assign({ 'X-Requested-With': 'baiyn' }, headers || {});
    let payload; if (body !== undefined) { payload = JSON.stringify(body); hd['Content-Type'] = 'application/json'; }
    const ck = Object.entries(jar).map(([k, v]) => k + '=' + v).join('; '); if (ck) hd.Cookie = ck;
    const r = await fetch((url || base) + u, { method, headers: hd, body: payload });
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }
    const ct = r.headers.get('content-type') || '';
    return { status: r.status, body: ct.includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => f('GET', u), post: (u, b) => f('POST', u, b), put: (u, b) => f('PUT', u, b), del: u => f('DELETE', u) };
}
async function customer(name, url) {
  const c = client(url), ident = name + '@example.mn';
  await c.post('/api/register', { name, ident, password: 'long-enough-1' });
  const uid = (await c.get('/api/me')).body.uid;
  const card = (await c.post('/api/cards', { card: { occ: 'halloween', fx: 'pumpkin', theme: 'pumpkin', to: 'Азаа', msg: 'Мэнд ' + name } })).body;
  return { c, uid, id: card.id };
}
const opens = async (cu, guest) => (await guest.get(`/api/card/${cu.uid}/${cu.id}`)).body.card.msg !== undefined;
const unthrottle = () => srv.ctx.db.prepare('UPDATE qpay_inv SET checked = 0').run();
const ap = id => srv.ctx.db.prepare('SELECT * FROM approvals WHERE card_id = ?').get(id);
const cbPath = card => { const u = new URL(fake.st.bodies.filter(b => b.callback_url.includes('/' + card + '/')).pop().callback_url); return u.pathname; };

test.before(async () => {
  fake = fakeQpay(); qurl = await fake.listen();
  ({ s: srv, h: httpd, dir: tmp, url: base } = await boot({ qpayBase: qurl }));
  await ensureAdmin(srv.ctx, 'owner@example.mn', 'owner-pass-123', 'Эзэн');
  owner = client();
  await owner.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' });
});
test.after(() => { httpd.close(); srv.close(); fake.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

/* ---------- тохиргоо ---------- */
test('админ: QPay байхгүй үед асаах боломжгүй, эрхгүй хүн хандаж чадахгүй', async () => {
  const st = (await owner.get('/api/admin/qpay')).body;
  assert.equal(st.configured, false); assert.equal(st.on, false); assert.equal(st.tested, false);
  const r = await owner.put('/api/admin/main', { patch: { qpay: true } });
  assert.equal(r.status, 400); assert.match(r.body.message, /Холболт шалгах/);
  const anon = client(), user = await customer('nobody');
  assert.equal((await anon.get('/api/admin/qpay')).status, 401);
  assert.equal((await user.c.get('/api/admin/qpay')).status, 403);
  assert.equal((await user.c.put('/api/admin/qpay', { env: 'prod', id: 'x1', secret: 'abc', code: 'C1' })).status, 403);
  assert.equal((await user.c.post('/api/admin/qpay/test')).status, 403);
});

test('админ: буруу утга татгалзагдана', async () => {
  const bad = async o => (await owner.put('/api/admin/qpay', Object.assign({ env: 'sandbox', id: 'MERCHANT_X', secret: SECRET, code: 'MERCHANT_INVOICE' }, o))).status;
  assert.equal(await bad({ env: 'http://evil.example' }), 400);      // орчин зөвхөн sandbox | prod, хаяг биш (SSRF байхгүй)
  assert.equal(await bad({ id: 'a:b' }), 400);
  assert.equal(await bad({ id: '' }), 400);
  assert.equal(await bad({ code: 'bad code!' }), 400);
  assert.equal(await bad({ secret: 'has space' }), 400);
  assert.equal((await owner.put('/api/admin/qpay', { env: 'prod', id: 'abc', code: 'CODE1' })).status, 400);   // нууц үггүй анхны хадгалалт
});

test('буруу нууц үг: шалгалт унана, асаах боломжгүй', async () => {
  let r = await owner.put('/api/admin/qpay', { env: 'sandbox', id: 'MERCHANT_X', secret: 'wrong-password', code: 'MERCHANT_INVOICE' });
  assert.equal(r.status, 200); assert.equal(r.body.configured, true); assert.equal(r.body.tested, false);
  r = await owner.post('/api/admin/qpay/test');
  assert.equal(r.body.ok, false); assert.match(r.body.msg, /хүлээж авсангүй/); assert.equal(r.body.status.tested, false);
  assert.equal((await owner.put('/api/admin/main', { patch: { qpay: true } })).status, 400);
});

test('зөв нууц үг: хадгалах, шалгах, асаах. Нууц үг хаана ч харагдахгүй', async () => {
  let r = await owner.put('/api/admin/qpay', { env: 'sandbox', id: 'MERCHANT_X', secret: SECRET, code: 'MERCHANT_INVOICE' });
  assert.equal(r.status, 200); assert.equal(r.body.hasSecret, true);
  assert.equal((await owner.post('/api/admin/qpay/test')).body.ok, true);
  assert.equal((await owner.get('/api/admin/qpay')).body.tested, true);
  r = await owner.put('/api/admin/main', { patch: { payRequired: true, price: 5000, qpay: true } });   // банкны мэдээлэлгүй ч QPay байвал болно
  assert.equal(r.status, 200, JSON.stringify(r.body));
  // хэзээ ч хариунд гарахгүй
  const seen = [JSON.stringify((await owner.get('/api/admin/qpay')).body), JSON.stringify((await owner.get('/api/config')).body), JSON.stringify((await owner.get('/api/admin/orders')).body), JSON.stringify((await client().get('/api/config')).body)];
  for (const t of seen) assert.ok(!t.includes(SECRET), 'нууц үг харагдлаа');
  // өгөгдлийн санд ил текстээр байхгүй
  const raw = srv.ctx.db.prepare("SELECT v FROM kv WHERE k = 'qpay'").get().v;
  assert.ok(!raw.includes(SECRET)); assert.match(raw, /"sec":"v1\./);
  for (const f of fs.readdirSync(tmp)) { if (f.startsWith('app.db')) assert.ok(!fs.readFileSync(path.join(tmp, f)).includes(SECRET), f + ' дотор нууц үг байна'); }
  assert.ok(fs.existsSync(path.join(tmp, '.secret')));
  assert.equal(((await client().get('/api/config')).body.main).qpay, true);
});

test('нууц үгийг хоосон үлдээвэл хуучин нь хадгалагдана, гэхдээ шинэ шалгалт шаардана', async () => {
  let r = await owner.put('/api/admin/qpay', { env: 'sandbox', id: 'MERCHANT_X', secret: '', code: 'MERCHANT_INVOICE' });
  assert.equal(r.status, 200); assert.equal(r.body.tested, false); assert.equal(r.body.on, false);        // өөрчилсөн тул QPay өөрөө унтарна
  assert.equal(((await client().get('/api/config')).body.main).qpay, false);
  assert.equal((await owner.post('/api/admin/qpay/test')).body.ok, true);                                 // хуучин нууц үг хэвээр ажиллана
  assert.equal((await owner.put('/api/admin/main', { patch: { qpay: true } })).status, 200);
});

/* ---------- нэхэмжлэх ---------- */
test('нэхэмжлэх: QR, банкны холбоос; аюултай холбоос шүүгдэнэ; нэг нэхэмжлэх дахин ашиглагдана', async () => {
  fake.st.evil = true;
  const cu = await customer('buyer1');
  const r = await cu.c.post(`/api/cards/${cu.id}/qpay`);
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.amount, 5000); assert.match(r.body.qr, /^[A-Za-z0-9+/=]+$/); assert.ok(r.body.short.startsWith('https://'));
  assert.deepEqual(r.body.urls.map(u => u.name), ['Khan bank', 'M bank']);       // javascript: ба data: холбоос, <img> нэр хасагдсан
  assert.ok(r.body.urls.every(u => !/^(javascript|data):/i.test(u.link)));
  const sent = fake.st.bodies.pop(); fake.st.bodies.push(sent);
  assert.equal(sent.invoice_code, 'MERCHANT_INVOICE'); assert.equal(sent.amount, 5000);
  assert.match(sent.sender_invoice_no, /^MN-[A-Z0-9]{6}-[a-z0-9]{6}$/);
  assert.ok(sent.callback_url.startsWith(base + '/api/pay/qpay/cb/' + cu.id + '/'));
  assert.equal(await opens(cu, client()), false);
  const again = await cu.c.post(`/api/cards/${cu.id}/qpay`);
  assert.equal(again.body.id, r.body.id);
  const before = fake.st.count.invoice;
  const [a, b] = await Promise.all([cu.c.post(`/api/cards/${cu.id}/qpay`), cu.c.post(`/api/cards/${cu.id}/qpay`)]);
  assert.equal(a.body.id, b.body.id); assert.equal(fake.st.count.invoice, before);
  fake.st.evil = false;
});

test('cleanInvoice: хайхрамжгүй хариуг цэвэрлэнэ', () => {
  const ok = cleanInvoice({ invoice_id: 'abc123', qr_image: 'data:image/png;base64,AAAA', qPay_shortUrl: 'http://not-https.example/x', urls: [{ name: 'A', link: 'abank://x' }, { name: '', link: 'abank://y' }, { name: 'B', link: 'JaVaScRiPt:1' }, { name: 'C' }, null] });
  assert.equal(ok.resp.short, ''); assert.deepEqual(ok.resp.urls.map(u => u.name), ['A']); assert.equal(ok.resp.qr, 'AAAA');
  assert.throws(() => cleanInvoice({ invoice_id: '../x' }), /буруу/);
  assert.throws(() => cleanInvoice({}), /буруу/);
  assert.equal(cleanInvoice({ invoice_id: 'abc123', qr_image: '"><script>' }).resp.qr, '');
});

/* ---------- төлбөр шалгах ---------- */
test('төлөөгүй, дутуу, буруу төлөвтэй, өөр валюттай төлбөрөөр карт нээгдэхгүй', async () => {
  const cu = await customer('buyer2'), guest = client();
  const inv = (await cu.c.post(`/api/cards/${cu.id}/qpay`)).body;
  let r = (await cu.c.get(`/api/cards/${cu.id}/qpay`)).body; assert.equal(r.paid, false);
  for (const [amount, o] of [[3000, {}], [5000, { status: 'NEW' }], [5000, { status: 'FAILED' }], [5000, { status: 'REFUNDED' }], [5000, { currency: 'USD' }]]) {
    fake.pay(inv.id, amount, o); unthrottle();
    r = (await cu.c.get(`/api/cards/${cu.id}/qpay`)).body;
    assert.equal(r.paid, false, JSON.stringify([amount, o]));
    assert.equal(await opens(cu, guest), false);
  }
  assert.equal(ap(cu.id), undefined);
});

test('бүрэн төлөгдвөл карт нээгдэнэ; давтан шалгахад давхар бүртгэл үүсэхгүй; админ QPay гэж харна', async () => {
  const cu = await customer('buyer3'), guest = client();
  const inv = (await cu.c.post(`/api/cards/${cu.id}/qpay`)).body;
  fake.pay(inv.id, 5000); unthrottle();
  let r = (await cu.c.get(`/api/cards/${cu.id}/qpay`)).body;
  assert.equal(r.paid, true); assert.equal(await opens(cu, guest), true);
  const a1 = ap(cu.id); assert.equal(a1.st, 'ok'); assert.equal(a1.by, 'qpay'); assert.equal(a1.amt, 5000); assert.equal(a1.uid, cu.uid);
  r = (await cu.c.get(`/api/cards/${cu.id}/qpay`)).body; assert.equal(r.paid, true);
  assert.deepEqual(ap(cu.id), a1);
  const mine = (await cu.c.get('/api/mine')).body.find(x => x.id === cu.id); assert.equal(mine.ap.st, 'ok'); assert.equal(mine.ap.via, 'qpay');
  const order = (await owner.get('/api/admin/orders')).body.list.find(x => x.id === cu.id); assert.equal(order.ap.via, 'qpay');
  assert.equal((await cu.c.post(`/api/cards/${cu.id}/qpay`)).status, 409);       // баталгаажсан картад шинэ нэхэмжлэх үүсгэхгүй
});

test('бүртгэлгүй зочин QPay-ээр төлж холбоос авна', async () => {
  const g = client(), stranger = client(), recipient = client();
  const { uid } = (await g.post('/api/guest')).body;
  const id = (await g.post('/api/cards', { card: { occ: 'halloween', fx: 'pumpkin', theme: 'pumpkin', to: 'Азаа', msg: 'Зочноос мэнд' } })).body.id;
  assert.equal((await stranger.post(`/api/cards/${id}/qpay`)).status, 401, 'session-гүй хүн нэхэмжлэх үүсгэж чадахгүй');
  assert.equal(await opens({ uid, id }, recipient), false);
  const inv = (await g.post(`/api/cards/${id}/qpay`)).body;
  assert.ok(inv.id && inv.qr);
  fake.pay(inv.id, 5000); unthrottle();
  assert.equal((await g.get(`/api/cards/${id}/qpay`)).body.paid, true);
  assert.equal(await opens({ uid, id }, recipient), true, 'төлсний дараа холбоос хэнд ч нээгдэнэ');
  const a = ap(id); assert.equal(a.by, 'qpay'); assert.equal(a.uid, uid);
});

test('нэхэмжлэхээс илүү төлсөн ч, хоёр удаа хуваан төлсөн ч нийлбэрээр бодно', async () => {
  const over = await customer('buyer4'), split = await customer('buyer5');
  const i1 = (await over.c.post(`/api/cards/${over.id}/qpay`)).body, i2 = (await split.c.post(`/api/cards/${split.id}/qpay`)).body;
  fake.pay(i1.id, 7000); fake.pay(i2.id, 2000); unthrottle();
  assert.equal((await over.c.get(`/api/cards/${over.id}/qpay`)).body.paid, true); assert.equal(ap(over.id).amt, 7000);
  assert.equal((await split.c.get(`/api/cards/${split.id}/qpay`)).body.paid, false);
  fake.pay(i2.id, 3000); unthrottle();
  assert.equal((await split.c.get(`/api/cards/${split.id}/qpay`)).body.paid, true); assert.equal(ap(split.id).amt, 5000);
});

test('QPay-аас лавлах давтамж хязгаарлагдана (4 секунд)', async () => {
  const cu = await customer('buyer6'); await cu.c.post(`/api/cards/${cu.id}/qpay`);
  const n0 = fake.st.count.check;
  for (let i = 0; i < 5; i++) await cu.c.get(`/api/cards/${cu.id}/qpay`);
  assert.equal(fake.st.count.check - n0, 1);
});

/* ---------- callback ---------- */
test('callback: буруу гарын үсэг, өөр картын гарын үсэг татгалзагдана', async () => {
  const a = await customer('cbA'), b = await customer('cbB');
  await a.c.post(`/api/cards/${a.id}/qpay`); await b.c.post(`/api/cards/${b.id}/qpay`);
  const tokA = cbPath(a.id).split('/').pop();
  const anon = client();
  assert.equal((await anon.get(`/api/pay/qpay/cb/${a.id}/${'0'.repeat(32)}`)).status, 404);
  assert.equal((await anon.get(`/api/pay/qpay/cb/${a.id}/short`)).status, 404);
  assert.equal((await anon.get(`/api/pay/qpay/cb/${b.id}/${tokA}`)).status, 404);        // A-ийн токеныг B дээр хэрэглэж болохгүй
  assert.equal((await anon.post(`/api/pay/qpay/cb/${a.id}/${tokA}x`, {})).status, 404);
});

test('callback: ирсэн өгөгдөлд итгэхгүй, зөвхөн QPay-ээс лавлана. Төлөгдсөн бол даруй нээнэ, давтагдвал нэг л бүртгэл', async () => {
  const cu = await customer('cbC'), guest = client(), anon = client();
  const inv = (await cu.c.post(`/api/cards/${cu.id}/qpay`)).body, p = cbPath(cu.id);
  // төлөөгүй байхад «төлсөн» гэсэн callback ирсэн ч юу ч өөрчлөгдөхгүй
  let r = await anon.post(p, { invoice_id: inv.id, payment_status: 'PAID', paid_amount: 5000 });
  assert.equal(r.status, 200); assert.equal(await opens(cu, guest), false); assert.equal(ap(cu.id), undefined);
  r = await anon.get(p + '?qpay_payment_id=999&invoice_id=' + inv.id);
  assert.equal(r.status, 200); assert.equal(await opens(cu, guest), false);
  // үнэхээр төлөгдсөн: callback шууд (4 секунд хүлээлгүй) нээнэ
  fake.pay(inv.id, 5000);
  r = await anon.post(p, { invoice_id: inv.id });
  assert.equal(r.status, 200); assert.equal(await opens(cu, guest), true);
  const a1 = ap(cu.id); assert.equal(a1.by, 'qpay');
  await anon.get(p); await anon.post(p, {});
  assert.deepEqual(ap(cu.id), a1);
});

/* ---------- эрх, горим ---------- */
test('өөр хүний карт, нэвтрээгүй хүн, байхгүй карт', async () => {
  const a = await customer('ownA'), b = await customer('ownB'), anon = client();
  assert.equal((await b.c.post(`/api/cards/${a.id}/qpay`)).status, 404);
  assert.equal((await b.c.get(`/api/cards/${a.id}/qpay`)).status, 404);
  assert.equal((await anon.post(`/api/cards/${a.id}/qpay`)).status, 401);
  assert.equal((await anon.get(`/api/cards/${a.id}/qpay`)).status, 401);
  assert.equal((await a.c.post('/api/cards/zzzzzzzz/qpay')).status, 404);
  assert.equal((await a.c.post('/api/cards/..%2Fx/qpay')).status, 400);
  assert.equal((await b.c.post(`/api/cards/${a.id}/qpay`)).status, 404);
});

test('үнэгүй карт, төлбөргүй горимд нэхэмжлэх үүсгэхгүй', async () => {
  const cu = await customer('freebie');
  const n = fake.st.count.invoice;
  srv.ctx.db.prepare('UPDATE cards SET free = 1 WHERE id = ?').run(cu.id);
  assert.equal((await cu.c.post(`/api/cards/${cu.id}/qpay`)).status, 409);
  const paid = await customer('paidmode');
  assert.equal((await owner.put('/api/admin/main', { patch: { payRequired: false } })).status, 200);
  assert.equal((await paid.c.post(`/api/cards/${paid.id}/qpay`)).status, 409);
  assert.equal((await owner.put('/api/admin/main', { patch: { payRequired: true } })).status, 200);
  assert.equal(fake.st.count.invoice, n);
});

test('QPay унтарсан үед шинэ нэхэмжлэх үгүй, гэхдээ өмнө нь өгсөн нэхэмжлэх төлөгдвөл хүлээн авна', async () => {
  const cu = await customer('late'), guest = client();
  const inv = (await cu.c.post(`/api/cards/${cu.id}/qpay`)).body;
  assert.equal((await owner.put('/api/admin/main', { patch: { qpay: false } })).status, 400);       // банкны мэдээлэлгүй байхад QPay-г унтраавал төлбөрийн арга үлдэхгүй
  assert.equal((await owner.put('/api/admin/main', { patch: { bank: 'М банк', account: '8000222222', holder: 'Бат' } })).status, 200);
  assert.equal((await owner.put('/api/admin/main', { patch: { qpay: false } })).status, 200);
  assert.equal(((await client().get('/api/config')).body.main).qpay, false);
  const other = await customer('late2');
  assert.equal((await other.c.post(`/api/cards/${other.id}/qpay`)).status, 503);
  fake.pay(inv.id, 5000); unthrottle();
  assert.equal((await cu.c.get(`/api/cards/${cu.id}/qpay`)).body.paid, true); assert.equal(await opens(cu, guest), true);
  assert.equal((await owner.put('/api/admin/main', { patch: { qpay: true } })).status, 200);
});

test('үнэ өөрчлөгдвөл шинэ нэхэмжлэх гарна; хуучин нэхэмжлэхийн дүнг хүндэтгэнэ', async () => {
  const cu = await customer('pricey'), guest = client();
  const a = (await cu.c.post(`/api/cards/${cu.id}/qpay`)).body; assert.equal(a.amount, 5000);
  assert.equal((await owner.put('/api/admin/main', { patch: { price: 8000 } })).status, 200);
  const b = (await cu.c.post(`/api/cards/${cu.id}/qpay`)).body; assert.equal(b.amount, 8000); assert.notEqual(b.id, a.id);
  fake.pay(a.id, 5000); unthrottle();
  assert.equal((await cu.c.get(`/api/cards/${cu.id}/qpay`)).body.paid, true); assert.equal(await opens(cu, guest), true);
  assert.equal((await owner.put('/api/admin/main', { patch: { price: 5000 } })).status, 200);
});

test('админ «төлөгдөөгүй» гэж татгалзсан картыг QPay-ийн баталгаатай төлбөр нээнэ', async () => {
  const cu = await customer('rejected'), guest = client();
  await owner.post('/api/admin/approve', { id: cu.id, uid: cu.uid, st: 'no', note: 'ирээгүй' });
  const inv = (await cu.c.post(`/api/cards/${cu.id}/qpay`)).body;
  fake.pay(inv.id, 5000); unthrottle();
  assert.equal((await cu.c.get(`/api/cards/${cu.id}/qpay`)).body.paid, true);
  assert.equal(ap(cu.id).st, 'ok'); assert.equal(await opens(cu, guest), true);
});

/* ---------- QPay-ийн тал ---------- */
test('токен: нэг удаа авч дахин ашиглана; хугацаа дууссан бол шинэчилнэ', async () => {
  const f2 = fakeQpay({ expiresIn: 30 }), u2 = await f2.listen();      // 30 секундийн токен: зүгээр л шинэчлэх үед
  const t = await boot({ qpayBase: u2 }); tmp2.push(t.dir);
  try {
    await ensureAdmin(t.s.ctx, 'o2@example.mn', 'owner-pass-123', 'Эзэн');
    const o = client(t.url); await o.post('/api/login', { ident: 'o2@example.mn', password: 'owner-pass-123' });
    await o.put('/api/admin/qpay', { env: 'sandbox', id: 'MERCHANT_X', secret: SECRET, code: 'MERCHANT_INVOICE' });
    assert.equal((await o.post('/api/admin/qpay/test')).body.ok, true);
    assert.equal((await o.put('/api/admin/main', { patch: { payRequired: true, price: 5000, qpay: true } })).status, 200);
    const cu = await customer('tok1', t.url);
    await cu.c.post(`/api/cards/${cu.id}/qpay`); await cu.c.get(`/api/cards/${cu.id}/qpay`);
    assert.ok(f2.st.count.refresh >= 1, 'refresh ашиглагдсангүй');
    assert.equal(f2.st.count.token, 1);
  } finally { t.h.close(); t.s.close(); f2.close(); }
});
test.after(() => { for (const d of tmp2) fs.rmSync(d, { recursive: true, force: true }); });

test('токен хугацаанаас өмнө хүчингүй болбол нэг удаа дахин нэвтэрч үргэлжилнэ', async () => {
  const cu = await customer('tok2');
  fake.expireAccessTokens();
  const r = await cu.c.post(`/api/cards/${cu.id}/qpay`);
  assert.equal(r.status, 200);
  fake.expireAccessTokens(); unthrottle();
  assert.equal((await cu.c.get(`/api/cards/${cu.id}/qpay`)).status, 200);
});

test('QPay унасан үед: ойлгомжтой алдаа, дотоод мэдээлэл алдагдахгүй, админд тэмдэглэгдэнэ, дараа нь сэргэнэ', async () => {
  const cu = await customer('down'), guest = client();
  try {
  fake.st.down = true;
  let r = await cu.c.post(`/api/cards/${cu.id}/qpay`);
  assert.equal(r.status, 502); assert.equal(r.body.error, 'qpay'); assert.ok(!/INTERNAL|merchant|S3cret/i.test(JSON.stringify(r.body)));
  assert.ok((await owner.get('/api/admin/qpay')).body.err);
  fake.st.down = false;
  r = await cu.c.post(`/api/cards/${cu.id}/qpay`); assert.equal(r.status, 200);
  assert.equal((await owner.get('/api/admin/qpay')).body.err, null);
  fake.pay(r.body.id, 5000); fake.st.down = true; unthrottle();
  const s = (await cu.c.get(`/api/cards/${cu.id}/qpay`)).body; assert.equal(s.paid, false); assert.equal(s.st, 'error');   // унасан үед «төлөгдсөн» гэж таамаглахгүй
  assert.equal(await opens(cu, guest), false);
  fake.st.down = false; unthrottle();
  assert.equal((await cu.c.get(`/api/cards/${cu.id}/qpay`)).body.paid, true);
  } finally { fake.st.down = false; }
});

test('invoice code буруу бол QPay-ийн алдаа админд харагдана, хэрэглэгчид ерөнхий мессеж', async () => {
  fake.opts.code = 'OTHER_CODE';
  try {
    const cu = await customer('badcode');
    const r = await cu.c.post(`/api/cards/${cu.id}/qpay`);
    assert.equal(r.status, 502); assert.ok(!JSON.stringify(r.body).includes('INVOICE_CODE'));
    assert.equal((await owner.get('/api/admin/qpay')).body.err.code, 'INVOICE_CODE_INVALID');
  } finally { fake.opts.code = 'MERCHANT_INVOICE'; }
});

test('.env-ээр тохируулсан бол эндээс солих, устгах боломжгүй', async () => {
  const t = await boot({ qpayBase: qurl, env: { QPAY_CLIENT_ID: 'MERCHANT_X', QPAY_CLIENT_SECRET: SECRET, QPAY_INVOICE_CODE: 'MERCHANT_INVOICE', QPAY_ENV: 'sandbox' } }); tmp2.push(t.dir);
  try {
    await ensureAdmin(t.s.ctx, 'o3@example.mn', 'owner-pass-123', 'Эзэн');
    const o = client(t.url); await o.post('/api/login', { ident: 'o3@example.mn', password: 'owner-pass-123' });
    const st = (await o.get('/api/admin/qpay')).body;
    assert.equal(st.source, 'env'); assert.equal(st.configured, true); assert.ok(!JSON.stringify(st).includes(SECRET));
    assert.equal((await o.put('/api/admin/qpay', { env: 'prod', id: 'x1', secret: 'abc', code: 'C1' })).status, 409);
    assert.equal((await o.del('/api/admin/qpay')).status, 409);
    assert.equal((await o.post('/api/admin/qpay/test')).body.ok, true);
    assert.equal((await o.put('/api/admin/main', { patch: { payRequired: true, price: 5000, qpay: true } })).status, 200);
  } finally { t.h.close(); t.s.close(); }
});

test('нууц үгийг устгахад QPay унтарна', async () => {
  const t = await boot({ qpayBase: qurl }); tmp2.push(t.dir);
  try {
    await ensureAdmin(t.s.ctx, 'o4@example.mn', 'owner-pass-123', 'Эзэн');
    const o = client(t.url); await o.post('/api/login', { ident: 'o4@example.mn', password: 'owner-pass-123' });
    await o.put('/api/admin/qpay', { env: 'sandbox', id: 'MERCHANT_X', secret: SECRET, code: 'MERCHANT_INVOICE' });
    await o.post('/api/admin/qpay/test');
    await o.put('/api/admin/main', { patch: { payRequired: true, price: 5000, qpay: true } });
    assert.equal(((await client(t.url).get('/api/config')).body.main).qpay, true);
    const r = await o.del('/api/admin/qpay');
    assert.equal(r.status, 200); assert.equal(r.body.configured, false);
    assert.equal(((await client(t.url).get('/api/config')).body.main).qpay, false);
    assert.equal(t.s.ctx.db.prepare("SELECT v FROM kv WHERE k = 'qpay'").get().v, 'null');
    assert.equal((await o.put('/api/admin/main', { patch: { qpay: true } })).status, 400);
  } finally { t.h.close(); t.s.close(); }
});

test('QPay тохируулагдаагүй, гэхдээ main.qpay үлдсэн бол товч харагдахгүй', async () => {
  const t = await boot({ qpayBase: qurl }); tmp2.push(t.dir);
  try {
    const kv = t.s.ctx.kv; kv.set('main', Object.assign({}, kv.get('main', {}), { qpay: true }));
    assert.equal(((await client(t.url).get('/api/config')).body.main).qpay, false);
  } finally { t.h.close(); t.s.close(); }
});
