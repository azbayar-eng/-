'use strict';
/* Серверийн шалгалт: npm test
   Түр хавтсанд шинэ өгөгдлийн сан үүсгэж, сервер асаагаад бүртгэл, төлбөр, эрх, файл хуулалтыг шалгана. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
process.env.BAIYN_NO_LIMITS = '1';
const { createApp } = require('../server');
const { ensureAdmin } = require('../lib/users');

let srv, httpd, base, tmp;
test.before(async () => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'baiyn-'));
  srv = createApp({ dataDir: tmp, baseUrl: '' });
  await new Promise(r => { httpd = srv.app.listen(0, '127.0.0.1', r); });
  base = 'http://127.0.0.1:' + httpd.address().port;
  await ensureAdmin(srv.ctx, 'owner@example.mn', 'owner-pass-123', 'Эзэн');
});
test.after(() => { httpd.close(); srv.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

/* a tiny browser: remembers cookies, sends the CSRF header */
function client() {
  const jar = {};
  const f = async (method, url, body, o) => {
    o = o || {};
    const headers = Object.assign({ 'X-Requested-With': 'baiyn' }, o.headers || {});
    let payload;
    if (o.raw) { payload = o.raw; headers['Content-Type'] = o.type || 'application/octet-stream'; }
    else if (body !== undefined) { payload = JSON.stringify(body); headers['Content-Type'] = 'application/json'; }
    const ck = Object.entries(jar).map(([k, v]) => k + '=' + v).join('; '); if (ck) headers.Cookie = ck;
    const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); const k = kv.slice(0, i), v = kv.slice(i + 1); if (/Max-Age=0/.test(c)) delete jar[k]; else jar[k] = v; }
    const ct = r.headers.get('content-type') || '';
    return { status: r.status, headers: r.headers, body: ct.includes('json') ? await r.json() : (ct.startsWith('image/') || ct.startsWith('video/') ? Buffer.from(await r.arrayBuffer()) : await r.text()) };
  };
  return { jar, get: (u, o) => f('GET', u, undefined, o), post: (u, b, o) => f('POST', u, b, o), put: (u, b, o) => f('PUT', u, b, o), del: (u) => f('DELETE', u) };
}
const CARD = { occ: 'halloween', fx: 'pumpkin', theme: 'pumpkin', to: 'Азаа', from: 'Болд', title: 'Хэллоуины мэнд!', msg: 'Сайхан баяраа тэмдэглээрэй' };
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(64, 1)]);

test('нэвтрээгүй хүн: тохиргоо харна, банкны мэдээлэл харахгүй, CSRF хамгаалалттай', async () => {
  const a = client(), owner = client();
  assert.equal((await a.get('/api/me')).body.uid, null);
  assert.equal((await owner.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' })).status, 200);
  assert.equal((await owner.put('/api/admin/main', { patch: { payRequired: true, price: 5000, bank: 'Хаан банк', account: '5000123456', holder: 'Бат', note: 'Утга дээр код бичнэ' } })).status, 200);
  const anon = (await a.get('/api/config')).body;
  assert.equal(anon.main.price, 5000);
  assert.equal(anon.main.bank, undefined); assert.equal(anon.main.account, undefined);
  const r = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(r.status, 403);                                   // header байхгүй
  const r2 = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'baiyn', Origin: 'https://evil.example' }, body: '{}' });
  assert.equal(r2.status, 403);                                  // өөр сайтаас
});

test('бүртгэл, нэвтрэлт, нууц үг', async () => {
  const c = client();
  assert.equal((await c.post('/api/register', { name: 'Саран', ident: 'saran@example.mn', password: 'short' })).status, 400);
  assert.equal((await c.post('/api/register', { name: 'Саран', ident: 'буруу', password: 'long-enough-1' })).status, 400);
  const ok = await c.post('/api/register', { name: 'Саран', ident: 'Saran@Example.mn', password: 'long-enough-1' });
  assert.equal(ok.status, 200);
  assert.ok(c.jar.sid, 'session cookie');
  assert.match(ok.headers.getSetCookie().join(';'), /HttpOnly/);
  assert.equal((await c.get('/api/me')).body.name, 'Саран');
  assert.equal((await client().post('/api/register', { name: 'Өөр', ident: 'saran@example.mn', password: 'long-enough-1' })).status, 409);
  const phone = client();
  assert.equal((await phone.post('/api/register', { name: 'Дорж', ident: '+976 9911-2233', password: 'long-enough-1' })).status, 200);
  assert.equal((await client().post('/api/login', { ident: '99112233', password: 'long-enough-1' })).status, 200);
  assert.equal((await client().post('/api/login', { ident: 'saran@example.mn', password: 'wrong-password' })).status, 401);
  await c.post('/api/logout'); assert.equal((await c.get('/api/me')).body.uid, null);
  const d = client(); await d.post('/api/login', { ident: 'saran@example.mn', password: 'long-enough-1' });
  assert.equal((await d.post('/api/password', { old: 'nope-nope-nope', next: 'new-password-1' })).status, 403);
  assert.equal((await d.post('/api/password', { old: 'long-enough-1', next: 'new-password-1' })).status, 200);
  assert.equal((await client().post('/api/login', { ident: 'saran@example.mn', password: 'long-enough-1' })).status, 401);
  assert.equal((await client().post('/api/login', { ident: 'saran@example.mn', password: 'new-password-1' })).status, 200);
});

test('төлбөр: төлөхөөс өмнө хүлээн авагч юу ч харахгүй, админ батлахад нээгдэнэ', async () => {
  const owner = client(), cust = client(), guest = client(), other = client();
  await owner.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' });
  await cust.post('/api/register', { name: 'Хэрэглэгч', ident: 'pay@example.mn', password: 'long-enough-1' });
  await other.post('/api/register', { name: 'Бусад', ident: 'other@example.mn', password: 'long-enough-1' });
  const me = (await cust.get('/api/me')).body.uid;

  const saved = (await cust.post('/api/cards', { card: CARD })).body;
  assert.equal(saved.free, false);
  assert.match(saved.id, /^[a-z0-9]{8}$/);
  const blocked = (await guest.get(`/api/card/${me}/${saved.id}`)).body;
  assert.equal(blocked.card.msg, undefined); assert.equal(blocked.card.to, undefined); assert.equal(blocked.card.free, false);
  assert.equal((await cust.get(`/api/card/${me}/${saved.id}`)).body.card.msg, CARD.msg);        // эзэн өөрөө харна

  assert.equal((await other.post(`/api/cards/${saved.id}/claim`)).status, 404);                 // бусдын карт
  assert.equal((await other.post('/api/cards', { id: saved.id, card: CARD })).status, 404);
  assert.equal((await other.del(`/api/cards/${saved.id}`)).status, 404);
  assert.equal((await cust.post(`/api/cards/${saved.id}/claim`)).status, 200);

  const orders = (await owner.get('/api/admin/orders')).body;
  const o = orders.list.find(x => x.id === saved.id);
  assert.ok(o && o.claim > 0 && !o.ap && o.ref === 'MN-' + saved.id.slice(0, 6).toUpperCase());
  assert.equal((await cust.get('/api/admin/orders')).status, 403);
  assert.equal((await guest.get('/api/admin/orders')).status, 401);
  assert.equal((await cust.post('/api/admin/approve', { uid: me, id: saved.id, st: 'ok', amt: 5000 })).status, 403);

  assert.equal((await owner.post('/api/admin/approve', { uid: me, id: saved.id, st: 'ok', amt: 5000 })).status, 200);
  const open = (await guest.get(`/api/card/${me}/${saved.id}`)).body;
  assert.equal(open.card.msg, CARD.msg); assert.deepEqual(open.ap, { st: 'ok' });
  const mine = (await cust.get('/api/mine')).body.find(x => x.id === saved.id);
  assert.equal(mine.ap.st, 'ok'); assert.equal(mine.ap.amt, 5000);

  assert.equal((await owner.post('/api/admin/approve', { uid: me, id: saved.id, st: 'no', note: 'Шилжүүлэг ирээгүй' })).status, 200);
  assert.equal((await guest.get(`/api/card/${me}/${saved.id}`)).body.card.msg, undefined);
  assert.equal((await owner.del('/api/admin/approve/' + saved.id)).status, 200);

  assert.equal((await cust.del(`/api/cards/${saved.id}`)).status, 200);
  assert.equal((await guest.get(`/api/card/${me}/${saved.id}`)).status, 404);
});

test('үнэгүй горимд (эсвэл админ өөрөө) карт шууд нээгдэнэ; хуудасны хязгаар', async () => {
  const owner = client(), guest = client();
  await owner.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' });
  const mine = (await owner.post('/api/cards', { card: CARD })).body;
  assert.equal(mine.free, true);
  const uid = (await owner.get('/api/me')).body.uid;
  assert.equal((await guest.get(`/api/card/${uid}/${mine.id}`)).body.card.msg, CARD.msg);
  await owner.put('/api/admin/main', { patch: { payRequired: false } });
  const c = client(); await c.post('/api/register', { name: 'Үнэгүй', ident: 'free@example.mn', password: 'long-enough-1' });
  assert.equal((await c.post('/api/cards', { card: CARD })).body.free, true);
  await owner.put('/api/admin/main', { patch: { payRequired: true } });
  assert.equal((await c.post('/api/cards', { card: CARD })).body.free, false);
});

test('картын өгөгдөл шалгагдана', async () => {
  const c = client(); await c.post('/api/register', { name: 'Шалгагч', ident: 'val@example.mn', password: 'long-enough-1' });
  const bad = async x => assert.equal((await c.post('/api/cards', { card: Object.assign({}, CARD, x) })).status, 400, JSON.stringify(x).slice(0, 60));
  await bad({ fx: '../etc' }); await bad({ occ: '' }); await bad({ photo: 'javascript:alert(1)' }); await bad({ photo: 'data:text/html;base64,PHNjcmlwdD4=' });
  await bad({ themeDef: { name: 'x', bg0: 'red', bg1: '#000000', glow: '#000000', ink: '#000000', a: '#000000', b: '#000000', c: '#000000' } });
  assert.equal((await c.post('/api/cards', { card: { fx: 'pumpkin' } })).status, 400);
  assert.equal((await c.post('/api/cards', { card: Object.assign({}, CARD, { msg: 'ө'.repeat(5000), unknownKey: 'x', free: true }) })).status, 200);
  const list = (await c.get('/api/mine')).body; assert.equal(list.length, 1); assert.equal(list[0].free, false);   // «free»-г хөтөч тогтоож чадахгүй
  const uid = (await c.get('/api/me')).body.uid, got = (await c.get(`/api/card/${uid}/${list[0].id}`)).body.card;
  assert.equal(got.msg.length, 700); assert.equal(got.unknownKey, undefined);
  const tiny = 'data:image/jpeg;base64,' + Buffer.alloc(300, 7).toString('base64');
  assert.equal((await c.post('/api/cards', { card: Object.assign({}, CARD, { photo: tiny }) })).status, 200);
});

test('зочдын бүртгэл: бүртгэлтэй ба бүртгэлгүй хүн', async () => {
  const owner = client(), cust = client(), guest = client();
  await owner.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' });
  await cust.post('/api/register', { name: 'Эзэмшигч', ident: 'v@example.mn', password: 'long-enough-1' });
  const uid = (await cust.get('/api/me')).body.uid, id = (await cust.post('/api/cards', { card: CARD })).body.id;
  await owner.post('/api/admin/approve', { uid, id, st: 'ok', amt: 1 });
  assert.equal((await guest.post('/api/visit', {})).status, 200);
  assert.equal((await guest.post('/api/visit', { o: uid, c: id })).status, 200);
  await guest.post('/api/visit', { o: uid, c: id });                                     // 1 минут дотор давтагдсан нь тоологдохгүй
  assert.equal((await guest.post('/api/visit', { o: uid, c: 'zzzzzzzz' })).status, 200);
  assert.equal((await guest.post('/api/visit', { o: uid })).status, 400);
  await cust.post('/api/visit', { o: uid, c: id });                                      // эзэн өөрөө: views нэмэгдэхгүй
  const vs = (await owner.get('/api/admin/visitors')).body;
  const g = vs.find(v => v.uid === guest.jar.vid && v.uid.startsWith('a_'));
  assert.ok(g, 'anonymous visitor listed'); assert.equal(g.v.length, 1); assert.equal(g.v[0].c, id); assert.equal(g.n, 1);
  assert.ok(vs.find(v => v.uid === uid), 'signed-in visitor listed');
  assert.equal((await cust.get('/api/mine')).body.find(x => x.id === id).views, 1);
  const names = (await owner.post('/api/admin/names', { ids: [uid, g.uid, 'u_unknown'] })).body;
  assert.equal(names[uid], 'Эзэмшигч · v@example.mn'); assert.match(names[g.uid], /^Зочин …/); assert.equal(names.u_unknown, undefined);
  assert.equal((await cust.get('/api/admin/visitors')).status, 403);
});

test('студи: өнгө, загвар, дуу, зураг/видео хуулалт', async () => {
  const owner = client(), cust = client(), guest = client();
  await owner.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' });
  await cust.post('/api/register', { name: 'Студи', ident: 's@example.mn', password: 'long-enough-1' });
  const theme = { name: 'Алтан шөнө', bg0: '#160C3A', bg1: '#5B2A9E', glow: '#B07CFF', ink: '#FFF3D6', a: '#FFC857', b: '#FF6FB5', c: '#7FD6FF' };
  assert.equal((await cust.put('/api/admin/items/themes/t1', theme)).status, 403);
  assert.equal((await owner.put('/api/admin/items/themes/t1', Object.assign({}, theme, { a: 'url(x)' }))).status, 400);
  assert.equal((await owner.put('/api/admin/items/themes/t1', theme)).status, 200);
  assert.equal((await owner.put('/api/admin/items/bogus/t1', theme)).status, 400);
  assert.equal((await owner.put('/api/admin/items/templates/tp1', { name: 'Загвар', occ: 'bday', fx: 'confetti', theme: 'sun', sfx: { open: 'chime', bad: 5 } })).status, 200);
  assert.equal((await owner.put('/api/admin/items/sounds/s1', { name: 'Дуу', base: 'pop', vol: 99, file: { data: 'AAAA', mime: 'text/html', name: 'x' } })).status, 400);
  assert.equal((await owner.put('/api/admin/items/sounds/s1', { name: 'Дуу', base: 'pop', vol: 99, file: { data: 'AAAA', mime: 'audio/mpeg', name: 'x.mp3' } })).status, 200);

  assert.equal((await owner.post('/api/admin/upload', undefined, { raw: Buffer.from('<script>alert(1)</script>'), type: 'image/png' })).status, 400);   // type худал байж болно
  const up = await owner.post('/api/admin/upload', undefined, { raw: PNG, type: 'image/png' });
  assert.equal(up.status, 200); assert.match(up.body.src, /^\/_blob\/[a-z0-9]{16}$/);
  assert.equal((await owner.put('/api/admin/items/media/m1', { kind: 'image', role: 'bg', assetId: 'nonexistent1234', name: 'x' })).status, 400);
  assert.equal((await owner.put('/api/admin/items/media/m1', { kind: 'image', role: 'bg', assetId: up.body.assetId, name: 'Арын зураг' })).status, 200);
  assert.equal((await owner.put('/api/admin/items/media/m2', { kind: 'video', role: 'sticker', assetId: up.body.assetId, name: 'v' })).status, 400);

  const blob = await guest.get(up.body.src);
  assert.equal(blob.status, 200); assert.equal(blob.headers.get('content-type'), 'image/png'); assert.equal(blob.headers.get('x-content-type-options'), 'nosniff');
  assert.match(blob.headers.get('content-security-policy'), /sandbox/);
  assert.equal(Buffer.compare(blob.body, PNG), 0);
  const rng = await fetch(base + up.body.src, { headers: { Range: 'bytes=0-9' } }); assert.equal(rng.status, 206);

  const cfg = (await guest.get('/api/config')).body;
  assert.equal(cfg.themes[0].name, 'Алтан шөнө'); assert.equal(cfg.templates[0].sfx.bad, undefined); assert.equal(cfg.media[0].assetId, up.body.assetId);
  const same = (await guest.get('/api/config?rev=' + cfg.rev)).body; assert.equal(same.same, true);

  assert.equal((await owner.del('/api/admin/items/media/m1')).status, 200);
  assert.equal((await owner.del('/api/admin/assets/' + up.body.assetId)).status, 200);
  assert.equal((await guest.get(up.body.src)).status, 404);
});

test('төлбөртэй горимыг банкны мэдээлэлгүй асаахгүй', async () => {
  const owner = client(); await owner.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' });
  assert.equal((await owner.put('/api/admin/main', { patch: { payRequired: false, bank: '', account: '', holder: '' } })).status, 200);
  assert.equal((await owner.put('/api/admin/main', { patch: { payRequired: true } })).status, 400);
  assert.equal((await owner.put('/api/admin/main', { patch: { bank: 'Хаан банк', account: '5000123456', holder: 'Бат', price: 5000, payRequired: true } })).status, 200);
});

test('хэт олон оролдлогыг хязгаарлана', () => {
  delete process.env.BAIYN_NO_LIMITS;
  const S = require('../lib/security');
  const r = Array.from({ length: 6 }, () => S.hit('unit:k', 5, 60000));
  process.env.BAIYN_NO_LIMITS = '1';
  assert.deepEqual(r, [true, true, true, true, true, false]);
});

test('хуваалцах хуудас, хуудсууд, нууц замууд', async () => {
  const g = client();
  const og = await g.get('/c/u_abc/xyz12345'); assert.equal(og.status, 200); assert.match(og.body, /og:title/); assert.match(og.body, /refresh/); assert.ok(!/style=/.test(og.body), 'CSP forbids inline styles');
  const evil = await g.get('/c/' + encodeURIComponent('"><script>') + '/x'); assert.ok(!evil.body.includes('<script>'));
  const idx = await g.get('/'); assert.equal(idx.status, 200); assert.match(idx.body, /app\.[0-9a-f]{8}\.js/);
  assert.match(idx.headers.get('content-security-policy'), /script-src 'self'/);
  const cfgjs = await g.get('/config.js'); assert.match(cfgjs.body, /APP_REST=true/);
  assert.equal((await g.get('/data/app.db')).status, 404); assert.equal((await g.get('/server.js')).status, 404); assert.equal((await g.get('/api/nope')).status, 404);
  assert.equal((await g.get('/healthz')).body, 'ok');
});
