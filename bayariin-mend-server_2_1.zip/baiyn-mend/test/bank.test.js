'use strict';
/* Банкны имэйлээр автомат батлах хэсгийн шалгалт: задлагч, баталгаажуулалт, тааруулалт, админы жагсаалт. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
process.env.BAIYN_NO_LIMITS = '1';
const { createApp } = require('../server');
const { ensureAdmin } = require('../lib/users');
const B = require('../lib/bankmail');

const SECRET = 'test-secret-0123456789-abcdefghij';
const TEMPLATE = fs.readFileSync(path.join(__dirname, 'fixtures', 'mbank-in.txt'), 'utf8');
const ACCT = '8000222222';
const GOOD = { dmarc: 'pass', from: 'm-bank.mn', spf: 'pass', spfDom: 'm-bank.mn', dkim: '', dkimDom: '' };

let srv, httpd, base, tmp, owner, seq = 0;
async function boot(opts) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'baiyn-bank-'));
  const s = createApp(Object.assign({ dataDir: dir, baseUrl: '' }, opts));
  const h = await new Promise(r => { const x = s.app.listen(0, '127.0.0.1', () => r(x)); });
  return { s, h, dir, url: 'http://127.0.0.1:' + h.address().port };
}
function client(url) {
  const jar = {};
  const f = async (method, u, body, headers) => {
    const hd = Object.assign({ 'X-Requested-With': 'baiyn' }, headers || {});
    let payload; if (body !== undefined) { payload = JSON.stringify(body); hd['Content-Type'] = 'application/json'; }
    const ck = Object.entries(jar).map(([k, v]) => k + '=' + v).join('; '); if (ck) hd.Cookie = ck;
    const r = await fetch((url || base) + u, { method, headers: hd, body: payload });
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }
    const ct = r.headers.get('content-type') || '';
    return { status: r.status, body: ct.includes('json') ? await r.json() : await r.text() };
  };
  return { get: u => f('GET', u), post: (u, b) => f('POST', u, b), put: (u, b) => f('PUT', u, b), del: u => f('DELETE', u) };
}
/* Apps Script-ийн ажлыг дуурайна: нууц түлхүүртэй, CSRF-ийн толгойгүй */
async function notify(items, secret, url) {
  const headers = { 'Content-Type': 'application/json' };
  if (secret !== null) headers.Authorization = 'Bearer ' + (secret === undefined ? SECRET : secret);
  const r = await fetch((url || base) + '/api/bank/notify', { method: 'POST', headers, body: JSON.stringify({ items }) });
  return { status: r.status, body: await r.json() };
}
function mail(o) {
  o = Object.assign({ note: '', amount: '5,000.00', to: ACCT, from: 'smartinfo3@m-bank.mn', auth: GOOD, kind: 'in', subject: 'М банк - Гүйлгээний мэдэгдэл' }, o);
  let body = TEMPLATE.replace('{NOTE}', o.note).replace('{AMOUNT}', o.amount).replace('{TO}', o.to);
  if (o.kind === 'out') body = body.replace('орлого нэмэгдлээ', 'зарлага хийгдлээ');
  return { id: o.id || ('m' + String(++seq).padStart(6, '0') + 'abcdef'), date: new Date().toISOString(), from: o.from, subject: o.subject, body, auth: o.auth };
}
async function customer(name) {
  const c = client(), ident = name + '@example.mn';
  await c.post('/api/register', { name, ident, password: 'long-enough-1' });
  const uid = (await c.get('/api/me')).body.uid;
  const card = (await c.post('/api/cards', { card: { occ: 'halloween', fx: 'pumpkin', theme: 'pumpkin', to: 'Азаа', msg: 'Мэнд ' + name } })).body;
  return { c, uid, id: card.id, code: 'MN-' + card.id.slice(0, 6).toUpperCase() };
}
const opensFor = async (cu, guest) => (await guest.get(`/api/card/${cu.uid}/${cu.id}`)).body.card.msg !== undefined;
const row = async id => (await owner.get('/api/admin/bank')).body.list.find(r => r.id === id);

test.before(async () => {
  ({ s: srv, h: httpd, dir: tmp, url: base } = await boot({ bankSecret: SECRET }));
  await ensureAdmin(srv.ctx, 'owner@example.mn', 'owner-pass-123', 'Эзэн');
  owner = client();
  await owner.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' });
  const r = await owner.put('/api/admin/main', { patch: { payRequired: true, autoPay: true, price: 5000, bank: 'М банк', account: ACCT, holder: 'Бат' } });
  assert.equal(r.status, 200);
});
test.after(() => { httpd.close(); srv.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

/* ---------- цэвэр функцүүд ---------- */
test('задлагч: жинхэнэ М банкны загвар, markdown, HTML, зарлага', () => {
  const p = B.parseMBank(TEMPLATE.replace('{NOTE}', 'mn abc234 төлбөр').replace('{AMOUNT}', '50,000.00').replace('{TO}', ACCT));
  assert.deepEqual(p, { ok: true, kind: 'in', amount: 50000, note: 'mn abc234 төлбөр', toAcct: ACCT, fromAcct: '8000111111', payer: 'ТЕСТ ХЭРЭГЛЭГЧ', bank: 'М Банк' });
  const html = B.parseMBank('<p>Таны дансанд орлого нэмэгдлээ.</p><ul><li>Гүйлгээний дүн:&nbsp;5,000.00MNT</li><li>Гүйлгээний утга:&nbsp;MN-abc234</li></ul><p>Энэ имэйл нь таны тохиргооны дагуу</p>');
  assert.equal(html.amount, 5000); assert.equal(html.note, 'MN-abc234');
  assert.equal(B.parseMBank('Таны дансанд зарлага хийгдлээ. Гүйлгээний дүн: 8400.00MNT Гүйлгээний утга: CU-72').kind, 'out');
  assert.equal(B.parseMBank('Сайн байна уу, энэ өөр имэйл').ok, false);
  assert.equal(B.parseMBank('Таны дансанд орлого нэмэгдлээ. Гүйлгээний утга: x').why, 'no_amount');
  assert.equal(B.parseMBank('Таны дансанд орлого нэмэгдлээ. Гүйлгээний дүн: 4,999.60MNT').amount, 4999);   // бутархайг дээш бөөрөнхийлөхгүй
});

test('задлагч: утганд хуурамч «дүн», «данс» бичсэн ч жинхэнэ утгыг дардаггүй', () => {
  const note = 'Гүйлгээний дүн: 999999.00MNT Хүлээн авсан данс: 8000999999 Хэнээс: ХУУРМАГ MN-xyz789';
  const p = B.parseMBank(TEMPLATE.replace('{NOTE}', note).replace('{AMOUNT}', '100.00').replace('{TO}', ACCT));
  assert.equal(p.amount, 100); assert.equal(p.toAcct, ACCT); assert.equal(p.payer, 'ТЕСТ ХЭРЭГЛЭГЧ');
});

test('кодыг ямар ч бичлэгээр таньна, MNT-г код гэж андуурахгүй', () => {
  assert.deepEqual(B.extractCodes('MN-ABC234'), ['abc234']);
  assert.deepEqual(B.extractCodes('мэнд mn abc234, MNxyz789 төлбөр'), ['abc234', 'xyz789']);
  assert.deepEqual(B.extractCodes('5000 MNT төлбөр. TMN-abcdef'), []);
  assert.deepEqual(B.extractCodes('MN_abc234 MN.abc234'), ['abc234']);
  assert.deepEqual(B.extractCodes(''), []);
});

test('баталгаажуулалт: dmarc заавал, spf эсвэл dkim банкны домэйнтэй таарах ёстой', () => {
  const v = (from, auth) => B.verifyMail(B.MBANK, from, auth).ok;
  assert.equal(v('smartinfo <smartinfo3@m-bank.mn>', GOOD), true);
  assert.equal(v('smartinfo14@m-bank.mn', Object.assign({}, GOOD, { spf: '', dkim: 'pass', dkimDom: '@m-bank.mn' })), true);
  assert.equal(v('smartinfo3@m-bank.mn', Object.assign({}, GOOD, { dmarc: 'fail' })), false);
  assert.equal(v('smartinfo3@m-bank.mn', Object.assign({}, GOOD, { dmarc: '' })), false);
  assert.equal(v('smartinfo3@m-bank.mn', Object.assign({}, GOOD, { from: 'evil.example' })), false);
  assert.equal(v('smartinfo3@m-bank.mn', Object.assign({}, GOOD, { spf: 'softfail' })), false);
  assert.equal(v('smartinfo3@m-bank.mn', Object.assign({}, GOOD, { spfDom: 'smartinfo3@evil-m-bank.mn' })), false);
  assert.equal(v('smartinfo3@m-bank.mn.evil.example', GOOD), false);
  assert.equal(v('evil@m-bank.mn', GOOD), false);                      // зөвхөн smartinfo*
  assert.equal(v('smartinfo3@m-bank.mn', null), false);
});

/* ---------- webhook ---------- */
test('webhook: нууц түлхүүргүй, буруу түлхүүртэй хүсэлтийг хүлээж авахгүй; CSRF-ийн толгой шаардахгүй', async () => {
  assert.equal((await notify([], null)).status, 401);
  assert.equal((await notify([], 'wrong-secret-wrong-secret-wrong')).status, 401);
  assert.equal((await notify([], SECRET.slice(0, -1))).status, 401);
  const ok = await notify([]);
  assert.equal(ok.status, 200); assert.deepEqual(ok.body, { ok: true, results: {} });
  const st = (await owner.get('/api/admin/bank')).body.status;
  assert.ok(st.lastRun > 0 && st.enabled && st.autoPay && !st.stale);
});

test('нууц түлхүүр тохируулаагүй сервер: webhook 503, автомат батлахыг асаахгүй', async () => {
  const b = await boot({ bankSecret: '' });
  try {
    await ensureAdmin(b.s.ctx, 'o@example.mn', 'owner-pass-123', 'Эзэн');
    const o = client(b.url); await o.post('/api/login', { ident: 'o@example.mn', password: 'owner-pass-123' });
    assert.equal((await notify([], undefined, b.url)).status, 503);
    const r = await o.put('/api/admin/main', { patch: { payRequired: true, autoPay: true, price: 5000, bank: 'М', account: '1', holder: 'Б' } });
    assert.equal(r.status, 400); assert.match(r.body.message, /BANK_WEBHOOK_SECRET/);
    assert.equal((await o.get('/api/admin/bank')).body.status.enabled, false);
  } finally { b.h.close(); b.s.close(); fs.rmSync(b.dir, { recursive: true, force: true }); }
});

test('нууц түлхүүр хэрэглэгчид харагдахгүй; autoPay нь нийтийн тохиргоонд байна', async () => {
  const cfg = (await client().get('/api/config')).body;
  assert.equal(cfg.main.autoPay, true);
  assert.ok(!JSON.stringify(cfg).includes(SECRET));
});

/* ---------- тааруулалт ---------- */
test('код + хангалттай дүн: карт автоматаар батлагдаж, холбоос нээгдэнэ', async () => {
  const cu = await customer('Тест1'), guest = client();
  assert.equal(await opensFor(cu, guest), false);
  const m = mail({ note: cu.code });
  const r = await notify([m]);
  assert.equal(r.status, 200); assert.deepEqual(r.body.results[m.id], { st: 'matched', why: '' });
  assert.equal(await opensFor(cu, guest), true);
  const mine = (await cu.c.get('/api/mine')).body.find(x => x.id === cu.id);
  assert.equal(mine.ap.st, 'ok'); assert.equal(mine.ap.amt, 5000); assert.equal(mine.ap.auto, true);
  const o = (await owner.get('/api/admin/orders')).body.list.find(x => x.id === cu.id);
  assert.equal(o.ap.auto, true);
  const bk = await row(m.id);
  assert.equal(bk.st, 'matched'); assert.equal(bk.auto, true); assert.equal(bk.card, cu.id); assert.equal(bk.card_info.ref, cu.code); assert.equal(bk.acct, '1111');
});

test('нэг имэйл хоёр удаа ирвэл дахин боловсрогдохгүй', async () => {
  const cu = await customer('Тест2'), m = mail({ note: cu.code });
  assert.equal((await notify([m])).body.results[m.id].st, 'matched');
  const at1 = (await owner.get('/api/admin/orders')).body.list.find(x => x.id === cu.id).ap.at;
  await new Promise(r => setTimeout(r, 15));
  assert.equal((await notify([m])).body.results[m.id].st, 'matched');
  assert.equal((await owner.get('/api/admin/orders')).body.list.find(x => x.id === cu.id).ap.at, at1);
  const dup = mail({ note: cu.code });                                  // өөр имэйл, ижил карт: давхар төлбөр
  assert.deepEqual((await notify([dup])).body.results[dup.id], { st: 'open', why: 'already_paid' });
});

test('кодын бичлэг: жижиг үсэг, зай, тэмдэг, Монгол үгтэй хамт', async () => {
  const items = [];
  for (const f of [c => c.toLowerCase(), c => c.replace('-', ' '), c => c.replace('-', ''), c => 'Мэндчилгээний төлбөр ' + c + ' баярлалаа']) {
    const cu = await customer('Код' + (++seq)), m = mail({ note: f(cu.code) });
    items.push([cu, m]);
  }
  const r = await notify(items.map(x => x[1]));
  for (const [cu, m] of items) { assert.equal(r.body.results[m.id].st, 'matched', m.body.slice(-300)); assert.equal(await opensFor(cu, client()), true); }
});

test('нэг дор олон имэйл: тус бүрийн үр дүн', async () => {
  const a = await customer('Багц1'), b = await customer('Багц2');
  const ma = mail({ note: a.code }), mb = mail({ note: b.code, amount: '1,000.00' }), mc = mail({ note: 'код байхгүй' });
  const r = (await notify([ma, mb, mc])).body.results;
  assert.equal(r[ma.id].st, 'matched'); assert.deepEqual(r[mb.id], { st: 'open', why: 'amount_low' }); assert.deepEqual(r[mc.id], { st: 'open', why: 'no_code' });
});

test('дүн үнээс бага: батлахгүй; хэсэгчлэн төлсөн нийлбэр хүрвэл батална', async () => {
  const cu = await customer('Хэсэг'), guest = client();
  const m1 = mail({ note: cu.code, amount: '3,000.00' });
  assert.deepEqual((await notify([m1])).body.results[m1.id], { st: 'open', why: 'amount_low' });
  assert.equal(await opensFor(cu, guest), false);
  const m2 = mail({ note: cu.code, amount: '2,000.00' });
  assert.deepEqual((await notify([m2])).body.results[m2.id], { st: 'matched', why: '' });
  assert.equal(await opensFor(cu, guest), true);
  assert.equal((await row(m1.id)).st, 'matched');                       // өмнөх хэсэг ч хаагдана
  assert.equal((await cu.c.get('/api/mine')).body.find(x => x.id === cu.id).ap.amt, 5000);
});

test('илүү төлсөн бол бодит дүн нь орлогод бүртгэгдэнэ', async () => {
  const cu = await customer('Илүү'), m = mail({ note: cu.code, amount: '20,000.00' });
  assert.equal((await notify([m])).body.results[m.id].st, 'matched');
  assert.equal((await cu.c.get('/api/mine')).body.find(x => x.id === cu.id).ap.amt, 20000);
});

test('утганд хуурамч дүн бичсэн ч жинхэнэ дүнгээр шалгана', async () => {
  const cu = await customer('Залилан'), m = mail({ note: 'Гүйлгээний дүн: 999999.00MNT ' + cu.code, amount: '100.00' });
  assert.deepEqual((await notify([m])).body.results[m.id], { st: 'open', why: 'amount_low' });
  assert.equal(await opensFor(cu, client()), false);
});

test('код байхгүй, мэдэгдэхгүй код: админы жагсаалтад үлдэнэ; гараар холбоход картыг батална', async () => {
  const cu = await customer('Гараар'), guest = client();
  await cu.c.post(`/api/cards/${cu.id}/claim`);
  const noCode = mail({ note: 'ТӨЛБӨР' }), unknown = mail({ note: 'MN-zzzzzz' });
  const r = (await notify([noCode, unknown])).body.results;
  assert.deepEqual(r[noCode.id], { st: 'open', why: 'no_code' }); assert.deepEqual(r[unknown.id], { st: 'open', why: 'unknown_code' });
  const b = (await owner.get('/api/admin/bank')).body;
  assert.ok(b.status.open >= 2);
  const p = b.pending.find(x => x.id === cu.id);
  assert.ok(p && p.claimed && p.ref === cu.code);
  assert.equal(await opensFor(cu, guest), false);

  assert.equal((await cu.c.post(`/api/admin/bank/${noCode.id}/assign`, { card: cu.id })).status, 403);
  assert.equal((await owner.post(`/api/admin/bank/${noCode.id}/assign`, { card: 'nonexistent' })).status, 404);
  assert.equal((await owner.post(`/api/admin/bank/${noCode.id}/assign`, { card: cu.id })).status, 200);
  assert.equal(await opensFor(cu, guest), true);
  const bk = await row(noCode.id); assert.equal(bk.st, 'matched'); assert.equal(bk.auto, false);
  const ap = (await owner.get('/api/admin/orders')).body.list.find(x => x.id === cu.id).ap;
  assert.equal(ap.st, 'ok'); assert.equal(ap.auto, false);
  assert.equal((await owner.post(`/api/admin/bank/${noCode.id}/assign`, { card: cu.id })).status, 409);       // аль хэдийн холбосон
  const other = await customer('Дахин');
  assert.equal((await owner.post(`/api/admin/bank/${unknown.id}/assign`, { card: cu.id })).status, 409);       // карт нь аль хэдийн баталгаажсан

  assert.equal((await owner.post(`/api/admin/bank/${unknown.id}/ignore`)).status, 200);
  assert.equal((await row(unknown.id)).st, 'ignored');
  assert.equal((await owner.post(`/api/admin/bank/${unknown.id}/assign`, { card: other.id })).status, 200);   // орхисон ч дараа нь холбож болно
  assert.equal(await opensFor(other, guest), true);
  assert.equal((await owner.post(`/api/admin/bank/${noCode.id}/ignore`)).status, 409);                         // баталгаажсаныг орхихгүй
  assert.equal((await client().get('/api/admin/bank')).status, 401);
  assert.equal((await cu.c.get('/api/admin/bank')).status, 403);
});

test('өөр дансанд орсон мөнгийг тооцохгүй', async () => {
  const cu = await customer('ӨөрДанс'), m = mail({ note: cu.code, to: '8000999000' });
  assert.deepEqual((await notify([m])).body.results[m.id], { st: 'ignored', why: 'other_account' });
  assert.equal(await opensFor(cu, client()), false);
});

test('зарлага, банкных биш илгээгч: хадгалагдахгүй', async () => {
  const cu = await customer('Зарлага');
  const out = mail({ note: cu.code, kind: 'out' }), stranger = mail({ note: cu.code, from: 'someone@gmail.com' });
  const r = (await notify([out, stranger])).body.results;
  assert.deepEqual(r[out.id], { st: 'ignored', why: 'out' }); assert.equal(r[stranger.id].why, 'sender');
  assert.equal(await row(out.id), undefined); assert.equal(await row(stranger.id), undefined);
  assert.equal(await opensFor(cu, client()), false);
});

test('хуурамч имэйл: dmarc/spf шалгалтад унавал код, дүн зөв байсан ч батлахгүй', async () => {
  const bads = [
    { dmarc: 'fail' }, { dmarc: '' }, { from: 'evil.example' }, { spf: 'fail' }, { spf: 'softfail', dkim: '' },
    { spfDom: 'evil.example' }, { spf: '', dkim: '' }
  ];
  for (const b of bads) {
    const cu = await customer('Хуурамч' + (++seq)), m = mail({ note: cu.code, auth: Object.assign({}, GOOD, b) });
    const r = (await notify([m])).body.results[m.id];
    assert.deepEqual(r, { st: 'rejected', why: 'auth' }, JSON.stringify(b));
    assert.equal(await opensFor(cu, client()), false, JSON.stringify(b));
    assert.equal((await row(m.id)).st, 'rejected');
  }
  const cu = await customer('ХуурамчБиш'), m = mail({ note: cu.code });
  m.auth = undefined;
  assert.equal((await notify([m])).body.results[m.id].st, 'rejected');
  assert.equal(await opensFor(cu, client()), false);
});

test('автомат унтраалттай: бүртгэнэ, батлахгүй; админ нэг товчоор батална', async () => {
  const cu = await customer('Унтраалт');
  assert.equal((await owner.put('/api/admin/main', { patch: { autoPay: false } })).status, 200);
  try {
    const m = mail({ note: cu.code });
    assert.deepEqual((await notify([m])).body.results[m.id], { st: 'open', why: 'auto_off' });
    assert.equal(await opensFor(cu, client()), false);
    assert.equal((await owner.get('/api/admin/bank')).body.status.stale, false);
    assert.equal((await owner.post(`/api/admin/bank/${m.id}/assign`, { card: cu.id })).status, 200);
    assert.equal(await opensFor(cu, client()), true);
  } finally { await owner.put('/api/admin/main', { patch: { autoPay: true } }); }
});

test('татгалзсан карт, үнэгүй горим: автоматаар батлахгүй', async () => {
  const cu = await customer('Татгалз');
  await owner.post('/api/admin/approve', { uid: cu.uid, id: cu.id, st: 'no', note: 'шалгана' });
  const m = mail({ note: cu.code });
  assert.deepEqual((await notify([m])).body.results[m.id], { st: 'open', why: 'was_rejected' });
  assert.equal(await opensFor(cu, client()), false);
  await owner.put('/api/admin/main', { patch: { payRequired: false } });
  try {
    const cu2 = await customer('Үнэгүй'), m2 = mail({ note: cu2.code });
    assert.deepEqual((await notify([m2])).body.results[m2.id], { st: 'open', why: 'already_paid' });     // үнэгүй горимд үүссэн карт
  } finally { await owner.put('/api/admin/main', { patch: { payRequired: true } }); }
});

test('Gmail удаан дохио өгөхгүй бол анхааруулна', async () => {
  srv.ctx.kv.set('bank_run', { at: Date.now() - 20 * 60000 });
  assert.equal((await owner.get('/api/admin/bank')).body.status.stale, true);
  await notify([]);
  assert.equal((await owner.get('/api/admin/bank')).body.status.stale, false);
});

test('буруу хүсэлт: сервер унахгүй', async () => {
  assert.equal((await notify('энэ жагсаалт биш')).status, 200);
  const r = await notify([{ id: 'x' }, { id: 'a'.repeat(100) }, null, 5, { id: 'okid0001', from: 'smartinfo3@m-bank.mn', subject: 'М банк - Гүйлгээний мэдэгдэл', body: 'өөр юм', auth: GOOD }]);
  assert.equal(r.status, 200); assert.deepEqual(Object.keys(r.body.results), ['okid0001']);
  assert.equal(r.body.results.okid0001.st, 'ignored');
  const raw = await fetch(base + '/api/bank/notify', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + SECRET }, body: '{bad json' });
  assert.equal(raw.status, 400);
  assert.equal((await fetch(base + '/api/bank/notify')).status, 404);                                  // GET байхгүй
});
