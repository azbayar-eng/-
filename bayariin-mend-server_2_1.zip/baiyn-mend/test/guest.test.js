'use strict';
/* Нэвтрэлтгүй (зочин) горимын шалгалт: бүртгүүлэхгүйгээр карт хийж, төлж, холбоос авна. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
process.env.BAIYN_NO_LIMITS = '1';
const { createApp } = require('../server');
const { ensureAdmin } = require('../lib/users');

let srv, httpd, base, tmp;
test.before(async () => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'baiyn-guest-'));
  srv = createApp({ dataDir: tmp, baseUrl: '' });
  await new Promise(r => { httpd = srv.app.listen(0, '127.0.0.1', r); });
  base = 'http://127.0.0.1:' + httpd.address().port;
  await ensureAdmin(srv.ctx, 'owner@example.mn', 'owner-pass-123', 'Эзэн');
});
test.after(() => { httpd.close(); srv.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

function client() {
  const jar = {};
  const f = async (method, url, body, headers) => {
    const hd = Object.assign({ 'X-Requested-With': 'baiyn' }, headers || {});
    let payload; if (body !== undefined) { payload = JSON.stringify(body); hd['Content-Type'] = 'application/json'; }
    const ck = Object.entries(jar).map(([k, v]) => k + '=' + v).join('; '); if (ck) hd.Cookie = ck;
    const r = await fetch(base + url, { method, headers: hd, body: payload });
    const cookies = r.headers.getSetCookie();
    for (const c of cookies) { const [kv] = c.split(';'); const i = kv.indexOf('='); if (/Max-Age=0/.test(c)) delete jar[kv.slice(0, i)]; else jar[kv.slice(0, i)] = kv.slice(i + 1); }
    const ct = r.headers.get('content-type') || '';
    return { status: r.status, cookies, body: ct.includes('json') ? await r.json() : await r.text() };
  };
  return { jar, get: u => f('GET', u), post: (u, b, h) => f('POST', u, b, h), put: (u, b) => f('PUT', u, b), del: u => f('DELETE', u) };
}
const CARD = { occ: 'halloween', fx: 'pumpkin', theme: 'pumpkin', to: 'Азаа', from: 'Болд', title: 'Хэллоуины мэнд!', msg: 'Сайхан баяраа тэмдэглээрэй' };
const asOwner = async () => { const o = client(); await o.post('/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' }); return o; };

test('зочин: бүртгэлгүй, нэг товшилтоор; хоёр дахь удаа шинэ бүртгэл үүсгэхгүй', async () => {
  const g = client();
  assert.equal((await g.get('/api/me')).body.uid, null);
  const r = await g.post('/api/guest');
  assert.equal(r.status, 200);
  assert.equal(r.body.guest, true); assert.equal(r.body.isAdmin, false); assert.equal(r.body.name, 'Зочин');
  assert.equal(r.body.ident, undefined, 'дотоод нэр харагдахгүй');
  const ck = r.cookies.join(';');
  assert.match(ck, /sid=/); assert.match(ck, /HttpOnly/); assert.match(ck, /SameSite=Lax/);
  assert.match(ck, /Max-Age=31536000/, 'нэг жил');
  const me = (await g.get('/api/me')).body;
  assert.equal(me.uid, r.body.uid); assert.equal(me.guest, true);
  assert.equal((await g.post('/api/guest')).body.uid, r.body.uid, 'давхар үүсгэхгүй');
  const n = srv.ctx.db.prepare("SELECT COUNT(*) n FROM users WHERE ident LIKE 'guest:%'").get().n;
  assert.ok(n >= 1);
});

test('зочин: нэвтрэх, нууц үг солих, админ хийх боломжгүй; CSRF хамгаалалттай', async () => {
  const g = client(); const { uid } = (await g.post('/api/guest')).body;
  assert.equal((await client().post('/api/login', { ident: 'guest:' + uid, password: '!' })).status, 401);
  assert.equal((await client().post('/api/login', { ident: uid, password: '!' })).status, 401);
  assert.equal((await g.post('/api/password', { old: '!', next: 'brand-new-pass-1' })).status, 403);
  assert.equal((await g.get('/api/admin/orders')).status, 403);
  assert.equal((await g.put('/api/admin/main', { patch: { price: 1 } })).status, 403);
  const raw = await fetch(base + '/api/guest', { method: 'POST' });
  assert.equal(raw.status, 403);                                  // X-Requested-With байхгүй
  const cross = await fetch(base + '/api/guest', { method: 'POST', headers: { 'X-Requested-With': 'baiyn', Origin: 'https://evil.example' } });
  assert.equal(cross.status, 403);
});

test('зочин төлбөртэй карт хийж, төлж, холбоос авна; төлөхөөс өмнө хүлээн авагч юу ч харахгүй', async () => {
  const owner = await asOwner();
  assert.equal((await owner.put('/api/admin/main', { patch: { payRequired: true, price: 5000, bank: 'Хаан банк', account: '5000123456', holder: 'Бат', note: 'Утга дээр код бичнэ' } })).status, 200);
  const anon = client(), g = client(), recipient = client();
  assert.equal((await anon.get('/api/config')).body.main.account, undefined, 'нэвтрээгүй хүн дансыг харахгүй');
  await g.post('/api/guest');
  assert.equal((await g.get('/api/config')).body.main.account, '5000123456', 'зочин төлөхийн тулд дансыг харна');
  const saved = (await g.post('/api/cards', { card: CARD })).body, uid = (await g.get('/api/me')).body.uid;
  assert.equal(saved.free, false);
  const locked = (await recipient.get(`/api/card/${uid}/${saved.id}`)).body;
  assert.equal(locked.card.msg, undefined); assert.equal(locked.card.to, undefined);
  assert.equal((await g.get(`/api/card/${uid}/${saved.id}`)).body.card.msg, CARD.msg, 'эзэн өөрөө харна');
  assert.equal((await g.post(`/api/cards/${saved.id}/claim`)).status, 200);
  assert.equal((await owner.post('/api/admin/approve', { uid, id: saved.id, st: 'ok', amt: 5000 })).status, 200);
  assert.equal((await recipient.get(`/api/card/${uid}/${saved.id}`)).body.card.msg, CARD.msg, 'төлсний дараа холбоос нээгдэнэ');
  const mine = (await g.get('/api/mine')).body;
  assert.equal(mine.length, 1); assert.equal(mine[0].ap.st, 'ok'); assert.equal(mine[0].ap.amt, 5000);
  const other = client(); await other.post('/api/guest');
  assert.equal((await other.post(`/api/cards/${saved.id}/claim`)).status, 404, 'өөр зочин бусдын картанд хүрч чадахгүй');
  assert.equal((await other.del(`/api/cards/${saved.id}`)).status, 404);
  assert.equal((await other.post('/api/cards', { id: saved.id, card: CARD })).status, 404);
  assert.equal((await other.get('/api/mine')).body.length, 0);
});

test('зочин: админ захиалгын жагсаалтад «Зочин #xxxx» гэж харагдана, дотоод нэр биш', async () => {
  const owner = await asOwner(), g = client();
  const { uid } = (await g.post('/api/guest')).body; await g.post('/api/cards', { card: CARD });
  const names = (await owner.post('/api/admin/names', { ids: [uid] })).body;
  assert.equal(names[uid], 'Зочин #' + uid.slice(2, 6)); assert.ok(!/guest:/.test(names[uid]));
  const ord = (await owner.get('/api/admin/orders')).body;
  assert.ok(ord.users.some(u => u.id === uid));
});

test('зочин: хадгалах картын дээд хязгаар 20', async () => {
  const g = client(); await g.post('/api/guest');
  for (let i = 0; i < 20; i++) assert.equal((await g.post('/api/cards', { card: CARD })).status, 200);
  const over = await g.post('/api/cards', { card: CARD });
  assert.equal(over.status, 400); assert.match(over.body.message, /20/);
});

test('зочин үүсгэхийг нэг хаягаас цаг тутамд хязгаарлана', async () => {
  const keep = process.env.BAIYN_NO_LIMITS; delete process.env.BAIYN_NO_LIMITS;
  try {
    const codes = []; for (let i = 0; i < 33; i++) codes.push((await client().post('/api/guest')).status);
    assert.equal(codes.filter(c => c === 200).length, 30); assert.ok(codes.includes(429));
  } finally { process.env.BAIYN_NO_LIMITS = keep; }
});

test('цэвэрлэгээ: төлөөгүй хуучин зочны карт, хоосон зочин устна; төлсөн, бүртгэлтэй, шинэ нь үлдэнэ', async () => {
  const { db } = srv.ctx, now = Date.now(), DAY = 86400000;
  const owner = await asOwner();
  const mk = async () => { const c = client(); const { uid } = (await c.post('/api/guest')).body; return { c, uid }; };
  const unpaid = await mk(), paid = await mk(), idle = await mk(), fresh = await mk();
  const cu = (await unpaid.c.post('/api/cards', { card: CARD })).body.id;
  const cp = (await paid.c.post('/api/cards', { card: CARD })).body.id;
  await owner.post('/api/admin/approve', { uid: paid.uid, id: cp, st: 'ok', amt: 5000 });
  const cf = (await fresh.c.post('/api/cards', { card: CARD })).body.id;
  const old = (uid, days) => db.prepare('UPDATE users SET created = ? WHERE id = ?').run(now - days * DAY, uid);
  db.prepare('UPDATE cards SET created = ? WHERE id IN (?, ?)').run(now - 31 * DAY, cu, cp);
  [unpaid, paid, idle].forEach(x => old(x.uid, 40));
  const reg = client(); await reg.post('/api/register', { name: 'Бүртгэлтэй', ident: 'keep@example.mn', password: 'long-enough-1' });
  const regUid = (await reg.get('/api/me')).body.uid; old(regUid, 400);
  srv.sweep();
  const has = id => !!db.prepare('SELECT 1 FROM cards WHERE id = ?').get(id), hasU = id => !!db.prepare('SELECT 1 FROM users WHERE id = ?').get(id);
  assert.equal(has(cu), false, 'төлөөгүй хуучин карт устсан');
  assert.equal(has(cp), true, 'төлсөн карт үлдсэн'); assert.equal(hasU(paid.uid), true);
  assert.equal(has(cf), true);
  assert.equal(hasU(unpaid.uid), false, 'картгүй болсон хуучин зочин устсан');
  assert.equal(hasU(idle.uid), false);
  assert.equal(hasU(fresh.uid), true); assert.equal(hasU(regUid), true, 'бүртгэлтэй хэрэглэгч хөндөгдөөгүй');
  assert.equal((await paid.c.get('/api/mine')).body.length, 1, 'төлсөн зочин картаа харсаар');
  assert.equal((await unpaid.c.get('/api/me')).body.uid, null, 'устсан зочны cookie хүчингүй');
});
