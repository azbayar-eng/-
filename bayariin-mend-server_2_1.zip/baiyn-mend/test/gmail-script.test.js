'use strict';
/* deploy/gmail/Code.gs-ийн шалгалт. Скрипт Apps Script-д ажилладаг тул Node дээр Gmail, UrlFetchApp зэргийг дуурайлган ачаална.
   Сүүлийн шалгалт нь бодит серверийг тусдаа процесст асааж, скриптийн run()-ыг түүнтэй шууд холбоно. */
const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const cp = require('node:child_process');

const SRC = fs.readFileSync(path.join(__dirname, '..', 'deploy', 'gmail', 'Code.gs'), 'utf8');
const TEMPLATE = fs.readFileSync(path.join(__dirname, 'fixtures', 'mbank-in.txt'), 'utf8');
const SECRET = 'gmail-script-secret-0123456789abc';
const ACCT = '8000222222';

/* ---------- Apps Script орчин ---------- */
function env(opts) {
  opts = opts || {};
  const store = {}, posts = [], searches = [], logs = [];
  const sandbox = {
    GmailApp: { search(q) { searches.push(q); return (opts.threads || []).map(msgs => ({ getMessages: () => msgs })); } },
    UrlFetchApp: { fetch(url, o) { posts.push({ url, o, body: JSON.parse(o.payload) }); return opts.fetch ? opts.fetch(url, o, posts.length) : { getResponseCode: () => 200, getContentText: () => JSON.stringify({ ok: true, results: {} }) }; } },
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => (k in store ? store[k] : null), setProperty: (k, v) => { store[k] = String(v); } }) },
    LockService: { getScriptLock: () => ({ tryLock: () => true, releaseLock() {} }) },
    ScriptApp: { newTrigger() { throw new Error('not used'); }, getProjectTriggers: () => [], deleteTrigger() {} },
    Logger: { log: m => logs.push(String(m)) }
  };
  vm.createContext(sandbox); vm.runInContext(SRC, sandbox);
  sandbox.SERVER_URL = opts.url || 'https://card.example.mn'; sandbox.SECRET = SECRET;
  return { g: sandbox, store, posts, searches, logs };
}

const AUTH_OK = 'Authentication-Results: mx.google.com;\r\n       dkim=pass header.i=@m-bank.mn header.s=sel header.b=abc123;\r\n       spf=pass (google.com: domain of smartinfo3@m-bank.mn designates 203.0.113.5 as permitted sender) smtp.mailfrom=smartinfo3@m-bank.mn;\r\n       dmarc=pass (p=NONE sp=NONE dis=NONE) header.from=m-bank.mn';
const AUTH_FAIL = 'Authentication-Results: mx.google.com;\r\n       dkim=none;\r\n       spf=fail (google.com: domain of smartinfo3@m-bank.mn does not designate 198.51.100.9 as permitted sender) smtp.mailfrom=smartinfo3@m-bank.mn;\r\n       dmarc=fail (p=NONE sp=NONE dis=NONE) header.from=m-bank.mn';
const raw = (auth, extra) => ['Delivered-To: owner@example.com', 'Received: by 2002:a05:6a00:1 with SMTP id x; Mon, 26 Oct 2026 01:02:03 -0700 (PDT)',
  'ARC-Authentication-Results: i=1; mx.google.com; dmarc=pass header.from=m-bank.mn', 'Return-Path: <smartinfo3@m-bank.mn>', auth,
  'From: M Bank <smartinfo3@m-bank.mn>', 'Subject: Gүйлгээний мэдэгдэл'].concat(extra || []).join('\r\n') + '\r\n\r\nбие хэсэг энд';

let seq = 0;
function msg(o) {
  o = Object.assign({ from: 'М Банк <smartinfo3@m-bank.mn>', subject: 'М банк - Гүйлгээний мэдэгдэл', note: '', amount: '5,000.00', kind: 'in', auth: AUTH_OK, date: new Date(), plain: undefined, html: '' }, o);
  let body = TEMPLATE.replace('{NOTE}', o.note).replace('{AMOUNT}', o.amount).replace('{TO}', ACCT);
  if (o.kind === 'out') body = body.replace('орлого нэмэгдлээ', 'зарлага хийгдлээ');
  const id = o.id || ('18f' + String(++seq).padStart(13, '0'));
  return { getId: () => id, getFrom: () => o.from, getSubject: () => o.subject, getDate: () => o.date,
    getRawContent: () => o.raw || raw(o.auth), getPlainBody: () => (o.plain === undefined ? body : o.plain), getBody: () => o.html || '' };
}

/* ---------- толгой задлах ---------- */
test('Authentication-Results: Gmail-ийн толгой задрах', () => {
  const { g } = env();
  const a = g.parseAuthResults(g.pickAuthResults(raw(AUTH_OK)));
  assert.deepEqual(JSON.parse(JSON.stringify(a)), { dmarc: 'pass', from: 'm-bank.mn', spf: 'pass', spfDom: 'smartinfo3@m-bank.mn', dkim: 'pass', dkimDom: '@m-bank.mn' });
  const f = g.parseAuthResults(g.pickAuthResults(raw(AUTH_FAIL)));
  assert.equal(f.dmarc, 'fail'); assert.equal(f.spf, 'fail'); assert.equal(f.dkim, 'none');
});

test('хуурамч толгой: хамгийн дээрх (Gmail-ийн) мөр ялна, доорхи хуурамч мөр, ARC, нугалсан мөр тооцогдохгүй', () => {
  const { g } = env();
  const forgedBelow = raw(AUTH_FAIL, ['Authentication-Results: mx.google.com; dkim=pass header.i=@m-bank.mn; spf=pass smtp.mailfrom=smartinfo3@m-bank.mn; dmarc=pass header.from=m-bank.mn']);
  assert.equal(g.parseAuthResults(g.pickAuthResults(forgedBelow)).dmarc, 'fail');
  // X-Foo-ийн үргэлжлэл мөр нь тусдаа толгой биш
  const folded = raw(AUTH_FAIL.replace(/^/, ''), ['X-Foo: bar\r\n Authentication-Results: mx.google.com; dmarc=pass header.from=m-bank.mn']);
  assert.equal(g.parseAuthResults(g.pickAuthResults(folded)).dmarc, 'fail');
  // зөвхөн ARC байвал юу ч биш
  const arcOnly = ['ARC-Authentication-Results: i=1; mx.google.com; dmarc=pass header.from=m-bank.mn', 'From: x'].join('\r\n') + '\r\n\r\nbody';
  assert.equal(g.pickAuthResults(arcOnly), '');
  assert.equal(g.parseAuthResults('').dmarc, '');
  // өөр authserv-id (хуурамч «evil.example») тооцогдохгүй
  assert.equal(g.pickAuthResults(['Authentication-Results: evil.example; dmarc=pass header.from=m-bank.mn', 'From: x'].join('\r\n') + '\r\n\r\nb'), '');
  assert.equal(g.pickAuthResults('Authentication-Results: mx.google.com.evil.example; dmarc=pass\r\n\r\nb'), '');
  // бие хэсэгт бичсэн мөр толгойд тооцогдохгүй
  assert.equal(g.pickAuthResults(['From: x', '', 'Authentication-Results: mx.google.com; dmarc=pass header.from=m-bank.mn'].join('\r\n')), '');
});
test('олон DKIM гарын үсэг: pass болсныг авна', () => {
  const { g } = env();
  const a = g.parseAuthResults('mx.google.com; dkim=fail header.d=other.example; dkim=pass header.d=m-bank.mn; spf=pass smtp.mailfrom=m-bank.mn; dmarc=pass header.from=m-bank.mn');
  assert.equal(a.dkim, 'pass'); assert.equal(a.dkimDom, 'm-bank.mn'); assert.equal(a.spfDom, 'm-bank.mn');
});

/* ---------- шүүлт ---------- */
test('зөвхөн банкны ОРЛОГО серверт явна: зарлага, өөр илгээгч, өөр гарчиг, төстэй хаяг явахгүй', () => {
  const { g } = env();
  const ok = g.itemFrom(msg({ note: 'MN-ABC234' }));
  assert.ok(ok); assert.equal(ok.auth.dmarc, 'pass'); assert.match(ok.body, /Гүйлгээний утга: MN-ABC234/); assert.ok(!Number.isNaN(Date.parse(ok.date)));
  assert.equal(g.itemFrom(msg({ kind: 'out' })), null);
  assert.equal(g.itemFrom(msg({ from: 'Bank <smartinfo3@m-bank.mn.evil.example>' })), null);
  assert.equal(g.itemFrom(msg({ from: 'evil@m-bank.mn.example' })), null);
  assert.equal(g.itemFrom(msg({ from: '"smartinfo3@m-bank.mn" <phish@evil.example>' })), null);
  assert.equal(g.itemFrom(msg({ from: 'otheruser@m-bank.mn' })), null);
  assert.equal(g.itemFrom(msg({ subject: 'Хөнгөлөлт!' })), null);
  assert.ok(g.itemFrom(msg({ from: 'smartinfo14@m-bank.mn' })));
});

test('HTML-only имэйл: зургийг хасаад HTML-ийг илгээнэ', () => {
  const { g } = env();
  const html = '<p>Таны дансанд орлого нэмэгдлээ.</p><img src="data:image/png;base64,AAAA"><ul><li>Гүйлгээний дүн: 5,000.00MNT</li><li>Гүйлгээний утга: MN-ABC234</li></ul>';
  const it = g.itemFrom(msg({ plain: '', html }));
  assert.ok(it); assert.ok(!/<img/i.test(it.body)); assert.match(it.body, /MN-ABC234/);
  assert.equal(g.itemFrom(msg({ plain: '', html: '<p>Сайн байна уу</p>' })), null);
});

/* ---------- run() ---------- */
test('run: сервертэй холбогдож, сервер хүлээн авсан имэйлийг дахин илгээхгүй, имэйлгүй үед ч дохио өгнө', () => {
  const m1 = msg({ note: 'MN-ABC234' }), m2 = msg({ note: 'MN-XYZ789' }), out = msg({ kind: 'out' });
  const e = env({
    threads: [[m1, out], [m2]],
    fetch: (url, o) => { const ids = JSON.parse(o.payload).items.map(i => i.id); return { getResponseCode: () => 200, getContentText: () => JSON.stringify({ ok: true, results: Object.fromEntries(ids.map(i => [i, { st: 'matched' }])) }) }; }
  });
  e.g.run();
  assert.equal(e.posts.length, 1);
  const p = e.posts[0];
  assert.equal(p.url, 'https://card.example.mn/api/bank/notify'); assert.equal(p.o.headers.Authorization, 'Bearer ' + SECRET); assert.equal(p.o.followRedirects, false);
  assert.deepEqual(p.body.items.map(i => i.id), [m1.getId(), m2.getId()]);                    // зарлага явсангүй
  assert.match(e.searches[0], /^from:m-bank\.mn subject:"Гүйлгээний мэдэгдэл" after:\d+$/);
  assert.equal(JSON.parse(e.store.done).length, 2);
  const c1 = Number(e.store.cursor); assert.ok(c1 > Date.now() - 3 * 3600000 && c1 <= Date.now() - 3500 * 1000);   // ~1 цагийн нөөцтэй
  e.g.run();                                                                                  // хоёр дахь удаа: шинэ имэйлгүй, гэхдээ дохио явна
  assert.equal(e.posts.length, 2); assert.deepEqual(e.posts[1].body.items, []);
});

test('run: сервер унавал cursor, done өөрчлөгдөхгүй, дараа нь дахин илгээнэ; нэг имэйл алдаатай бол зөвхөн тэр давтагдана', () => {
  let mode = 'down';
  const m1 = msg({ note: 'MN-ABC234' }), m2 = msg({ note: 'MN-XYZ789' });
  const e = env({
    threads: [[m1, m2]],
    fetch: (url, o) => {
      const ids = JSON.parse(o.payload).items.map(i => i.id);
      if (mode === 'down') return { getResponseCode: () => 500, getContentText: () => 'oops' };
      if (mode === 'one') return { getResponseCode: () => 200, getContentText: () => JSON.stringify({ results: { [ids[0]]: { st: 'matched' }, [ids[1]]: { st: 'error', why: 'server' } } }) };
      return { getResponseCode: () => 200, getContentText: () => JSON.stringify({ results: Object.fromEntries(ids.map(i => [i, { st: 'open' }])) }) };
    }
  });
  assert.throws(() => e.g.run(), /Сервер 500/);
  assert.equal(e.store.done, undefined); assert.equal(e.store.cursor, undefined);
  mode = 'one'; e.g.run();
  assert.deepEqual(JSON.parse(e.store.done), [m1.getId()]); assert.equal(e.store.cursor, undefined);      // cursor урагшлаагүй
  mode = 'ok'; e.g.run();
  assert.deepEqual(e.posts[e.posts.length - 1].body.items.map(i => i.id), [m2.getId()]);                  // зөвхөн алдаатай нь дахин явсан
  assert.equal(JSON.parse(e.store.done).length, 2); assert.ok(Number(e.store.cursor) > 0);
});

test('run: SECRET дутуу, буруу хариу, хэт олон имэйл', () => {
  const e = env({ threads: [] }); e.g.SECRET = 'short';
  assert.throws(() => e.g.run(), /SECRET/);
  assert.equal(e.posts.length, 0);
  const many = Array.from({ length: 60 }, (_, i) => msg({ note: 'MN-ABC' + (100 + i), date: new Date(Date.now() - (60 - i) * 1000) }));
  const e2 = env({
    threads: [many],
    fetch: (url, o) => ({ getResponseCode: () => 200, getContentText: () => JSON.stringify({ results: Object.fromEntries(JSON.parse(o.payload).items.map(i => [i.id, { st: 'open' }])) }) })
  });
  e2.g.run();
  assert.equal(e2.posts[0].body.items.length, 50); assert.equal(e2.store.cursor, undefined);                // үлдсэн 10 дараагийн удаа
  e2.g.run();
  assert.equal(e2.posts[1].body.items.length, 10); assert.ok(Number(e2.store.cursor) > 0);
});

/* ---------- бодит сервертэй ---------- */
function syncFetch(url, o) {                 // Apps Script-ийн UrlFetchApp.fetch синхрон тул хүүхэд процессоор дуурайна
  const code = `let s='';process.stdin.on('data',c=>s+=c).on('end',async()=>{const q=JSON.parse(s);const r=await fetch(q.url,{method:'POST',headers:Object.assign({'Content-Type':q.contentType},q.headers),body:q.payload,redirect:'manual'});process.stdout.write(JSON.stringify({status:r.status,text:await r.text()}));});`;
  const out = JSON.parse(cp.execFileSync(process.execPath, ['-e', code], { input: JSON.stringify({ url, contentType: o.contentType, headers: o.headers, payload: o.payload }), encoding: 'utf8' }));
  return { getResponseCode: () => out.status, getContentText: () => out.text };
}
async function http(base, jar, method, u, body) {
  const hd = { 'X-Requested-With': 'baiyn' }; if (body !== undefined) hd['Content-Type'] = 'application/json';
  const ck = Object.entries(jar).map(([k, v]) => k + '=' + v).join('; '); if (ck) hd.Cookie = ck;
  const r = await fetch(base + u, { method, headers: hd, body: body === undefined ? undefined : JSON.stringify(body) });
  for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); }
  const ct = r.headers.get('content-type') || ''; return { status: r.status, body: ct.includes('json') ? await r.json() : await r.text() };
}

test('Code.gs ↔ бодит сервер: жинхэнэ имэйлээр карт нээгдэнэ, хуурамч имэйлээр нээгдэхгүй', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'baiyn-gs-')), port = 20000 + Math.floor(Math.random() * 20000), base = `http://127.0.0.1:${port}`;
  const child = cp.spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    env: Object.assign({}, process.env, { PORT: String(port), HOST: '127.0.0.1', DATA_DIR: dir, BASE_URL: '', BANK_WEBHOOK_SECRET: SECRET, BAIYN_NO_LIMITS: '1', ADMIN_EMAIL: 'owner@example.mn', ADMIN_PASSWORD: 'owner-pass-123' }), stdio: 'ignore'
  });
  try {
    for (let i = 0; ; i++) { try { if ((await fetch(base + '/healthz')).ok) break; } catch (e) { /* not up yet */ } if (i > 100) throw new Error('сервер ассангүй'); await new Promise(r => setTimeout(r, 100)); }
    const adm = {}; assert.equal((await http(base, adm, 'POST', '/api/login', { ident: 'owner@example.mn', password: 'owner-pass-123' })).status, 200);
    assert.equal((await http(base, adm, 'PUT', '/api/admin/main', { patch: { payRequired: true, autoPay: true, price: 5000, bank: 'М банк', account: ACCT, holder: 'Бат' } })).status, 200);
    const mkCard = async n => {
      const jar = {}; await http(base, jar, 'POST', '/api/register', { name: n, ident: n + '@example.mn', password: 'long-enough-1' });
      const uid = (await http(base, jar, 'GET', '/api/me')).body.uid;
      const c = (await http(base, jar, 'POST', '/api/cards', { card: { occ: 'halloween', fx: 'pumpkin', theme: 'pumpkin', to: 'Азаа', msg: 'Мэнд ' + n } })).body;
      return { uid, id: c.id, code: 'MN-' + c.id.slice(0, 6).toUpperCase() };
    };
    const opens = async c => (await http(base, {}, 'GET', `/api/card/${c.uid}/${c.id}`)).body.card.msg !== undefined;
    const real = await mkCard('real'), fake = await mkCard('fake'), plain = await mkCard('plain');
    const e = env({
      url: base, fetch: syncFetch,
      threads: [[msg({ note: real.code }), msg({ note: 'Төлбөр ' + fake.code, auth: AUTH_FAIL }), msg({ kind: 'out', note: plain.code }), msg({ from: 'Bank <smartinfo3@m-bank.mn.evil.example>', note: plain.code })]]
    });
    e.g.run();
    assert.equal(e.posts[0].body.items.length, 2);                                // жинхэнэ ба хуурамч (сервер тань), зарлага ба өөр хаяг скриптэд шүүгдсэн
    assert.equal(await opens(real), true, 'жинхэнэ имэйлээр карт нээгдсэнгүй');
    assert.equal(await opens(fake), false, 'ХУУРАМЧ имэйлээр карт нээгдлээ');
    assert.equal(await opens(plain), false);
    const list = (await http(base, adm, 'GET', '/api/admin/bank')).body;
    assert.ok(list.status.lastRun > 0);
    assert.equal(list.list.find(r => r.card === real.id).st, 'matched');
    assert.ok(list.list.some(r => r.st === 'rejected' && r.why === 'auth'));
    e.g.run(); assert.deepEqual(e.posts[1].body.items, []);                        // дахин илгээгдэхгүй
    e.g.SECRET = 'wrong-secret-0123456789-abcdefgh';
    assert.throws(() => e.g.run(), /Сервер 401/);
  } finally { child.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
});
