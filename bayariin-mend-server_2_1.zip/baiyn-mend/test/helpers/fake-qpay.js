'use strict';
/* A stand-in for QPay's merchant API v2 (auth, invoice, payment/check) so the integration can be tested without a contract.
   It follows developer.qpay.mn: Basic auth on /v2/auth/token, Bearer everywhere else, QPay's field names. */
const http = require('node:http');
const crypto = require('node:crypto');

const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

function fakeQpay(opts) {
  opts = Object.assign({ id: 'MERCHANT_X', secret: 'S3cretPass', code: 'MERCHANT_INVOICE', expiresIn: null }, opts);
  const st = {
    invoices: new Map(), payments: new Map(), access: new Set(), refresh: new Set(),
    count: { token: 0, refresh: 0, invoice: 0, check: 0 }, bodies: [], down: false, evil: false
  };
  const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };

  const server = http.createServer((req, res) => {
    let raw = ''; req.on('data', c => { raw += c; });
    req.on('end', () => {
      if (st.down) { send(res, 500, { error: 'INTERNAL' }); return; }
      let body = {}; try { body = raw ? JSON.parse(raw) : {}; } catch (e) { /* ignore */ }
      const auth = req.headers.authorization || '', url = req.url.split('?')[0];
      const issue = () => {
        const a = 'at_' + crypto.randomBytes(8).toString('hex'), r = 'rt_' + crypto.randomBytes(8).toString('hex');
        st.access.add(a); st.refresh.add(r);
        const exp = opts.expiresIn ? opts.expiresIn : Math.floor(Date.now() / 1000) + 3600;   // QPay's expires_in is a unix time in seconds
        return { token_type: 'bearer', access_token: a, expires_in: exp, refresh_token: r, refresh_expires_in: Math.floor(Date.now() / 1000) + 86400, scope: 'profile', not_before_policy: '0', session_state: 'x' };
      };
      if (url === '/v2/auth/token' && req.method === 'POST') {
        const want = 'Basic ' + Buffer.from(opts.id + ':' + opts.secret).toString('base64');
        if (auth !== want) { send(res, 401, { error: 'AUTHENTICATION_FAILED', message: 'bad credentials' }); return; }
        st.count.token++; send(res, 200, issue()); return;
      }
      if (url === '/v2/auth/refresh' && req.method === 'POST') {
        const t = auth.replace(/^Bearer /, '');
        if (!st.refresh.has(t)) { send(res, 401, { error: 'TOKEN_INVALID' }); return; }
        st.refresh.delete(t); st.count.refresh++; send(res, 200, issue()); return;
      }
      const t = auth.replace(/^Bearer /, '');
      if (!st.access.has(t)) { send(res, 401, { error: 'TOKEN_EXPIRED' }); return; }
      if (url === '/v2/invoice' && req.method === 'POST') {
        st.bodies.push(body);
        if (body.invoice_code !== opts.code) { send(res, 400, { error: 'INVOICE_CODE_INVALID' }); return; }
        if (!(body.amount > 0) || !body.sender_invoice_no || !body.callback_url || !body.invoice_description) { send(res, 400, { error: 'INVALID_PARAMS' }); return; }
        for (const v of st.invoices.values()) if (v.sender_invoice_no === body.sender_invoice_no) { send(res, 400, { error: 'SENDER_INVOICE_NO_DUPLICATED' }); return; }
        st.count.invoice++;
        const id = 'inv' + String(st.invoices.size + 1).padStart(4, '0') + crypto.randomBytes(5).toString('hex');
        st.invoices.set(id, { sender_invoice_no: body.sender_invoice_no, amount: body.amount, callback_url: body.callback_url });
        const urls = [
          { name: 'Khan bank', description: 'Хаан банк', logo: 'https://qpay.mn/q/logo/khanbank.png', link: 'khanbank://q?qPay_QRcode=' + id },
          { name: 'M bank', description: 'М банк', logo: 'https://qpay.mn/q/logo/mbank.png', link: 'https://m.mbank.mn/pay/' + id }
        ];
        if (st.evil) urls.push({ name: '<img src=x onerror=alert(1)>', description: 'x', logo: '', link: 'javascript:alert(1)' }, { name: 'Data', description: '', logo: '', link: 'data:text/html,hi' });
        send(res, 200, { invoice_id: id, qr_text: 'QPAY' + id, qr_image: PNG, qPay_shortUrl: 'https://s.qpay.mn/' + id, urls });
        return;
      }
      if (url === '/v2/payment/check' && req.method === 'POST') {
        st.count.check++;
        if (body.object_type !== 'INVOICE') { send(res, 400, { error: 'INVALID_OBJECT_TYPE' }); return; }
        if (!st.invoices.has(body.object_id)) { send(res, 200, { count: 0, paid_amount: 0, rows: [] }); return; }
        const rows = st.payments.get(body.object_id) || [];
        send(res, 200, { count: rows.length, paid_amount: rows.filter(r => r.payment_status === 'PAID').reduce((s, r) => s + Number(r.payment_amount), 0), rows });
        return;
      }
      send(res, 404, { error: 'NOT_FOUND' });
    });
  });

  return {
    st, opts,
    async listen() { await new Promise(r => server.listen(0, '127.0.0.1', r)); return 'http://127.0.0.1:' + server.address().port; },
    close() { server.closeAllConnections(); server.close(); },
    /* the customer paid in their bank app */
    pay(invoiceId, amount, o) {
      o = Object.assign({ status: 'PAID', currency: 'MNT' }, o);
      const rows = st.payments.get(invoiceId) || []; st.payments.set(invoiceId, rows);
      rows.push({ payment_id: String(100000 + rows.length), payment_status: o.status, payment_amount: String(amount), trx_fee: '0.00', payment_currency: o.currency, payment_wallet: 'QPay', payment_type: 'P2P', card_transactions: [], p2p_transactions: [] });
    },
    lastInvoiceId() { return [...st.invoices.keys()].pop(); },
    expireAccessTokens() { st.access.clear(); }
  };
}

module.exports = { fakeQpay };
