/* Баярын мэнд: card engine. Pure canvas, no network, no framework.
   Shared by the artifact build and the server build.
   Everything is a deterministic function of time t, so previews, thumbnails and saved pictures all use the same code. */
(function (root) {
'use strict';
const TAU = Math.PI * 2;
const clamp = (x, a = 0, b = 1) => x < a ? a : x > b ? b : x;
const mix = (a, b, k) => a + (b - a) * k;
const smooth = x => { x = clamp(x); return x * x * (3 - 2 * x); };
const easeOut = x => 1 - Math.pow(1 - clamp(x), 3);
const easeIn = x => { x = clamp(x); return x * x * x; };
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; };
const hexMix = (h1, h2, k) => { const a = parseInt(h1.slice(1), 16), b = parseInt(h2.slice(1), 16); const c = s => Math.round(mix(a >> s & 255, b >> s & 255, k)); return '#' + ((1 << 24) | (c(16) << 16) | (c(8) << 8) | c(0)).toString(16).slice(1); };
const lum = hex => { const n = parseInt(hex.slice(1), 16); return (0.2126 * (n >> 16 & 255) + 0.7152 * (n >> 8 & 255) + 0.0722 * (n & 255)) / 255; };

/* ---------- Data. Order of THEME_IDS / FX_IDS / OCC_IDS is part of old share links: only append. ---------- */
const THEME_IDS = ['blush', 'gold', 'sky', 'night', 'green', 'sun'];
const THEMES = {
  blush: { name: 'Ягаан', bg: ['#FFE3EC', '#FF9EBB'], glow: '#FFFFFF', ink: '#4A1230', soft: '#6E2A49', a: '#E8336D', b: '#FFFFFF', c: '#F2A93B', light: true, pal: ['#E8336D', '#FFFFFF', '#F2A93B', '#B5179E', '#FF6F9C', '#7C3AED'] },
  gold: { name: 'Улаан алт', bg: ['#8E1030', '#D8284B'], glow: '#FF9A6B', ink: '#FFE9B8', soft: '#FFD58A', a: '#FFC857', b: '#FFF1CF', c: '#FF6B6B', light: false, pal: ['#FFC857', '#FFF1CF', '#FF6B6B', '#FFFFFF', '#FF9A3C', '#FFD9A0'] },
  sky: { name: 'Хөх тэнгэр', bg: ['#0B3C8C', '#47B0FF'], glow: '#BFE6FF', ink: '#FFFFFF', soft: '#DCF0FF', a: '#FFD35C', b: '#FFFFFF', c: '#FF8FB1', light: false, pal: ['#FFFFFF', '#FFD35C', '#8FD3FF', '#FFB3C7', '#C8F0FF', '#5DE0B0'] },
  night: { name: 'Шөнө', bg: ['#160C3A', '#5B2A9E'], glow: '#B07CFF', ink: '#FFF3D6', soft: '#E6D4FF', a: '#FFC857', b: '#FF6FB5', c: '#7FD6FF', light: false, pal: ['#FFC857', '#FF6FB5', '#7FD6FF', '#FFFFFF', '#B07CFF', '#7DFFB8'] },
  green: { name: 'Ногоон', bg: ['#12301F', '#4F7F3A'], glow: '#C2E59A', ink: '#FFF2C9', soft: '#E1EDC8', a: '#F2C14E', b: '#FFF2C9', c: '#E0603A', light: false, pal: ['#F2C14E', '#FFF2C9', '#9BD16B', '#FFFFFF', '#E0603A', '#CFE8A8'] },
  sun: { name: 'Наран', bg: ['#FFD54A', '#FF7A3D'], glow: '#FFF3B0', ink: '#3B1708', soft: '#5E250C', a: '#D6246E', b: '#FFFFFF', c: '#3FA9F5', light: true, pal: ['#D6246E', '#FFFFFF', '#3FA9F5', '#7ED957', '#8E44AD', '#FFF3B0'] }
};
/* A custom theme is stored as seven colours; the rest is derived. */
function buildTheme(d) {
  const light = lum(d.bg0) * 0.5 + lum(d.bg1) * 0.5 > 0.6;
  return {
    name: d.name || 'Өнгө', bg: [d.bg0, d.bg1], glow: d.glow, ink: d.ink, soft: hexMix(d.ink, d.bg0, light ? 0.18 : 0.12),
    a: d.a, b: d.b, c: d.c, light,
    pal: [d.a, d.b, d.c, hexMix(d.a, d.b, 0.5), hexMix(d.b, d.c, 0.5), hexMix(d.c, d.a, 0.5)]
  };
}
function registerTheme(id, def) { THEMES[id] = def; }
function unregisterThemes(keepIds) { Object.keys(THEMES).forEach(k => { if (!THEME_IDS.includes(k) && !keepIds.includes(k)) delete THEMES[k]; }); }

const FX_IDS = ['fireworks', 'confetti', 'balloons', 'hearts', 'petals', 'snow', 'spider', 'ghost',
  'cannon', 'stars', 'lanterns', 'bubbles', 'fireflies', 'aurora', 'coins', 'disco', 'ribbons', 'bats', 'eyes'];
const FXS = {
  fireworks: { name: 'Салют' }, confetti: { name: 'Конфетти' }, balloons: { name: 'Бөмбөлөг' }, hearts: { name: 'Зүрх' },
  petals: { name: 'Цэцгийн дэлбээ' }, snow: { name: 'Цас' }, cannon: { name: 'Конфетти буу' }, stars: { name: 'Одод буух' },
  lanterns: { name: 'Тэнгэрийн дэнлүү' }, bubbles: { name: 'Хөөс' }, fireflies: { name: 'Галт хорхой' }, aurora: { name: 'Туяа' },
  coins: { name: 'Алтан зоос' }, disco: { name: 'Диско гэрэл' }, ribbons: { name: 'Тууз' },
  spider: { name: 'Аалз', scare: true }, ghost: { name: 'Сүнс', scare: true }, bats: { name: 'Сарьсан багваахай', scare: true }, eyes: { name: 'Харанхуйн нүд', scare: true }
};
const OCC_IDS = ['bday', 'wed', 'women', 'army', 'tsagaan', 'newyear', 'friend', 'other'];
const OCC = {
  bday: { name: 'Төрсөн өдөр', title: 'Төрсөн өдрийн мэнд!', theme: 'sun', motif: 'cake',
    msg: 'Төрсөн өдрийн чинь мэнд хүргэе! Амьдралд чинь аз жаргал, эрүүл энх, хүссэн бүхэн чинь биелж байх болтугай.',
    fx: ['confetti', 'balloons', 'cannon', 'fireworks', 'spider', 'ghost', 'hearts', 'disco'] },
  wed: { name: 'Гэрлэсний ой', title: 'Гэрлэсний ойн мэнд!', theme: 'gold', motif: 'rings',
    msg: 'Гэрлэсний ойн мэнд хүргэе! Хайр сэтгэл тань жил ирэх тусам улам гүнзгийрч, гэр бүл тань аз жаргалаар дүүрэн байх болтугай.',
    fx: ['hearts', 'petals', 'lanterns', 'fireworks', 'confetti', 'fireflies', 'bubbles', 'stars'] },
  women: { name: '3-р сарын 8', title: 'Эмэгтэйчүүдийн баярын мэнд!', theme: 'blush', motif: 'tulips',
    msg: 'Гурван сарын 8-ны баярын мэнд хүргэе! Таны инээмсэглэл, дулаан сэтгэл эргэн тойрныхоо хүн бүрт гэрэл болдог. Үргэлж жаргалтай байгаарай.',
    fx: ['petals', 'hearts', 'bubbles', 'ribbons', 'confetti', 'balloons', 'fireworks', 'fireflies'] },
  army: { name: 'Цэргийн баяр', title: 'Цэргийн баярын мэнд!', theme: 'green', motif: 'star',
    msg: 'Цэргийн баярын мэнд хүргэе! Эх орноо хамгаалагчдын зориг, хүч чадал, нэр төрийг хүндэлнэ. Эрүүл энх, амжилт дагуулах болтугай.',
    fx: ['fireworks', 'cannon', 'confetti', 'stars', 'balloons', 'aurora', 'snow', 'ribbons'] },
  tsagaan: { name: 'Цагаан сар', title: 'Цагаан сарын мэнд!', theme: 'sky', motif: 'ugalz',
    msg: 'Амар байна уу? Цагаан сарын мэнд хүргэе! Шинэ жилдээ тавтай морилно уу. Идээ ундаа цагаан, ерөөл сайхан, гэр бүл амгалан байх болтугай.',
    fx: ['snow', 'aurora', 'lanterns', 'fireworks', 'coins', 'stars', 'petals', 'confetti'] },
  newyear: { name: 'Шинэ жил', title: 'Шинэ жилийн мэнд!', theme: 'night', motif: 'tree',
    msg: 'Шинэ жилийн мэнд хүргэе! Шинэ онд хүссэн бүхэн чинь биелж, аз жаргал, эрүүл энх, амжилт дагуулах болтугай.',
    fx: ['fireworks', 'snow', 'stars', 'cannon', 'aurora', 'disco', 'coins', 'confetti'] },
  friend: { name: 'Найздаа', title: 'Сайхан өдрийн мэнд!', theme: 'blush', motif: 'gift',
    msg: 'Чам шиг сайхан найзтай болсондоо баяртай байна. Өнөөдөр инээмсэглэл дүүрэн, сайхан өдөр байх болтугай!',
    fx: ['spider', 'ghost', 'bats', 'eyes', 'confetti', 'cannon', 'hearts', 'disco'] },
  other: { name: 'Өөр баяр', title: 'Баярын мэнд!', theme: 'night', motif: 'burst',
    msg: 'Баярын мэнд хүргэе! Сайхан сэтгэл, эрүүл энх, аз жаргал дүүрэн өдрүүд дагуулах болтугай.',
    fx: ['fireworks', 'confetti', 'cannon', 'hearts', 'stars', 'balloons', 'spider', 'ghost'] }
};
function occFx(occ) {
  const top = (OCC[occ] || OCC.other).fx;
  const rest = FX_IDS.filter(x => !top.includes(x));
  return [...top, ...rest.filter(x => !FXS[x].scare), ...rest.filter(x => FXS[x].scare)];
}
/* Frame (seconds) used for small previews and for the saved picture. */
const THUMB_T = { fireworks: 2.3, confetti: 1, balloons: 1, hearts: 1, petals: 1, snow: 1, spider: 3.9, ghost: 3.9, cannon: 1.0, stars: 2.0, lanterns: 1, bubbles: 1, fireflies: 1, aurora: 1, coins: 1, disco: 1, ribbons: 1, bats: 3.9, eyes: 4.5 };
const FINAL_T = Object.assign({}, THUMB_T, { spider: 7.9, ghost: 7.9, bats: 7.9, eyes: 7.9 });
const LOOP = { spider: 10, ghost: 10, bats: 10, eyes: 10 };

/* ---------- Drawing helpers ---------- */
function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
function heart(ctx, x, y, s) { ctx.beginPath(); ctx.moveTo(x, y + s * 0.9); ctx.bezierCurveTo(x - s * 1.5, y - s * 0.1, x - s * 0.7, y - s * 1.1, x, y - s * 0.35); ctx.bezierCurveTo(x + s * 0.7, y - s * 1.1, x + s * 1.5, y - s * 0.1, x, y + s * 0.9); ctx.closePath(); }
function sparkle(ctx, x, y, r) { ctx.beginPath(); ctx.moveTo(x, y - r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.quadraticCurveTo(x, y, x, y + r); ctx.quadraticCurveTo(x, y, x - r, y); ctx.quadraticCurveTo(x, y, x, y - r); ctx.fill(); }
function star5(ctx, x, y, R, r, rot) { rot = rot === undefined ? -Math.PI / 2 : rot; ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = rot + i * Math.PI / 5, d = i % 2 ? r : R; const px = x + Math.cos(a) * d, py = y + Math.sin(a) * d; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.closePath(); }
function petal(ctx, s) { ctx.beginPath(); ctx.moveTo(0, -s); ctx.bezierCurveTo(s * 0.9, -s * 0.5, s * 0.7, s * 0.6, 0, s); ctx.bezierCurveTo(-s * 0.7, s * 0.6, -s * 0.9, -s * 0.5, 0, -s); ctx.closePath(); }
function icing(ctx, x, y, wd, n) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + wd, y); const st = wd / n; for (let i = n; i > 0; i--) ctx.arc(x + st * (i - 0.5), y, st / 2, 0, Math.PI); ctx.closePath(); ctx.fill(); }
function ready(el) { if (!el) return false; if (el.tagName === 'VIDEO') return el.readyState >= 2 && el.videoWidth > 0; return !!(el.complete && el.naturalWidth > 0); }
function srcSize(el) { return el.tagName === 'VIDEO' ? [el.videoWidth, el.videoHeight] : [el.naturalWidth, el.naturalHeight]; }
function drawCover(ctx, el, x, y, w, h) { const [sw, sh] = srcSize(el); const k = Math.max(w / sw, h / sh); const dw = sw * k, dh = sh * k; ctx.drawImage(el, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh); }
function drawContain(ctx, el, cx, cy, size) { const [sw, sh] = srcSize(el); const k = Math.min(size / sw, size / sh); ctx.drawImage(el, cx - sw * k / 2, cy - sh * k / 2, sw * k, sh * k); }

/* ---------- Background ---------- */
function drawBg(ctx, w, h, u, th, t, R) {
  const g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, th.bg[0]); g.addColorStop(1, th.bg[1]);
  ctx.fillStyle = g; ctx.fillRect(-40, -40, w + 80, h + 80);
  if (R && R.bgEl && ready(R.bgEl)) {
    ctx.save(); drawCover(ctx, R.bgEl, -20, -20, w + 40, h + 40); ctx.restore();
    const sg = ctx.createLinearGradient(0, 0, 0, h); sg.addColorStop(0, rgba(th.bg[0], 0.5)); sg.addColorStop(1, rgba(th.bg[1], 0.62));
    ctx.fillStyle = sg; ctx.fillRect(-40, -40, w + 80, h + 80);
  }
  const rg = ctx.createRadialGradient(w / 2, h * 0.3, 0, w / 2, h * 0.3, u * 1.05); rg.addColorStop(0, rgba(th.glow, 0.5)); rg.addColorStop(1, rgba(th.glow, 0));
  ctx.fillStyle = rg; ctx.fillRect(-40, -40, w + 80, h + 80);
  const r = rng(5);
  for (let i = 0; i < 16; i++) { const x = r() * w + Math.sin(t * 0.25 + i) * u * 0.02, y = r() * h + Math.cos(t * 0.2 + i * 2) * u * 0.02, rad = u * (0.03 + r() * 0.09); ctx.fillStyle = rgba(th.glow, 0.05 + r() * 0.09); ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.fill(); }
  const m = Math.min(w, h) * 0.035;
  ctx.lineWidth = Math.max(1, u * 0.0045); ctx.strokeStyle = rgba(th.ink, 0.4); rr(ctx, m, m, w - 2 * m, h - 2 * m, u * 0.05); ctx.stroke();
  ctx.lineWidth = Math.max(1, u * 0.002); ctx.strokeStyle = rgba(th.ink, 0.2); rr(ctx, m * 1.7, m * 1.7, w - 3.4 * m, h - 3.4 * m, u * 0.04); ctx.stroke();
}
function drawTwinkles(ctx, w, h, u, th, t) {
  const r = rng(21);
  for (let i = 0; i < 26; i++) { const x = r() * w, y = r() * h, ph = r() * TAU, sz = u * (0.008 + r() * 0.014), sp = 1.2 + r(); const a = Math.pow(Math.max(0, Math.sin(t * sp + ph)), 2); ctx.fillStyle = rgba(i % 3 ? '#FFFFFF' : th.a, a * 0.9); sparkle(ctx, x, y, sz * 3); }
}

/* ---------- Motifs, photo, sticker (about s wide and tall, centred at cx,cy) ---------- */
const MOTIFS = {
  cake(ctx, cx, cy, s, th, t) {
    cy += Math.sin(t * 1.6) * s * 0.015;
    ctx.fillStyle = 'rgba(0,0,0,.16)'; ctx.beginPath(); ctx.ellipse(cx, cy + s * 0.46, s * 0.52, s * 0.07, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = th.a; rr(ctx, cx - s * 0.46, cy + s * 0.12, s * 0.92, s * 0.33, s * 0.06); ctx.fill();
    ctx.fillStyle = th.b; rr(ctx, cx - s * 0.32, cy - s * 0.12, s * 0.64, s * 0.26, s * 0.06); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; icing(ctx, cx - s * 0.46, cy + s * 0.12, s * 0.92, 7);
    ctx.fillStyle = th.c; icing(ctx, cx - s * 0.32, cy - s * 0.12, s * 0.64, 5);
    ctx.fillStyle = th.c; for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.arc(cx - s * 0.36 + i * s * 0.18, cy + s * 0.33, s * 0.022, 0, TAU); ctx.fill(); }
    for (let i = 0; i < 3; i++) {
      const x = cx + (i - 1) * s * 0.17, by = cy - s * 0.12, hh = s * 0.19;
      ctx.fillStyle = i === 1 ? th.a : '#FFFFFF'; ctx.fillRect(x - s * 0.025, by - hh, s * 0.05, hh);
      ctx.fillStyle = th.c; for (let k = 0; k < 3; k++) ctx.fillRect(x - s * 0.025, by - hh + k * hh / 3 + hh / 12, s * 0.05, hh / 9);
      const f = 1 + 0.18 * Math.sin(t * 9 + i * 2), fy = by - hh - s * 0.05;
      const gl = ctx.createRadialGradient(x, fy, 0, x, fy, s * 0.18); gl.addColorStop(0, 'rgba(255,200,80,.5)'); gl.addColorStop(1, 'rgba(255,200,80,0)');
      ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, fy, s * 0.18, 0, TAU); ctx.fill();
      ctx.fillStyle = '#FFB02E'; ctx.beginPath(); ctx.ellipse(x, fy, s * 0.032, s * 0.058 * f, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#FFF3B0'; ctx.beginPath(); ctx.ellipse(x, fy + s * 0.012, s * 0.016, s * 0.03 * f, 0, 0, TAU); ctx.fill();
    }
  },
  rings(ctx, cx, cy, s, th, t) {
    cy += Math.sin(t * 1.5) * s * 0.015;
    const r = s * 0.25, dx = s * 0.14, y = cy + s * 0.1;
    ctx.lineCap = 'round'; ctx.lineWidth = s * 0.065;
    ctx.strokeStyle = th.a; ctx.beginPath(); ctx.arc(cx - dx, y, r, 0, TAU); ctx.stroke();
    ctx.strokeStyle = th.b; ctx.beginPath(); ctx.arc(cx + dx, y, r, 0, TAU); ctx.stroke();
    ctx.strokeStyle = th.a; ctx.beginPath(); ctx.arc(cx - dx, y, r, -1.3, -0.7); ctx.stroke();
    const gx = cx - dx, gy = y - r - s * 0.07;
    ctx.fillStyle = '#FFFFFF'; ctx.beginPath(); ctx.moveTo(gx - s * 0.07, gy); ctx.lineTo(gx - s * 0.04, gy - s * 0.06); ctx.lineTo(gx + s * 0.04, gy - s * 0.06); ctx.lineTo(gx + s * 0.07, gy); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#BFE3FF'; ctx.beginPath(); ctx.moveTo(gx - s * 0.07, gy); ctx.lineTo(gx + s * 0.07, gy); ctx.lineTo(gx, gy + s * 0.07); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, gx + s * 0.1, gy - s * 0.1, s * (0.07 + 0.04 * Math.sin(t * 3)));
    ctx.fillStyle = rgba(th.ink, 0.9); ctx.globalAlpha = 0.55; heart(ctx, cx, y - r * 1.55, s * 0.05); ctx.fill(); ctx.globalAlpha = 1;
  },
  tulips(ctx, cx, cy, s, th, t) {
    const base = cy + s * 0.48, cols = [th.a, th.b, th.c], xs = [-0.21, 0, 0.21], hs = [0.0, -0.14, 0.0];
    ctx.lineCap = 'round'; ctx.fillStyle = '#34B067';
    for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx, base); ctx.bezierCurveTo(cx + sd * s * 0.12, base - s * 0.5, cx + sd * s * 0.38, base - s * 0.34, cx + sd * s * 0.38, base - s * 0.12); ctx.bezierCurveTo(cx + sd * s * 0.28, base - s * 0.26, cx + sd * s * 0.12, base - s * 0.12, cx, base); ctx.fill(); }
    for (let i = 0; i < 3; i++) {
      const sway = Math.sin(t * 1.4 + i * 1.3) * s * 0.02, hx = cx + xs[i] * s + sway, hy = cy + s * (hs[i] - 0.06), r = s * 0.14;
      ctx.strokeStyle = '#2E9B58'; ctx.lineWidth = s * 0.03; ctx.beginPath(); ctx.moveTo(cx + xs[i] * s * 0.3, base); ctx.quadraticCurveTo(cx + xs[i] * s * 0.9, base - s * 0.35, hx, hy + r * 0.9); ctx.stroke();
      ctx.fillStyle = cols[i]; ctx.beginPath(); ctx.moveTo(hx - r, hy - r * 0.9); ctx.quadraticCurveTo(hx - r * 1.2, hy + r * 0.6, hx, hy + r * 1.0); ctx.quadraticCurveTo(hx + r * 1.2, hy + r * 0.6, hx + r, hy - r * 0.9); ctx.lineTo(hx + r * 0.5, hy - r * 0.3); ctx.lineTo(hx, hy - r * 1.2); ctx.lineTo(hx - r * 0.5, hy - r * 0.3); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.28)'; ctx.beginPath(); ctx.moveTo(hx, hy - r * 1.2); ctx.quadraticCurveTo(hx - r * 0.55, hy + r * 0.1, hx, hy + r * 1.0); ctx.quadraticCurveTo(hx + r * 0.55, hy + r * 0.1, hx, hy - r * 1.2); ctx.fill();
    }
    ctx.fillStyle = th.a; ctx.beginPath(); ctx.ellipse(cx, base - s * 0.1, s * 0.07, s * 0.035, 0, 0, TAU); ctx.fill();
  },
  star(ctx, cx, cy, s, th, t) {
    const R = s * 0.4, p = 1 + 0.03 * Math.sin(t * 2.2);
    ctx.fillStyle = rgba(th.ink, 0.1); ctx.beginPath(); ctx.arc(cx, cy, R * 1.02, 0, TAU); ctx.fill();
    ctx.strokeStyle = th.b; ctx.lineWidth = s * 0.012; ctx.lineCap = 'round';
    for (const sd of [-1, 1]) {
      ctx.beginPath();
      for (let i = 0; i <= 8; i++) { const b = 0.12 + i * 0.2, px = cx + sd * Math.sin(b) * R, py = cy + Math.cos(b) * R; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
      ctx.stroke(); ctx.fillStyle = th.b;
      for (let i = 0; i <= 8; i++) { const b = 0.12 + i * 0.2, px = cx + sd * Math.sin(b) * R * 1.04, py = cy + Math.cos(b) * R * 1.04; const rot = Math.atan2(-Math.sin(b), sd * Math.cos(b)) + sd * 0.55; ctx.beginPath(); ctx.ellipse(px, py, s * 0.075, s * 0.03, rot, 0, TAU); ctx.fill(); }
    }
    ctx.save(); ctx.translate(cx, cy + s * 0.01); ctx.scale(p, p);
    ctx.fillStyle = th.a; star5(ctx, 0, 0, s * 0.26, s * 0.105); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.3)'; star5(ctx, 0, 0, s * 0.12, s * 0.05); ctx.fill(); ctx.restore();
  },
  ugalz(ctx, cx, cy, s, th, t) {
    const r = s * 0.17; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const spiral = (x0, y0, phase, sc) => { ctx.beginPath(); const N = 80; for (let i = 0; i <= N; i++) { const q = i / N * 3.3 * Math.PI, rad = r * sc * (1 - q / (3.8 * Math.PI)), ang = phase + q; const px = x0 + Math.cos(ang) * rad, py = y0 + Math.sin(ang) * rad; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke(); };
    for (const sg of [-1, 1]) {
      const y0 = cy + sg * s * 0.2; ctx.lineWidth = s * 0.055; ctx.strokeStyle = th.a;
      spiral(cx - r, y0, 0, 1); spiral(cx + r, y0, Math.PI, 1);
      ctx.fillStyle = th.b; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.arc(cx + sx * r, y0, s * 0.02, 0, TAU); ctx.fill(); }
    }
    ctx.fillStyle = th.b; sparkle(ctx, cx, cy, s * 0.07 * (1 + 0.15 * Math.sin(t * 2.5)));
    ctx.fillStyle = th.a; for (const sx of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx + sx * s * 0.46, cy - s * 0.06); ctx.lineTo(cx + sx * s * 0.5, cy); ctx.lineTo(cx + sx * s * 0.46, cy + s * 0.06); ctx.lineTo(cx + sx * s * 0.42, cy); ctx.closePath(); ctx.fill(); }
  },
  tree(ctx, cx, cy, s, th, t) {
    cy += Math.sin(t * 1.3) * s * 0.012;
    ctx.fillStyle = '#8A4B25'; ctx.fillRect(cx - s * 0.05, cy + s * 0.37, s * 0.1, s * 0.12);
    const tiers = [[cy + s * 0.4, s * 0.7, s * 0.3, '#1F9D5C'], [cy + s * 0.16, s * 0.56, s * 0.28, '#27B26A'], [cy - s * 0.06, s * 0.42, s * 0.26, '#2FC37A']];
    for (const [y, w, h, c] of tiers) { ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(cx, y - h); ctx.lineTo(cx + w / 2, y); ctx.lineTo(cx - w / 2, y); ctx.closePath(); ctx.fill(); }
    [[-0.2, 0.34], [0.15, 0.37], [0.0, 0.2], [-0.14, 0.12], [0.18, 0.14], [-0.06, -0.02], [0.09, -0.06]].forEach((b, i) => { ctx.fillStyle = th.pal[i % th.pal.length]; ctx.beginPath(); ctx.arc(cx + b[0] * s, cy + b[1] * s - s * 0.02, s * 0.03, 0, TAU); ctx.fill(); });
    const p = 1 + 0.1 * Math.sin(t * 3); ctx.fillStyle = th.a; star5(ctx, cx, cy - s * 0.37, s * 0.075 * p, s * 0.032 * p); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, cx + s * 0.09, cy - s * 0.42, s * 0.05 * (0.6 + 0.4 * Math.sin(t * 4)));
  },
  gift(ctx, cx, cy, s, th, t) {
    const hop = Math.abs(Math.sin(t * 2.4)) * s * 0.05;
    ctx.fillStyle = 'rgba(0,0,0,.15)'; ctx.beginPath(); ctx.ellipse(cx, cy + s * 0.46, s * 0.4 * (1 - hop / s * 2), s * 0.05, 0, 0, TAU); ctx.fill();
    cy -= hop;
    ctx.fillStyle = th.a; rr(ctx, cx - s * 0.34, cy + s * 0.02, s * 0.68, s * 0.42, s * 0.04); ctx.fill();
    ctx.fillStyle = th.b; rr(ctx, cx - s * 0.39, cy - s * 0.12, s * 0.78, s * 0.16, s * 0.04); ctx.fill();
    ctx.fillStyle = th.c; ctx.fillRect(cx - s * 0.05, cy - s * 0.12, s * 0.1, s * 0.56);
    for (const sd of [-1, 1]) { ctx.save(); ctx.translate(cx + sd * s * 0.1, cy - s * 0.2); ctx.rotate(sd * 0.55); ctx.fillStyle = th.c; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.13, s * 0.075, 0, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(0,0,0,.14)'; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.06, s * 0.035, 0, 0, TAU); ctx.fill(); ctx.restore(); }
    ctx.fillStyle = th.c; ctx.beginPath(); ctx.arc(cx, cy - s * 0.17, s * 0.05, 0, TAU); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, cx + s * 0.34, cy - s * 0.22, s * 0.06 * (0.6 + 0.4 * Math.sin(t * 3.5)));
  },
  burst(ctx, cx, cy, s, th, t) {
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * 0.25);
    for (let i = 0; i < 12; i++) { ctx.rotate(TAU / 12); ctx.fillStyle = i % 2 ? th.a : th.b; ctx.beginPath(); ctx.moveTo(s * 0.15, -s * 0.03); ctx.lineTo(i % 2 ? s * 0.38 : s * 0.46, 0); ctx.lineTo(s * 0.15, s * 0.03); ctx.closePath(); ctx.fill(); }
    ctx.restore();
    ctx.fillStyle = th.a; ctx.beginPath(); ctx.arc(cx, cy, s * 0.15, 0, TAU); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, cx, cy, s * (0.14 + 0.02 * Math.sin(t * 3)));
  }
};
function drawPhoto(ctx, cx, cy, s, th, img, t) {
  const r = s * 0.42;
  ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = s * 0.08; ctx.shadowOffsetY = s * 0.02; ctx.fillStyle = '#FFFFFF'; ctx.beginPath(); ctx.arc(cx, cy, r + s * 0.03, 0, TAU); ctx.fill(); ctx.restore();
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.clip(); drawCover(ctx, img, cx - r, cy - r, r * 2, r * 2); ctx.restore();
  ctx.strokeStyle = th.a; ctx.lineWidth = s * 0.03; ctx.beginPath(); ctx.arc(cx, cy, r + s * 0.045, 0, TAU); ctx.stroke();
  ctx.save(); ctx.strokeStyle = th.b; ctx.lineWidth = s * 0.016; ctx.lineCap = 'round'; ctx.setLineDash([s * 0.02, s * 0.065]); ctx.lineDashOffset = -t * s * 0.1; ctx.beginPath(); ctx.arc(cx, cy, r + s * 0.1, 0, TAU); ctx.stroke(); ctx.restore();
  for (let k = 0; k < 6; k++) { const a = t * 0.6 + k * TAU / 6, rad = r + s * 0.17; ctx.fillStyle = k % 2 ? '#FFFFFF' : th.a; sparkle(ctx, cx + Math.cos(a) * rad, cy + Math.sin(a) * rad, s * (0.035 + 0.02 * Math.sin(t * 3 + k))); }
}
function drawSticker(ctx, cx, cy, s, el, t) { cy += Math.sin(t * 1.6) * s * 0.02; ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.28)'; ctx.shadowBlur = s * 0.06; drawContain(ctx, el, cx, cy, s * 1.0); ctx.restore(); }

/* ---------- Effects ---------- */
const FW_P = 1.05;
function fxFireworks(ctx, w, h, u, th, t) {
  const kMin = Math.max(0, Math.floor((t - 2.4) / FW_P)), kMax = Math.floor(t / FW_P);
  for (let k = kMin; k <= kMax; k++) {
    const r = rng(k * 7919 + 17), tau = t - k * FW_P;
    const x = w * (0.16 + 0.68 * r()), ay = h * (0.1 + 0.28 * r()), c1 = th.pal[(r() * th.pal.length) | 0], c2 = th.pal[(r() * th.pal.length) | 0];
    const rise = 0.72;
    if (tau < rise) { const p = easeOut(tau / rise), y = mix(h * 1.02, ay, p); ctx.strokeStyle = rgba('#FFFFFF', 0.9); ctx.lineWidth = u * 0.008; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + u * 0.1 * (1 - p * 0.6)); ctx.stroke(); continue; }
    const b = tau - rise; if (b > 2.1) continue;
    const life = clamp(1 - b / 1.9);
    if (b < 0.14) { const gl = ctx.createRadialGradient(x, ay, 0, x, ay, u * 0.2); gl.addColorStop(0, rgba('#FFFFFF', 0.8 * (1 - b / 0.14))); gl.addColorStop(1, rgba('#FFFFFF', 0)); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, ay, u * 0.2, 0, TAU); ctx.fill(); }
    const n = 56;
    for (let i = 0; i < n; i++) {
      const inner = i % 2, ang = i / n * TAU + (r() - 0.5) * 0.12, rad = u * ((inner ? 0.2 : 0.34) * (0.85 + 0.2 * r()));
      const pos = bb => { const d = rad * (1 - Math.exp(-3.2 * bb)); return [x + Math.cos(ang) * d, ay + Math.sin(ang) * d + u * 0.16 * bb * bb]; };
      const [px, py] = pos(b), [qx, qy] = pos(Math.max(0, b - 0.06));
      const al = Math.pow(life, 1.3) * (0.7 + 0.3 * Math.sin(b * 38 + i));
      ctx.strokeStyle = rgba(inner ? c2 : c1, al * 0.7); ctx.lineWidth = u * 0.006; ctx.beginPath(); ctx.moveTo(qx, qy); ctx.lineTo(px, py); ctx.stroke();
      ctx.fillStyle = rgba(inner ? c2 : c1, al); ctx.beginPath(); ctx.arc(px, py, u * 0.0075, 0, TAU); ctx.fill();
    }
  }
}
function fxConfetti(ctx, w, h, u, th, t, opt) {
  const fromTop = opt && opt.fromTop, r = rng(11), n = 70;
  for (let i = 0; i < n; i++) {
    const x0 = r(), sp = 0.15 + r() * 0.22, ph = r() * TAU, sz = u * (0.016 + r() * 0.02), col = th.pal[(r() * th.pal.length) | 0], rs = 2 + r() * 4, o = r(), pad = sz * 6;
    let f; if (fromTop) { f = t * sp - o * 0.5; if (f < 0) continue; } else f = o + t * sp;
    const y = (f % 1) * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 1.3 + ph) * u * 0.04, rot = t * rs + ph, flip = Math.cos(t * rs * 1.3 + ph);
    ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(1, flip); ctx.fillStyle = col; ctx.fillRect(-sz, -sz * 0.5, sz * 2, sz); ctx.restore();
  }
}
function fxBalloons(ctx, w, h, u, th, t) {
  const r = rng(31), n = 9;
  for (let i = 0; i < n; i++) {
    const sp = 0.05 + r() * 0.045, o = r(), rad = u * (0.06 + r() * 0.04), ph = r() * TAU, col = th.pal[i % th.pal.length];
    const f = (o + t * sp) % 1, y = h * 1.12 - f * (h * 1.4), x = w * ((i + 0.5) / n) + Math.sin(t * 0.9 + ph) * u * 0.05;
    ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = Math.max(1, u * 0.004);
    ctx.beginPath(); ctx.moveTo(x, y + rad * 1.25); ctx.quadraticCurveTo(x + Math.sin(t * 2 + ph) * rad * 0.5, y + rad * 2.3, x, y + rad * 3.2); ctx.stroke();
    ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(x, y, rad, rad * 1.2, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(x - rad * 0.35, y - rad * 0.45, rad * 0.2, rad * 0.32, 0.5, 0, TAU); ctx.fill();
    ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x, y + rad * 1.17); ctx.lineTo(x - rad * 0.14, y + rad * 1.4); ctx.lineTo(x + rad * 0.14, y + rad * 1.4); ctx.closePath(); ctx.fill();
  }
}
function fxHearts(ctx, w, h, u, th, t) {
  const r = rng(41), n = 22, cols = [th.a, th.b, th.c, '#FF5C8E'];
  for (let i = 0; i < n; i++) {
    const sp = 0.08 + r() * 0.1, o = r(), sz = u * (0.025 + r() * 0.04), ph = r() * TAU, col = cols[i % cols.length];
    const f = (o + t * sp) % 1, y = h * 1.08 - f * (h * 1.2), x = r() * w + Math.sin(t * 1.1 + ph) * u * 0.05;
    ctx.globalAlpha = clamp(y / (h * 0.3)) * 0.92; ctx.fillStyle = col; heart(ctx, x, y, sz); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.beginPath(); ctx.ellipse(x - sz * 0.5, y - sz * 0.45, sz * 0.18, sz * 0.1, -0.6, 0, TAU); ctx.fill();
  }
  ctx.globalAlpha = 1;
}
function fxPetals(ctx, w, h, u, th, t) {
  const r = rng(51), n = 40;
  for (let i = 0; i < n; i++) {
    const sp = 0.1 + r() * 0.14, o = r(), sz = u * (0.02 + r() * 0.025), ph = r() * TAU, col = th.pal[(r() * th.pal.length) | 0], rs = 1 + r() * 2.2, x0 = r();
    const pad = sz * 4, f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 0.9 + ph) * u * 0.07;
    ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(t * rs + ph) * 0.9 + ph); ctx.scale(0.45 + 0.55 * Math.abs(Math.cos(t * rs * 0.9 + ph)), 1); ctx.globalAlpha = 0.92; ctx.fillStyle = col; petal(ctx, sz); ctx.fill(); ctx.restore();
  }
}
function fxSnow(ctx, w, h, u, th, t) {
  const r = rng(61);
  for (let i = 0; i < 80; i++) { const sp = 0.07 + r() * 0.14, o = r(), sz = u * (0.004 + r() * 0.01), ph = r() * TAU, x0 = r(), pad = sz * 4; const f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 0.8 + ph) * u * 0.04; ctx.fillStyle = 'rgba(255,255,255,.88)'; ctx.beginPath(); ctx.arc(x, y, sz, 0, TAU); ctx.fill(); }
  for (let i = 0; i < 7; i++) {
    const sp = 0.05 + r() * 0.05, o = r(), sz = u * (0.02 + r() * 0.02), ph = r() * TAU, x0 = r(), pad = sz * 4;
    const f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 0.7 + ph) * u * 0.05;
    ctx.save(); ctx.translate(x, y); ctx.rotate(t * 0.5 + ph); ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = Math.max(1, sz * 0.14); ctx.lineCap = 'round';
    for (let k = 0; k < 3; k++) { ctx.rotate(Math.PI / 3); ctx.beginPath(); ctx.moveTo(-sz, 0); ctx.lineTo(sz, 0); ctx.stroke(); }
    ctx.restore();
  }
}
const CAN_P = 2.6;
function fxCannon(ctx, w, h, u, th, t) {
  const kMin = Math.max(0, Math.floor((t - 2.7) / CAN_P)), kMax = Math.floor(t / CAN_P);
  for (let k = kMin; k <= kMax; k++) {
    const tau = t - (k * CAN_P + 0.35); if (tau < 0 || tau > 2.5) continue;
    const r = rng(k * 313 + 7);
    for (const sd of [-1, 1]) {
      const ox = sd < 0 ? w * 0.05 : w * 0.95, oy = h * 0.97;
      if (tau < 0.2) { const gl = ctx.createRadialGradient(ox, oy, 0, ox, oy, u * 0.25); gl.addColorStop(0, rgba('#FFFFFF', 0.85 * (1 - tau / 0.2))); gl.addColorStop(1, rgba('#FFFFFF', 0)); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(ox, oy, u * 0.25, 0, TAU); ctx.fill(); }
      for (let i = 0; i < 42; i++) {
        const a = 0.2 + 0.55 * r(), ang = -Math.PI / 2 - sd * a, sp = u * (1.1 + 0.9 * r()), col = th.pal[(r() * th.pal.length) | 0], sz = u * (0.012 + 0.014 * r()), rs = 4 + 8 * r(), ph = r() * TAU;
        const d = (1 - Math.exp(-2.2 * tau)) / 2.2;
        const x = ox + Math.cos(ang) * sp * d, y = oy + Math.sin(ang) * sp * d + 0.5 * u * 1.1 * tau * tau;
        const al = clamp(1 - Math.max(0, tau - 1.6) / 0.9);
        ctx.save(); ctx.translate(x, y); ctx.rotate(tau * rs + ph); ctx.scale(1, Math.cos(tau * 7 + i)); ctx.globalAlpha = al; ctx.fillStyle = col; ctx.fillRect(-sz, -sz * 0.5, sz * 2, sz); ctx.restore();
      }
    }
  }
  ctx.globalAlpha = 1;
}
function fxStars(ctx, w, h, u, th, t) {
  const r = rng(71);
  for (let i = 0; i < 7; i++) {
    const P = 2.2 + r() * 2.6, o = r() * P, x0 = w * (0.35 + 0.75 * r()), y0 = h * (-0.05 + 0.45 * r()), len = u * (0.28 + 0.2 * r()), ang = Math.PI * 0.78;
    const f = ((t + o) % P) / P; if (f > 0.3) continue;
    const p = f / 0.3, x = x0 + Math.cos(ang) * u * 1.1 * p, y = y0 + Math.sin(ang) * u * 1.1 * p, tx = x - Math.cos(ang) * len, ty = y - Math.sin(ang) * len;
    const g = ctx.createLinearGradient(x, y, tx, ty); g.addColorStop(0, 'rgba(255,255,255,' + (0.95 * (1 - p * 0.4)) + ')'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.strokeStyle = g; ctx.lineWidth = u * 0.009; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(tx, ty); ctx.stroke();
    ctx.fillStyle = '#FFFFFF'; sparkle(ctx, x, y, u * 0.022);
  }
  const r2 = rng(72);
  for (let i = 0; i < 12; i++) { const x = r2() * w, y = r2() * h, ph = r2() * TAU, sz = u * (0.025 + r2() * 0.03); const a = 0.35 + 0.65 * Math.pow(Math.max(0, Math.sin(t * 1.5 + ph)), 2); ctx.fillStyle = rgba(i % 2 ? '#FFFFFF' : th.a, a); sparkle(ctx, x, y, sz); }
}
function fxLanterns(ctx, w, h, u, th, t) {
  const r = rng(81), n = 8;
  for (let i = 0; i < n; i++) {
    const sp = 0.035 + r() * 0.03, o = r(), sz = u * (0.07 + r() * 0.04), ph = r() * TAU;
    const f = (o + t * sp) % 1, y = h * 1.1 - f * (h * 1.3), x = w * ((i + 0.6) / n) + Math.sin(t * 0.7 + ph) * u * 0.05, fl = 0.85 + 0.15 * Math.sin(t * 6 + ph);
    const gl = ctx.createRadialGradient(x, y, 0, x, y, sz * 2.6); gl.addColorStop(0, 'rgba(255,190,90,' + (0.55 * fl) + ')'); gl.addColorStop(1, 'rgba(255,190,90,0)');
    ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y, sz * 2.6, 0, TAU); ctx.fill();
    const g = ctx.createLinearGradient(x, y - sz, x, y + sz); g.addColorStop(0, '#FFD27A'); g.addColorStop(1, '#F2762E');
    ctx.fillStyle = g; rr(ctx, x - sz * 0.62, y - sz * 0.8, sz * 1.24, sz * 1.6, sz * 0.3); ctx.fill();
    ctx.fillStyle = 'rgba(120,40,10,.55)'; ctx.fillRect(x - sz * 0.62, y - sz * 0.8, sz * 1.24, sz * 0.12); ctx.fillRect(x - sz * 0.62, y + sz * 0.68, sz * 1.24, sz * 0.12);
    ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(x, y, sz * 0.22, sz * 0.5, 0, 0, TAU); ctx.fill();
  }
}
function fxBubbles(ctx, w, h, u, th, t) {
  const r = rng(91);
  for (let i = 0; i < 26; i++) {
    const sp = 0.05 + r() * 0.08, o = r(), rad = u * (0.015 + r() * 0.05), ph = r() * TAU, x0 = r();
    const f = (o + t * sp) % 1, y = h * 1.05 - f * (h * 1.15), x = x0 * w + Math.sin(t * 1.3 + ph) * u * 0.04;
    ctx.fillStyle = 'rgba(255,255,255,.1)'; ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = Math.max(1, rad * 0.08); ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = Math.max(1, rad * 0.12); ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(x, y, rad * 0.72, -2.5, -1.7); ctx.stroke();
  }
}
function fxFireflies(ctx, w, h, u, th, t) {
  const r = rng(101);
  for (let i = 0; i < 44; i++) {
    const cx = r() * w, cy = h * (0.25 + 0.7 * r()), ax = u * (0.05 + 0.12 * r()), ay = u * (0.04 + 0.1 * r()), fx = 0.2 + r() * 0.5, fy = 0.25 + r() * 0.5, ph = r() * TAU, ps = 1.5 + r() * 2.5;
    const x = cx + Math.sin(t * fx + ph) * ax, y = cy + Math.cos(t * fy + ph * 1.3) * ay, a = 0.25 + 0.75 * Math.pow(Math.max(0, Math.sin(t * ps + ph)), 2);
    const col = th.light ? (i % 3 ? '#FF9A1F' : '#E0701A') : (i % 3 ? '#FFF3A0' : '#C8FF7A');
    const g = ctx.createRadialGradient(x, y, 0, x, y, u * 0.05); g.addColorStop(0, rgba(col, a)); g.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, u * 0.05, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,230,' + a + ')'; ctx.beginPath(); ctx.arc(x, y, u * 0.0055, 0, TAU); ctx.fill();
  }
}
function fxAurora(ctx, w, h, u, th, t) {
  const cols = [th.a, th.c, th.b];
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let k = 0; k < 3; k++) {
    const base = h * (0.13 + 0.09 * k), amp = u * (0.06 + 0.03 * k), hh = u * 0.42;
    const yAt = x => base + Math.sin(x / u * 3.1 + t * 0.6 + k * 1.7) * amp + Math.sin(x / u * 1.7 - t * 0.4 + k) * amp * 0.6;
    const g = ctx.createLinearGradient(0, base - amp * 2, 0, base + hh); g.addColorStop(0, rgba(cols[k], 0)); g.addColorStop(0.25, rgba(cols[k], 0.4)); g.addColorStop(1, rgba(cols[k], 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(0, yAt(0));
    for (let x = 0; x <= w; x += w / 28) ctx.lineTo(x, yAt(x));
    ctx.lineTo(w, yAt(w) + hh); for (let x = w; x >= 0; x -= w / 28) ctx.lineTo(x, yAt(x) + hh * (0.8 + 0.2 * Math.sin(x / u * 8 + t))); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
}
function fxCoins(ctx, w, h, u, th, t) {
  const r = rng(111);
  for (let i = 0; i < 30; i++) {
    const sp = 0.12 + r() * 0.16, o = r(), sz = u * (0.02 + r() * 0.02), ph = r() * TAU, x0 = r(), rs = 3 + r() * 4, pad = sz * 4;
    const f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t + ph) * u * 0.03, sx = Math.max(0.1, Math.abs(Math.cos(t * rs + ph)));
    ctx.save(); ctx.translate(x, y); ctx.scale(sx, 1);
    const g = ctx.createLinearGradient(-sz, -sz, sz, sz); g.addColorStop(0, '#FFF2A8'); g.addColorStop(0.5, '#FFC940'); g.addColorStop(1, '#C98A12');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, sz, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(140,90,10,.7)'; ctx.lineWidth = Math.max(1, sz * 0.14); ctx.beginPath(); ctx.arc(0, 0, sz * 0.72, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.ellipse(-sz * 0.3, -sz * 0.3, sz * 0.18, sz * 0.1, -0.7, 0, TAU); ctx.fill();
    ctx.restore();
  }
}
function fxDisco(ctx, w, h, u, th, t) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 6; i++) {
    const ang = Math.PI / 2 + Math.sin(t * 0.9 + i * 1.3) * 0.75 + (i - 2.5) * 0.26, len = h * 1.15, x0 = w * 0.5, y0 = u * 0.09, sp = 0.1, col = th.pal[i % th.pal.length];
    const g = ctx.createLinearGradient(x0, y0, x0 + Math.cos(ang) * len, y0 + Math.sin(ang) * len); g.addColorStop(0, rgba(col, 0.55)); g.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + Math.cos(ang - sp) * len, y0 + Math.sin(ang - sp) * len); ctx.lineTo(x0 + Math.cos(ang + sp) * len, y0 + Math.sin(ang + sp) * len); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
  const bx = w / 2, by = u * 0.09, br = u * 0.07;
  ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = Math.max(1, u * 0.003); ctx.beginPath(); ctx.moveTo(bx, -10); ctx.lineTo(bx, by - br); ctx.stroke();
  const g = ctx.createRadialGradient(bx - br * 0.3, by - br * 0.3, br * 0.1, bx, by, br); g.addColorStop(0, '#FFFFFF'); g.addColorStop(1, '#8E96B5');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.fill();
  ctx.save(); ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.clip(); ctx.strokeStyle = 'rgba(60,70,100,.45)'; ctx.lineWidth = Math.max(1, br * 0.05);
  for (let k = -3; k <= 3; k++) { ctx.beginPath(); ctx.moveTo(bx - br, by + k * br / 3.5); ctx.lineTo(bx + br, by + k * br / 3.5); ctx.stroke(); const dx = ((k * br / 3.5 + t * br * 0.5) % (br * 0.6)); for (let m = -4; m <= 4; m++) { ctx.beginPath(); ctx.moveTo(bx + m * br * 0.3 + dx, by - br); ctx.lineTo(bx + m * br * 0.3 + dx, by + br); ctx.stroke(); } }
  ctx.restore();
  ctx.fillStyle = '#FFFFFF'; for (let k = 0; k < 4; k++) sparkle(ctx, bx + Math.cos(t * 2 + k * 1.6) * br * 1.5, by + Math.sin(t * 2 + k * 1.6) * br * 1.5, br * 0.35 * Math.max(0, Math.sin(t * 5 + k)));
}
function fxRibbons(ctx, w, h, u, th, t) {
  const r = rng(121);
  for (let i = 0; i < 14; i++) {
    const x0 = r() * w, sp = 0.1 + r() * 0.12, o = r(), len = u * (0.3 + 0.3 * r()), ph = r() * TAU, col = th.pal[(r() * th.pal.length) | 0];
    const f = (o + t * sp) % 1, head = f * (h + len * 1.3) - len * 0.2;
    ctx.strokeStyle = col; ctx.lineWidth = u * 0.012; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.globalAlpha = 0.92; ctx.beginPath();
    for (let j = 0; j <= 18; j++) { const yy = head - j / 18 * len, xx = x0 + Math.sin(j * 0.5 + t * 3 + ph) * u * 0.035 * (1 + j / 18); j ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy); }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}
const FXR = {
  fireworks: { fn: fxFireworks, front: true }, confetti: { fn: fxConfetti, front: true }, balloons: { fn: fxBalloons, front: false },
  hearts: { fn: fxHearts, front: true }, petals: { fn: fxPetals, front: true }, snow: { fn: fxSnow, front: true },
  cannon: { fn: fxCannon, front: true }, stars: { fn: fxStars, front: false }, lanterns: { fn: fxLanterns, front: false },
  bubbles: { fn: fxBubbles, front: true }, fireflies: { fn: fxFireflies, front: true }, aurora: { fn: fxAurora, front: false },
  coins: { fn: fxCoins, front: true }, disco: { fn: fxDisco, front: false }, ribbons: { fn: fxRibbons, front: true },
  spider: {}, ghost: {}, bats: {}, eyes: {}
};

/* ---------- Creatures ---------- */
function drawSpider(ctx, x, y, s, t) {
  ctx.save(); ctx.translate(x, y); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const wig = (i, k) => Math.sin(t * 9 + i * 1.7 + k) * s * 0.07;
  for (const sd of [-1, 1]) for (let i = 0; i < 4; i++) {
    const ay = -s * 0.25 + i * s * 0.28, mid = (i === 1 || i === 2);
    const kx = sd * s * (mid ? 1.5 : 1.2), ky = ay - s * (1.0 - i * 0.12) + wig(i, sd), fx = sd * s * (mid ? 2.25 : 2.0) + wig(i, 2), fy = ay + s * (0.9 + i * 0.35) + wig(i, 5);
    ctx.beginPath(); ctx.moveTo(sd * s * 0.35, ay); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy);
    ctx.strokeStyle = '#0E0712'; ctx.lineWidth = s * 0.13; ctx.stroke(); ctx.strokeStyle = 'rgba(150,90,180,.35)'; ctx.lineWidth = s * 0.03; ctx.stroke();
  }
  const g = ctx.createRadialGradient(-s * 0.25, s * 0.25, s * 0.1, 0, s * 0.65, s * 1.1); g.addColorStop(0, '#40254F'); g.addColorStop(1, '#0B0510');
  ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, s * 0.65, s * 0.85, s * 1.0, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#D62839';
  ctx.beginPath(); ctx.moveTo(-s * 0.2, s * 0.35); ctx.lineTo(s * 0.2, s * 0.35); ctx.lineTo(0, s * 0.66); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(-s * 0.22, s * 1.0); ctx.lineTo(s * 0.22, s * 1.0); ctx.lineTo(0, s * 0.66); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#1A0D22'; ctx.beginPath(); ctx.arc(0, -s * 0.35, s * 0.55, 0, TAU); ctx.fill();
  ctx.shadowColor = '#FF2B2B'; ctx.shadowBlur = s * 0.35; ctx.fillStyle = '#FF3B3B';
  for (const sd of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sd * s * 0.2, -s * 0.45, s * 0.13, s * 0.17, 0, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(sd * s * 0.36, -s * 0.28, s * 0.05, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(sd * s * 0.1, -s * 0.68, s * 0.05, 0, TAU); ctx.fill(); }
  ctx.shadowBlur = 0; ctx.fillStyle = '#FFE6E6'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.arc(sd * s * 0.17, -s * 0.5, s * 0.04, 0, TAU); ctx.fill(); }
  ctx.fillStyle = '#F4F0E6'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * s * 0.08, -s * 0.02); ctx.lineTo(sd * s * 0.24, -s * 0.02); ctx.lineTo(sd * s * 0.14, s * 0.24); ctx.closePath(); ctx.fill(); }
  ctx.restore();
}
function drawGhost(ctx, x, y, s, t, mouth, alpha) {
  ctx.save(); ctx.translate(x, y); ctx.globalAlpha = alpha;
  ctx.shadowColor = 'rgba(180,205,255,.95)'; ctx.shadowBlur = s * 0.4;
  const g = ctx.createLinearGradient(0, -s, 0, s * 1.1); g.addColorStop(0, '#FFFFFF'); g.addColorStop(1, '#C9D6FF'); ctx.fillStyle = g;
  for (const sd of [-1, 1]) { ctx.save(); ctx.translate(sd * s * 0.88, s * 0.1 + Math.sin(t * 5 + sd) * s * 0.06); ctx.rotate(sd * (0.7 + Math.sin(t * 5 + sd) * 0.15)); ctx.beginPath(); ctx.ellipse(0, 0, s * 0.3, s * 0.13, 0, 0, TAU); ctx.fill(); ctx.restore(); }
  ctx.beginPath(); ctx.moveTo(-s * 0.8, s * 0.95); ctx.lineTo(-s * 0.8, -s * 0.2); ctx.arc(0, -s * 0.2, s * 0.8, Math.PI, 0, false); ctx.lineTo(s * 0.8, s * 0.95);
  const n = 4, st = s * 1.6 / n; for (let i = 0; i < n; i++) { const x1 = s * 0.8 - st * i; ctx.quadraticCurveTo(x1 - st / 2, s * 0.95 + (i % 2 ? -1 : 1) * s * 0.22 + Math.sin(t * 6 + i) * s * 0.04, x1 - st, s * 0.95); }
  ctx.closePath(); ctx.fill(); ctx.shadowBlur = 0;
  ctx.fillStyle = '#1B1030'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sd * s * 0.28, -s * 0.28, s * 0.12, s * 0.2, 0, 0, TAU); ctx.fill(); }
  ctx.beginPath(); ctx.ellipse(0, s * 0.2, s * 0.17 * (0.8 + 0.5 * mouth), s * 0.26 * (0.6 + 0.7 * mouth), 0, 0, TAU); ctx.fill();
  ctx.restore();
}
function drawMoon(ctx, cx, cy, r) {
  const g = ctx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 2.4); g.addColorStop(0, 'rgba(255,244,200,.55)'); g.addColorStop(1, 'rgba(255,244,200,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r * 2.4, 0, TAU); ctx.fill();
  const g2 = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r); g2.addColorStop(0, '#FFFBE8'); g2.addColorStop(1, '#F4DC8C');
  ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(180,150,70,.22)'; [[-0.3, -0.2, 0.2], [0.35, 0.1, 0.14], [-0.1, 0.4, 0.12]].forEach(c => { ctx.beginPath(); ctx.arc(cx + c[0] * r, cy + c[1] * r, c[2] * r, 0, TAU); ctx.fill(); });
}
function drawBat(ctx, x, y, s, flap) {
  ctx.save(); ctx.translate(x, y); ctx.fillStyle = '#0A0510'; ctx.strokeStyle = 'rgba(170,110,220,.55)'; ctx.lineWidth = Math.max(1, s * 0.03); ctx.lineJoin = 'round';
  for (const sd of [-1, 1]) {
    const lift = flap * s * 0.55;
    ctx.beginPath(); ctx.moveTo(sd * s * 0.1, -s * 0.12);
    ctx.bezierCurveTo(sd * s * 0.5, -s * 0.55 - lift, sd * s * 0.95, -s * 0.35 - lift, sd * s * 1.15, -s * 0.05 - lift * 0.5);
    ctx.lineTo(sd * s * 0.9, s * 0.1 - lift * 0.3); ctx.lineTo(sd * s * 0.72, s * 0.02); ctx.lineTo(sd * s * 0.55, s * 0.24); ctx.lineTo(sd * s * 0.34, s * 0.06); ctx.lineTo(sd * s * 0.12, s * 0.2); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  ctx.beginPath(); ctx.ellipse(0, 0, s * 0.17, s * 0.28, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, -s * 0.3, s * 0.13, 0, TAU); ctx.fill();
  for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * s * 0.04, -s * 0.38); ctx.lineTo(sd * s * 0.14, -s * 0.52); ctx.lineTo(sd * s * 0.14, -s * 0.34); ctx.closePath(); ctx.fill(); }
  ctx.fillStyle = '#FF3B3B'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.arc(sd * s * 0.055, -s * 0.31, s * 0.03, 0, TAU); ctx.fill(); }
  ctx.restore();
}
function drawBats(ctx, w, h, u, top, ch, t) {
  const r = rng(131);
  for (let i = 0; i < 18; i++) {
    const ti = 2.65 + r() * 1.0, x1 = w * (0.2 + 0.6 * r()), y0 = h * (0.1 + 0.8 * r()), y1 = top + ch * (0.12 + 0.55 * r()), ph = r() * TAU, big = 0.6 + r() * 0.8;
    const p = (t - ti) / 1.7; if (p < 0 || p > 1.4) continue;
    const e = smooth(Math.min(p, 1)), sx = (i % 2 ? -0.12 : 1.12) * w, ex = Math.max(0, p - 1);
    const x = mix(sx, x1, e) + (x1 - sx) * ex * 1.1 + Math.sin(t * 3 + ph) * u * 0.03, y = mix(y0, y1, e) + Math.sin(t * 4 + ph) * u * 0.03 - ex * h * 0.7;
    drawBat(ctx, x, y, u * (0.05 + 0.09 * e) * big, Math.sin(t * 16 + ph));
  }
}
function drawEyePair(ctx, x, y, s, open, col, look) {
  if (open <= 0.01) return;
  for (const sd of [-1, 1]) {
    ctx.save(); ctx.translate(x + sd * s * 0.62, y);
    const gl = ctx.createRadialGradient(0, 0, 0, 0, 0, s * 1.2); gl.addColorStop(0, rgba(col, 0.45 * open)); gl.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(0, 0, s * 1.2, 0, TAU); ctx.fill();
    ctx.scale(1, Math.max(0.04, open));
    const g = ctx.createRadialGradient(0, 0, s * 0.05, 0, 0, s * 0.5); g.addColorStop(0, '#FFFFD0'); g.addColorStop(0.5, col); g.addColorStop(1, rgba(col, 0.3));
    ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.48, s * 0.34, sd * -0.22, 0, TAU); ctx.fill();
    ctx.fillStyle = '#0A0510'; ctx.beginPath(); ctx.ellipse(look * s * 0.1, 0, s * 0.07, s * 0.3, 0, 0, TAU); ctx.fill();
    ctx.restore();
  }
}
function drawEyes(ctx, w, h, u, top, ch, t) {
  const r = rng(141);
  for (let i = 0; i < 9; i++) {
    const ti = 2.7 + i * 0.16 + r() * 0.1, x = w * (0.14 + 0.72 * r()), y = top + ch * (0.1 + 0.8 * r()), s = u * (0.035 + 0.05 * r()), col = (i % 3 === 0) ? '#FF3B3B' : '#C6FF3B', ph = r() * TAU;
    const a = clamp((t - ti) / 0.25), fade = 1 - clamp((t - 4.9) / 0.35), bl = Math.sin(t * 1.9 + ph);
    drawEyePair(ctx, x, y, s, a * fade * (bl > 0.93 ? 1 - (bl - 0.93) / 0.07 * 0.95 : 1), col, Math.sin(t + ph));
  }
  if (t >= 4.1 && t < 5.4) {
    const p = easeIn((t - 4.1) / 0.5), open = t < 4.8 ? 1 : 1 - smooth((t - 4.8) / 0.3);
    drawEyePair(ctx, w / 2, top + ch * 0.45, u * (0.06 + 0.42 * p), open, '#FF3B3B', 0);
  }
}

/* ---------- Scare timeline (spider, ghost, bats, eyes) ---------- */
const SCARE_AT = 2.4;
function scareState(t, kind) {
  const a = SCARE_AT, R = { dark: 0, shake: 0, flash: 0, flashCol: '#FF1E1E', cr: null, shout: '', shoutY: 0.2, asan: 0, confetti: 0, moon: 0 };
  if (t >= a && t < a + 0.25) R.dark = (Math.floor((t - a) * 30) % 2) ? 0.92 : 0.3;
  else if (t >= a + 0.25 && t < 5.0) R.dark = kind === 'bats' ? 0.88 : 0.92;
  else if (t >= 5.0 && t < 5.6) R.dark = (kind === 'bats' ? 0.88 : 0.92) * (1 - smooth((t - 5.0) / 0.6));
  if (kind === 'spider') {
    if (t >= 2.65 && t < 5.5) {
      let y, sc;
      if (t < 3.2) { const p = easeIn((t - 2.65) / 0.55); y = mix(-0.25, 0.46, p); sc = mix(0.5, 1.5, p); }
      else if (t < 4.8) { y = 0.46 + Math.sin(t * 3.2) * 0.012; sc = 1.5 + Math.sin(t * 5) * 0.03; }
      else { const p = easeIn((t - 4.8) / 0.7); y = mix(0.46, -0.4, p); sc = 1.5; }
      R.cr = { kind: 'spider', y, sc };
    }
    if (t >= 3.2 && t < 4.2) R.shake = Math.exp(-(t - 3.2) * 5); else if (t >= 4.2 && t < 4.8) R.shake = 0.08;
    if (t >= 3.2) R.flash = 0.4 * Math.exp(-(t - 3.2) * 8);
  } else if (kind === 'ghost') {
    if (t >= 2.65 && t < 5.6) {
      let y = 0.46, sc, al = 1, mo = 0.5;
      if (t < 3.25) { const p = easeIn((t - 2.65) / 0.6); sc = mix(0.03, 1.0, p); mo = 0.2; }
      else if (t < 4.7) { sc = 1.0 + Math.sin(t * 4) * 0.03; mo = 0.5 + 0.5 * Math.sin(t * 9); }
      else { const p = easeIn((t - 4.7) / 0.9); sc = 1.0 + p * 0.3; y = mix(0.46, -0.45, p); al = 1 - smooth((t - 4.9) / 0.6); }
      R.cr = { kind: 'ghost', y, sc, al, mo, sway: (t >= 3.25 && t < 4.7) ? Math.sin(t * 2.1) : 0 };
    }
    if (t >= 3.25 && t < 4.7) { R.shout = 'БҮҮҮ!'; R.shake = 0.12; }
    if (t >= 3.25) R.flash = 0.55 * Math.exp(-(t - 3.25) * 9);
    R.flashCol = '#FFFFFF';
  } else if (kind === 'bats') {
    if (t >= 2.65 && t < 5.6) { R.cr = { kind: 'bats' }; R.moon = smooth((t - 2.65) / 0.5) * (1 - smooth((t - 5.0) / 0.6)); }
    if (t >= 2.9) R.flash = 0.3 * Math.exp(-(t - 2.9) * 8);
    R.flashCol = '#FFFFFF';
    if (t >= 3.4 && t < 4.6) R.shake = 0.05;
  } else if (X.HSCARE[kind]) {
    X.HSCARE[kind](t, R);
  } else {
    if (t >= 2.65 && t < 5.5) R.cr = { kind: 'eyes' };
    if (t >= 4.1) R.flash = 0.4 * Math.exp(-(t - 4.1) * 7);
    if (t >= 4.1 && t < 4.8) R.shake = 0.1;
  }
  if (R.darkK != null) R.dark *= R.darkK;
  if (t >= 5.5) R.asan = clamp((t - 5.5) / 0.35) * (t < 6.8 ? 1 : 1 - clamp((t - 6.8) / 0.4));
  R.confetti = t - 5.5;
  return R;
}
/* Sound cues fired between times a and b. */
function events(fx, a, b) {
  const out = [], cross = x => a < x && b >= x;
  if (fx === 'fireworks') { for (let k = Math.max(0, Math.floor((a - 0.72) / FW_P)); k <= Math.floor((b - 0.72) / FW_P); k++) if (cross(k * FW_P + 0.72)) out.push('burst'); }
  else if (fx === 'cannon') { for (let k = Math.max(0, Math.floor((a - 0.35) / CAN_P)); k <= Math.floor((b - 0.35) / CAN_P); k++) if (cross(k * CAN_P + 0.35)) out.push('burst'); }
  else if (fx === 'spider') { if (cross(2.45)) out.push('riser'); if (cross(3.2)) out.push('impact'); if (cross(5.5)) out.push('end'); }
  else if (fx === 'ghost') { if (cross(2.45)) out.push('riser'); if (cross(3.25)) out.push('boo'); if (cross(5.5)) out.push('end'); }
  else if (fx === 'bats') { if (cross(2.45)) out.push('riser'); if (cross(2.9)) out.push('impact'); if (cross(5.5)) out.push('end'); }
  else if (fx === 'eyes') { if (cross(2.45)) out.push('riser'); if (cross(4.1)) out.push('boo'); if (cross(5.5)) out.push('end'); }
  else if (X.EVENTS[fx]) return X.EVENTS[fx](cross);
  return out;
}

/* ---------- Text ---------- */
let TL = { key: '', v: null };
const F_NAME = 'Rubik,"Noto Sans",system-ui,sans-serif', F_TITLE = 'Pacifico,cursive', F_MSG = 'Nunito,"Noto Sans",system-ui,sans-serif';
function fitFont(ctx, str, fam, wt, maxW, start, min) { let s = start; const step = Math.max(0.5, start * 0.04); while (s > min) { ctx.font = `${wt} ${s}px ${fam}`; if (ctx.measureText(str).width <= maxW) break; s -= step; } return s; }
function wrapText(ctx, text, maxW) { const words = text.split(/\s+/).filter(Boolean), lines = []; let cur = ''; for (const wd of words) { const test = cur ? cur + ' ' + wd : wd; if (ctx.measureText(test).width <= maxW || !cur) cur = test; else { lines.push(cur); cur = wd; } } if (cur) lines.push(cur); return lines; }
function textLayout(ctx, w, h, u, R) {
  const key = [w | 0, h | 0, R.name, R.title, R.msg, R.from].join('|');
  if (TL.key === key) return TL.v;
  const v = {};
  v.nameSz = fitFont(ctx, R.name, F_NAME, 800, w * 0.84, u * 0.17, u * 0.06);
  v.titleSz = fitFont(ctx, R.title, F_TITLE, 400, w * 0.86, u * 0.09, u * 0.04);
  let sz = u * 0.046, lines;
  for (; ;) { ctx.font = `600 ${sz}px ${F_MSG}`; lines = wrapText(ctx, R.msg, w * 0.78); if (lines.length <= 5 || sz < u * 0.032) break; sz *= 0.93; }
  v.msgSz = sz; v.lines = lines;
  TL = { key, v }; return v;
}
function drawTexts(ctx, w, h, u, ch, top, th, R) {
  const v = textLayout(ctx, w, h, u, R);
  ctx.save(); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  ctx.shadowColor = th.light ? 'rgba(255,255,255,.6)' : 'rgba(0,0,0,.35)'; ctx.shadowBlur = u * 0.02; ctx.shadowOffsetY = u * 0.006;
  ctx.fillStyle = th.ink; ctx.font = `800 ${v.nameSz}px ${F_NAME}`; ctx.fillText(R.name, w / 2, top + ch * 0.565);
  ctx.fillStyle = th.a; ctx.font = `400 ${v.titleSz}px ${F_TITLE}`; ctx.fillText(R.title, w / 2, top + ch * 0.655);
  ctx.fillStyle = th.soft; ctx.font = `600 ${v.msgSz}px ${F_MSG}`;
  const lh = v.msgSz * 1.42; v.lines.forEach((ln, i) => ctx.fillText(ln, w / 2, top + ch * 0.725 + i * lh));
  if (R.from) { ctx.fillStyle = th.ink; ctx.font = `400 ${u * 0.05}px ${F_TITLE}`; ctx.fillText('— ' + R.from, w / 2, top + ch * 0.955); }
  ctx.restore();
}

/* ---------- Scene ---------- */
function render(ctx, w, h, t, R) {
  const th = THEMES[R.theme] || THEMES.sun, u = Math.min(w, h * 0.64), ch = Math.min(h, w * 1.8), top = (h - ch) / 2;
  const fxd = FXS[R.fx] || FXS.confetti, scare = !!fxd.scare, T = scare ? scareState(t, R.fx) : null, fx = FXR[R.fx] || {};
  ctx.save(); ctx.clearRect(0, 0, w, h);
  if (T && T.shake) ctx.translate(Math.sin(t * 83) * T.shake * u * 0.03, Math.cos(t * 67) * T.shake * u * 0.03);
  drawBg(ctx, w, h, u, th, t, R); drawTwinkles(ctx, w, h, u, th, t);
  if (fx.fn && !fx.front) fx.fn(ctx, w, h, u, th, t);
  const mcx = w / 2, mcy = top + ch * 0.25, ms = u * 0.5;
  if (R.photoEl && ready(R.photoEl)) drawPhoto(ctx, mcx, mcy, ms, th, R.photoEl, t);
  else if (R.stickerEl && ready(R.stickerEl)) drawSticker(ctx, mcx, mcy, ms, R.stickerEl, t);
  else (MOTIFS[R.motif && MOTIFS[R.motif] ? R.motif : (OCC[R.occ] || OCC.other).motif] || MOTIFS.burst)(ctx, mcx, mcy, ms, th, t);
  drawTexts(ctx, w, h, u, ch, top, th, R);
  if (fx.fn && fx.front) fx.fn(ctx, w, h, u, th, t);
  if (T) {
    if (T.confetti > 0) { ctx.globalAlpha = clamp(T.confetti / 0.3); fxConfetti(ctx, w, h, u, th, T.confetti, { fromTop: true }); ctx.globalAlpha = 1; }
    if (T.dark > 0) { ctx.fillStyle = `rgba(4,2,10,${T.dark})`; ctx.fillRect(-40, -40, w + 80, h + 80); }
    if (T.moon > 0) { ctx.save(); ctx.globalAlpha = T.moon; drawMoon(ctx, w / 2, top + ch * 0.3, u * 0.3); ctx.restore(); }
    if (T.cr) {
      const c = T.cr, cx = w / 2;
      if (c.kind === 'spider') { const s = u * 0.14 * c.sc, cy = top + ch * c.y; ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = Math.max(1.5, u * 0.005); ctx.beginPath(); ctx.moveTo(cx, -40); ctx.lineTo(cx, cy - s * 0.6); ctx.stroke(); drawSpider(ctx, cx, cy, s, t); }
      else if (c.kind === 'ghost') drawGhost(ctx, cx + c.sway * u * 0.07, top + ch * c.y, u * 0.34 * c.sc, t, c.mo, c.al);
      else if (c.kind === 'bats') drawBats(ctx, w, h, u, top, ch, t);
      else if (X.HDRAW[c.kind]) X.HDRAW[c.kind](ctx, w, h, u, top, ch, t, c);
      else drawEyes(ctx, w, h, u, top, ch, t);
    }
    if (T.shout) { ctx.save(); ctx.textAlign = 'center'; ctx.lineJoin = 'round'; const fs = fitFont(ctx, T.shout, F_NAME, 800, w * 0.88, u * 0.22, u * 0.08); ctx.translate(w / 2 + Math.sin(t * 60) * u * 0.01, top + ch * T.shoutY + Math.cos(t * 47) * u * 0.01); ctx.font = `800 ${fs}px ${F_NAME}`; ctx.lineWidth = u * 0.02; ctx.strokeStyle = '#1B0B3A'; ctx.strokeText(T.shout, 0, 0); ctx.fillStyle = '#FFFFFF'; ctx.fillText(T.shout, 0, 0); ctx.restore(); }
    if (T.flash > 0.01) { const g = ctx.createRadialGradient(w / 2, h / 2, u * 0.1, w / 2, h / 2, Math.max(w, h) * 0.8); g.addColorStop(0, rgba(T.flashCol, T.flash * 0.35)); g.addColorStop(1, rgba(T.flashCol, T.flash)); ctx.fillStyle = g; ctx.fillRect(-40, -40, w + 80, h + 80); }
    if (T.asan > 0) { const p = T.asan, sc = 0.5 + 0.5 * easeOut(p) + 0.06 * Math.sin(p * Math.PI); ctx.save(); ctx.globalAlpha = clamp(p * 1.4); ctx.translate(w / 2, top + ch * 0.5); ctx.scale(sc, sc); ctx.textAlign = 'center'; ctx.font = `400 ${u * 0.17}px ${F_TITLE}`; ctx.lineWidth = u * 0.025; ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(20,8,40,.85)'; ctx.strokeText('Айсан уу?', 0, 0); ctx.fillStyle = th.a; ctx.fillText('Айсан уу?', 0, 0); ctx.restore(); }
  }
  ctx.restore();
}
function resetTextCache() { TL.key = ''; }

/* ---------- Sound ---------- */
const PRESETS = {
  tada: { name: 'Тада', ops: [{ t: 'tone', f: 523, d: .45, w: 'triangle', v: .12, at: 0 }, { t: 'tone', f: 659, d: .45, w: 'triangle', v: .12, at: .09 }, { t: 'tone', f: 784, d: .45, w: 'triangle', v: .12, at: .18 }, { t: 'tone', f: 1047, d: .6, w: 'triangle', v: .12, at: .27 }] },
  pop: { name: 'Паф', ops: [{ t: 'noise', d: .3, v: .12, hp: 1500 }, { t: 'tone', f: 200, d: .25, w: 'sine', v: .1, to: 60 }] },
  riser: { name: 'Өсөх дуу', ops: [{ t: 'tone', f: 120, d: .6, w: 'sawtooth', v: .08, to: 700 }] },
  sting: { name: 'Айлгах цохилт', ops: [{ t: 'tone', f: 90, d: .9, w: 'sawtooth', v: .22, to: 40 }, { t: 'tone', f: 1500, d: .5, w: 'square', v: .06, to: 300 }, { t: 'noise', d: .7, v: .25, hp: 200 }] },
  boo: { name: 'Бүү', ops: [{ t: 'tone', f: 230, d: 1.0, w: 'sawtooth', v: .2, to: 70 }, { t: 'noise', d: .5, v: .16, hp: 300 }] },
  chime: { name: 'Хонх', ops: [{ t: 'tone', f: 880, d: .8, w: 'sine', v: .12 }, { t: 'tone', f: 1320, d: .9, w: 'sine', v: .08, at: .12 }, { t: 'tone', f: 1760, d: 1, w: 'sine', v: .05, at: .24 }] },
  whoosh: { name: 'Сэвшээ', ops: [{ t: 'noise', d: .9, v: .14, hp: 400 }, { t: 'tone', f: 300, d: .8, w: 'sine', v: .04, to: 900 }] },
  drum: { name: 'Бөмбөр', ops: [{ t: 'tone', f: 140, d: .35, w: 'sine', v: .3, to: 45 }, { t: 'noise', d: .15, v: .15, hp: 2500 }] },
  zap: { name: 'Цахилгаан', ops: [{ t: 'tone', f: 1800, d: .25, w: 'square', v: .08, to: 120 }] },
  fanfare: { name: 'Фанфар', ops: [{ t: 'tone', f: 392, d: .25, w: 'square', v: .07, at: 0 }, { t: 'tone', f: 523, d: .25, w: 'square', v: .07, at: .18 }, { t: 'tone', f: 659, d: .25, w: 'square', v: .07, at: .36 }, { t: 'tone', f: 784, d: .6, w: 'square', v: .07, at: .54 }] },
  bell: { name: 'Хонхны дуу', ops: [{ t: 'tone', f: 660, d: 1.2, w: 'sine', v: .12 }, { t: 'tone', f: 1320, d: 1.0, w: 'sine', v: .06 }] },
  silence: { name: 'Дуугүй', ops: [] }
};
const CUES = { open: 'Нээгдэх үед', burst: 'Салют, буу', riser: 'Айлгахын өмнө', impact: 'Цохилт', boo: 'Бүү', end: 'Айсан уу?' };
const DEFAULT_SFX = { open: 'tada', burst: 'pop', riser: 'riser', impact: 'sting', boo: 'boo', end: 'tada' };
const Sound = {
  ac: null, muted: false, vol: 1, map: {}, lib: {}, files: {},
  init() { try { Sound.ac = Sound.ac || new (root.AudioContext || root.webkitAudioContext)(); if (Sound.ac.state === 'suspended') Sound.ac.resume(); } catch (e) { Sound.ac = null; } },
  setLibrary(docs) { Sound.lib = {}; (docs || []).forEach(d => { Sound.lib[d.id] = d; }); },
  setMap(m) { Sound.map = m || {}; },
  tone(f, d, type, vol, delay, to) {
    const ac = Sound.ac; if (!ac || Sound.muted) return; const n = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.setValueAtTime(f, n); if (to) o.frequency.exponentialRampToValueAtTime(Math.max(1, to), n + d);
    g.gain.setValueAtTime(0.0001, n); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), n + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, n + d);
    o.connect(g); g.connect(ac.destination); o.start(n); o.stop(n + d + 0.05);
  },
  noise(d, vol, delay, hp) {
    const ac = Sound.ac; if (!ac || Sound.muted) return; const n = ac.currentTime + (delay || 0), len = Math.max(1, Math.floor(ac.sampleRate * d)), buf = ac.createBuffer(1, len, ac.sampleRate), da = buf.getChannelData(0);
    for (let i = 0; i < len; i++) da[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = ac.createBufferSource(); s.buffer = buf; const f = ac.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp || 600; const g = ac.createGain(); g.gain.value = vol;
    s.connect(f); f.connect(g); g.connect(ac.destination); s.start(n);
  },
  runOps(ops, vol, pitch) {
    ops.forEach(o => { if (o.t === 'tone') Sound.tone(o.f * pitch, o.d, o.w, o.v * vol, o.at, o.to ? o.to * pitch : 0); else Sound.noise(o.d, o.v * vol, o.at, o.hp); });
  },
  async playFile(doc, vol, pitch) {
    const ac = Sound.ac; if (!ac || Sound.muted || !doc.file) return;
    try {
      let buf = Sound.files[doc.id];
      if (!buf) {
        let ab;
        if (doc.file.url) ab = await (await fetch(doc.file.url)).arrayBuffer();
        else { const bin = atob(doc.file.data), arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i); ab = arr.buffer; }
        buf = await ac.decodeAudioData(ab); Sound.files[doc.id] = buf;
      }
      const s = ac.createBufferSource(); s.buffer = buf; s.playbackRate.value = pitch; const g = ac.createGain(); g.gain.value = vol; s.connect(g); g.connect(ac.destination); s.start();
    } catch (e) { /* unplayable file: stay silent */ }
  },
  playPreset(id) {
    const vol = Sound.vol;
    let doc = Sound.lib[id];
    if (doc) { const v = (doc.vol == null ? 1 : doc.vol) * vol, p = doc.pitch || 1; if (doc.file) return Sound.playFile(doc, v, p); const base = PRESETS[doc.base] || PRESETS.pop; return Sound.runOps(base.ops, v, p); }
    const b = PRESETS[id]; if (b) Sound.runOps(b.ops, vol, 1);
  },
  play(cue, ovr) { const id = (ovr && ovr[cue]) || Sound.map[cue] || DEFAULT_SFX[cue]; if (id) Sound.playPreset(id); }
};

/* Extension point: packs (see halloween.js) add themes, effects, creatures, motifs and sounds through this object. */
const X = {
  TAU, clamp, mix, smooth, easeOut, easeIn, rng, rgba, hexMix, rr, heart, sparkle, drawGhost, drawBats, fitFont, F_NAME, F_TITLE, F_MSG,
  THEMES, THEME_IDS, FXS, FX_IDS, FXR, OCC, OCC_IDS, THUMB_T, FINAL_T, LOOP, PRESETS, CUES, DEFAULT_SFX, MOTIFS,
  OCC_ORDER: OCC_IDS.slice(), THEME_ORDER: THEME_IDS.slice(), MOTIF_NAMES: {}, BUILTIN_TPL: [],
  HSCARE: {}, HDRAW: {}, EVENTS: {}
};
root.Mend = {
  THEMES, THEME_IDS, FXS, FX_IDS, OCC, OCC_IDS, THUMB_T, FINAL_T, LOOP, PRESETS, CUES, DEFAULT_SFX,
  OCC_ORDER: X.OCC_ORDER, THEME_ORDER: X.THEME_ORDER, MOTIF_NAMES: X.MOTIF_NAMES, BUILTIN_TPL: X.BUILTIN_TPL, ext: X,
  render, events, occFx, buildTheme, registerTheme, unregisterThemes, resetTextCache, Sound, lum, hexMix, ready
};
})(typeof window !== 'undefined' ? window : globalThis);

;
/* halloween.js — the Halloween pack: cute-but-startling creatures, colours, motifs, sounds and ready-made designs.
   Everything is a pure function of time, like the rest of the engine. Registered through Mend.ext. */
(function () {
'use strict';
const M = window.Mend, X = M.ext;
const { TAU, clamp, mix, smooth, easeOut, easeIn, rng, rgba, rr, sparkle, heart } = X;
const easeBack = x => { x = clamp(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
const pulse = (q, a, b, f) => smooth((q - a) / f) * (1 - smooth((q - b) / f));
const A = 2.65;

/* ---------- small drawing helpers ---------- */
function disc(ctx, x, y, r, fill) { ctx.fillStyle = fill; ctx.beginPath(); ctx.arc(x, y, Math.max(0.01, r), 0, TAU); ctx.fill(); }
function oval(ctx, x, y, rx, ry, fill, rot) { ctx.fillStyle = fill; ctx.beginPath(); ctx.ellipse(x, y, Math.max(0.01, rx), Math.max(0.01, ry), rot || 0, 0, TAU); ctx.fill(); }
function googly(ctx, x, y, r, px, py) {
  disc(ctx, x, y, r, '#FFFFFF'); ctx.strokeStyle = 'rgba(30,10,50,.45)'; ctx.lineWidth = r * 0.14; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke();
  const ox = x + px * r * 0.42, oy = y + py * r * 0.42; disc(ctx, ox, oy, r * 0.46, '#170A22'); disc(ctx, ox - r * 0.14, oy - r * 0.16, r * 0.14, '#FFFFFF');
}
function blush(ctx, x, y, r) { oval(ctx, x, y, r, r * 0.6, 'rgba(255,92,150,.45)'); }
function tri(ctx, x1, y1, x2, y2, x3, y3, fill) { ctx.fillStyle = fill; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.lineTo(x3, y3); ctx.closePath(); ctx.fill(); }

/* ---------- Pumpkin ---------- */
function drawPumpkin(ctx, x, y, s, o) {
  o = o || {}; const glow = o.glow == null ? 1 : o.glow, mo = o.mouth || 0, tg = o.tongue || 0, wk = o.wink || 0;
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot || 0); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  const g = ctx.createRadialGradient(0, 0, s * 0.3, 0, 0, s * 2.2); g.addColorStop(0, rgba('#FFB000', 0.4 * glow)); g.addColorStop(1, rgba('#FFB000', 0));
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s * 2.2, 0, TAU); ctx.fill();
  [[-0.66, 0.5, 0.8, '#C24A07'], [0.66, 0.5, 0.8, '#C24A07'], [-0.33, 0.56, 0.88, '#E4620E'], [0.33, 0.56, 0.88, '#E4620E'], [0, 0.56, 0.93, '#FF8A1F']].forEach(l => {
    oval(ctx, l[0] * s, 0.04 * s, l[1] * s, l[2] * s, l[3]); ctx.strokeStyle = 'rgba(95,25,0,.45)'; ctx.lineWidth = s * 0.03; ctx.stroke();
  });
  oval(ctx, -0.52 * s, -0.5 * s, 0.16 * s, 0.26 * s, 'rgba(255,255,255,.17)', -0.5);
  ctx.fillStyle = '#5E7F2B'; ctx.beginPath(); ctx.moveTo(-0.15 * s, -0.78 * s); ctx.quadraticCurveTo(-0.1 * s, -1.14 * s, 0.14 * s, -1.26 * s); ctx.lineTo(0.32 * s, -1.14 * s); ctx.quadraticCurveTo(0.14 * s, -1.0 * s, 0.17 * s, -0.78 * s); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#86C443'; ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.moveTo(0.2 * s, -0.96 * s); ctx.bezierCurveTo(0.62 * s, -1.02 * s, 0.78 * s, -0.76 * s, 0.56 * s, -0.7 * s); ctx.stroke();
  ctx.shadowColor = '#FFB000'; ctx.shadowBlur = s * 0.32 * glow; ctx.fillStyle = '#FFE066'; ctx.strokeStyle = '#4A1500'; ctx.lineWidth = s * 0.035;
  const T3 = (cx, cy, w, hh) => { ctx.beginPath(); ctx.moveTo(cx, cy - hh / 2); ctx.lineTo(cx + w / 2, cy + hh / 2); ctx.lineTo(cx - w / 2, cy + hh / 2); ctx.closePath(); };
  T3(-0.52 * s, -0.24 * s, 0.4 * s, 0.4 * s); ctx.fill(); ctx.stroke();
  const rh = 0.4 * s * (1 - wk * 0.86); T3(0.52 * s, -0.24 * s + (0.4 * s - rh) / 2, 0.4 * s, rh); ctx.fill(); ctx.stroke();
  T3(0, 0.03 * s, 0.17 * s, 0.15 * s); ctx.fill(); ctx.stroke();
  const yb = 0.2 * s, ab = (0.22 + 0.34 * mo) * s;
  ctx.beginPath(); ctx.moveTo(-0.82 * s, yb); ctx.quadraticCurveTo(0, yb + 0.22 * s, 0.82 * s, yb); ctx.quadraticCurveTo(0, yb + 2 * ab, -0.82 * s, yb); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.save(); ctx.clip(); ctx.fillStyle = '#E4620E';
  for (const px of [-0.54, -0.13, 0.28]) { ctx.beginPath(); ctx.moveTo(px * s, yb - 0.06 * s); ctx.lineTo((px + 0.27) * s, yb - 0.06 * s); ctx.lineTo((px + 0.135) * s, yb + 0.3 * s); ctx.closePath(); ctx.fill(); }
  if (mo > 0.3) for (const px of [-0.36, 0.1]) { const u0 = (px * s + 0.82 * s) / (1.64 * s), ly = yb + 2 * ab * u0 * (1 - u0); ctx.beginPath(); ctx.moveTo(px * s, ly + 0.04 * s); ctx.lineTo((px + 0.24) * s, ly + 0.04 * s); ctx.lineTo((px + 0.12) * s, ly - 0.2 * s); ctx.closePath(); ctx.fill(); }
  ctx.restore();
  if (tg > 0.02) {
    const tx = 0.22 * s, u1 = (tx + 0.82 * s) / (1.64 * s), ly = yb + 2 * ab * u1 * (1 - u1);
    oval(ctx, tx, ly + 0.1 * s * tg, 0.2 * s * (0.5 + 0.5 * tg), 0.26 * s * tg, '#FF5C8A'); ctx.strokeStyle = 'rgba(120,10,50,.5)'; ctx.lineWidth = s * 0.025; ctx.beginPath(); ctx.moveTo(tx, ly); ctx.lineTo(tx, ly + 0.2 * s * tg); ctx.stroke();
  }
  blush(ctx, -0.86 * s, 0.06 * s, 0.13 * s); blush(ctx, 0.86 * s, 0.06 * s, 0.13 * s);
  ctx.restore();
}

/* ---------- Mummy ---------- */
function drawMummy(ctx, x, y, s, o) {
  const t = o.t || 0, arm = o.arms == null ? 1 : o.arms, cross = o.cross || 0, mo = o.mouth || 0, rg = rng(77);
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.rot || 0); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.fillStyle = '#E3D8BC'; rr(ctx, -0.62 * s, 0.5 * s, 1.24 * s, 2.6 * s, 0.35 * s); ctx.fill();
  ctx.save(); rr(ctx, -0.62 * s, 0.5 * s, 1.24 * s, 2.6 * s, 0.35 * s); ctx.clip(); ctx.strokeStyle = 'rgba(110,90,55,.35)'; ctx.lineWidth = s * 0.02;
  for (let i = 0; i < 6; i++) { const yy = (0.7 + i * 0.26) * s; ctx.beginPath(); ctx.moveTo(-0.7 * s, yy + (rg() - 0.5) * 0.1 * s); ctx.lineTo(0.7 * s, yy + (rg() - 0.5) * 0.1 * s); ctx.stroke(); } ctx.restore();
  for (const sd of [-1, 1]) {
    ctx.save(); ctx.translate(sd * 0.5 * s, 0.85 * s); ctx.scale(sd, 1); ctx.rotate(-0.5 - 0.62 * arm + Math.sin(t * 9 + sd) * 0.07 * arm);
    ctx.fillStyle = '#E3D8BC'; rr(ctx, 0, -0.19 * s, 1.0 * s, 0.38 * s, 0.19 * s); ctx.fill();
    ctx.strokeStyle = 'rgba(110,90,55,.45)'; ctx.lineWidth = s * 0.025; for (let k = 1; k < 5; k++) { ctx.beginPath(); ctx.moveTo(k * 0.2 * s, -0.19 * s); ctx.lineTo(k * 0.2 * s - 0.05 * s, 0.19 * s); ctx.stroke(); }
    ctx.restore();
  }
  ctx.fillStyle = '#EFE6CE'; rr(ctx, -0.8 * s, -0.95 * s, 1.6 * s, 1.7 * s, 0.72 * s); ctx.fill();
  ctx.save(); rr(ctx, -0.8 * s, -0.95 * s, 1.6 * s, 1.7 * s, 0.72 * s); ctx.clip();
  const rg2 = rng(78);
  for (let i = 0; i < 9; i++) {
    ctx.save(); ctx.translate(0, -0.98 * s + i * 0.21 * s); ctx.rotate((rg2() - 0.5) * 0.4); ctx.fillStyle = i % 2 ? '#E1D6BA' : '#F6EFDB'; ctx.fillRect(-1 * s, 0, 2 * s, 0.17 * s);
    ctx.fillStyle = 'rgba(90,70,40,.22)'; ctx.fillRect(-1 * s, 0.17 * s, 2 * s, 0.025 * s); ctx.restore();
  }
  ctx.restore();
  ctx.fillStyle = '#1B1030'; rr(ctx, -0.64 * s, -0.42 * s, 1.28 * s, 0.5 * s, 0.24 * s); ctx.fill();
  for (const sd of [-1, 1]) googly(ctx, sd * 0.29 * s, -0.17 * s, 0.21 * s, -sd * cross * 0.9 + Math.sin(t * 3 + sd) * 0.35 * (1 - cross), 0.15 * cross + Math.cos(t * 2.3) * 0.2 * (1 - cross));
  oval(ctx, 0, 0.4 * s, 0.14 * s * (0.65 + 0.55 * mo), 0.1 * s * (0.5 + 0.9 * mo), '#2A1020');
  ctx.strokeStyle = '#F6EFDB'; ctx.lineWidth = s * 0.15; ctx.beginPath(); ctx.moveTo(0.46 * s, -0.84 * s); ctx.bezierCurveTo(1.1 * s + Math.sin(t * 6) * 0.15 * s, -1.25 * s, 1.35 * s, -0.55 * s + Math.cos(t * 5) * 0.2 * s, 1.05 * s, -0.3 * s + Math.sin(t * 7) * 0.12 * s); ctx.stroke();
  ctx.strokeStyle = 'rgba(90,70,40,.3)'; ctx.lineWidth = s * 0.03; ctx.stroke();
  ctx.restore();
}

/* ---------- Skull and skeleton ---------- */
function drawSkull(ctx, x, y, s, o) {
  const bone = '#F6F1E2', edge = '#CBBFA2', jaw = (o.jaw || 0) * 0.22 * s, lk = o.look || 0;
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.tilt || 0); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.strokeStyle = edge; ctx.lineWidth = s * 0.04;
  ctx.fillStyle = bone; rr(ctx, -0.48 * s, 0.36 * s + jaw, 0.96 * s, 0.4 * s, 0.17 * s); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = 'rgba(80,60,40,.5)'; ctx.lineWidth = s * 0.03; for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(i * 0.16 * s, 0.45 * s + jaw); ctx.lineTo(i * 0.16 * s, 0.72 * s + jaw); ctx.stroke(); }
  ctx.strokeStyle = edge; ctx.lineWidth = s * 0.04; ctx.fillStyle = bone;
  ctx.beginPath(); ctx.ellipse(0, 0, 0.8 * s, 0.74 * s, 0, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-0.55 * s, 0.3 * s); ctx.quadraticCurveTo(-0.5 * s, 0.52 * s, -0.4 * s, 0.5 * s); ctx.lineTo(0.4 * s, 0.5 * s); ctx.quadraticCurveTo(0.5 * s, 0.52 * s, 0.55 * s, 0.3 * s); ctx.fill();
  ctx.strokeStyle = 'rgba(80,60,40,.5)'; ctx.lineWidth = s * 0.03; for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(i * 0.16 * s, 0.4 * s); ctx.lineTo(i * 0.16 * s, 0.52 * s); ctx.stroke(); }
  for (const sd of [-1, 1]) {
    oval(ctx, sd * 0.3 * s, -0.04 * s, 0.22 * s, 0.26 * s, '#1B0F2A', sd * 0.12);
    ctx.shadowColor = '#FF9A2E'; ctx.shadowBlur = s * 0.2; disc(ctx, sd * 0.3 * s + lk * 0.05 * s, -0.02 * s, 0.075 * s, '#FFB347'); ctx.shadowBlur = 0;
  }
  tri(ctx, -0.07 * s, 0.26 * s, 0.07 * s, 0.26 * s, 0, 0.14 * s, '#1B0F2A');
  blush(ctx, -0.6 * s, 0.22 * s, 0.1 * s); blush(ctx, 0.6 * s, 0.22 * s, 0.1 * s);
  ctx.restore();
}
function drawSkeleton(ctx, x, y, s, o) {
  const bone = '#F6F1E2', edge = '#CBBFA2', sway = o.sway || 0, lift = (o.lift || 0) * s;
  ctx.save(); ctx.translate(x, y); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const stroke2 = (w) => { ctx.strokeStyle = edge; ctx.lineWidth = w + s * 0.04; ctx.stroke(); ctx.strokeStyle = bone; ctx.lineWidth = w; ctx.stroke(); };
  ctx.beginPath(); ctx.moveTo(sway * s * 0.2, 0.7 * s); ctx.lineTo(0, 2.6 * s); stroke2(s * 0.14);
  for (let i = 0; i < 3; i++) { const yy = (1.2 + i * 0.34) * s, w = (0.66 - i * 0.07) * s; ctx.beginPath(); ctx.moveTo(-w, yy - 0.1 * s); ctx.quadraticCurveTo(0, yy + 0.26 * s, w, yy - 0.1 * s); stroke2(s * 0.12); }
  for (const sd of [-1, 1]) {
    const a = (sd < 0 ? o.armL : o.armR) || 0, sx = sd * 0.7 * s, sy = 1.08 * s, f1 = 0.5 + a, ex = sx + sd * Math.sin(f1) * 0.95 * s, ey = sy + Math.cos(f1) * 0.95 * s, f2 = f1 + 0.5, hx = ex + sd * Math.sin(f2) * 0.8 * s, hy = ey + Math.cos(f2) * 0.8 * s;
    ctx.beginPath(); ctx.moveTo(sd * 0.1 * s, 1.0 * s); ctx.lineTo(sx, sy); ctx.lineTo(ex, ey); ctx.lineTo(hx, hy); stroke2(s * 0.12);
    disc(ctx, ex, ey, s * 0.11, bone); oval(ctx, hx, hy, 0.17 * s, 0.14 * s, bone);
  }
  drawSkull(ctx, sway * s * 0.25, -lift, s, { jaw: o.jaw, look: o.look, tilt: sway * 0.12 });
  ctx.restore();
}

/* ---------- Zombie hand ---------- */
function drawHand(ctx, x, y, s, o) {
  const skin = '#86C85A', dk = '#4F9232', curl = o.curl || 0, lk = o.look || 0;
  ctx.save(); ctx.translate(x, y); ctx.rotate(o.wave || 0); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.fillStyle = skin; ctx.beginPath(); ctx.moveTo(-0.34 * s, 0); ctx.lineTo(-0.42 * s, 3.2 * s); ctx.lineTo(0.42 * s, 3.2 * s); ctx.lineTo(0.34 * s, 0); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#4B2A7A'; ctx.beginPath(); ctx.moveTo(-0.52 * s, 0.95 * s); for (let i = 0; i <= 6; i++) ctx.lineTo((-0.52 + i * 0.1733) * s, (i % 2 ? 0.78 : 0.97) * s); ctx.lineTo(0.55 * s, 3.2 * s); ctx.lineTo(-0.55 * s, 3.2 * s); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.moveTo(-0.2 * s, 1.1 * s); ctx.lineTo(-0.22 * s, 3 * s); ctx.stroke();
  ctx.strokeStyle = dk; ctx.lineWidth = s * 0.03; for (let i = 0; i < 4; i++) { const yy = (0.1 + i * 0.12) * s; ctx.beginPath(); ctx.moveTo(-0.2 * s, yy); ctx.lineTo(0.2 * s, yy + 0.04 * s); ctx.stroke(); }
  const fb = [-0.31, -0.1, 0.11, 0.31], fa = [-0.22, -0.07, 0.07, 0.22], fl = [0.62, 0.78, 0.72, 0.56];
  for (let i = 0; i < 4; i++) {
    const len = fl[i] * s * (1 - 0.62 * curl), bx = fb[i] * s, by = -0.5 * s, ang = fa[i], tx = bx + Math.sin(ang) * len, ty = by - Math.cos(ang) * len;
    ctx.strokeStyle = dk; ctx.lineWidth = s * 0.2; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(tx, ty); ctx.stroke(); ctx.strokeStyle = skin; ctx.lineWidth = s * 0.16; ctx.stroke();
    if (curl < 0.6) oval(ctx, tx, ty - s * 0.02, s * 0.06, s * 0.08, '#EFE6B8', ang);
  }
  ctx.fillStyle = skin; ctx.strokeStyle = dk; ctx.lineWidth = s * 0.03; rr(ctx, -0.44 * s, -0.66 * s, 0.88 * s, 0.82 * s, 0.3 * s); ctx.fill(); ctx.stroke();
  const ta = mix(-1.15, -0.1, curl), tb = { x: mix(-0.4, -0.38, curl) * s, y: mix(-0.06, -0.2, curl) * s }, tl = (0.52 + 0.34 * curl) * s, tx = tb.x + Math.sin(ta) * tl, ty = tb.y - Math.cos(ta) * tl;
  ctx.strokeStyle = dk; ctx.lineWidth = s * 0.22; ctx.beginPath(); ctx.moveTo(tb.x, tb.y); ctx.lineTo(tx, ty); ctx.stroke(); ctx.strokeStyle = skin; ctx.lineWidth = s * 0.18; ctx.stroke();
  oval(ctx, tx, ty - s * 0.02, s * 0.07, s * 0.09, '#EFE6B8', ta);
  if (curl > 0.4) { for (let i = 0; i < 4; i++) { const kx = fb[i] * s * 1.05, ky = -0.62 * s; oval(ctx, kx, ky, 0.13 * s, 0.11 * s, skin); ctx.strokeStyle = dk; ctx.lineWidth = s * 0.025; ctx.beginPath(); ctx.ellipse(kx, ky, 0.13 * s, 0.11 * s, 0, 0, TAU); ctx.stroke(); } }
  googly(ctx, 0.02 * s, -0.27 * s, 0.22 * s, Math.sin(lk * 2) * 0.8, Math.cos(lk * 1.7) * 0.6);
  ctx.strokeStyle = dk; ctx.lineWidth = s * 0.025; ctx.beginPath(); ctx.moveTo(0.18 * s, 0.02 * s); ctx.lineTo(0.34 * s, -0.1 * s); ctx.moveTo(0.22 * s, -0.04 * s); ctx.lineTo(0.2 * s, -0.12 * s); ctx.stroke();
  ctx.restore();
}
function drawMound(ctx, w, h, u, top, ch) {
  const y = top + ch;
  ctx.fillStyle = '#3A2315'; ctx.beginPath(); ctx.ellipse(w / 2, y + u * 0.02, w * 0.46, ch * 0.055, 0, Math.PI, TAU); ctx.fill();
  ctx.fillStyle = '#2C1A0F'; ctx.beginPath(); ctx.ellipse(w / 2, y + u * 0.02, w * 0.46, ch * 0.03, 0, Math.PI, TAU); ctx.fill();
  const r = rng(61); ctx.strokeStyle = '#5FAE3A'; ctx.lineWidth = Math.max(2, u * 0.012); ctx.lineCap = 'round';
  for (let i = 0; i < 12; i++) { const gx = w * (0.12 + 0.76 * r()), gh = u * (0.03 + 0.04 * r()); ctx.beginPath(); ctx.moveTo(gx, y - ch * 0.01); ctx.quadraticCurveTo(gx + gh * 0.3, y - gh * 0.7 - ch * 0.01, gx + (r() - 0.5) * gh, y - gh - ch * 0.01); ctx.stroke(); }
}

/* ---------- Cute monster ---------- */
function drawMonster(ctx, x, y, s, o) {
  const t = o.t || 0, mo = o.mouth || 0, hp = o.happy || 0, lk = o.look || 0, sq = o.squash || 0, arms = o.arms == null ? 1 : o.arms;
  ctx.save(); ctx.translate(x, y); ctx.scale(1 + sq, 1 - sq); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  for (const sd of [-1, 1]) { tri(ctx, sd * 0.38 * s, -0.8 * s, sd * 0.72 * s, -0.7 * s, sd * 0.62 * s, -1.3 * s, '#FFE0A0'); }
  for (const sd of [-1, 1]) {
    ctx.save(); ctx.translate(sd * 0.95 * s, 0.35 * s); ctx.rotate(sd * (0.6 + 0.7 * arms) + Math.sin(t * 14 + sd) * 0.12 * arms); oval(ctx, sd * 0.18 * s, -0.1 * s, 0.34 * s, 0.2 * s, '#7B3BC9');
    for (let k = 0; k < 3; k++) disc(ctx, sd * (0.46 + k * 0.01) * s, (-0.2 + k * 0.1) * s, 0.05 * s, '#FFF1D0'); ctx.restore();
  }
  const g = ctx.createRadialGradient(-0.3 * s, -0.4 * s, s * 0.1, 0, 0, s * 1.1); g.addColorStop(0, '#B672F2'); g.addColorStop(1, '#6A2BC0');
  ctx.fillStyle = '#7F39D1'; for (let i = 0; i < 40; i++) { const a = i * TAU / 40, r = s * (0.97 + 0.03 * Math.sin(a * 5 + t * 8)); ctx.beginPath(); ctx.arc(Math.cos(a) * r, Math.sin(a) * r, s * 0.13, 0, TAU); ctx.fill(); }
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, s * 1.0, 0, TAU); ctx.fill();
  oval(ctx, 0, 0.5 * s, 0.62 * s, 0.4 * s, 'rgba(214,170,255,.35)');
  if (hp > 0.5) {
    ctx.strokeStyle = '#1B0B2E'; ctx.lineWidth = s * 0.08;
    [[0, -0.4, 0.26], [-0.56, -0.2, 0.16], [0.56, -0.2, 0.16]].forEach(e => { ctx.beginPath(); ctx.arc(e[0] * s, (e[1] + 0.08) * s, e[2] * s, Math.PI * 1.12, Math.PI * 1.88); ctx.stroke(); });
  } else {
    googly(ctx, 0, -0.4 * s, 0.3 * s, lk * 0.9, 0.2); googly(ctx, -0.56 * s, -0.2 * s, 0.17 * s, lk, -0.2); googly(ctx, 0.56 * s, -0.2 * s, 0.17 * s, -lk * 0.6, 0.3);
  }
  const yb = 0.2 * s, ab = (0.16 + 0.42 * mo) * s;
  ctx.fillStyle = '#2B0B3F'; ctx.beginPath(); ctx.moveTo(-0.66 * s, yb); ctx.quadraticCurveTo(0, yb + 0.12 * s, 0.66 * s, yb); ctx.quadraticCurveTo(0, yb + 2 * ab, -0.66 * s, yb); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.clip(); ctx.fillStyle = '#FFFFFF';
  for (let i = 0; i < 5; i++) { const px = (-0.5 + i * 0.25) * s; ctx.beginPath(); ctx.moveTo(px, yb - 0.04 * s); ctx.lineTo(px + 0.2 * s, yb - 0.04 * s); ctx.lineTo(px + 0.1 * s, yb + (0.2 + 0.04 * (i % 2)) * s); ctx.closePath(); ctx.fill(); }
  if (mo > 0.35) oval(ctx, 0, yb + ab * 1.05, 0.34 * s, 0.22 * s * (0.5 + mo), '#FF6FA3');
  ctx.restore();
  blush(ctx, -0.76 * s, 0.12 * s, 0.14 * s); blush(ctx, 0.76 * s, 0.12 * s, 0.14 * s);
  ctx.restore();
}

/* ---------- Black cat ---------- */
function drawCat(ctx, x, y, s, o) {
  const fl = o.fluff || 0, pu = o.pupil == null ? 1 : o.pupil, ht = o.heart || 0, mo = o.mouth || 0, t = o.t || 0, K = '#170D26';
  ctx.save(); ctx.translate(x, y); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.strokeStyle = K; ctx.lineWidth = s * (0.22 + 0.22 * fl); ctx.beginPath(); ctx.moveTo(0.7 * s, 1.5 * s); ctx.bezierCurveTo(1.7 * s, 1.5 * s, 1.5 * s + Math.sin(t * (fl > 0.5 ? 14 : 4)) * 0.1 * s, 0.4 * s, 1.1 * s, -0.25 * s + Math.sin(t * 4) * 0.1 * s); ctx.stroke();
  ctx.fillStyle = K; ctx.beginPath();
  const hw = yy => (0.74 + 0.42 * smooth((yy - 0.4) / 1.1) - 0.1 * smooth((yy - 1.8) / 0.8)) * s, N = 22;
  for (let i = 0; i <= N; i++) { const yy = 0.45 + i * (2.7 - 0.45) / N, sp = (i % 2 && fl > 0.02 && yy < 1.9) ? 0.16 * fl * s : 0; ctx.lineTo(-(hw(yy) + sp), yy * s); }
  for (let i = N; i >= 0; i--) { const yy = 0.45 + i * (2.7 - 0.45) / N, sp = (i % 2 && fl > 0.02 && yy < 1.9) ? 0.16 * fl * s : 0; ctx.lineTo(hw(yy) + sp, yy * s); }
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(176,124,255,.4)'; ctx.lineWidth = s * 0.035; ctx.beginPath(); for (let i = 0; i <= N; i++) { const yy = 0.5 + i * (1.9 - 0.5) / N; i ? ctx.lineTo(-hw(yy), yy * s) : ctx.moveTo(-hw(yy), yy * s); } ctx.stroke(); ctx.beginPath(); for (let i = 0; i <= N; i++) { const yy = 0.5 + i * (1.9 - 0.5) / N; i ? ctx.lineTo(hw(yy), yy * s) : ctx.moveTo(hw(yy), yy * s); } ctx.stroke();
  oval(ctx, 0, 1.55 * s, 0.55 * s, 0.7 * s, 'rgba(255,255,255,.04)');
  for (const sd of [-1, 1]) { tri(ctx, sd * 0.74 * s, -0.4 * s, sd * 0.66 * s, -1.32 * s, sd * 0.1 * s, -0.78 * s, K); tri(ctx, sd * 0.62 * s, -0.5 * s, sd * 0.58 * s, -1.05 * s, sd * 0.26 * s, -0.74 * s, '#FF9EBB'); }
  disc(ctx, 0, -0.05 * s, 0.8 * s, K); ctx.strokeStyle = 'rgba(176,124,255,.4)'; ctx.lineWidth = s * 0.04; ctx.beginPath(); ctx.arc(0, -0.05 * s, 0.8 * s, Math.PI * 1.05, Math.PI * 1.45); ctx.stroke();
  for (const sd of [-1, 1]) {
    const cx = sd * 0.36 * s, cy = -0.12 * s; ctx.shadowColor = '#E4FF3A'; ctx.shadowBlur = s * 0.22; oval(ctx, cx, cy, 0.27 * s, 0.3 * s, '#E4FF3A'); ctx.shadowBlur = 0;
    if (ht > 0.05) { ctx.fillStyle = '#FF3D7F'; heart(ctx, cx, cy - 0.04 * s, s * 0.17 * ht); ctx.fill(); }
    else oval(ctx, cx, cy, s * (0.05 + 0.17 * (1 - pu)), 0.28 * s, '#0B0614');
    disc(ctx, cx - 0.08 * s, cy - 0.12 * s, 0.06 * s, '#FFFFFF');
  }
  tri(ctx, -0.07 * s, 0.14 * s, 0.07 * s, 0.14 * s, 0, 0.23 * s, '#FF9EBB');
  if (mo > 0.05) {
    oval(ctx, 0, 0.42 * s, 0.27 * s * (0.6 + 0.4 * mo), 0.2 * s * mo, '#6B0F2A');
    tri(ctx, -0.17 * s, 0.3 * s, -0.07 * s, 0.3 * s, -0.12 * s, 0.4 * s, '#FFFFFF'); tri(ctx, 0.17 * s, 0.3 * s, 0.07 * s, 0.3 * s, 0.12 * s, 0.4 * s, '#FFFFFF');
    oval(ctx, 0, 0.5 * s, 0.1 * s * mo, 0.06 * s * mo, '#FF7AA5');
  } else { ctx.strokeStyle = '#FF9EBB'; ctx.lineWidth = s * 0.03; ctx.beginPath(); ctx.moveTo(0, 0.23 * s); ctx.lineTo(0, 0.3 * s); ctx.moveTo(-0.16 * s, 0.34 * s); ctx.quadraticCurveTo(-0.08 * s, 0.4 * s, 0, 0.3 * s); ctx.quadraticCurveTo(0.08 * s, 0.4 * s, 0.16 * s, 0.34 * s); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = s * 0.02;
  for (const sd of [-1, 1]) for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(sd * 0.46 * s, (0.2 + k * 0.08) * s); ctx.lineTo(sd * 1.3 * s, (0.02 + k * 0.2) * s - 0.1 * s); ctx.stroke(); }
  ctx.restore();
}

/* ---------- Vampire ---------- */
function drawVampire(ctx, x, y, s, o) {
  const cp = o.cape == null ? 1 : o.cape, fg = o.fang || 0, gl = o.glow == null ? 1 : o.glow, mo = o.mouth || 0, W = (0.85 + 0.95 * cp) * s;
  ctx.save(); ctx.translate(x, y); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  let g = ctx.createLinearGradient(0, 0, 0, 2.4 * s); g.addColorStop(0, '#A21233'); g.addColorStop(1, '#2A0716');
  ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-0.5 * s, 0.4 * s); ctx.quadraticCurveTo(-W, 0.9 * s, -W * 1.05, 2.6 * s); ctx.lineTo(W * 1.05, 2.6 * s); ctx.quadraticCurveTo(W, 0.9 * s, 0.5 * s, 0.4 * s); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#17082A'; rr(ctx, -0.62 * s, 0.7 * s, 1.24 * s, 2.0 * s, 0.4 * s); ctx.fill();
  tri(ctx, -0.3 * s, 0.75 * s, 0.3 * s, 0.75 * s, 0, 1.5 * s, '#F4EEF8'); disc(ctx, 0, 0.98 * s, 0.1 * s, '#E0183F');
  for (const sd of [-1, 1]) { ctx.fillStyle = '#17082A'; ctx.beginPath(); ctx.moveTo(sd * 0.3 * s, 0.55 * s); ctx.lineTo(sd * 1.0 * s, -0.15 * s); ctx.lineTo(sd * 0.9 * s, 1.0 * s); ctx.lineTo(sd * 0.25 * s, 0.9 * s); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#D01F48'; ctx.lineWidth = s * 0.05; ctx.stroke(); }
  for (const sd of [-1, 1]) tri(ctx, sd * 0.55 * s, -0.05 * s, sd * 0.9 * s, -0.5 * s, sd * 0.6 * s, -0.4 * s, '#E6DDF0');
  g = ctx.createRadialGradient(-0.2 * s, -0.3 * s, s * 0.1, 0, 0, s * 0.9); g.addColorStop(0, '#FBF7FF'); g.addColorStop(1, '#D8CCE8');
  ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, -0.02 * s, 0.64 * s, 0.74 * s, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#150A24'; ctx.beginPath(); ctx.moveTo(-0.66 * s, -0.05 * s); ctx.quadraticCurveTo(-0.78 * s, -0.95 * s, 0, -0.88 * s); ctx.quadraticCurveTo(0.78 * s, -0.95 * s, 0.66 * s, -0.05 * s); ctx.lineTo(0.42 * s, -0.45 * s); ctx.lineTo(0, -0.18 * s); ctx.lineTo(-0.42 * s, -0.45 * s); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#150A24'; ctx.lineWidth = s * 0.08; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * 0.46 * s, -0.3 * s); ctx.lineTo(sd * 0.12 * s, -0.17 * s); ctx.stroke(); }
  for (const sd of [-1, 1]) { ctx.shadowColor = '#FF2B4E'; ctx.shadowBlur = s * 0.25 * gl; oval(ctx, sd * 0.27 * s, -0.02 * s, 0.13 * s, 0.16 * s, '#FF2B4E'); ctx.shadowBlur = 0; disc(ctx, sd * 0.27 * s - 0.04 * s, -0.07 * s, 0.045 * s, '#FFFFFF'); }
  tri(ctx, -0.04 * s, 0.14 * s, 0.04 * s, 0.14 * s, 0, 0.22 * s, 'rgba(120,80,140,.6)');
  const yb = 0.3 * s; ctx.fillStyle = '#3A0A18'; ctx.beginPath(); ctx.moveTo(-0.3 * s, yb); ctx.quadraticCurveTo(0, yb + 0.16 * s + 0.4 * s * mo, 0.3 * s, yb); ctx.quadraticCurveTo(0, yb - 0.05 * s, -0.3 * s, yb); ctx.closePath(); ctx.fill();
  for (const sd of [-1, 1]) tri(ctx, sd * 0.2 * s, yb - 0.01 * s, sd * 0.07 * s, yb - 0.01 * s, sd * 0.14 * s, yb + (0.08 + 0.34 * fg) * s, '#FFFFFF');
  blush(ctx, -0.46 * s, 0.14 * s, 0.1 * s); blush(ctx, 0.46 * s, 0.14 * s, 0.1 * s);
  ctx.restore();
}

/* ---------- Witch on a broom (faces right) ---------- */
function drawWitch(ctx, x, y, s, o) {
  const t = o.t || 0;
  ctx.save(); ctx.translate(x, y); ctx.scale(o.dir || 1, 1); ctx.rotate(o.tilt || 0); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  for (let i = 0; i < 9; i++) { const k = i / 9; ctx.fillStyle = rgba(i % 2 ? '#B6FF5C' : '#E0A8FF', 0.9 * (1 - k)); sparkle(ctx, -2.5 * s - k * 2.4 * s, Math.sin(t * 8 + i * 1.3) * 0.28 * s + k * 0.3 * s, s * 0.2 * (1 - k * 0.7)); }
  ctx.strokeStyle = '#7A4A22'; ctx.lineWidth = s * 0.13; ctx.beginPath(); ctx.moveTo(-1.5 * s, 0.1 * s); ctx.lineTo(1.4 * s, -0.05 * s); ctx.stroke();
  ctx.fillStyle = '#E3B44E'; ctx.beginPath(); ctx.moveTo(-1.45 * s, 0.1 * s); ctx.lineTo(-2.3 * s, -0.3 * s); ctx.lineTo(-2.45 * s, 0.1 * s); ctx.lineTo(-2.3 * s, 0.5 * s); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#B07F26'; ctx.lineWidth = s * 0.03; for (let k = -2; k <= 2; k++) { ctx.beginPath(); ctx.moveTo(-1.5 * s, 0.1 * s); ctx.lineTo(-2.4 * s, 0.1 * s + k * 0.17 * s); ctx.stroke(); }
  ctx.fillStyle = '#C0392B'; ctx.fillRect(-1.58 * s, -0.08 * s, 0.14 * s, 0.4 * s);
  oval(ctx, -0.9 * s, -0.42 * s, 0.32 * s, 0.38 * s, '#170D26'); disc(ctx, -0.82 * s, -0.95 * s, 0.26 * s, '#170D26'); tri(ctx, -1.02 * s, -1.1 * s, -0.96 * s, -1.38 * s, -0.84 * s, -1.14 * s, '#170D26'); tri(ctx, -0.8 * s, -1.14 * s, -0.68 * s, -1.38 * s, -0.62 * s, -1.08 * s, '#170D26');
  disc(ctx, -0.9 * s, -0.98 * s, 0.05 * s, '#B6FF5C'); disc(ctx, -0.74 * s, -0.98 * s, 0.05 * s, '#B6FF5C');
  ctx.strokeStyle = '#170D26'; ctx.lineWidth = s * 0.12; ctx.beginPath(); ctx.moveTo(-1.15 * s, -0.1 * s); ctx.quadraticCurveTo(-1.6 * s, -0.5 * s, -1.4 * s, -0.95 * s + Math.sin(t * 5) * 0.1 * s); ctx.stroke();
  oval(ctx, 0.12 * s, -0.4 * s, 0.52 * s, 0.58 * s, '#6A33B5');
  ctx.strokeStyle = '#2A1347'; ctx.lineWidth = s * 0.17; for (const dx of [0.1, 0.4]) { ctx.beginPath(); ctx.moveTo(dx * s, 0.15 * s); ctx.lineTo((dx + 0.05) * s, 0.65 * s); ctx.stroke(); ctx.strokeStyle = dx < 0.2 ? '#FF8A1F' : '#FF8A1F'; ctx.lineWidth = s * 0.05; ctx.beginPath(); ctx.moveTo((dx - 0.07) * s, 0.3 * s); ctx.lineTo((dx + 0.07) * s, 0.3 * s); ctx.stroke(); ctx.strokeStyle = '#2A1347'; ctx.lineWidth = s * 0.17; }
  oval(ctx, 0.45 * s, 0.68 * s, 0.2 * s, 0.1 * s, '#170D26'); oval(ctx, 0.15 * s, 0.7 * s, 0.2 * s, 0.1 * s, '#170D26');
  ctx.strokeStyle = '#6A33B5'; ctx.lineWidth = s * 0.17; ctx.beginPath(); ctx.moveTo(0.3 * s, -0.7 * s); ctx.lineTo(0.95 * s, -0.12 * s); ctx.stroke(); disc(ctx, 1.0 * s, -0.08 * s, 0.12 * s, '#8FD14F');
  for (let k = 0; k < 5; k++) { ctx.strokeStyle = '#FF8A1F'; ctx.lineWidth = s * 0.09; ctx.beginPath(); ctx.moveTo(0.05 * s, (-1.2 + k * 0.08) * s); ctx.quadraticCurveTo(-0.5 * s, (-1.1 + k * 0.18) * s + Math.sin(t * 7 + k) * 0.1 * s, -0.95 * s - k * 0.08 * s, (-0.8 + k * 0.28) * s + Math.sin(t * 6 + k) * 0.12 * s); ctx.stroke(); }
  disc(ctx, 0.3 * s, -1.2 * s, 0.44 * s, '#8FD14F'); tri(ctx, 0.62 * s, -1.28 * s, 0.62 * s, -1.0 * s, 1.0 * s, -1.02 * s, '#8FD14F'); disc(ctx, 0.9 * s, -1.0 * s, 0.045 * s, '#4F8F2A');
  googly(ctx, 0.47 * s, -1.28 * s, 0.1 * s, 0.7, 0.1);
  ctx.strokeStyle = '#2A1347'; ctx.lineWidth = s * 0.04; ctx.beginPath(); ctx.arc(0.5 * s, -1.08 * s, 0.17 * s, 0.15, Math.PI - 0.2); ctx.stroke(); tri(ctx, 0.4 * s, -0.93 * s, 0.48 * s, -0.93 * s, 0.44 * s, -0.84 * s, '#FFFFFF');
  ctx.fillStyle = '#170D26'; ctx.beginPath(); ctx.ellipse(0.28 * s, -1.5 * s, 0.84 * s, 0.15 * s, -0.08, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.moveTo(-0.28 * s, -1.55 * s); ctx.quadraticCurveTo(0.1 * s, -2.1 * s, -0.25 * s + Math.sin(t * 5) * 0.06 * s, -2.9 * s); ctx.quadraticCurveTo(0.75 * s, -2.1 * s, 0.82 * s, -1.55 * s); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#8B3FD6'; ctx.beginPath(); ctx.moveTo(-0.25 * s, -1.6 * s); ctx.lineTo(0.8 * s, -1.6 * s); ctx.lineTo(0.78 * s, -1.78 * s); ctx.lineTo(-0.2 * s, -1.78 * s); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#FFC83D'; ctx.fillRect(0.2 * s, -1.8 * s, 0.2 * s, 0.22 * s); ctx.fillStyle = '#170D26'; ctx.fillRect(0.25 * s, -1.75 * s, 0.1 * s, 0.12 * s);
  ctx.restore();
}

/* ---------- Slime that covers the top of the card ---------- */
function drawSlime(ctx, w, h, u, top, ch, t, c) {
  const cov = c.cov, off = c.drop * (ch + 80), base = ch * 0.27 * cov, r = rng(123), n = 10;
  ctx.save(); ctx.translate(0, off);
  const g = ctx.createLinearGradient(0, 0, 0, base + ch * 0.25); g.addColorStop(0, '#5FD52B'); g.addColorStop(1, '#2FB84B');
  ctx.fillStyle = g; ctx.fillRect(-40, -40, w + 80, base + 40);
  for (let i = 0; i < n; i++) {
    const x = w * (i + 0.5) / n + (r() - 0.5) * w * 0.03, rad = w * (0.032 + 0.03 * r()), len = base + ch * (0.03 + 0.19 * r()) * cov + Math.sin(t * 2 + i) * ch * 0.012 * cov;
    ctx.fillRect(x - rad, base - 4, rad * 2, len - base + 4); ctx.beginPath(); ctx.arc(x, len, rad * 1.12, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.3)'; ctx.fillRect(x - rad * 0.55, base, rad * 0.28, Math.max(0, len - base - rad * 0.2)); ctx.fillStyle = g;
  }
  ctx.fillStyle = 'rgba(255,255,255,.22)'; ctx.beginPath(); ctx.ellipse(w * 0.3, base * 0.35, w * 0.16, base * 0.07, -0.1, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.ellipse(w * 0.72, base * 0.5, w * 0.1, base * 0.05, 0.1, 0, TAU); ctx.fill();
  const lk = Math.sin(t * 3) * 0.7, ey = base * 0.62, er = w * 0.1;
  googly(ctx, w * 0.35, ey, er, lk, 0.2); googly(ctx, w * 0.65, ey, er, lk, 0.2);
  ctx.strokeStyle = '#0B5A25'; ctx.lineWidth = Math.max(2, w * 0.016); ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(w * 0.5, ey + er * 0.3, er * 1.2, 0.25, Math.PI - 0.25); ctx.stroke();
  ctx.restore();
}

/* ---------- Ambient effects ---------- */
function fxCandy(ctx, w, h, u, th, t) {
  const r = rng(91), cols = ['#FF6A00', '#FFD23F', '#B14CFF', '#4DE0A8', '#FF5C8E', '#FFFFFF'];
  for (let i = 0; i < 27; i++) {
    const sp = 0.08 + r() * 0.12, o = r(), sz = u * (0.028 + r() * 0.03), ph = r() * TAU, x0 = r(), kind = i % 3, col = cols[(r() * cols.length) | 0];
    const pad = sz * 4, f = (o + t * sp) % 1, y = f * (h + pad) - pad / 2, x = x0 * w + Math.sin(t * 1.2 + ph) * u * 0.05;
    ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(t * 1.6 + ph) * 0.7);
    if (kind === 0) {
      ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(0, 0, sz * 0.8, sz * 0.5, 0, 0, TAU); ctx.fill();
      for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(sd * sz * 0.7, 0); ctx.lineTo(sd * sz * 1.45, -sz * 0.55); ctx.lineTo(sd * sz * 1.45, sz * 0.55); ctx.closePath(); ctx.fill(); }
      ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.ellipse(-sz * 0.2, -sz * 0.15, sz * 0.35, sz * 0.12, 0, 0, TAU); ctx.fill();
    } else if (kind === 1) {
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = Math.max(1.5, sz * 0.18); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, sz * 2.3); ctx.stroke();
      disc(ctx, 0, 0, sz, col); ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = Math.max(1, sz * 0.16); ctx.beginPath(); ctx.arc(0, 0, sz * 0.62, 0, TAU * 0.8); ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, sz * 0.28, 0, TAU * 0.8); ctx.stroke();
    } else {
      oval(ctx, 0, 0, sz * 0.95, sz * 0.8, '#FF8A1F'); oval(ctx, -sz * 0.35, 0, sz * 0.5, sz * 0.78, '#E4620E'); oval(ctx, sz * 0.35, 0, sz * 0.5, sz * 0.78, '#E4620E'); ctx.fillStyle = '#5E7F2B'; ctx.fillRect(-sz * 0.08, -sz * 1.05, sz * 0.16, sz * 0.35);
      ctx.fillStyle = '#4A1500'; ctx.beginPath(); ctx.moveTo(-sz * 0.35, -sz * 0.15); ctx.lineTo(-sz * 0.15, -sz * 0.15); ctx.lineTo(-sz * 0.25, -sz * 0.4); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.moveTo(sz * 0.35, -sz * 0.15); ctx.lineTo(sz * 0.15, -sz * 0.15); ctx.lineTo(sz * 0.25, -sz * 0.4); ctx.closePath(); ctx.fill(); ctx.beginPath(); ctx.arc(0, sz * 0.15, sz * 0.3, 0.2, Math.PI - 0.2); ctx.fill();
    }
    ctx.restore();
  }
}
function fxFog(ctx, w, h, u, th, t) {
  for (let i = 0; i < 7; i++) {
    const x = (((i * 0.23 + t * 0.014 * (1 + i % 3)) % 1.5) - 0.25) * w, y = h * (0.66 + 0.07 * (i % 4)), rx = u * (0.45 + 0.1 * (i % 3)), ry = u * 0.09;
    const g = ctx.createRadialGradient(x, y, 0, x, y, rx); g.addColorStop(0, rgba(th.glow, 0.2)); g.addColorStop(1, rgba(th.glow, 0)); ctx.fillStyle = g; ctx.save(); ctx.translate(0, y); ctx.scale(1, ry / rx); ctx.translate(0, -y); ctx.beginPath(); ctx.arc(x, y, rx, 0, TAU); ctx.fill(); ctx.restore();
  }
  [[0.14, 0.12], [0.86, 0.2], [0.8, 0.8], [0.18, 0.88]].forEach((p, k) => X.drawGhost(ctx, w * p[0] + Math.sin(t * 0.8 + k) * u * 0.05, h * p[1] + Math.sin(t * 1.4 + k * 2) * u * 0.03, u * (0.05 + 0.012 * (k % 2)), t + k, 0.3 + 0.3 * Math.sin(t * 2 + k), 0.9));
}

/* ---------- Motifs for the middle of the card (about s wide, centred at cx, cy) ---------- */
X.MOTIFS.pumpkin = (ctx, cx, cy, s, th, t) => {
  cy += Math.sin(t * 1.6) * s * 0.015; oval(ctx, cx, cy + s * 0.37, s * 0.42, s * 0.05, 'rgba(0,0,0,.2)');
  drawPumpkin(ctx, cx, cy + s * 0.02, s * 0.36, { mouth: 0.2 + 0.12 * Math.sin(t * 2), glow: 0.85 + 0.15 * Math.sin(t * 9), wink: Math.sin(t * 0.9 + 1) > 0.965 ? 1 : 0, rot: Math.sin(t * 1.3) * 0.03 });
};
X.MOTIFS.ghost = (ctx, cx, cy, s, th, t) => {
  const yy = cy + Math.sin(t * 2) * s * 0.03 - s * 0.02, k = s * 0.3; X.drawGhost(ctx, cx, yy, k, t, 0.15 + 0.15 * Math.sin(t * 3), 1);
  blush(ctx, cx - k * 0.52, yy + k * 0.05, k * 0.14); blush(ctx, cx + k * 0.52, yy + k * 0.05, k * 0.14);
  ctx.fillStyle = '#FFFFFF'; sparkle(ctx, cx + s * 0.42, yy - s * 0.3, s * 0.05 * (0.6 + 0.4 * Math.sin(t * 3)));
};
X.MOTIFS.cat = (ctx, cx, cy, s, th, t) => {
  const bl = Math.sin(t * 1.1) > 0.97;
  drawCat(ctx, cx, cy - s * 0.12, s * 0.3, { fluff: 0, pupil: bl ? 1 : 0.15 + 0.1 * Math.sin(t * 2), heart: 0, mouth: 0, t });
};
X.MOTIFS.skull = (ctx, cx, cy, s, th, t) => {
  oval(ctx, cx, cy + s * 0.43, s * 0.34, s * 0.04, 'rgba(0,0,0,.2)'); drawSkull(ctx, cx, cy + Math.sin(t * 1.8) * s * 0.015, s * 0.4, { jaw: 0.1 + 0.12 * Math.max(0, Math.sin(t * 2.2)), look: Math.sin(t), tilt: Math.sin(t * 1.2) * 0.06 });
};
X.MOTIFS.bucket = (ctx, cx, cy, s, th, t) => {
  cy += Math.sin(t * 1.6) * s * 0.012;
  oval(ctx, cx, cy + s * 0.46, s * 0.4, s * 0.05, 'rgba(0,0,0,.2)');
  const cols = ['#FF5C8E', '#FFD23F', '#4DE0A8', '#B14CFF', '#FFFFFF'];
  const r = rng(5); for (let i = 0; i < 9; i++) { const px = cx + (r() - 0.5) * s * 0.5, py = cy - s * 0.02 + (r() - 0.5) * s * 0.1 - Math.abs(Math.sin(t * 2.2 + i)) * s * 0.012; ctx.fillStyle = cols[i % 5]; ctx.beginPath(); ctx.ellipse(px, py, s * 0.06, s * 0.04, r() * 3, 0, TAU); ctx.fill(); }
  ctx.strokeStyle = '#170D26'; ctx.lineWidth = s * 0.03; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(cx, cy + s * 0.1, s * 0.4, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke();
  ctx.fillStyle = '#FF8A1F'; ctx.beginPath(); ctx.moveTo(cx - s * 0.36, cy + s * 0.05); ctx.lineTo(cx + s * 0.36, cy + s * 0.05); ctx.lineTo(cx + s * 0.28, cy + s * 0.44); ctx.quadraticCurveTo(cx, cy + s * 0.52, cx - s * 0.28, cy + s * 0.44); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#E4620E'; ctx.fillRect(cx - s * 0.38, cy + s * 0.02, s * 0.76, s * 0.06);
  ctx.fillStyle = '#4A1500'; tri(ctx, cx - s * 0.2, cy + s * 0.2, cx - s * 0.08, cy + s * 0.2, cx - s * 0.14, cy + s * 0.1, '#4A1500'); tri(ctx, cx + s * 0.2, cy + s * 0.2, cx + s * 0.08, cy + s * 0.2, cx + s * 0.14, cy + s * 0.1, '#4A1500');
  ctx.beginPath(); ctx.arc(cx, cy + s * 0.28, s * 0.14, 0.2, Math.PI - 0.2); ctx.fill();
};

/* ---------- Timelines: the creature's state at time t (q = seconds since it appeared) ---------- */
const flash = (R, t, t0, col, k, rate) => { if (t >= t0) { R.flash = k * Math.exp(-(t - t0) * (rate || 8)); R.flashCol = col; } };
const H = X.HSCARE;
H.pumpkin = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y, sc = 1;
  if (q < 0.45) { const p = easeBack(q / 0.45); y = mix(1.25, 0.5, p); sc = mix(0.55, 1, p); } else if (q < 2.0) y = 0.5 + Math.sin(q * 3) * 0.008; else y = mix(0.5, 1.4, easeIn((q - 2.0) / 0.5));
  R.cr = { kind: 'pumpkin', y, sc, rot: q > 0.45 && q < 2.0 ? Math.sin(q * 6) * 0.08 : 0, mouth: q < 0.45 ? q / 0.45 : 0.55 + 0.45 * Math.sin(q * 9), tongue: pulse(q, 1.05, 1.9, 0.25), wink: q > 1.45 && q < 1.85 ? 1 : 0, glow: 0.85 + 0.15 * Math.sin(q * 15) };
  if (q > 0.3 && q < 1.5) R.shout = 'БҮҮҮ!'; if (q > 0.3 && q < 1.0) R.shake = 0.5 * Math.exp(-(q - 0.3) * 4); flash(R, t, A + 0.3, '#FFB000', 0.4);
};
H.mummy = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let x, y = 0.5, rot = 0, hop = 0;
  if (q < 0.55) { x = mix(1.5, 0.5, easeBack(q / 0.55)); hop = Math.abs(Math.sin(q * 14)) * 0.05 * (1 - q / 0.55); } else if (q < 1.9) { x = 0.5; hop = Math.abs(Math.sin(q * 7)) * 0.045; } else { const p = (q - 1.9) / 0.6; x = 0.5 + p * 0.05; rot = easeIn(p) * 1.5; y = 0.5 + easeIn(p) * 0.9; }
  R.cr = { kind: 'mummy', x, y: y - hop, rot, arms: 1, cross: pulse(q, 0.9, 1.7, 0.25), mouth: q < 1.9 ? 0.5 + 0.5 * Math.sin(q * 10) : 1 };
  if (q > 0.5 && q < 1.5) R.shout = 'ӨӨӨӨӨ!'; flash(R, t, A + 0.45, '#FFFFFF', 0.3, 9); if (q > 2.35 && q < 2.8) R.shake = 0.12;
};
H.skeleton = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y;
  if (q < 0.5) y = mix(1.4, 0.34, easeBack(q / 0.5)); else if (q < 2.1) y = 0.34; else y = mix(0.34, 1.5, easeIn((q - 2.1) / 0.5));
  const dance = q > 0.5 && q < 2.1 ? Math.sin(q * 6) : 0, lift = clamp((q - 1.3) / 0.55);
  R.cr = { kind: 'skeleton', y, sway: dance, jaw: q > 0.5 && q < 1.3 ? Math.abs(Math.sin(q * 17)) : (q < 2.1 ? 0.15 : 0), look: Math.sin(q * 4), lift: lift > 0 && lift < 1 ? Math.sin(lift * Math.PI) * 0.95 : 0, armL: 1.5 + Math.sin(q * 9) * 0.45, armR: 1.1 + Math.sin(q * 9 + 2) * 0.45 };
  if (q > 0.5 && q < 1.3) R.shout = 'ХЭ-ХЭ-ХЭ!'; flash(R, t, A + 0.45, '#FFFFFF', 0.3, 9); R.darkK = 0.95;
};
H.hand = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y;
  if (q < 0.5) y = mix(1.55, 0.6, easeOut(q / 0.5)); else if (q < 2.5) y = 0.6 + Math.sin(q * 4) * 0.006; else y = mix(0.6, 1.7, easeIn((q - 2.5) / 0.5));
  const wave = q > 0.55 && q < 1.65 ? Math.sin((q - 0.55) * 9) * 0.34 : (q >= 1.65 && q < 2.5 ? Math.sin(q * 5) * 0.05 : 0);
  R.cr = { kind: 'hand', y, wave, curl: smooth((q - 1.7) / 0.25), look: q * 2.2 };
  if (q > 0.55 && q < 1.65) R.shout = 'САЙН УУ?'; if (q > 1.8 && q < 2.45) R.shout = 'ЗА!'; R.shoutY = 0.17;
  if (q > 0.2 && q < 0.7) R.shake = 0.3 * Math.exp(-(q - 0.2) * 5); flash(R, t, A + 0.3, '#86C85A', 0.3, 8);
};
H.monster = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y = 0.48, sc = 1, sq = 0, mouth = 0, happy = 0, arms = 1;
  if (q < 0.5) { const p = easeBack(q / 0.5); y = mix(1.35, 0.48, p); sq = -0.1 * (1 - p); }
  else if (q < 1.55) { mouth = 0.6 + 0.4 * Math.sin(q * 18); sq = 0.03 * Math.sin(q * 25); }
  else if (q < 2.4) { happy = 1; mouth = 0.18 + 0.1 * Math.sin(q * 22); sq = 0.05 * Math.sin(q * 20); arms = 0.4; y = 0.48 - Math.abs(Math.sin((q - 1.55) * 7)) * 0.03; }
  else { const p = easeIn((q - 2.4) / 0.5); sc = 1 - p * 0.95; happy = 1; arms = 0.3; }
  R.cr = { kind: 'monster', y, sc, squash: sq, mouth, happy, arms, look: Math.sin(q * 3) * 0.8 };
  if (q > 0.35 && q < 1.55) R.shout = 'РААААА!'; if (q > 0.35 && q < 1.0) R.shake = 0.6 * Math.exp(-(q - 0.35) * 4); flash(R, t, A + 0.35, '#B46BFF', 0.4); R.darkK = 0.95;
};
H.cat = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let y = 0.46, fluff = 0, pupil = 1, heartV = 0, mouth = 0;
  if (q < 0.4) y = mix(1.3, 0.46, easeBack(q / 0.4));
  if (q >= 0.4 && q < 1.45) { fluff = 1; mouth = 1; pupil = 1; } else if (q >= 1.45 && q < 2.25) { fluff = 1 - smooth((q - 1.45) / 0.3); pupil = 1 - smooth((q - 1.5) / 0.3); heartV = smooth((q - 1.75) / 0.3); } else if (q >= 2.25) { pupil = 0; heartV = 1; y = mix(0.46, -0.6, easeIn((q - 2.25) / 0.45)); }
  R.cr = { kind: 'cat', y, fluff, pupil, heart: heartV, mouth, t };
  if (q > 0.4 && q < 1.45) R.shout = 'МЯУУУУ!'; if (q > 0.4 && q < 0.9) R.shake = 0.5 * Math.exp(-(q - 0.4) * 4); flash(R, t, A + 0.4, '#E4FF3A', 0.4);
};
H.vampire = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A;
  R.cr = { kind: 'vampire', y: 0.44, sc: mix(0.06, 1, easeOut(q / 0.55)), cape: easeOut(q / 0.8), fang: smooth((q - 0.5) / 0.4), mouth: q > 0.6 && q < 1.8 ? 0.5 + 0.5 * Math.sin(q * 8) : 0.1, glow: 0.8 + 0.2 * Math.sin(q * 12), al: 1 - smooth((q - 2.1) / 0.5) };
  if (q > 0.6 && q < 1.7) R.shout = 'БЛЭЭЭЭ!'; if (q > 0.5 && q < 1.0) R.shake = 0.3; flash(R, t, A + 0.5, '#FF2B4E', 0.35);
};
H.witch = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let x, y, dir, sc = 1;
  if (q < 1.55) { const p = q / 1.55; x = mix(-0.45, 1.45, p); y = 0.4 + Math.sin(q * 4.5) * 0.05; dir = 1; } else if (q < 1.7) { x = 1.6; y = 0.5; dir = -1; } else { const p = (q - 1.7) / 1.15; x = mix(1.5, -0.5, p); y = 0.54 + Math.sin(q * 4.5) * 0.04; dir = -1; sc = 1.2; }
  R.cr = { kind: 'witch', x, y, dir, sc, tilt: Math.sin(q * 4.5) * 0.1 };
  R.moon = smooth((t - A) / 0.5) * (1 - smooth((t - 5.0) / 0.6)); if ((q > 0.5 && q < 1.4) || (q > 1.9 && q < 2.7)) R.shout = 'ХИ-ХИ-ХИ!'; flash(R, t, A + 0.1, '#7CFF6B', 0.25); R.darkK = 0.93;
};
H.slime = (t, R) => {
  if (t < A || t >= 5.5) return; const q = t - A; let cov = easeOut(q / 0.9), drop = 0;
  if (q >= 2.1) { cov = 1; drop = easeIn((q - 2.1) / 0.6); }
  R.cr = { kind: 'slime', cov, drop };
  if (q > 0.5 && q < 1.8) { R.shout = 'ЛИЖ!'; R.shoutY = 0.72; } if (q > 0.2 && q < 0.7) R.shake = 0.3; flash(R, t, A + 0.2, '#7CFF3B', 0.3, 8); R.darkK = 0.9;
};
const D = X.HDRAW;
D.pumpkin = (ctx, w, h, u, top, ch, t, c) => drawPumpkin(ctx, w / 2, top + ch * c.y, u * 0.3 * c.sc, c);
D.mummy = (ctx, w, h, u, top, ch, t, c) => drawMummy(ctx, w * c.x, top + ch * c.y, u * 0.3, Object.assign({ t }, c));
D.skeleton = (ctx, w, h, u, top, ch, t, c) => drawSkeleton(ctx, w / 2 + c.sway * u * 0.05, top + ch * c.y, u * 0.25, c);
D.hand = (ctx, w, h, u, top, ch, t, c) => { drawHand(ctx, w / 2, top + ch * c.y, u * 0.3, c); drawMound(ctx, w, h, u, top, ch); };
D.monster = (ctx, w, h, u, top, ch, t, c) => drawMonster(ctx, w / 2, top + ch * c.y, u * 0.28 * c.sc, Object.assign({ t }, c));
D.cat = (ctx, w, h, u, top, ch, t, c) => drawCat(ctx, w / 2, top + ch * c.y, u * 0.3, c);
D.vampire = (ctx, w, h, u, top, ch, t, c) => { ctx.save(); ctx.globalAlpha = clamp(c.al); drawVampire(ctx, w / 2, top + ch * c.y, u * 0.3 * c.sc, c); ctx.restore(); X.drawBats(ctx, w, h, u, top, ch, t); };
D.witch = (ctx, w, h, u, top, ch, t, c) => drawWitch(ctx, w * c.x, top + ch * c.y, u * 0.2 * c.sc, Object.assign({ t }, c));
D.slime = drawSlime;

/* ---------- Sound cues ---------- */
const ev = list => cross => { const out = []; list.forEach(p => { if (cross(p[0])) out.push(p[1]); }); return out; };
X.EVENTS.pumpkin = ev([[2.45, 'riser'], [2.95, 'boo'], [4.3, 'giggle'], [5.5, 'end']]);
X.EVENTS.mummy = ev([[2.45, 'riser'], [3.0, 'boo'], [4.55, 'thud'], [5.5, 'end']]);
X.EVENTS.skeleton = ev([[2.45, 'riser'], [3.0, 'rattle'], [4.0, 'rattle'], [5.5, 'end']]);
X.EVENTS.hand = ev([[2.65, 'burst'], [3.3, 'hello'], [4.5, 'hello'], [5.5, 'end']]);
X.EVENTS.monster = ev([[2.45, 'riser'], [3.0, 'roar'], [4.3, 'giggle'], [5.5, 'end']]);
X.EVENTS.cat = ev([[2.45, 'riser'], [3.05, 'meow'], [4.4, 'hello'], [5.5, 'end']]);
X.EVENTS.vampire = ev([[2.45, 'riser'], [3.25, 'cackle'], [5.5, 'end']]);
X.EVENTS.witch = ev([[2.45, 'riser'], [3.2, 'cackle'], [4.6, 'cackle'], [5.5, 'end']]);
X.EVENTS.slime = ev([[2.45, 'riser'], [2.95, 'splat'], [4.95, 'splat'], [5.5, 'end']]);
const op = (f, d, w, v, at, to) => ({ t: 'tone', f, d, w, v, at: at || 0, to });
Object.assign(X.PRESETS, {
  meow: { name: 'Мяу', ops: [op(520, .2, 'triangle', .14, 0, 920), op(920, .34, 'triangle', .14, .17, 430)] },
  cackle: { name: 'Шулмын инээд', ops: [0, .13, .26, .39].map((a, i) => op(520 + i * 40, .12, 'sawtooth', .09, a, 720 + i * 40)).concat([op(560, .3, 'sawtooth', .09, .54, 360)]) },
  rattle: { name: 'Яс шажигнах', ops: [0, .06, .12, .21, .27, .34].map(a => ({ t: 'noise', d: .05, v: .2, hp: 3200, at: a })) },
  splat: { name: 'Лиш цохих', ops: [{ t: 'noise', d: .28, v: .16, hp: 300 }, op(260, .26, 'sine', .22, 0, 55)] },
  roar: { name: 'Мангасын архирал', ops: [op(110, .8, 'sawtooth', .2, 0, 70), op(165, .7, 'square', .05, 0, 90), { t: 'noise', d: .5, v: .1, hp: 200 }] },
  giggle: { name: 'Инээх', ops: [0, .11, .22, .33].map((a, i) => op(700 + i * 40, .09, 'triangle', .12, a, 950 + i * 40)) },
  creak: { name: 'Хаалганы шаз', ops: [op(150, .9, 'sawtooth', .07, 0, 330), op(160, .9, 'square', .03, .05, 300), { t: 'noise', d: .8, v: .05, hp: 2500 }] },
  wail: { name: 'Сүнсний уйлаа', ops: [op(400, 1.2, 'sine', .1, 0, 900), op(404, 1.2, 'sine', .1, .06, 460)] }
});
Object.assign(X.CUES, { meow: 'Муур мяулах', cackle: 'Шулмын инээд', rattle: 'Яс шажигнах', splat: 'Лиш цохих', roar: 'Мангасын архирал', hello: 'Сайн уу (хонх)', thud: 'Унах цохилт', giggle: 'Инээх' });
Object.assign(X.DEFAULT_SFX, { meow: 'meow', cackle: 'cackle', rattle: 'rattle', splat: 'splat', roar: 'roar', hello: 'chime', thud: 'drum', giggle: 'giggle' });

/* ---------- Registration ---------- */
const NEW = { pumpkin: ['Хулуу', 3.95], mummy: ['Мөмми', 3.8], skeleton: ['Араг яс', 4.05], hand: ['Үхсэн гар', 3.5], monster: ['Хөөрхөн мангас', 3.75], cat: ['Хар муур', 3.7], vampire: ['Цуст', 4.0], witch: ['Шулам', 3.75], slime: ['Лиш', 3.95] };
Object.keys(NEW).forEach(k => { X.FX_IDS.push(k); X.FXS[k] = { name: NEW[k][0], scare: true }; X.FXR[k] = {}; X.THUMB_T[k] = NEW[k][1]; X.FINAL_T[k] = 7.9; X.LOOP[k] = 10; });
X.FX_IDS.push('candy', 'fog'); X.FXS.candy = { name: 'Чихрийн бороо' }; X.FXS.fog = { name: 'Манан, сүнснүүд' };
X.FXR.candy = { fn: fxCandy, front: true }; X.FXR.fog = { fn: fxFog, front: true }; X.THUMB_T.candy = 1.3; X.FINAL_T.candy = 1.3; X.THUMB_T.fog = 1.6; X.FINAL_T.fog = 1.6;

Object.assign(X.THEMES, {
  pumpkin: { name: 'Хулуу', bg: ['#34124F', '#FF7A1A'], glow: '#FFB347', ink: '#FFF4DC', soft: '#FFE3B8', a: '#FFC83D', b: '#FFFFFF', c: '#9BFF4D', light: false, pal: ['#FF8A1F', '#FFC83D', '#9BFF4D', '#FFFFFF', '#B07CFF', '#FF5A36'] },
  witch: { name: 'Шулам', bg: ['#22093C', '#0F6B45'], glow: '#7CFF6B', ink: '#F2FFE6', soft: '#D8F5C6', a: '#A8FF4F', b: '#D39BFF', c: '#FFB02E', light: false, pal: ['#A8FF4F', '#D39BFF', '#FFB02E', '#FFFFFF', '#6BE3FF', '#FF7AD9'] },
  slime: { name: 'Лиш', bg: ['#0D3A22', '#8BE02B'], glow: '#E8FF8A', ink: '#FBFFE6', soft: '#E6F8B8', a: '#FFE93B', b: '#FFFFFF', c: '#C77DFF', light: false, pal: ['#FFE93B', '#FFFFFF', '#C77DFF', '#7CFF3B', '#FF8A1F', '#6BE3FF'] },
  blood: { name: 'Цус', bg: ['#14030B', '#9A1426'], glow: '#FF5252', ink: '#FFEDED', soft: '#FFD0D0', a: '#FF6B6B', b: '#FFFFFF', c: '#FFC857', light: false, pal: ['#FF6B6B', '#FFFFFF', '#FFC857', '#FF3D7F', '#FFB3B3', '#B07CFF'] },
  bone: { name: 'Сарны гэрэл', bg: ['#0A1230', '#43569B'], glow: '#DDE8FF', ink: '#F6F2E4', soft: '#DCE4FF', a: '#FFE8A3', b: '#BFD0FF', c: '#FF9A5C', light: false, pal: ['#FFE8A3', '#BFD0FF', '#FF9A5C', '#FFFFFF', '#8FD3FF', '#D39BFF'] },
  candy: { name: 'Чихэр', bg: ['#FFB6E8', '#8F5BE8'], glow: '#FFFFFF', ink: '#2A0A4D', soft: '#4B1D7D', a: '#FF6A00', b: '#FFFFFF', c: '#00B386', light: true, pal: ['#FF6A00', '#FFFFFF', '#00B386', '#FFD23F', '#FF4D8D', '#6C3CE0'] }
});
const HT = ['pumpkin', 'witch', 'slime', 'blood', 'bone', 'candy'];
HT.forEach(id => X.THEME_IDS.push(id)); M.HALLOWEEN_THEMES = HT;
X.THEME_ORDER.length = 0; HT.concat(['blush', 'gold', 'sky', 'night', 'green', 'sun']).forEach(id => X.THEME_ORDER.push(id));

X.MOTIF_NAMES.pumpkin = 'Хулуу'; X.MOTIF_NAMES.ghost = 'Сүнс'; X.MOTIF_NAMES.cat = 'Хар муур'; X.MOTIF_NAMES.skull = 'Гавал'; X.MOTIF_NAMES.bucket = 'Чихрийн хувин';
X.OCC.halloween = {
  name: 'Хэллоуин', title: 'Хэллоуины мэнд!', theme: 'pumpkin', motif: 'pumpkin', motifs: ['pumpkin', 'ghost', 'cat', 'skull', 'bucket'],
  msg: 'Хэллоуины мэнд хүргэе! Өнөө орой хамгийн хөөрхөн мангасууд чамайг хайж явна. Чихрээ бэлд, үгүй бол инээлгэж орхино шүү!',
  fx: ['pumpkin', 'ghost', 'cat', 'monster', 'skeleton', 'hand', 'mummy', 'vampire', 'witch', 'slime', 'spider', 'bats', 'eyes', 'candy', 'fog', 'confetti']
};
X.OCC_IDS.push('halloween'); X.OCC_ORDER.unshift('halloween');
X.OCC.friend.fx = ['hand', 'monster', 'cat', 'pumpkin', 'spider', 'ghost', 'bats', 'eyes', 'confetti', 'cannon', 'hearts', 'disco'];
X.OCC.bday.fx = ['confetti', 'balloons', 'cannon', 'fireworks', 'monster', 'spider', 'ghost', 'hearts', 'disco'];

/* ---------- Ready-made designs ---------- */
const T = (n, name, fx, theme, motif, title, msg, open) => ({ id: 'h-' + n, builtin: true, name, occ: 'halloween', fx, theme, motif, title, msg, sfx: open ? { open } : {}, order: n });
[
  T(1, 'Хөөрхөн хулуу', 'pumpkin', 'pumpkin', 'pumpkin', 'Хулуу ирлээ!', 'Хулуу чамайг хараад инээмсэглэв. Хэллоуины мэнд хүргэе, өнөө орой чихэр элбэг байг!'),
  T(2, 'Инээдтэй сүнс', 'ghost', 'bone', 'ghost', 'Бүүү! Би сүнс байна', 'Айсан уу? Айгаагүй юм шиг дүр эсгэсэн ч зүгээр. Хэллоуины мэнд!', 'wail'),
  T(3, 'Хар муур', 'cat', 'witch', 'cat', 'Мяу, мяу!', 'Эхлээд сүртэй исгэрсэн ч дотроо зөөлөн зүрхтэй. Хэллоуины мэнд хүргэе!'),
  T(4, 'Шулам нисэв', 'witch', 'witch', 'pumpkin', 'Шулам нисэж ирлээ', 'Шулмын тогоо буцалж байна. Чихрээ бэлд, үгүй бол инээлгэж орхино шүү!', 'creak'),
  T(5, 'Араг яс бүжиглэв', 'skeleton', 'bone', 'skull', 'Шажигнаж ирлээ', 'Яс шажигнатал инээгээд толгойгоо ч мартчихлаа. Хэллоуины мэнд!', 'creak'),
  T(6, 'Мөмми гүйлээ', 'mummy', 'candy', 'ghost', 'Мөмми гүйж ирлээ', 'Уяа нь сулраад бүр бүдэрчихлээ. Чамд Хэллоуины мэнд хүргэе!'),
  T(7, 'Хөөрхөн мангас', 'monster', 'candy', 'pumpkin', 'Мангас найз', 'Архиран байгаад дараа нь өөрөө инээчихдэг хөөрхөн мангас чамайг хайж яваа шүү.'),
  T(8, 'Гар мэндэлж байна', 'hand', 'slime', 'skull', 'Газраас гар гарлаа', 'Айх хэрэггүй, зүгээр л мэндлэх гэсэн юм. Хэллоуины мэнд!'),
  T(9, 'Хөөрхөн цуст', 'vampire', 'blood', 'cat', 'Хөөрхөн цуст', 'Шүд нь урт ч сэтгэл нь дулаан. Хэллоуины мэнд хүргэе!', 'creak'),
  T(10, 'Лиж бороо', 'slime', 'slime', 'bucket', 'Лиж дусаллаа', 'Цэвэрлэхэд хэцүү ч инээхэд амархан. Хэллоуины мэнд хүргэе!'),
  T(11, 'Чихрийн бороо', 'candy', 'candy', 'bucket', 'Чихэр үү, зальжин уу?', 'Хувингаа бэлд! Өнөөдөр чихэр бороо шиг орно. Хэллоуины мэнд!'),
  T(12, 'Манан дахь сүнснүүд', 'fog', 'bone', 'ghost', 'Манан хөврөв', 'Харанхуйд гэрэл асаж, жижиг сүнснүүд бүжиглэж байна. Хэллоуины мэнд!', 'wail'),
  T(13, 'Аалз бууж ирэв', 'spider', 'pumpkin', 'pumpkin', 'Аалзнаас болгоомжил', 'Толгой дээр чинь юу байна вэ? Хэллоуины мэнд!', 'creak'),
  T(14, 'Харанхуйн нүд', 'eyes', 'blood', 'skull', 'Харж байна...', 'Харанхуйд хэдэн нүд чамайг ажиглаж байна. Хэллоуины мэнд!', 'wail')
].forEach(t => X.BUILTIN_TPL.push(t));
})();

;
/* core.js — shared helpers, config, card <-> render mapping. No backend knowledge in here. */
(function () {
'use strict';
const M = window.Mend;
const App = window.App = { M, backend: null, me: { uid: null, name: '', isAdmin: false, canWrite: false }, S: null, boot: { done: false } };

/* ---------- tiny emitter ---------- */
const subs = {};
App.on = (e, f) => { (subs[e] = subs[e] || []).push(f); };
App.emit = (e, a) => (subs[e] || []).slice().forEach(f => { try { f(a); } catch (err) { console.error(err); } });

/* ---------- DOM ---------- */
App.$ = id => document.getElementById(id);
App.h = function (tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const k in props) {
    const v = props[k];
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k === 'on') { for (const ev in v) e.addEventListener(ev, v[ev]); }
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k === 'for' || k.indexOf('-') > 0 || k === 'role') e.setAttribute(k, v === true ? '' : v);
    else if (k in e) e[k] = v;
    else e.setAttribute(k, v === true ? '' : v);
  }
  kids.flat(2).forEach(c => { if (c == null || c === false) return; e.append(c.nodeType ? c : document.createTextNode(String(c))); });
  return e;
};
const h = App.h;

App.toast = function (msg, ms) {
  let t = App.$('toast');
  if (!t) { t = h('div', { id: 'toast', role: 'status' }); document.body.append(t); }
  t.textContent = msg; t.hidden = false;
  clearTimeout(App.toast.h); App.toast.h = setTimeout(() => { t.hidden = true; }, ms || 3200);
};

/* in-page confirm (native dialogs are not reliable inside the artifact frame) */
App.confirm = function (msg, okText, danger) {
  return new Promise(res => {
    const done = v => { m.remove(); res(v); };
    const m = h('div', { class: 'modal', on: { click: e => { if (e.target === m) done(false); } } },
      h('div', { class: 'dlg', role: 'dialog', 'aria-modal': 'true' },
        h('p', { text: msg }),
        h('div', { class: 'btns' },
          h('button', { class: 'ghost', type: 'button', text: 'Болих', on: { click: () => done(false) } }),
          h('button', { class: danger ? 'danger' : 'primary', type: 'button', text: okText || 'Тийм', on: { click: () => done(true) } }))));
    document.body.append(m);
    m.querySelector('button').focus();
  });
};

App.prompt = function (msg, placeholder, okText) {
  return new Promise(res => {
    const done = v => { m.remove(); res(v); };
    const inp = h('input', { type: 'text', placeholder: placeholder || '', maxLength: 120, 'aria-label': msg, on: { keydown: e => { if (e.key === 'Enter') done(inp.value.trim()); if (e.key === 'Escape') done(null); } } });
    const m = h('div', { class: 'modal', on: { click: e => { if (e.target === m) done(null); } } },
      h('div', { class: 'dlg', role: 'dialog', 'aria-modal': 'true' }, h('p', { text: msg }), inp,
        h('div', { class: 'btns' },
          h('button', { class: 'ghost', type: 'button', text: 'Болих', on: { click: () => done(null) } }),
          h('button', { class: 'primary', type: 'button', text: okText || 'Болсон', on: { click: () => done(inp.value.trim()) } }))));
    document.body.append(m); inp.focus();
  });
};

/* ---------- formatting ---------- */
App.fmtT = ts => { if (!ts) return '—'; const d = new Date(ts), p = n => String(n).padStart(2, '0'); return `${d.getMonth() + 1}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; };
App.fmtMoney = n => (Math.round(n) || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '₮';
App.newId = () => { const a = 'abcdefghjkmnpqrstuvwxyz23456789'; const r = crypto.getRandomValues(new Uint8Array(8)); return Array.from(r, b => a[b % a.length]).join(''); };
App.refCode = id => 'MN-' + String(id).slice(0, 6).toUpperCase();
App.ST = { free: ['Үнэгүй', 'info'], ok: ['Төлөгдсөн', 'ok'], pending: ['Админ шалгаж байна', 'warn'], no: ['Татгалзсан', 'bad'], draft: ['Төлбөр хүлээгдэж байна', 'mute'] };
App.badge = st => { const [t, c] = App.ST[st] || ['—', 'mute']; return h('span', { class: 'badge ' + c, text: t }); };
App.copy = async function (text, okMsg, inputEl) {
  try { await navigator.clipboard.writeText(text); App.toast(okMsg || 'Хуулагдлаа'); }
  catch (e) { if (inputEl) { inputEl.focus(); inputEl.select(); } App.toast('Сонгосон. Хуулж аваарай.'); }
};

/* ---------- canvas ---------- */
App.fit = function (c) {
  const r = c.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = Math.max(1, Math.round(r.width)), hh = Math.max(1, Math.round(r.height));
  const pw = Math.round(w * dpr), ph = Math.round(hh * dpr);
  if (c.width !== pw || c.height !== ph) { c.width = pw; c.height = ph; }
  const ctx = c.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w, h: hh };
};

/* ---------- media elements (cached by source) ---------- */
const mcache = new Map();
App.media = {
  img(src) {
    if (!src) return null; let e = mcache.get(src);
    if (!e) { e = new Image(); e.decoding = 'async'; e.onload = () => App.emit('media'); e.src = src; mcache.set(src, e); }
    return e;
  },
  video(src) {
    if (!src) return null; let e = mcache.get(src);
    if (!e) {
      e = document.createElement('video'); e.muted = true; e.defaultMuted = true; e.loop = true; e.playsInline = true; e.setAttribute('playsinline', ''); e.preload = 'auto';
      e.addEventListener('loadeddata', () => App.emit('media')); e.src = src; mcache.set(src, e);
    }
    return e;
  },
  play(el) { if (el && el.tagName === 'VIDEO') { const p = el.play(); if (p && p.catch) p.catch(() => {}); } },
  pause(el) { if (el && el.tagName === 'VIDEO') el.pause(); }
};

/* A picture from the phone: shrink to fit a document (or an upload) and return a JPEG data URL. */
App.shrink = async function (file, max, targetKB) {
  let bmp;
  try { bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch (e) {
    bmp = await new Promise((res, rej) => { const i = new Image(), u = URL.createObjectURL(file); i.onload = () => { URL.revokeObjectURL(u); res(i); }; i.onerror = () => rej(new Error('bad image')); i.src = u; });
  }
  let sw = bmp.width || bmp.naturalWidth, sh = bmp.height || bmp.naturalHeight, k = Math.min(1, max / Math.max(sw, sh)), url = '', c;
  for (let round = 0; round < 4; round++) {
    c = document.createElement('canvas'); c.width = Math.max(1, Math.round(sw * k)); c.height = Math.max(1, Math.round(sh * k));
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
    let q = 0.84; url = c.toDataURL('image/jpeg', q);
    while (url.length * 0.75 > targetKB * 1024 && q > 0.45) { q -= 0.07; url = c.toDataURL('image/jpeg', q); }
    if (url.length * 0.75 <= targetKB * 1024) break;
    k *= 0.8;
  }
  if (bmp.close) bmp.close();
  return { url, w: c.width, h: c.height, kb: Math.round(url.length * 0.75 / 1024) };
};
App.dataUrlToBlob = function (u) {
  const [head, b64] = u.split(','), mime = (/data:([^;]+)/.exec(head) || [])[1] || 'application/octet-stream';
  const bin = atob(b64), arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
};
App.fileToB64 = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(f); });

/* ---------- configuration (live, from the backend) ---------- */
App.DEFAULT_MAIN = { payRequired: false, qpay: false, price: 5000, bank: '', account: '', holder: '', note: '', offFx: [], offThemes: [], offOcc: [], sfx: {} };
App.emptyCfg = () => ({ main: Object.assign({}, App.DEFAULT_MAIN), themes: [], sounds: [], media: [], templates: [] });
App.cfg = App.emptyCfg();
App.applyConfig = function (cfg) {
  cfg.main = Object.assign({}, App.DEFAULT_MAIN, cfg.main || {});
  ['offFx', 'offThemes', 'offOcc'].forEach(k => { if (!Array.isArray(cfg.main[k])) cfg.main[k] = []; });
  if (!cfg.main.sfx || typeof cfg.main.sfx !== 'object') cfg.main.sfx = {};
  cfg.templates = M.BUILTIN_TPL.concat((cfg.templates || []).filter(t => !t.builtin));
  App.cfg = cfg;
  cfg.themes.forEach(t => { try { M.registerTheme(t.id, M.buildTheme(t)); } catch (e) { /* bad colours: skip */ } });
  M.Sound.setLibrary(cfg.sounds); M.Sound.setMap(cfg.main.sfx);
  M.resetTextCache();
  App.emit('config', cfg);
};
App.bankReady = () => { const m = App.cfg.main; return !!(m.bank && m.account && m.holder && m.price > 0); };
/* QPay товч зөвхөн серверийн хувилбарт (backend.qpayStart байвал) гарна */
App.qpayReady = () => { const m = App.cfg.main; return !!(m.qpay && m.price > 0 && App.backend && App.backend.qpayStart); };
App.payReady = () => App.bankReady() || App.qpayReady();
App.occIds = () => M.OCC_ORDER.filter(o => !App.cfg.main.offOcc.includes(o));
App.fxIds = occ => M.occFx(occ).filter(f => !App.cfg.main.offFx.includes(f));
App.themeList = occ => {
  const hs = M.HALLOWEEN_THEMES || [], order = occ === 'halloween' ? M.THEME_ORDER : M.THEME_ORDER.filter(t => !hs.includes(t)).concat(hs);
  return order.filter(t => M.THEMES[t] && !App.cfg.main.offThemes.includes(t)).map(id => ({ id, name: M.THEMES[id].name }))
    .concat(App.cfg.themes.map(t => ({ id: t.id, name: t.name || 'Өнгө', custom: true })));
};
App.mediaList = role => App.cfg.media.filter(m => m.role === role);
App.mediaById = id => App.cfg.media.find(m => m.id === id) || null;
App.soundList = () => Object.keys(M.PRESETS).map(id => ({ id, name: M.PRESETS[id].name })).concat(App.cfg.sounds.map(s => ({ id: s.id, name: s.name + (s.file ? ' (файл)' : ''), custom: true })));

/* ---------- card model ---------- */
/* card = {id, occ, fx, theme, themeDef?, to, from, title, msg, photo, photoMode, bg, sticker, sfx, free, created, updated} */
App.blankCard = function (occ) {
  occ = occ || App.occIds()[0] || 'bday';
  const o = M.OCC[occ];
  return { id: null, occ, fx: App.fxIds(occ)[0], theme: o.theme, to: '', from: '', title: '', msg: '', photo: null, photoMode: 'circle', bg: null, sticker: null, sfx: null };
};
App.CARD_KEYS = ['occ', 'fx', 'theme', 'themeDef', 'motif', 'to', 'from', 'title', 'msg', 'photo', 'photoMode', 'bg', 'sticker', 'sfx'];
App.cardFields = c => { const o = {}; App.CARD_KEYS.forEach(k => { if (c[k] != null) o[k] = c[k]; }); return o; };
App.themeDefOf = id => { const t = App.cfg.themes.find(x => x.id === id); return t ? { name: t.name, bg0: t.bg0, bg1: t.bg1, glow: t.glow, ink: t.ink, a: t.a, b: t.b, c: t.c } : null; };
App.toR = function (c) {
  const o = M.OCC[c.occ] || M.OCC.other;
  if (c.themeDef && !M.THEMES[c.theme]) { try { M.registerTheme(c.theme, M.buildTheme(c.themeDef)); } catch (e) { /* ignore */ } }
  const bgM = c.bg && App.mediaById(c.bg), stM = c.sticker && App.mediaById(c.sticker);
  let photoEl = c.photo ? App.media.img(c.photo) : null, bgEl = null;
  if (photoEl && c.photoMode === 'bg') { bgEl = photoEl; photoEl = null; }
  else if (bgM) bgEl = bgM.kind === 'video' ? App.media.video(bgM.src) : App.media.img(bgM.src);
  return {
    occ: c.occ, motif: c.motif || null, fx: M.FXS[c.fx] ? c.fx : 'confetti', theme: M.THEMES[c.theme] ? c.theme : o.theme,
    name: (c.to || '').trim() || 'Найз минь', title: (c.title || '').trim() || o.title, msg: (c.msg || '').trim() || o.msg, from: (c.from || '').trim(),
    photoEl, bgEl, stickerEl: stM && stM.kind !== 'video' ? App.media.img(stM.src) : null, sfx: c.sfx || null
  };
};

/* ---------- links ---------- */
function decodeLegacy(tok) {
  try {
    let b = tok.replace(/-/g, '+').replace(/_/g, '/'); while (b.length % 4) b += '=';
    const bin = atob(b), bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
    const a = JSON.parse(new TextDecoder().decode(bytes));
    if (!Array.isArray(a) || a[0] !== 1) return null;
    const occ = M.OCC_IDS[a[1]], fx = M.FX_IDS[a[2]], theme = M.THEME_IDS[a[3]]; if (!occ || !fx || !theme) return null;
    const str = (v, n) => typeof v === 'string' ? v.slice(0, n) : '';
    return { occ, fx, theme, to: str(a[4], 24), from: str(a[5], 24), msg: str(a[6], 200), title: str(a[7], 40), free: true };
  } catch (e) { return null; }
}
/* What the address bar asks for: {type:'card',uid,id} | {type:'legacy',card} | null */
App.parseHash = function () {
  const s = (location.hash || '').replace(/^#/, '');
  if (s.startsWith('k~')) { const p = s.split('~'); if (p[1] && p[2]) return { type: 'card', uid: p[1], id: p[2] }; return null; }
  const d = s && decodeLegacy(s); return d ? { type: 'legacy', card: d } : null;
};

/* ---------- save a picture / file ---------- */
App.saveFile = async function (name, blob) {
  if (App.backend && App.backend.saveFile) return App.backend.saveFile(name, blob);
  const a = h('a', { href: URL.createObjectURL(blob), download: name }); document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  return 'saved';
};
App.renderPng = async function (card) {
  if (document.fonts && document.fonts.ready) await document.fonts.ready;
  const c = document.createElement('canvas'); c.width = 1000; c.height = 1600;
  const R = App.toR(card); M.resetTextCache();
  M.render(c.getContext('2d'), 1000, 1600, M.FINAL_T[R.fx], R); M.resetTextCache();
  return new Promise(r => c.toBlob(r, 'image/png'));
};

/* thumbnails: draw a card state onto a small canvas */
App.thumbDraw = function (canvas, card, fx) {
  const { ctx, w, h: hh } = App.fit(canvas); if (w < 8) return;
  const R = App.toR(card); if (fx) R.fx = fx;
  M.render(ctx, w, hh, M.THUMB_T[R.fx] || 1, R);
};

/* ---------- views ---------- */
App.views = {};
App.show = function (name) {
  App.view = name;
  Object.keys(App.views).forEach(k => { const el = App.$('v-' + k); if (el) el.hidden = k !== name; });
  document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', String(b.dataset.v === name)));
  const v = App.views[name]; if (v && v.enter) v.enter();
  window.scrollTo(0, 0);
};
})();

;
/* backend-common.js — pieces every backend shares: payment status, address handling, the no-storage fallback. */
(function () {
'use strict';
const App = window.App;

App.statusOf = function (m, ap) {
  const pay = App.cfg.main.payRequired;
  if (ap && ap.st === 'ok') return 'ok';
  if (m && m.free) return 'free';
  if (!pay) return 'free';
  if (ap && ap.st === 'no' && !(m && m.claim && m.claim > ap.at)) return 'no';
  if (m && m.claim) return 'pending';
  return 'draft';
};

App.noop = () => {};
App.hashNav = () => ({ current: () => App.parseHash(), clear() { if (location.hash) location.hash = ''; }, listen(fn) { window.addEventListener('hashchange', fn); } });
const noop = App.noop, nav = App.hashNav;

/* Works without any storage: preview, templates and old self-contained links still run. */
App.nullBackend = function (reason) {
  const fail = () => Promise.reject({ code: 'unavailable', message: reason || 'Хадгалах боломжгүй' });
  return {
    kind: 'null', reason, nav: nav(),
    async init() { return { uid: null, name: '', isAdmin: false, canWrite: false, canUpload: false }; },
    onConfig(cb) { cb(App.emptyCfg(), true); }, onMine(cb) { cb([]); },
    saveCard: fail, getCard: fail, claim: fail, deleteCard: fail, logVisit: noop,
    linkFor: () => '', names: async () => ({})
  };
};
})();

;
/* backend-rest.js — the server build keeps its data on the server (Express + SQLite) and talks to it over /api.
   It offers exactly the same methods as backend-artifact.js, so the rest of the app cannot tell the two apart.
   "Live" views are plain polling: every few seconds while the tab is visible, and straight away after the person's own changes. */
(function () {
'use strict';
const App = window.App, h = App.h;
const noop = App.noop, nav = App.hashNav;

App.restBackend = function () {
  /* Nobody has to sign up: anyone can make a card. The server hands out an anonymous "guest" account the first time
     something has to be saved (see ensure()); the person only pays for the card, never registers. */
  let me = { uid: null, name: '', isAdmin: false, canWrite: true, canUpload: false, guest: false };
  let cfgRev = -1, mineCb = null, guestP = null;
  const refresh = {};                       // name -> function that re-reads that list right now

  async function call(method, url, body, raw) {
    const opt = { method, credentials: 'same-origin', headers: { 'X-Requested-With': 'baiyn' } };
    if (raw) { opt.body = raw.blob; opt.headers['Content-Type'] = raw.type || 'application/octet-stream'; }
    else if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers['Content-Type'] = 'application/json'; }
    let r;
    try { r = await fetch(url, opt); } catch (e) { throw { code: 'unavailable', message: 'Сервертэй холбогдож чадсангүй. Интернэтээ шалгана уу.' }; }
    let j = null; try { j = await r.json(); } catch (e) { /* no body */ }
    if (!r.ok) throw { code: r.status === 401 ? 'unauthenticated' : 'unavailable', status: r.status, message: (j && j.message) || 'Алдаа гарлаа. Дахин оролдоно уу.' };
    return j;
  }
  const missing = e => e && (e.status === 404 || e.status === 400);

  /* make sure there is an account (an anonymous guest one if the person never signed in) before saving anything */
  async function ensure() {
    if (me.uid) return me;
    if (!guestP) guestP = (async () => {
      const u = await call('POST', '/api/guest');
      me.uid = u.uid; me.name = u.name || 'Зочин'; me.guest = !!u.guest; me.isAdmin = !!u.isAdmin; me.canWrite = true;
      cfgRev = -1;                                            // the payment details are only sent to people who have an account
      try { if (refresh.cfg) await refresh.cfg(); } catch (e) { /* the next poll will do it */ }
      if (mineCb && !refresh.mine) poll('mine', () => call('GET', '/api/mine'), mineCb, 8000);
    })().finally(() => { guestP = null; });
    await guestP; return me;
  }

  /* call `get` every `ms` while the page is visible; hand the result on only when it changed.
     refresh[name]() re-reads right now (waiting for a read already under way, so the answer is never older than the call). */
  function poll(name, get, cb, ms) {
    let last = null, cur = null;
    const run = force => {
      if (cur) return force ? cur.then(() => run(true)) : cur;
      cur = (async () => {
        try { const d = await get(); const s = JSON.stringify(d); if (s !== last) { last = s; cb(d); } } catch (e) { if (e && e.status === 401 && me.uid) { me.uid = null; location.reload(); } /* otherwise: try again next time */ }
      })().finally(() => { cur = null; });
      return cur;
    };
    refresh[name] = () => run(true);
    setInterval(() => { if (!document.hidden) run(false); }, ms);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) run(false); });
    run(false);
  }
  const again = (...names) => names.forEach(n => refresh[n] && refresh[n]());
  const done = (v, ...names) => { again(...names); return v; };

  const B = {
    kind: 'rest', nav: nav(),
    visitorsHint: 'Сайтад орсон, мэндчилгээний холбоос нээсэн хүмүүс. Админ нэрээрээ, бусад нь «Зочин» нэрээр харагдана.',
    visitWord: 'орсон',

    async init() {
      try { const u = await call('GET', '/api/me'); me = { uid: u.uid || null, name: u.name || '', isAdmin: !!u.isAdmin, canWrite: true, canUpload: !!u.isAdmin, guest: !!u.guest }; }
      catch (e) { /* offline: behave as a visitor without an account yet */ }
      return me;
    },

    /* ---- configuration ---- */
    onConfig(cb) {
      poll('cfg', async () => call('GET', '/api/config?rev=' + cfgRev), d => {
        if (d.same) return; cfgRev = d.rev;
        const cfg = App.emptyCfg();
        cfg.main = d.main || {};
        const byOrder = (a, b) => (a.order || 0) - (b.order || 0) || String(a.id).localeCompare(String(b.id));
        ['themes', 'sounds', 'templates'].forEach(k => { cfg[k] = (d[k] || []).sort(byOrder); });
        cfg.media = (d.media || []).map(x => { x.src = x.data || (x.assetId ? '/_blob/' + x.assetId : ''); return x; }).sort(byOrder);
        cb(cfg, true);
      }, 20000);
    },

    /* ---- the signed-in customer ---- */
    onMine(cb) {
      mineCb = cb;
      if (!me.uid) { cb([]); return; }                         // no account yet: the list starts once the first card is saved
      poll('mine', () => call('GET', '/api/mine'), cb, 8000);
    },
    async saveCard(card) {
      await ensure();
      const r = await call('POST', '/api/cards', { id: card.id || undefined, card: App.cardFields(card) });
      return done(r, 'mine', 'orders');
    },
    async getCard(ouid, id) {
      try { return await call('GET', `/api/card/${encodeURIComponent(ouid)}/${encodeURIComponent(id)}`); }
      catch (e) { if (missing(e)) return null; throw e; }
    },
    async claim(id) { return done(await call('POST', `/api/cards/${encodeURIComponent(id)}/claim`), 'mine', 'orders'); },
    async deleteCard(id) { return done(await call('DELETE', `/api/cards/${encodeURIComponent(id)}`), 'mine', 'orders'); },
    /* open = null: this person opened the app. open = {o, c}: this person opened card c of owner o. */
    logVisit(open) { return call('POST', '/api/visit', open ? { o: open.o, c: open.c } : {}).catch(noop); },
    linkFor(card) { const base = window.APP_BASE || (location.origin + '/'); return me.uid && card && card.id ? `${base}c/${me.uid}/${card.id}` : ''; },
    async names(ids) { return ids.length ? call('POST', '/api/admin/names', { ids }) : {}; },
    /* no saveFile: App.saveFile falls back to an ordinary browser download */

    /* ---- the owner ---- */
    onOrders(cb) { poll('orders', () => call('GET', '/api/admin/orders'), d => cb(d.list, d.users), 6000); },
    onVisitors(cb) { poll('visitors', () => call('GET', '/api/admin/visitors'), cb, 12000); },
    async setApproval(ouid, id, st, note, amt) { return done(await call('POST', '/api/admin/approve', { uid: ouid, id, st, note: note || '', amt: amt || 0 }), 'orders', 'bank'); },
    async clearApproval(id) { return done(await call('DELETE', '/api/admin/approve/' + encodeURIComponent(id)), 'orders', 'bank'); },
    async saveMain(patch) { return done(await call('PUT', '/api/admin/main', { patch }), 'cfg', 'bank'); },

    /* QPay: the customer pays by QR / bank app; the card opens when QPay itself confirms (only this build has it) */
    async qpayStart(id) { return call('POST', `/api/cards/${encodeURIComponent(id)}/qpay`); },
    async qpayStatus(id) { const r = await call('GET', `/api/cards/${encodeURIComponent(id)}/qpay`); if (r && r.paid) again('mine', 'orders'); return r; },
    async qpayGet() { return call('GET', '/api/admin/qpay'); },
    async qpaySave(v) { return done(await call('PUT', '/api/admin/qpay', v), 'cfg'); },
    async qpayTest() { return call('POST', '/api/admin/qpay/test'); },
    async qpayClear() { return done(await call('DELETE', '/api/admin/qpay'), 'cfg'); },

    /* bank income read from the owner's Gmail (only this build has it; the admin panel shows the section when onBank exists) */
    onBank(cb) { poll('bank', () => call('GET', '/api/admin/bank'), cb, 8000); },
    async bankAssign(id, card) { return done(await call('POST', `/api/admin/bank/${encodeURIComponent(id)}/assign`, { card }), 'bank', 'orders'); },
    async bankIgnore(id) { return done(await call('POST', `/api/admin/bank/${encodeURIComponent(id)}/ignore`), 'bank'); },
    async saveItem(kind, item) {
      const id = item.id || App.newId(), d = Object.assign({}, item); delete d.id; delete d.src;
      await call('PUT', `/api/admin/items/${kind}/${encodeURIComponent(id)}`, d);
      return done(id, 'cfg');
    },
    async deleteItem(kind, id) { return done(await call('DELETE', `/api/admin/items/${kind}/${encodeURIComponent(id)}`), 'cfg'); },
    async upload(blob, type) { return call('POST', '/api/admin/upload', undefined, { blob, type: type || blob.type }); },
    async deleteAsset(id) { if (id) await call('DELETE', '/api/admin/assets/' + encodeURIComponent(id)); },

    /* ---- account: sign in / out, shown in the page header ---- */
    openLogin() { loginDialog(); },
    mountAccount(el) {
      el.textContent = '';
      if (me.uid && !me.guest) {
        el.append(h('span', { class: 'nm', text: (me.name || 'Хэрэглэгч') + (me.isAdmin ? ' · Админ' : '') }),
          h('button', { class: 'ghost sm', type: 'button', text: 'Нууц үг', on: { click: passwordDialog } }),
          h('button', { class: 'ghost sm', type: 'button', text: 'Гарах', on: { click: async () => { try { await call('POST', '/api/logout'); } catch (e) { /* ignore */ } location.reload(); } } }));
      } else {
        el.append(h('button', { class: 'ghost sm', type: 'button', text: 'Нэвтрэх', on: { click: () => loginDialog() } }));
      }
    },
    reason: 'Холбоос авахын тулд нэвтрэх шаардлагагүй. Картаа хадгалахад л болно.'
  };

  /* ---------- dialogs ---------- */
  function modal(...kids) {
    const m = h('div', { class: 'modal', on: { mousedown: e => { if (e.target === m) m.remove(); } } },
      h('div', { class: 'dlg', role: 'dialog', 'aria-modal': 'true' }, ...kids));
    document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { m.remove(); document.removeEventListener('keydown', esc); } });
    document.body.append(m); return m;
  }

  /* Signing in is only for the owner (and anyone who already has an account): making and paying for a card needs no account. */
  function loginDialog() {
    const err = h('div', { class: 'stat bad err', role: 'alert', hidden: true });
    const ident = h('input', { type: 'text', inputMode: 'email', autocomplete: 'username', maxLength: 120, placeholder: 'и-мэйл эсвэл утасны дугаар', 'aria-label': 'И-мэйл эсвэл утасны дугаар' });
    const pw = h('input', { type: 'password', autocomplete: 'current-password', maxLength: 200, 'aria-label': 'Нууц үг' });
    const go = h('button', { class: 'primary', type: 'submit', text: 'Нэвтрэх' });
    const form = h('form', { novalidate: true, on: { submit: async e => {
      e.preventDefault(); err.hidden = true; go.disabled = true;
      try { await call('POST', '/api/login', { ident: ident.value, password: pw.value }); location.reload(); }
      catch (ex) { err.textContent = ex.message || 'Алдаа гарлаа.'; err.hidden = false; go.disabled = false; }
    } } },
      h('label', {}, 'И-мэйл эсвэл утас', ident),
      h('label', {}, 'Нууц үг', pw),
      err, go);
    const m = modal(h('h3', { text: 'Нэвтрэх' }),
      h('p', { class: 'hint', text: 'Мэндчилгээ бүтээх, төлбөр төлөх, холбоос авахад нэвтрэх шаардлагагүй. Энэ нь зөвхөн админ болон өмнө нь бүртгэлтэй хүмүүст зориулагдсан.' }),
      form, h('div', { class: 'btns' }, h('button', { class: 'ghost', type: 'button', text: 'Хаах', on: { click: () => m.remove() } })));
    setTimeout(() => ident.focus(), 0);
  }

  function passwordDialog() {
    const err = h('div', { class: 'stat bad err', role: 'alert', hidden: true });
    const old = h('input', { type: 'password', autocomplete: 'current-password', maxLength: 200, 'aria-label': 'Одоогийн нууц үг' });
    const nw = h('input', { type: 'password', autocomplete: 'new-password', maxLength: 200, 'aria-label': 'Шинэ нууц үг', placeholder: 'дор хаяж 8 тэмдэгт' });
    const go = h('button', { class: 'primary', type: 'submit', text: 'Солих' });
    const m = modal(h('h3', { text: 'Нууц үг солих' }),
      h('form', { novalidate: true, on: { submit: async e => {
        e.preventDefault(); err.hidden = true; go.disabled = true;
        try { await call('POST', '/api/password', { old: old.value, next: nw.value }); m.remove(); App.toast('Нууц үг солигдлоо.'); }
        catch (ex) { err.textContent = ex.message || 'Алдаа гарлаа.'; err.hidden = false; go.disabled = false; }
      } } }, h('label', {}, 'Одоогийн нууц үг', old), h('label', {}, 'Шинэ нууц үг', nw), err, go),
      h('div', { class: 'btns' }, h('button', { class: 'ghost', type: 'button', text: 'Хаах', on: { click: () => m.remove() } })));
    old.focus();
  }

  return B;
};
})();

;
/* maker.js — build a card, pay, get the link. Also "Миний картууд". */
(function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$;
let S = App.S = App.blankCard();
let mine = [], snapshot = '', busy = false, uploading = false;
const pv = { t0: performance.now(), playing: true };
const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
if (reduce) pv.playing = false;
const fieldsOf = () => JSON.stringify(App.cardFields(S));
const entryOf = () => (S.id ? mine.find(x => x.id === S.id) : null) || null;

/* ---------- build ---------- */
function build() {
  const root = $('v-make');
  root.append(
    h('p', { class: 'lead', text: 'Нэрийг нь бичиж, загвараа сонгоод холбоосыг нь илгээ. Хүлээн авсан хүн нээхэд салют буудаж, цэцэг сарнина, эсвэл аалз, сүнс гэнэт гарч ирж айлгана.' }),
    h('div', { class: 'maker' },
      h('section', { class: 'b-tpl', id: 'sec-tpl', hidden: true, 'aria-labelledby': 'h-tpl' }, h('h2', { id: 'h-tpl', text: 'Бэлэн загвар' }), h('div', { id: 'tplThumbs', class: 'thumbs tpl' })),
      h('section', { class: 'b-occ', 'aria-labelledby': 'h-occ' }, h('h2', { id: 'h-occ' }, h('span', { class: 'n', text: '1' }), 'Ямар баяр вэ?'), h('div', { id: 'chips', class: 'chips', role: 'radiogroup', 'aria-labelledby': 'h-occ' })),
      h('section', { class: 'b-text', 'aria-labelledby': 'h-text' }, h('h2', { id: 'h-text' }, h('span', { class: 'n', text: '2' }), 'Хэнд, юу гэж бичих вэ?'),
        h('div', { class: 'fields' },
          h('label', { for: 'toName' }, 'Хэнд', h('input', { id: 'toName', type: 'text', maxLength: 24, placeholder: 'Жишээ нь: Болд', autocomplete: 'off' })),
          h('label', { for: 'fromName' }, 'Таны нэр', h('input', { id: 'fromName', type: 'text', maxLength: 24, placeholder: 'Жишээ нь: Азаа', autocomplete: 'off' })),
          h('label', { class: 'wide', for: 'titleIn' }, h('span', {}, 'Гарчиг', h('small', { text: 'заавал биш' })), h('input', { id: 'titleIn', type: 'text', maxLength: 40, autocomplete: 'off' })),
          h('label', { class: 'wide', for: 'msgIn' }, h('span', {}, 'Мэндчилгээний үг', h('small', { text: 'заавал биш' })), h('textarea', { id: 'msgIn', rows: 3, maxLength: 160 }), h('span', { class: 'count', id: 'msgCount' })))),
      h('section', { class: 'b-photo', 'aria-labelledby': 'h-photo' }, h('h2', { id: 'h-photo' }, h('span', { class: 'n', text: '3' }), 'Зураг нэмэх', h('small', { class: 'hint', text: 'заавал биш' })),
        h('div', { class: 'photo-row' },
          h('div', { class: 'ph-prev', id: 'phPrev', text: 'Зураг алга' }),
          h('div', { style: { flex: '1 1 220px', display: 'flex', flexDirection: 'column', gap: '10px', minWidth: 0 } },
            h('p', { class: 'hint', text: 'Утсаараа зураг авах эсвэл галерейгаас сонгоно. Зураг мэндчилгээний голд гарна.' }),
            h('div', { class: 'ph-btns' },
              h('label', { class: 'ghost file-btn', id: 'phPick' }, h('span', { id: 'phPickT', text: 'Зураг сонгох' }), h('input', { id: 'phFile', type: 'file', accept: 'image/*', 'aria-label': 'Зураг сонгох' })),
              h('button', { class: 'ghost', id: 'phDel', type: 'button', text: 'Устгах', hidden: true })),
            h('div', { class: 'chips', id: 'phMode', hidden: true, role: 'radiogroup', 'aria-label': 'Зургийн байрлал' },
              ...[['circle', 'Дугуй хүрээнд'], ['bg', 'Бүтэн арын зураг']].map(([v, t]) => h('button', { class: 'chip', type: 'button', role: 'radio', 'data-m': v, text: t, on: { click: () => { S.photoMode = v; changed(); } } })))))),
      h('div', { class: 'stage' },
        h('section', { class: 'pv', 'aria-label': 'Урьдчилан харах' },
          h('div', { class: 'cardbox' }, h('canvas', { id: 'pvCanvas', role: 'img', 'aria-label': 'Мэндчилгээний урьдчилсан харагдац' })),
          h('div', { class: 'pvbtns' },
            h('button', { id: 'replay', class: 'ghost', type: 'button', text: 'Дахин тоглуулах', on: { click: () => { pv.t0 = performance.now(); pv.playing = true; } } }),
            h('button', { id: 'testBtn', class: 'ghost', type: 'button', text: 'Хүлээн авагчийн нүдээр үзэх', on: { click: () => App.openViewer({ card: Object.assign({}, S), test: true }) } }))),
        h('section', { class: 'send', id: 'send', 'aria-labelledby': 'h-send' })),
      h('section', { class: 'b-design', 'aria-labelledby': 'h-design' }, h('h2', { id: 'h-design' }, h('span', { class: 'n', text: '4' }), 'Хөдөлгөөнөө сонго'), h('div', { id: 'thumbs', class: 'thumbs' })),
      h('section', { class: 'b-color', 'aria-labelledby': 'h-color' }, h('h2', { id: 'h-color' }, h('span', { class: 'n', text: '5' }), 'Өнгө'), h('div', { id: 'swatches', class: 'swatches' })),
      h('section', { class: 'b-extra', id: 'sec-extra', hidden: true, 'aria-labelledby': 'h-extra' }, h('h2', { id: 'h-extra' }, h('span', { class: 'n', text: '6' }), 'Дүрс, дэвсгэр, наалт'), h('div', { id: 'extra' }))));

  $('toName').addEventListener('input', e => { S.to = e.target.value; changed(); });
  $('fromName').addEventListener('input', e => { S.from = e.target.value; try { localStorage.setItem('mend.from', e.target.value); } catch (err) { /* private mode */ } changed(); });
  $('titleIn').addEventListener('input', e => { S.title = e.target.value; changed(); });
  $('msgIn').addEventListener('input', e => { S.msg = e.target.value; changed(); });
  $('phFile').addEventListener('change', async e => { const f = e.target.files && e.target.files[0]; e.target.value = ''; await onPhoto(f); });
  $('phDel').addEventListener('click', () => { S.photo = null; changed(); });
  try { const f = localStorage.getItem('mend.from'); if (f) { S.from = f.slice(0, 24); $('fromName').value = S.from; } } catch (e) { /* ignore */ }
}

async function onPhoto(f) {
  if (!f) return;
  if (!/^image\//.test(f.type) && !/\.(jpe?g|png|webp|heic|heif|gif)$/i.test(f.name || '')) { App.toast('Зураг сонгоно уу.'); return; }
  uploading = true; $('phPickT').textContent = 'Уншиж байна…';
  try { const r = await App.shrink(f, 720, 110); S.photo = r.url; changed(); }
  catch (e) { App.toast('Зургийг уншиж чадсангүй. Өөр зураг сонгоно уу.'); }
  uploading = false; $('phPickT').textContent = S.photo ? 'Солих' : 'Зураг сонгох';
}

/* ---------- lists that depend on configuration ---------- */
function setTheme(id) { S.theme = id; const d = App.themeDefOf(id); if (d) S.themeDef = d; else delete S.themeDef; }
function buildChips() {
  const box = $('chips'); box.textContent = '';
  const ids = App.occIds(); if (!ids.includes(S.occ) && !S.id) { S.occ = ids[0] || 'bday'; }
  ids.concat(ids.includes(S.occ) ? [] : [S.occ]).forEach(id => {
    box.append(h('button', {
      type: 'button', class: 'chip', role: 'radio', 'data-id': id, text: M.OCC[id].name,
      on: { click: () => { S.occ = id; S.motif = null; setTheme(M.OCC[id].theme); if (!App.fxIds(id).includes(S.fx)) S.fx = App.fxIds(id)[0]; buildThumbs(); buildSwatches(); buildExtra(); syncAll(); } }
    }));
  });
}
function buildSwatches() {
  const box = $('swatches'); box.textContent = '';
  App.themeList(S.occ).forEach(t => {
    const th = M.THEMES[t.id]; if (!th) return;
    const b = h('button', { type: 'button', class: 'sw', title: t.name, 'aria-label': 'Өнгө: ' + t.name, 'data-id': t.id, on: { click: () => { setTheme(t.id); syncAll(); } } });
    b.style.background = `linear-gradient(160deg,${th.bg[0]},${th.bg[1]})`; box.append(b);
  });
  if (M.THEMES[S.theme] && !App.themeList(S.occ).some(t => t.id === S.theme)) {
    const th = M.THEMES[S.theme], b = h('button', { type: 'button', class: 'sw', title: th.name, 'aria-label': 'Өнгө: ' + th.name, 'data-id': S.theme }); b.style.background = `linear-gradient(160deg,${th.bg[0]},${th.bg[1]})`; box.append(b);
  }
}
function buildThumbs() {
  const box = $('thumbs'); box.textContent = '';
  const ids = App.fxIds(S.occ); if (!ids.includes(S.fx) && M.FXS[S.fx]) ids.unshift(S.fx);
  ids.forEach(id => {
    const b = h('button', { type: 'button', class: 'thumb', 'data-fx': id, on: { click: () => { S.fx = id; pv.t0 = performance.now(); if (!reduce) pv.playing = true; syncAll(); } } },
      h('canvas', { 'aria-hidden': 'true' }), h('span', { text: M.FXS[id].name }), M.FXS[id].scare && h('em', { text: 'Айлгана' }));
    box.append(b);
  });
}
function buildTemplates() {
  const box = $('tplThumbs'), list = App.cfg.templates.filter(t => !App.cfg.main.offOcc.includes(t.occ));
  box.textContent = ''; $('sec-tpl').hidden = !list.length;
  list.forEach(t => {
    box.append(h('button', { type: 'button', class: 'thumb', 'data-tpl': t.id, on: { click: () => applyTemplate(t) } }, h('canvas', { 'aria-hidden': 'true' }), h('span', { text: t.name || 'Загвар' })));
  });
}
function mediaPicker(role, title) {
  const list = App.mediaList(role).filter(m => role !== 'sticker' || m.kind !== 'video'), key = role === 'bg' ? 'bg' : 'sticker';
  if (!list.length) return null;
  const items = [h('button', { type: 'button', class: 'mi', 'aria-pressed': String(!S[key]), 'data-id': '', 'data-key': key, on: { click: () => { S[key] = null; syncAll(); } } }, 'Алга')];
  list.forEach(m => {
    const media = m.kind === 'video' ? h('video', { src: m.src, muted: true, playsInline: true, preload: 'metadata' }) : h('img', { src: m.src, alt: m.name || '' });
    items.push(h('button', { type: 'button', class: 'mi', 'aria-pressed': String(S[key] === m.id), 'data-id': m.id, 'data-key': key, title: m.name || '', on: { click: () => { S[key] = m.id; syncAll(); } } }, media, m.kind === 'video' && h('span', { class: 'tag', text: 'видео' })));
  });
  return h('div', {}, h('div', { class: 'sub', text: title }), h('div', { class: 'mgrid' }, items));
}
function motifPicker() {
  const o = M.OCC[S.occ]; if (!o || !o.motifs || o.motifs.length < 2) return null;
  return h('div', {}, h('div', { class: 'sub', text: 'Гол дүрс' }),
    h('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Гол дүрс' }, o.motifs.map(id => h('button', { type: 'button', class: 'chip', role: 'radio', 'data-motif': id, text: M.MOTIF_NAMES[id] || id, on: { click: () => { S.motif = id; syncAll(); } } }))));
}
function buildExtra() {
  const box = $('extra'); box.textContent = '';
  const mp = motifPicker(), bg = mediaPicker('bg', 'Арын дэвсгэр'), st = mediaPicker('sticker', 'Голын наалт');
  [mp, bg, st].forEach(x => x && box.append(x)); $('sec-extra').hidden = !(mp || bg || st);
}
function applyTemplate(t) {
  S.occ = t.occ || S.occ; S.fx = t.fx || S.fx; S.motif = t.motif || null; setTheme(t.theme || S.theme);
  S.bg = t.bg && App.mediaById(t.bg) ? t.bg : null; S.sticker = t.sticker && App.mediaById(t.sticker) ? t.sticker : null; S.sfx = t.sfx || null;
  if (t.title) S.title = t.title; if (t.msg) S.msg = t.msg;
  pv.t0 = performance.now(); if (!reduce) pv.playing = true;
  syncFields(); buildThumbs(); buildSwatches(); buildExtra(); syncAll();
}
function syncFields() {
  $('toName').value = S.to || ''; $('fromName').value = S.from || ''; $('titleIn').value = S.title || ''; $('msgIn').value = S.msg || '';
}

/* ---------- state -> screen ---------- */
function syncAll() {
  document.querySelectorAll('#chips .chip').forEach(b => b.setAttribute('aria-checked', String(b.dataset.id === S.occ)));
  document.querySelectorAll('#swatches .sw').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.id === S.theme)));
  document.querySelectorAll('#thumbs .thumb').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.fx === S.fx)));
  document.querySelectorAll('#extra .mi').forEach(b => b.setAttribute('aria-pressed', String((S[b.dataset.key] || '') === b.dataset.id)));
  document.querySelectorAll('#extra [data-motif]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.motif === (S.motif || (M.OCC[S.occ] || {}).motif))));
  const o = M.OCC[S.occ] || M.OCC.other;
  $('titleIn').placeholder = o.title; $('msgIn').placeholder = o.msg;
  changed();
}
let thumbQ = 0;
function changed() {
  $('msgCount').textContent = ($('msgIn').value.length) + ' / 160';
  const ph = $('phPrev');
  ph.style.backgroundImage = S.photo ? `url("${S.photo}")` : ''; ph.textContent = S.photo ? '' : 'Зураг алга';
  $('phDel').hidden = !S.photo; $('phMode').hidden = !S.photo; $('phPickT').textContent = S.photo ? 'Солих' : 'Зураг сонгох';
  document.querySelectorAll('#phMode .chip').forEach(b => b.setAttribute('aria-checked', String(b.dataset.m === (S.photoMode || 'circle'))));
  const R = App.toR(S); App.media.play(R.bgEl);
  renderSend();
  if (!thumbQ) thumbQ = requestAnimationFrame(() => { thumbQ = 0; renderThumbs(); });
}
function renderThumbs() {
  document.querySelectorAll('#thumbs canvas').forEach(c => App.thumbDraw(c, S, c.parentElement.dataset.fx));
  const tpl = Object.fromEntries(App.cfg.templates.map(t => [t.id, t]));
  document.querySelectorAll('#tplThumbs .thumb').forEach(b => {
    const t = tpl[b.dataset.tpl]; if (!t) return;
    App.thumbDraw(b.querySelector('canvas'), { occ: t.occ, fx: t.fx, motif: t.motif, theme: t.theme, themeDef: App.themeDefOf(t.theme) || undefined, to: S.to || 'Азаа', from: S.from, title: t.title, msg: t.msg, bg: t.bg, sticker: t.sticker }, t.fx);
  });
}
function previewFrame(now) {
  requestAnimationFrame(previewFrame);
  if (App.view !== 'make' || document.hidden || App.viewerOpen) return;
  const c = $('pvCanvas'), { ctx, w, h: hh } = App.fit(c); if (w < 8) return;
  let t = M.THUMB_T[S.fx] || 1;
  if (pv.playing) { t = (now - pv.t0) / 1000; if (M.LOOP[S.fx]) t %= M.LOOP[S.fx]; }
  M.render(ctx, w, hh, t, App.toR(S));
}

/* ---------- send panel ---------- */
function errMsg(e) {
  const c = e && e.code;
  if (c === 'invalid_argument') return 'Таны эрх зөвхөн үзэх түвшинд байна. Админаас «Contributor» эрх авна уу.';
  if (c === 'quota_exceeded') return 'Хадгалах багтаамж дүүрсэн байна. Админд мэдэгдээрэй.';
  if (c === 'unavailable' && e.message) return e.message;
  return 'Хадгалж чадсангүй. Дахин оролдоно уу.';
}
async function save() {
  if (busy) return;
  if (!S.id && mine.length >= 80) { App.toast('Хадгалах карт 80 хүрсэн. Хуучныг нь устгана уу.'); return; }
  busy = true; renderSend();
  try {
    const free = S.id ? !!S.free : (!App.cfg.main.payRequired || App.me.isAdmin);
    const doc = await App.backend.saveCard(S, free);
    S.id = doc.id; S.free = doc.free; S.created = doc.created; if (doc.photo) S.photo = doc.photo;
    snapshot = fieldsOf(); App.toast('Хадгалагдлаа.');
  } catch (e) { App.toast(errMsg(e), 5000); }
  busy = false; renderSend();
}
async function claim() {
  if (busy) return; busy = true; renderSend();
  try { await App.backend.claim(S.id); App.toast('Админд мэдэгдлээ. Баталгаажихыг хүлээнэ үү.'); } catch (e) { App.toast(errMsg(e), 5000); }
  busy = false; renderSend();
}
function newCard() {
  const from = S.from; S = App.S = App.blankCard(); S.from = from; snapshot = '';
  buildChips(); buildThumbs(); buildSwatches(); buildExtra(); syncFields(); syncAll();
}
function kvRow(k, v, copy) {
  return h('div', { class: 'kvr' },
    h('div', { class: 'kvt' }, h('span', { class: 'kvk', text: k }), h('span', { class: 'kvv', text: v })),
    copy && h('button', { type: 'button', class: 'ghost sm', text: 'Хуулах', on: { click: () => App.copy(v, k + ' хуулагдлаа') } }));
}
/* ---------- QPay (server build only): QR + bank-app links, the card opens when QPay itself confirms ---------- */
const Q = { id: '', inv: null, busy: false, err: '', timer: 0, polling: false };
function qpayReset() { clearInterval(Q.timer); Q.timer = 0; Q.inv = null; Q.err = ''; Q.id = ''; Q.polling = false; }
async function qpayStart() {
  if (Q.busy || !S.id) return;
  Q.busy = true; Q.err = ''; renderSend();
  const id = S.id;
  try {
    const inv = await App.backend.qpayStart(id);
    if (S.id === id) { Q.inv = inv; Q.id = id; clearInterval(Q.timer); Q.timer = setInterval(() => qpayPoll(false), 4000); }
  } catch (e) { Q.err = errMsg(e); }
  Q.busy = false; renderSend();
}
async function qpayPoll(manual) {
  if (!Q.inv) return;
  if (Q.id !== S.id) { qpayReset(); return; }
  if ((document.hidden && !manual) || Q.polling) return;
  Q.polling = true; const id = Q.id;
  try {
    const r = await App.backend.qpayStatus(id);
    if (r && r.paid) { if (Q.id === id) qpayReset(); App.toast('Төлбөр баталгаажлаа. Холбоос бэлэн боллоо.'); }
    else if (manual) App.toast(r && r.st === 'error' ? 'QPay-ээс хариу авч чадсангүй. Түр хүлээгээд дахин шалгана уу.' : 'Төлбөр хараахан ирээгүй байна. Төлсөн бол хэдэн секунд хүлээгээд дахин шалгана уу.', 4500);
  } catch (e) { if (manual) App.toast(errMsg(e), 4500); }
  Q.polling = false;
}
function qpayBox(dirty) {
  const inv = Q.inv && Q.id === S.id ? Q.inv : null;
  if (!inv) return h('div', { class: 'qpay' },
    h('button', { class: 'primary', type: 'button', disabled: busy || Q.busy || dirty, text: Q.busy ? 'QR бэлдэж байна…' : 'QPay-ээр төлөх', on: { click: qpayStart } }),
    h('p', { class: 'hint', text: 'QR кодыг банкныхаа апп-аар уншуулах, эсвэл банкаа сонгоод шууд төлнө. Төлсөн даруйд холбоос энд өөрөө гарч ирнэ.' }),
    Q.err && h('div', { class: 'stat bad', role: 'alert', text: Q.err }));
  return h('div', { class: 'qpay' },
    inv.qr && h('div', { class: 'qrbox' }, h('img', { class: 'qr', src: 'data:image/png;base64,' + inv.qr, alt: 'QPay төлбөрийн QR код' }), h('div', { class: 'hint', text: 'Банкныхаа апп-аар уншуулна уу' })),
    inv.urls.length > 0 && h('div', { class: 'banks', role: 'group', 'aria-label': 'Банкны апп сонгох' }, inv.urls.map(u => h('a', { class: 'ghost sm', href: u.link, rel: 'noopener', title: u.desc || u.name, text: u.name }))),
    inv.short && h('p', { class: 'hint' }, h('a', { href: inv.short, target: '_blank', rel: 'noopener noreferrer', text: 'QPay хуудас дээр нээх' })),
    h('div', { class: 'stat warn' }, h('span', { class: 'sk', 'aria-hidden': 'true' }), h('span', { text: 'Төлбөрийг хүлээж байна. Төлмөгц холбоос энд өөрөө гарч ирнэ.' })),
    h('div', { class: 'pvbtns' },
      h('button', { class: 'ghost sm', type: 'button', text: 'Төлбөр шалгах', on: { click: () => qpayPoll(true) } }),
      h('button', { class: 'ghost sm', type: 'button', text: 'Хаах', on: { click: () => { qpayReset(); renderSend(); } } })));
}
function payBox(dirty) {
  const m = App.cfg.main, bankOk = App.bankReady(), qp = App.qpayReady();
  return h('div', { class: 'pay' },
    h('div', { class: 'hint', text: 'Төлөх дүн' }), h('div', { class: 'amt', text: App.fmtMoney(m.price) }),
    qp && qpayBox(dirty),
    bankOk && qp && h('div', { class: 'or', text: 'эсвэл банкны шилжүүлгээр' }),
    bankOk && h('div', { class: 'kv' }, kvRow('Банк', m.bank), kvRow('Данс', m.account, true), kvRow('Хүлээн авагч', m.holder), kvRow('Гүйлгээний утга', App.refCode(S.id), true)),
    !bankOk && !qp && h('div', { class: 'stat warn', text: 'Төлбөрийн мэдээллийг админ одоогоор оруулаагүй байна. Түр хүлээнэ үү.' }),
    bankOk && m.note && h('p', { class: 'hint', text: m.note }),
    bankOk && h('p', { class: 'hint', text: m.autoPay ? 'Гүйлгээний утга дээр дээрх кодыг ЗААВАЛ бичнэ: код дээр тулгуурлан карт өөрөө нээгдэнэ. Шилжүүлсний дараа ихэвчлэн 1-2 минутад холбоос энд гарч ирнэ. «Төлсөн» товчийг дарвал админд мэдэгдэнэ.' : 'Гүйлгээний утга дээр дээрх кодыг заавал бичнэ. Шилжүүлсний дараа «Төлсөн» товчийг дарна.' }),
    bankOk && h('button', { class: 'primary', type: 'button', disabled: busy || dirty, text: 'Төлсөн', on: { click: claim } }),
    dirty && h('p', { class: 'hint', text: 'Эхлээд доорх «Өөрчлөлтийг хадгалах» товчийг дарна уу.' }));
}
function linkBox() {
  const link = App.backend.linkFor(S);
  if (!link) return h('div', { class: 'stat warn', text: 'Холбоос бэлэн болоогүй байна. Хуудсыг дахин нээгээд оролдоно уу.' });
  const inp = h('input', { class: 'ro', type: 'text', readOnly: true, value: link, 'aria-label': 'Мэндчилгээний холбоос' });
  const rows = [h('div', { class: 'linkrow' }, inp, h('button', { class: 'primary', type: 'button', text: 'Хуулах', on: { click: () => App.copy(link, 'Холбоос хуулагдлаа. Одоо найздаа илгээгээрэй.', inp) } }))];
  const acts = [];
  if (navigator.share) acts.push(h('button', { class: 'ghost', type: 'button', text: 'Хуваалцах', on: { click: async () => { try { await navigator.share({ title: 'Баярын мэнд', text: (S.to || 'Найз минь') + ' танд мэндчилгээ ирлээ', url: link }); } catch (e) { /* cancelled */ } } } }));
  if (App.backend.canDownload !== false) acts.push(h('button', { class: 'ghost', type: 'button', text: 'Зураг болгож хадгалах', on: { click: async () => {
    try { const b = await App.renderPng(S); const r = await App.saveFile('baiyn-mend.png', b); if (r) App.toast('Зураг хадгалагдлаа.'); } catch (e) { if (!e || e.code !== 'declined') App.toast('Зураг хадгалж чадсангүй.'); } } } }));
  if (acts.length) rows.push(h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start' } }, acts));
  rows.push(h('p', { class: 'hint', text: 'Холбоосыг Messenger, Viber, Facebook, Telegram-аар илгээнэ. Хүлээн авсан хүн нээгээд «Нээх» товчийг дарахад мэндчилгээ тоглоно.' }));
  return h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } }, rows);
}
const loginBtn = () => App.backend && App.backend.openLogin ? h('button', { class: 'primary', type: 'button', text: 'Нэвтрэх / бүртгүүлэх', on: { click: () => App.backend.openLogin() } }) : null;
function renderSend() {
  const box = $('send'); if (!box) return;
  const kids = [h('h2', { id: 'h-send', text: 'Илгээх' })];
  const entry = entryOf(), stt = entry ? App.statusOf(entry, entry.ap) : null, dirty = !!entry && snapshot !== fieldsOf();
  const m = App.cfg.main;
  if (Q.inv && (Q.id !== S.id || stt === 'ok' || stt === 'free')) qpayReset();
  if (!App.me.canWrite) {
    kids.push(h('div', { class: 'stat info', text: (App.backend && App.backend.reason) || 'Холбоос авахын тулд нэвтэрсэн байх шаардлагатай. Одоогоор урьдчилан харах боломжтой.' }), loginBtn());
  } else if (!entry) {
    const paid = m.payRequired && !App.me.isAdmin;
    if (paid) kids.push(h('div', { class: 'pay' }, h('div', { class: 'hint', text: 'Холбоос авахын үнэ' }), h('div', { class: 'amt', text: App.fmtMoney(m.price) }), h('p', { class: 'hint', text: App.qpayReady() ? 'Эхлээд картаа хадгална. Дараа нь QPay-ээр шууд төлнө, төлсөн даруйд холбоос нээгдэнэ.' : 'Эхлээд картаа хадгална. Дараа нь банкны мэдээлэл гарч ирнэ. Шилжүүлгийг админ баталгаажуулмагц холбоос нээгдэнэ.' })));
    kids.push(h('button', { class: 'primary', type: 'button', disabled: busy, text: busy ? 'Хадгалж байна…' : (paid ? 'Хадгалаад төлбөр рүү' : 'Холбоос авах'), on: { click: save } }));
  } else {
    if (dirty) kids.push(h('button', { class: 'primary', type: 'button', disabled: busy, text: busy ? 'Хадгалж байна…' : 'Өөрчлөлтийг хадгалах', on: { click: save } }));
    if (stt === 'free' || stt === 'ok') {
      if (stt === 'ok') kids.push(h('div', { class: 'stat ok', text: 'Төлбөр баталгаажлаа. Холбоосоо илгээж болно.' }));
      kids.push(linkBox());
      if (dirty) kids.push(h('p', { class: 'hint', text: 'Хадгалахаас өмнө хийсэн өөрчлөлт холбоост ороогүй байна.' }));
    } else if (stt === 'pending') {
      kids.push(h('div', { class: 'stat warn' }, h('span', { class: 'sk', 'aria-hidden': 'true' }), h('span', { text: m.autoPay ? 'Шилжүүлгийг хүлээж байна. Банкинд орсон даруйд холбоос энд өөрөө гарч ирнэ (ихэвчлэн 1-2 минут). Гүйлгээний утганд ' + App.refCode(S.id) + ' кодыг бичсэн байх ёстой.' : 'Админ таны шилжүүлгийг шалгаж байна. Баталгаажмагц энд холбоос гарч ирнэ. Гүйлгээний утга: ' + App.refCode(S.id) })));
    } else if (stt === 'no') {
      kids.push(h('div', { class: 'stat bad', text: 'Төлбөр баталгаажсангүй.' + (entry.ap && entry.ap.note ? ' Админы тайлбар: ' + entry.ap.note : '') }), payBox(dirty));
    } else {
      kids.push(payBox(dirty));
    }
    kids.push(h('button', { class: 'ghost', type: 'button', text: 'Шинэ мэндчилгээ эхлэх', on: { click: newCard } }));
  }
  box.textContent = ''; box.append(...kids);
}

/* ---------- my cards ---------- */
function mineView() {
  const root = $('v-mine'); root.textContent = '';
  root.append(h('p', { class: 'lead', text: 'Таны хадгалсан мэндчилгээнүүд. Төлбөрийн төлөв энд шууд шинэчлэгдэнэ.' }));
  if (!App.me.canWrite) { root.append(h('div', { class: 'stat info', text: (App.backend && App.backend.reason) || 'Картаа хадгалахын тулд нэвтэрсэн байх шаардлагатай.' }), loginBtn()); return; }
  if (!mine.length) { root.append(h('div', { class: 'empty' }, h('p', { text: 'Одоогоор хадгалсан мэндчилгээ алга.' }), h('p', { style: { marginTop: '10px' } }, h('button', { class: 'primary', type: 'button', text: 'Шинээр бүтээх', on: { click: () => App.show('make') } })))); return; }
  const rows = h('div', { class: 'rows' });
  mine.forEach(e => {
    const stt = App.statusOf(e, e.ap), canv = h('canvas', { 'aria-hidden': 'true' });
    rows.append(h('div', { class: 'row', 'data-id': e.id },
      canv,
      h('div', { class: 'grow' }, h('div', { class: 't', text: (e.to || 'Нэргүй') + ' · ' + (M.OCC[e.occ] ? M.OCC[e.occ].name : '') }), h('div', { class: 's', text: (M.FXS[e.fx] ? M.FXS[e.fx].name : '') + ' · ' + App.fmtT(e.at) + (stt === 'draft' || stt === 'no' ? ' · Утга: ' + App.refCode(e.id) : '') + (e.views ? ' · ' + e.views + ' удаа нээгдсэн' : '') })),
      App.badge(stt),
      h('div', { class: 'acts' },
        h('button', { class: 'ghost sm', type: 'button', text: 'Нээх', on: { click: () => openMine(e.id) } }),
        h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: async () => { if (await App.confirm('Энэ мэндчилгээг устгах уу? Илгээсэн холбоос ажиллахаа болино.', 'Устгах', true)) { try { await App.backend.deleteCard(e.id); if (S.id === e.id) newCard(); App.toast('Устгагдлаа.'); } catch (er) { App.toast(errMsg(er)); } } } } }))));
    requestAnimationFrame(() => App.thumbDraw(canv, { occ: e.occ, fx: e.fx, theme: (M.OCC[e.occ] || M.OCC.other).theme, to: e.to || 'Нэр' }, e.fx));
  });
  root.append(rows);
}
async function openMine(id) {
  try {
    const r = await App.backend.getCard(App.me.uid, id);
    if (!r) { App.toast('Карт олдсонгүй.'); return; }
    S = App.S = Object.assign(App.blankCard(r.card.occ), r.card);
    snapshot = fieldsOf(); buildChips(); buildThumbs(); buildSwatches(); buildExtra(); syncFields(); syncAll(); App.show('make');
  } catch (e) { App.toast('Нээж чадсангүй.'); }
}

/* ---------- wire up ---------- */
function rebuild() { buildChips(); buildSwatches(); buildThumbs(); buildTemplates(); buildExtra(); syncAll(); }
App.views.make = { enter() { changed(); } };
App.views.mine = { enter: mineView };
App.initMaker = function () {
  build(); rebuild(); syncFields();
  requestAnimationFrame(previewFrame);
  App.on('config', () => { rebuild(); if (App.view === 'mine') mineView(); });
  App.on('media', () => { if (!thumbQ) thumbQ = requestAnimationFrame(() => { thumbQ = 0; renderThumbs(); }); });
  App.backend.onMine(list => { mine = list; const e = entryOf(); if (e && !busy && snapshot === '') snapshot = fieldsOf(); renderSend(); if (App.view === 'mine') mineView(); App.emit('mine', list); });
  window.addEventListener('resize', () => { if (App.view === 'make') changed(); });
  if (document.fonts) {
    const sample = 'Өө Үү Аа Бб Хх 0123 БҮҮҮ! Айсан уу?';
    const refresh = () => { M.resetTextCache(); if (App.view === 'make') changed(); };
    Promise.all(['800 40px Rubik', '600 40px Rubik', '400 40px Pacifico', '600 40px Nunito', '500 16px Nunito'].map(f => document.fonts.load(f, sample).catch(() => {}))).then(refresh);
    if (document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', refresh);
  }
};
})();

;
/* viewer.js — what the person who receives the link sees. */
(function () {
'use strict';
const App = window.App, M = App.M, $ = App.$;
const V = { card: null, R: null, owner: null, t0: 0, prev: 0, started: false, test: false, raf: 0, logged: false };
App.viewerOpen = false;

function gateTheme(th) {
  const g = $('gate');
  g.style.background = `linear-gradient(180deg,${th.bg[0]},${th.bg[1]})`;
  g.style.setProperty('--gink', th.ink); g.style.setProperty('--gacc', th.a);
}
function frame(show) {
  App.viewerOpen = show; $('viewer').hidden = !show; $('app').hidden = show;
  if (show) { $('vCanvas').getContext('2d').clearRect(0, 0, 9999, 9999); }
}
function gate(o) {
  $('gate').hidden = false; gateTheme(o.th || M.THEMES.night);
  $('gateK').textContent = o.k || ''; $('gateName').textContent = o.name || ''; $('gateMsg').textContent = o.msg || ''; $('gateMsg').hidden = !o.msg;
  $('gateOpen').hidden = !o.open; $('gateHome').hidden = !o.home; $('gateHome').textContent = o.homeText || 'Өөрөө мэндчилгээ бүтээх';
  $('vBack').hidden = !V.test; $('vMake').hidden = true;
}
/* kind: 'loading' | 'blocked' | 'missing' | 'login' */
App.viewerMessage = function (kind, th) {
  V.started = false; V.test = false; frame(true); cancelAnimationFrame(V.raf);
  const T = {
    loading: { k: 'Мэндчилгээг ачаалж байна…', name: '', msg: '' },
    blocked: { k: 'Түр хүлээнэ үү', name: 'Идэвхжээгүй байна', msg: 'Энэ мэндчилгээний төлбөр баталгаажаагүй байна. Илгээсэн хүнээсээ асууна уу.', home: true },
    missing: { k: 'Олдсонгүй', name: 'Мэндчилгээ олдсонгүй', msg: 'Холбоос буруу эсвэл мэндчилгээ устгагдсан байж магадгүй.', home: true },
    login: { k: 'Нэвтрэх шаардлагатай', name: 'Нэвтэрнэ үү', msg: 'Мэндчилгээг үзэхийн тулд нэвтэрсэн байх шаардлагатай.', home: true }
  }[kind];
  gate(Object.assign({ th }, T));
};
/* o: {card, test, owner:{uid,id}} */
App.openViewer = function (o) {
  V.card = o.card; V.test = !!o.test; V.owner = o.owner || null; V.back = o.back || (App.view !== 'viewer' && App.view) || 'make'; V.R = App.toR(o.card); V.started = false; V.logged = false;
  frame(true);
  gate({ th: M.THEMES[V.R.theme], k: 'Танд мэндчилгээ ирлээ', name: V.R.name, open: true });
  if (V.owner && !V.test && !V.logged) { V.logged = true; App.backend.logVisit({ o: V.owner.uid, c: V.owner.id }); }
  cancelAnimationFrame(V.raf); V.raf = requestAnimationFrame(loop);
};
function open() {
  if (!V.R) return;
  V.R = App.toR(V.card); M.Sound.init(); V.t0 = performance.now(); V.prev = -0.01; V.started = true;
  $('gate').hidden = true; $('vMake').hidden = true;
  App.media.play(V.R.bgEl);
  if (!M.FXS[V.R.fx].scare) M.Sound.play('open', V.R.sfx);
}
function loop(now) {
  V.raf = requestAnimationFrame(loop);
  if (!V.started || document.hidden) return;
  const t = (now - V.t0) / 1000, { ctx, w, h } = App.fit($('vCanvas'));
  M.events(V.R.fx, V.prev, t).forEach(c => M.Sound.play(c, V.R.sfx));
  V.prev = t; M.render(ctx, w, h, t, V.R);
  if (t > 7.8 && !V.test) $('vMake').hidden = false;
}
function close() {
  cancelAnimationFrame(V.raf); V.started = false; App.media.pause(V.R && V.R.bgEl);
  const wasTest = V.test; frame(false);
  if (!wasTest) App.backend.nav.clear();
  App.show(wasTest ? (V.back || 'make') : (App.view || 'make'));
}
App.closeViewer = close;

/* Decide what an address means and show it. */
App.route = async function () {
  const r = App.backend.nav.current();
  if (!r) { if (App.viewerOpen && !V.test) { cancelAnimationFrame(V.raf); frame(false); } return; }
  if (r.type === 'legacy') { App.openViewer({ card: r.card }); return; }
  App.viewerMessage('loading');
  if (!App.me.uid && App.backend.kind !== 'rest') { App.viewerMessage('login'); return; }
  let got = null;
  try { got = await App.backend.getCard(r.uid, r.id); } catch (e) { got = null; }
  if (!got) { App.viewerMessage('missing'); return; }
  const free = got.card.free || !App.cfg.main.payRequired, ok = (got.ap && got.ap.st === 'ok') || free;
  if (!ok) { App.viewerMessage('blocked', M.THEMES[got.card.theme] || M.THEMES[(M.OCC[got.card.occ] || M.OCC.other).theme]); return; }
  App.openViewer({ card: got.card, owner: { uid: r.uid, id: r.id } });
};

App.initViewer = function () {
  $('gateOpen').addEventListener('click', open);
  $('gateHome').addEventListener('click', close);
  $('vReplay').addEventListener('click', () => { if (!V.started) { open(); return; } M.Sound.init(); V.t0 = performance.now(); V.prev = -0.01; $('vMake').hidden = true; if (!M.FXS[V.R.fx].scare) M.Sound.play('open', V.R.sfx); });
  $('vBack').addEventListener('click', close);
  $('vMake').addEventListener('click', close);
  $('vMute').addEventListener('click', e => { M.Sound.muted = !M.Sound.muted; e.currentTarget.textContent = M.Sound.muted ? 'Дуугүй' : 'Дуутай'; e.currentTarget.setAttribute('aria-pressed', String(M.Sound.muted)); });
  App.backend.nav.listen(() => App.route());
  App.on('media', () => { /* the loop redraws every frame; nothing to do */ });
};
})();

;
/* admin.js — the owner's panel: dashboard, orders, visitors, settings. The studio lives in studio.js. */
(function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$;
const A = App.A = { sub: 'dash', studio: 'themes', orders: [], users: [], visitors: [], names: {}, flt: 'pending', q: '', d: {}, started: false, busy: new Set(), bank: { status: {}, list: [], pending: [] }, bankSel: {}, qp: null, qpErr: false, qpLoading: false };

/* ---------- small form helpers (inputs bound to a draft object, so a re-render never loses typing) ---------- */
App.ui = {
  panel: (title, ...kids) => h('div', { class: 'panel' }, title && h('h3', { text: title }), ...kids),
  field(label, input, o) { o = o || {}; return h('label', { class: o.wide ? 'wide' : '' }, h('span', {}, label, o.hint && h('small', { text: o.hint })), input); },
  tin(obj, key, props) { return h('input', Object.assign({ type: 'text', value: obj[key] == null ? '' : obj[key], on: { input: e => { obj[key] = e.target.value; if (props && props.onInput) props.onInput(); } } }, props && { placeholder: props.placeholder, maxLength: props.maxLength, id: props.id })); },
  nin(obj, key, props) { return h('input', { type: 'number', min: (props && props.min) || 0, step: (props && props.step) || 1, value: obj[key] == null ? '' : obj[key], inputMode: 'numeric', on: { input: e => { obj[key] = e.target.value === '' ? '' : Number(e.target.value); } } }); },
  sel(obj, key, opts, props) {
    const s = h('select', { on: { change: e => { obj[key] = e.target.value; if (props && props.onChange) props.onChange(e.target.value); } } }, opts.map(([v, t]) => h('option', { value: v, text: t, selected: String(obj[key] == null ? '' : obj[key]) === String(v) })));
    return s;
  },
  chk(label, checked, on) { return h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!checked, on: { change: e => on(e.target.checked) } }), h('span', { text: label })); },
  busy(key, fn) { return async (...a) => { if (A.busy.has(key)) return; A.busy.add(key); try { return await fn(...a); } catch (e) { App.toast(failMsg(e), 5000); } finally { A.busy.delete(key); } }; }
};
const U = App.ui;
function failMsg(e) {
  const c = e && e.code;
  if (c === 'invalid_argument' || c === 'not_granted') return 'Таны эрх хүрэхгүй байна. Зөвхөн админ (Editor) өөрчилж чадна.';
  if (c === 'quota_exceeded' || c === 'quota_or_state') return 'Хадгалах багтаамж дүүрсэн байна.';
  if (c === 'too_large') return 'Файл хэт том байна.';
  if (c === 'unsupported_type') return 'Энэ төрлийн файл дэмжигдэхгүй.';
  return (e && e.message && e.code === 'unavailable') ? e.message : 'Хадгалж чадсангүй. Дахин оролдоно уу.';
}
App.failMsg = failMsg;

/* ---------- names (opaque ids -> display names, resolved at render time) ---------- */
const nm = uid => A.names[uid] || 'Нэргүй хэрэглэгч';
async function resolveNames() {
  const ids = new Set(); A.orders.forEach(o => o.uid && ids.add(o.uid)); A.visitors.forEach(v => { ids.add(v.uid); (v.v || []).forEach(x => x.o && ids.add(x.o)); });
  const miss = [...ids].filter(i => !(i in A.names)); if (!miss.length) return;
  try { const r = await App.backend.names(miss); miss.forEach(i => { A.names[i] = r[i] || ''; }); rerender(['orders', 'visitors', 'dash']); } catch (e) { /* names stay generic */ }
}

/* ---------- data ---------- */
const stOf = o => o.gone ? 'ok' : App.statusOf(o, o.ap);
const money = () => A.orders.filter(o => o.ap && o.ap.st === 'ok').reduce((s, o) => s + (Number(o.ap.amt) || 0), 0);
const pendingList = () => A.orders.filter(o => stOf(o) === 'pending');
function rerender(subs) { if (App.view === 'admin' && (!subs || subs.includes(A.sub))) render(); }
function updateBadge() {
  const n = pendingList().length, tab = document.querySelector('.tab[data-v="admin"]'); if (!tab) return;
  let d = tab.querySelector('.dot'); if (!n) { if (d) d.remove(); return; }
  if (!d) { d = h('span', { class: 'dot' }); tab.append(d); } d.textContent = String(n);
}

/* ---------- order actions ---------- */
const approve = U.busy('act', async o => { await App.backend.setApproval(o.uid, o.id, 'ok', '', Number(App.cfg.main.price) || 0); App.toast('Баталгаажлаа. Холбоос нээгдлээ.'); });
const reject = U.busy('act', async o => { const note = await App.prompt('Татгалзах шалтгаан (захиалагчид харагдана):', 'Жишээ нь: шилжүүлэг ирээгүй', 'Татгалзах'); if (note === null) return; await App.backend.setApproval(o.uid, o.id, 'no', note, 0); App.toast('Татгалзлаа.'); });
const undo = U.busy('act', async o => { if (!(await App.confirm('Баталгаажуулалтыг цуцлах уу? Холбоос дахин хаагдана.', 'Цуцлах', true))) return; await App.backend.clearApproval(o.id); App.toast('Цуцлагдлаа.'); });
const viewCard = U.busy('view', async o => {
  const r = await App.backend.getCard(o.uid, o.id); if (!r) { App.toast('Карт олдсонгүй.'); return; }
  App.openViewer({ card: r.card, test: true, back: 'admin' });
});

function orderRow(o) {
  const stt = stOf(o), canv = h('canvas', { 'aria-hidden': 'true' }), isMe = o.uid === App.me.uid;
  const acts = [];
  if (!o.gone) acts.push(h('button', { class: 'ghost sm', type: 'button', text: 'Харах', on: { click: () => viewCard(o) } }));
  if (stt === 'pending' || stt === 'no' || stt === 'draft') acts.push(h('button', { class: 'okbtn', type: 'button', text: stt === 'draft' ? 'Гараар батлах' : 'Батлах', on: { click: () => approve(o) } }));
  if (stt === 'pending') acts.push(h('button', { class: 'danger', type: 'button', text: 'Татгалзах', on: { click: () => reject(o) } }));
  if (o.ap && o.ap.st === 'ok') acts.push(h('button', { class: 'ghost sm', type: 'button', text: 'Цуцлах', on: { click: () => undo(o) } }));
  const row = h('div', { class: 'row', 'data-id': o.id },
    canv,
    h('div', { class: 'grow' },
      h('div', { class: 't', text: (o.to || 'Нэргүй') + ' · ' + (M.OCC[o.occ] ? M.OCC[o.occ].name : '—') }),
      h('div', { class: 's', text: 'Захиалагч: ' + (isMe ? 'та өөрөө' : nm(o.uid)) + ' · ' + (M.FXS[o.fx] ? M.FXS[o.fx].name : '—') + ' · ' + App.fmtT(o.claim || o.at) }),
      h('div', { class: 's', text: 'Утга: ' + o.ref + (o.ap && o.ap.st === 'ok' ? ' · ' + App.fmtMoney(o.ap.amt) + (o.ap.via === 'qpay' ? ' · QPay' : o.ap.auto ? ' · автомат' : '') : '') + (o.ap && o.ap.st === 'no' && o.ap.note ? ' · «' + o.ap.note + '»' : '') })),
    App.badge(stt), h('div', { class: 'acts' }, acts));
  requestAnimationFrame(() => App.thumbDraw(canv, { occ: o.occ, fx: o.fx, theme: (M.OCC[o.occ] || M.OCC.other).theme, to: o.to || 'Нэр' }, o.fx));
  return row;
}

/* ---------- sections ---------- */
function dash() {
  const m = App.cfg.main, pend = pendingList(), cards = A.orders.filter(o => !o.gone).length;
  const tile = (v, l) => h('div', { class: 'tile' }, h('b', { text: String(v) }), h('span', { text: l }));
  const go = (sub, studio) => () => { A.sub = sub; if (studio) A.studio = studio; render(); };
  const step = (done, text, btn, fn) => h('li', {}, h('span', { class: 'b' + (done ? ' done' : ''), text: done ? '✓' : '·' }), h('span', { style: { flex: '1' } }, text), !done && btn && h('button', { class: 'ghost sm', type: 'button', text: btn, on: { click: fn } }));
  const out = [
    h('div', { class: 'tiles' }, tile(App.fmtMoney(money()), 'Нийт орлого'), tile(pend.length, 'Шалгах төлбөр'), tile(cards, 'Мэндчилгээ'), tile(A.visitors.length, 'Хандсан хүн')),
    U.panel('Эхлэх алхмууд', h('ul', { class: 'checklist' },
      step(App.payReady(), (App.backend.qpayGet ? 'Үнээ оруулж, банкны данс эсвэл QPay тохируулах' : 'Банкны данс, үнээ оруулах'), 'Тохиргоо', go('settings')),
      step(!!m.payRequired, 'Төлбөртэй горимыг асаах (одоо: ' + (m.payRequired ? 'төлбөртэй' : 'үнэгүй') + ')', 'Асаах', go('settings')),
      App.backend.qpayGet && step(!!(A.qp && A.qp.on), 'QPay холбох (QPay-тэй гэрээ хийсний дараа)', 'Тохиргоо', go('settings')),
      App.backend.onBank && step(!!m.autoPay, 'Банкны мэдэгдлээр автомат батлалтыг асаах (Gmail)', 'Тохиргоо', go('settings')),
      step(App.cfg.themes.length > 0, 'Өөрийн өнгө нэмэх', 'Студи', go('studio', 'themes')),
      step(App.cfg.media.length > 0, 'Арын зураг, видео оруулах', 'Студи', go('studio', 'media')),
      step(App.cfg.templates.length > 0, 'Бэлэн загвар үүсгэх', 'Студи', go('studio', 'tpl')))),
    ...(App.backend.onBank ? [bankStatus(true)] : []),
    U.panel('Шалгах төлбөр', pend.length ? h('div', { class: 'rows' }, pend.slice(0, 5).map(orderRow)) : h('p', { class: 'hint', text: 'Одоогоор шалгах төлбөр алга.' }),
      pend.length > 5 && h('p', { style: { marginTop: '10px' } }, h('button', { class: 'ghost sm', type: 'button', text: 'Бүгдийг харах (' + pend.length + ')', on: { click: () => { A.flt = 'pending'; A.sub = 'orders'; render(); } } }))),
    U.panel('Сүүлд хандсан', A.visitors.length ? h('div', { class: 'rows' }, [...A.visitors].sort((a, b) => (b.last || 0) - (a.last || 0)).slice(0, 5).map(visitorRow)) : h('p', { class: 'hint', text: 'Одоогоор хандсан хүн алга.' }))
  ];
  return out;
}

const FILTERS = [['pending', 'Шалгах'], ['ok', 'Төлөгдсөн'], ['no', 'Татгалзсан'], ['draft', 'Төлбөр хүлээгдэж буй'], ['free', 'Үнэгүй'], ['all', 'Бүгд']];
function orders() {
  const cnt = k => k === 'all' ? A.orders.length : A.orders.filter(o => stOf(o) === k).length;
  const list = A.orders.filter(o => A.flt === 'all' || stOf(o) === A.flt);
  return [
    h('div', { class: 'chips', style: { marginBottom: '16px' }, role: 'group', 'aria-label': 'Шүүлтүүр' }, FILTERS.map(([k, t]) => h('button', { class: 'chip', type: 'button', 'aria-pressed': String(A.flt === k), text: t + ' (' + cnt(k) + ')', on: { click: () => { A.flt = k; render(); } } }))),
    list.length ? h('div', { class: 'rows' }, list.map(orderRow)) : h('div', { class: 'empty', text: 'Энэ ангилалд захиалга алга.' })
  ];
}

function visitorRow(v) {
  const idx = {}; A.users.forEach(u => Object.keys(u.cards || {}).forEach(id => { idx[id] = Object.assign({ uid: u.uid || u.id }, u.cards[id]); }));
  const own = A.users.find(u => (u.uid || u.id) === v.uid), ownN = own ? Object.keys(own.cards || {}).length : 0;
  const opens = (v.v || []).slice(0, 4).map(x => { const c = idx[x.c]; return (c ? '«' + (c.to || 'Нэргүй') + '»' : 'устгагдсан карт') + ' (' + (x.o === v.uid ? 'өөрийнх' : nm(x.o)) + ') ' + App.fmtT(x.t); });
  return h('div', { class: 'row' },
    h('div', { class: 'grow' },
      h('div', { class: 't', text: v.uid === App.me.uid ? 'Та өөрөө' : nm(v.uid) }),
      h('div', { class: 's', text: 'Анх: ' + App.fmtT(v.first) + ' · Сүүлд: ' + App.fmtT(v.last) + ' · ' + (v.n || 0) + ' удаа ' + (App.backend.visitWord || 'нэвтэрсэн') + (ownN ? ' · ' + ownN + ' карт хийсэн' : '') }),
      opens.length > 0 && h('div', { class: 's', text: 'Нээсэн: ' + opens.join(' · ') })));
}
function visitors() {
  const q = A.q.trim().toLowerCase();
  const list = [...A.visitors].filter(v => !q || nm(v.uid).toLowerCase().includes(q)).sort((a, b) => (b.last || 0) - (a.last || 0));
  return [
    h('p', { class: 'hint', style: { marginBottom: '12px' }, text: App.backend.visitorsHint || 'Энэ хуудсыг нээсэн, холбоос дээр дарсан нэвтэрсэн хүмүүс. Хүн бүрийн нэр claude.ai-ийн бүртгэлээс харагдана.' }),
    h('input', { class: 'search', type: 'search', placeholder: 'Нэрээр хайх', 'aria-label': 'Нэрээр хайх', value: A.q, on: { input: e => { A.q = e.target.value; const keep = e.target.selectionStart; render(); const i = $('v-admin').querySelector('.search'); if (i) { i.focus(); i.setSelectionRange(keep, keep); } } } }),
    list.length ? h('div', { class: 'rows' }, list.map(visitorRow)) : h('div', { class: 'empty', text: 'Хандсан хүн олдсонгүй.' })
  ];
}

function settings() {
  const m = App.cfg.main;
  const d = A.d.pay = A.d.pay || { payRequired: !!m.payRequired, autoPay: !!m.autoPay, price: m.price, bank: m.bank, account: m.account, holder: m.holder, note: m.note };
  const av = A.d.av = A.d.av || { offOcc: [...m.offOcc], offFx: [...m.offFx], offThemes: [...m.offThemes] };
  const ready = () => Number(d.price) > 0 && !!((d.bank && d.account && d.holder) || App.qpayReady());
  const savePay = U.busy('savePay', async () => {
    if (d.payRequired && !ready()) { App.toast('Төлбөртэй горимд үнэ, мөн банкны мэдээлэл (банк, данс, нэр) эсвэл QPay шаардлагатай.'); return; }
    await App.backend.saveMain(Object.assign({ payRequired: !!d.payRequired, price: Number(d.price) || 0, bank: (d.bank || '').trim(), account: (d.account || '').trim(), holder: (d.holder || '').trim(), note: (d.note || '').trim() }, App.backend.onBank ? { autoPay: !!d.autoPay } : {}));
    A.d.pay = null; App.toast('Төлбөрийн тохиргоо хадгалагдлаа.');
  });
  const saveAv = U.busy('saveAv', async () => { await App.backend.saveMain({ offOcc: av.offOcc, offFx: av.offFx, offThemes: av.offThemes }); A.d.av = null; App.toast('Хадгалагдлаа.'); });
  const toggle = (arr, id) => on => { const i = arr.indexOf(id); if (on && i >= 0) arr.splice(i, 1); if (!on && i < 0) arr.push(id); };
  const group = (title, ids, name, arr) => h('div', {}, h('div', { class: 'sub', text: title }), h('div', { class: 'checks' }, ids.map(id => U.chk(name(id), !arr.includes(id), toggle(arr, id)))));
  const payChk = h('input', { type: 'checkbox', checked: !!d.payRequired, on: { change: e => { if (e.target.checked && !ready()) { e.target.checked = false; App.toast('Эхлээд үнийг оруулаад банкны мэдээлэл (банк, данс, нэр) эсвэл QPay-г бүрдүүлнэ үү.'); return; } d.payRequired = e.target.checked; } } });
  return [
    U.panel(App.backend.onBank ? 'Төлбөр (банкны шилжүүлэг)' : 'Төлбөр (банкны шилжүүлэг, гараар баталгаажуулна)',
      h('div', { class: 'frm' },
        h('label', { class: 'check wide' }, payChk, h('span', { text: 'Төлбөртэй горим: холбоос авахын өмнө төлбөр шаардана' })),
        App.backend.onBank && U.chk('Банкны мэдэгдлээр автоматаар батлах: Gmail-д орлогын мэдэгдэл ирмэгц карт өөрөө нээгдэнэ', d.autoPay, on => { d.autoPay = on; }),
        U.field('Үнэ (₮)', U.nin(d, 'price', { min: 0, step: 100 })),
        U.field('Банкны нэр', U.tin(d, 'bank', { placeholder: 'Жишээ нь: Хаан банк', maxLength: 40 })),
        U.field('Дансны дугаар', U.tin(d, 'account', { maxLength: 40 })),
        U.field('Хүлээн авагчийн нэр', U.tin(d, 'holder', { maxLength: 60 })),
        U.field('Нэмэлт тайлбар', U.tin(d, 'note', { placeholder: 'Жишээ нь: Шилжүүлсний дараа «Төлсөн» товчийг дарна', maxLength: 140 }), { wide: true, hint: 'заавал биш' })),
      h('p', { class: 'hint', style: { margin: '12px 0' }, text: 'Захиалагч шилжүүлэг хийгээд «Төлсөн» дарахад «Захиалга» хэсэгт шалгах жагсаалтад гарна. Та банкаа шалгаад «Батлах» дарна. Түүнээс хойш холбоос нээгдэнэ. Энэ хувилбар мөнгө хөдөлгөдөггүй.' }),
      h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: savePay } })),
    qpayPanel(),
    U.panel('Хэрэглэгчид юу харагдах вэ',
      h('p', { class: 'hint', style: { marginBottom: '8px' }, text: 'Тэмдэглэгдсэн зүйл л хэрэглэгчийн сонголтод гарна. Илгээгдсэн картууд өөрчлөлтөд нөлөөлөхгүй.' }),
      group('Баярууд', M.OCC_IDS, id => M.OCC[id].name, av.offOcc),
      group('Хөдөлгөөн', M.FX_IDS, id => M.FXS[id].name + (M.FXS[id].scare ? ' (айлгана)' : ''), av.offFx),
      group('Үндсэн өнгө', M.THEME_IDS, id => M.THEMES[id].name, av.offThemes),
      h('p', { style: { marginTop: '14px' } }, h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveAv } })))
  ];
}

/* ---------- QPay холболт (server build only): гэрээний мэдээллийг энд оруулна, нууц үг хэзээ ч буцаж харагдахгүй ---------- */
const QERR = {
  INVOICE_CODE_INVALID: 'Invoice code буруу байна. QPay-ээс авсан кодоо шалгана уу.',
  AUTHENTICATION_FAILED: 'Нэвтрэх нэр эсвэл нууц үг буруу байна.',
  network: 'QPay сервертэй холбогдож чадсангүй.',
  SENDER_INVOICE_NO_DUPLICATED: 'Нэхэмжлэхийн дугаар давхцлаа (дахин оролдоход засарна).'
};
async function qpayLoad(force) {
  if (!App.backend.qpayGet || A.qpLoading || (A.qp && !force)) return;
  A.qpLoading = true; A.qpErr = false;
  try { A.qp = await App.backend.qpayGet(); } catch (e) { A.qpErr = true; }
  A.qpLoading = false; rerender(['settings', 'dash']);
}
function qpayPanel() {
  if (!App.backend.qpayGet) return null;
  const st = A.qp;
  if (!st) { qpayLoad(); return U.panel('QPay', h('p', { class: 'hint', text: A.qpErr ? 'QPay-ийн мэдээллийг ачаалж чадсангүй.' : 'Ачаалж байна…' }), A.qpErr && h('button', { class: 'ghost sm', type: 'button', text: 'Дахин оролдох', on: { click: () => qpayLoad(true) } })); }
  const env = st.source === 'env';
  const d = A.d.qp = A.d.qp || { env: st.env, id: st.id, secret: '', code: st.code };
  const took = (r, msg, ms) => { if (r) A.qp = r; A.d.qp = null; if (msg) App.toast(msg, ms); rerender(['settings', 'dash']); };
  const saveQ = U.busy('qpSave', async () => { took(await App.backend.qpaySave({ env: d.env, id: (d.id || '').trim(), secret: d.secret || '', code: (d.code || '').trim() }), 'Хадгалагдлаа. Одоо «Холболт шалгах» дарна уу.', 5000); });
  const testQ = U.busy('qpTest', async () => { const r = await App.backend.qpayTest(); took(r.status, r.ok ? 'QPay-тэй амжилттай холбогдлоо.' : r.msg, r.ok ? 3500 : 8000); });
  const clearQ = U.busy('qpClear', async () => { if (!(await App.confirm('QPay-ийн холболтыг устгах уу? Нууц үг серверээс арилж, QPay-ээр төлөх унтарна.', 'Устгах', true))) return; took(await App.backend.qpayClear(), 'Устгагдлаа.'); });
  const toggleQ = U.busy('qpToggle', async on => {
    try { await App.backend.saveMain({ qpay: !!on }); A.qp = await App.backend.qpayGet(); App.toast(on ? 'QPay-ээр төлөх идэвхжлээ.' : 'QPay-ээр төлөх унтарлаа.'); }
    finally { rerender(['settings', 'dash']); }
  });
  let box;
  if (!st.configured) box = h('div', { class: 'stat info', text: 'QPay-тэй гэрээ хийсний дараа QPay-ээс өгсөн нэвтрэх нэр, нууц үг, invoice code-оо доор оруулна. Гэрээ хараахан байхгүй бол энэ хэсгийг хоосон үлдээгээрэй: банкны шилжүүлгээр ажиллана.' });
  else if (!st.tested) box = h('div', { class: 'stat warn', text: 'Мэдээлэл хадгалагдсан, гэхдээ QPay-тэй холболт шалгагдаагүй байна. «Холболт шалгах» дарна уу.' });
  else if (!st.on) box = h('div', { class: 'stat info', text: 'Холболт амжилттай. Доорх сонголтыг тавьж хэрэглэгчдэд QPay-ээр төлөх боломжийг нээнэ.' });
  else box = h('div', { class: 'stat ok', text: 'QPay идэвхтэй: хэрэглэгч QR болон банкны апп-аар төлнө, төлмөгц карт өөрөө нээгдэнэ.' });
  const err = st.err ? h('div', { class: 'stat bad', role: 'alert', text: 'Сүүлийн алдаа (' + App.fmtT(st.err.at) + '): ' + (QERR[st.err.code] || ('QPay алдаа ' + (st.err.status || '') + ' ' + st.err.code)) }) : null;
  const secret = h('input', { type: 'password', autocomplete: 'new-password', maxLength: 200, value: d.secret, disabled: env, placeholder: st.hasSecret ? 'Хадгалагдсан (солихгүй бол хоосон үлдээнэ)' : '', 'aria-label': 'QPay нууц үг', on: { input: e => { d.secret = e.target.value; } } });
  return U.panel('QPay-ээр төлөх (автомат)',
    box, err,
    env && h('p', { class: 'hint', style: { margin: '10px 0' }, text: 'Эдгээр мэдээлэл серверийн .env файлаар (QPAY_CLIENT_ID гэх мэт) тохируулагдсан тул эндээс өөрчлөхгүй. Орчин: ' + (st.env === 'sandbox' ? 'туршилт' : 'жинхэнэ') + '.' }),
    !env && h('div', { class: 'frm', style: { marginTop: '12px' } },
      U.field('Орчин', U.sel(d, 'env', [['sandbox', 'Туршилт (sandbox)'], ['prod', 'Жинхэнэ (production)']])),
      U.field('Нэвтрэх нэр (client id)', h('input', { type: 'text', autocomplete: 'off', maxLength: 120, value: d.id || '', 'aria-label': 'QPay нэвтрэх нэр', on: { input: e => { d.id = e.target.value; } } })),
      U.field('Нууц үг (client secret)', secret),
      U.field('Invoice code', h('input', { type: 'text', autocomplete: 'off', maxLength: 80, value: d.code || '', 'aria-label': 'QPay invoice code', on: { input: e => { d.code = e.target.value; } } }), { hint: 'QPay-ээс өгсөн' })),
    h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start', margin: '12px 0' } },
      !env && h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveQ } }),
      st.configured && h('button', { class: 'ghost', type: 'button', text: 'Холболт шалгах', on: { click: testQ } }),
      st.configured && !env && h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: clearQ } })),
    st.configured && st.tested && U.chk('QPay-ээр төлөхийг идэвхжүүлэх', st.on, toggleQ),
    h('p', { class: 'hint', style: { marginTop: '12px' }, text: 'Хэрэглэгч төлөхөд мөнгө таны QPay гэрээнд заасан дансанд шууд орно, апп мөнгө хадгалдаггүй. Карт нээгдэхийн өмнө сервер QPay-ээс «төлөгдсөн» эсэхийг өөрөөс нь лавладаг тул хуурамч дохиогоор нээгдэхгүй. Нууц үг шифрлэгдэн хадгалагдаж, хэзээ ч дэлгэц дээр буцаж гарахгүй. Төлбөрийн дохио (callback) нь серверийн https хаягаар ирдэг тул «BASE_URL» зөв байх ёстой.' }));
}

/* ---------- bank income: read from the owner's Gmail (server build only) ---------- */
const WHY = {
  no_code: 'Гүйлгээний утганд код (MN-XXXXXX) байхгүй',
  unknown_code: 'Утга дахь код ямар ч картад таарсангүй',
  ambiguous: 'Утга дахь код хэд хэдэн картад таарч байна',
  already_paid: 'Карт аль хэдийн баталгаажсан: давхар төлбөр байж болно',
  was_rejected: 'Та өмнө нь энэ картыг татгалзсан',
  free_mode: 'Үнэгүй горимд байна',
  amount_low: 'Дүн үнээс бага',
  auto_off: 'Автомат батлалт унтраалттай',
  other_account: 'Өөр дансанд орсон мөнгө',
  auth: 'Банкнаас ирсэн гэдэг нь баталгаажсангүй: хуурамч имэйл байж болно',
  admin: 'Та хассан'
};
const BANK_BADGE = { matched: ['Батлагдсан', 'ok'], open: ['Шалгах', 'warn'], ignored: ['Хассан', 'mute'], rejected: ['Татгалзсан', 'bad'] };
const bankAssign = U.busy('bank', async (r, cardId) => {
  if (!cardId) { App.toast('Эхлээд холбох картаа сонгоно уу.'); return; }
  await App.backend.bankAssign(r.id, cardId); App.toast('Орлого картад холбогдож, карт нээгдлээ.');
});
const bankIgnore = U.busy('bank', async r => {
  if (!(await App.confirm('Энэ орлогыг шалгах жагсаалтаас хасах уу? Дараа нь доорх жагсаалтаас гараар холбож болно.', 'Хасах', true))) return;
  await App.backend.bankIgnore(r.id); App.toast('Хасагдлаа.');
});
function bankStatus(compact) {
  const s = A.bank.status || {}, m = App.cfg.main, open = s.open || 0;
  let box;
  if (!s.enabled) box = h('div', { class: 'stat warn', text: 'Gmail холболт серверт тохируулагдаагүй байна. README-ийн «Gmail-ээр автомат батлах» хэсгийн дагуу серверийн .env файлд BANK_WEBHOOK_SECRET нэмнэ.' });
  else if (!m.autoPay) box = h('div', { class: 'stat info', text: 'Автомат батлалт унтраалттай. Орлого бүртгэгдэнэ, гэхдээ та гараар баталгаажуулна. «Тохиргоо» хэсгээс асаана.' });
  else if (s.stale) box = h('div', { class: 'stat bad', role: 'alert', text: (s.lastRun ? 'Gmail-ээс сүүлд ' + App.fmtT(s.lastRun) + ' цагт дохио ирсэн.' : 'Gmail-ээс одоогоор дохио ирээгүй байна.') + ' Автомат батлалт түр зогссон тул төлбөрийг гараар шалгана уу. Gmail-ийн Apps Script ажиллаж байгаа эсэхийг шалгана.' });
  else box = h('div', { class: 'stat ok', text: 'Автомат батлалт ажиллаж байна. Gmail-ээс сүүлд шалгасан: ' + App.fmtT(s.lastRun) + (s.lastMail ? ' · Сүүлийн орлого: ' + App.fmtT(s.lastMail) : '') });
  return U.panel('Банкны автомат батлалт', box,
    open > 0 && h('p', { style: { marginTop: '10px' } }, h('span', { text: 'Шалгах орлого: ' + open + ' ' }), compact && h('button', { class: 'ghost sm', type: 'button', text: 'Харах', on: { click: () => { A.sub = 'bank'; render(); } } })));
}
function bankRow(r) {
  const [bt, bc] = BANK_BADGE[r.st] || ['—', 'mute'], acts = [];
  if (r.st !== 'matched') {
    const sel = h('select', { 'aria-label': 'Холбох карт', on: { change: e => { A.bankSel[r.id] = e.target.value; } } },
      h('option', { value: '', text: 'Карт сонгох…' }),
      (A.bank.pending || []).map(c => h('option', { value: c.id, selected: (A.bankSel[r.id] || r.card) === c.id, text: c.ref + ' · ' + (c.to || 'Нэргүй') + (c.claimed ? ' · «Төлсөн» дарсан' : '') })));
    acts.push(sel, h('button', { class: 'okbtn', type: 'button', text: 'Холбох', on: { click: () => bankAssign(r, sel.value) } }));
    if (r.st === 'open') acts.push(h('button', { class: 'ghost sm', type: 'button', text: 'Хасах', on: { click: () => bankIgnore(r) } }));
  }
  const why = r.st === 'matched' ? ('Карт: ' + (r.card_info ? r.card_info.ref + ' «' + (r.card_info.to || 'Нэргүй') + '»' : 'устгагдсан') + (r.auto ? ' · автоматаар' : ' · гараар холбосон')) : (WHY[r.why] || '');
  return h('div', { class: 'row', 'data-id': r.id },
    h('div', { class: 'grow' },
      h('div', { class: 't', text: App.fmtMoney(r.amount) + ' · ' + (r.payer || 'Төлөгч мэдэгдэхгүй') + (r.acct ? ' (…' + r.acct + ')' : '') }),
      h('div', { class: 's', text: 'Утга: ' + (r.note || '—') }),
      h('div', { class: 's', text: App.fmtT(r.at) + (why ? ' · ' + why : '') })),
    h('span', { class: 'badge ' + bc, text: bt }), acts.length > 0 && h('div', { class: 'acts' }, acts));
}
function bank() {
  const list = A.bank.list || [], open = list.filter(r => r.st === 'open'), rest = list.filter(r => r.st !== 'open');
  return [
    bankStatus(false),
    U.panel('Шалгах орлого', h('p', { class: 'hint', style: { marginBottom: '10px' }, text: 'Гүйлгээний утганд код байхгүй, дүн дутуу, эсвэл өөр шалтгаанаар автоматаар таарахгүй орлогууд. Банкаа шалгаад зөв картад «Холбох» дарна.' }),
      open.length ? h('div', { class: 'rows' }, open.map(bankRow)) : h('p', { class: 'hint', text: 'Таарахгүй орлого алга.' })),
    U.panel('Сүүлийн орлогууд', rest.length ? h('div', { class: 'rows' }, rest.map(bankRow)) : h('p', { class: 'hint', text: 'Банкнаас орлогын мэдэгдэл хараахан ирээгүй байна.' }))
  ];
}

/* ---------- chrome ---------- */
const subs = () => [['dash', 'Самбар'], ['orders', 'Захиалга']].concat(App.backend.onBank ? [['bank', 'Банкны орлого']] : [], [['visitors', 'Хандсан хүмүүс'], ['settings', 'Тохиргоо'], ['studio', 'Студи']]);
function render() {
  const root = $('v-admin'); if (!root) return;
  const body = h('div', {});
  const f = { dash, orders, bank, visitors, settings, studio: () => App.renderStudio() }[A.sub] || dash;
  let kids; try { kids = f(); } catch (e) { console.error(e); kids = [h('div', { class: 'stat bad', text: 'Алдаа гарлаа: ' + e.message })]; }
  body.append(...[].concat(kids));
  const pn = pendingList().length;
  const bar = h('div', { class: 'sub-tabs', role: 'tablist' }, subs().map(([k, t]) => h('button', { class: 'chip', type: 'button', role: 'tab', 'aria-pressed': String(A.sub === k), text: t + (k === 'orders' && pn ? ' (' + pn + ')' : '') + (k === 'bank' && A.bank.status && A.bank.status.open ? ' (' + A.bank.status.open + ')' : ''), on: { click: () => { A.sub = k; render(); window.scrollTo(0, 0); } } })));
  const keepScroll = window.scrollY;
  root.textContent = ''; root.append(bar, body);
  window.scrollTo(0, keepScroll);
}
App.adminRender = render;
App.views.admin = { enter() { render(); } };
App.initAdmin = function () {
  if (A.started) return; A.started = true;
  App.backend.onOrders((list, users) => { A.orders = list; A.users = users || []; updateBadge(); resolveNames(); rerender(['dash', 'orders', 'visitors']); });
  App.backend.onVisitors(list => { A.visitors = list; resolveNames(); rerender(['dash', 'visitors']); });
  if (App.backend.qpayGet) qpayLoad();
  if (App.backend.onBank) App.backend.onBank(d => {
    /* the server's "last checked" time moves every minute: redraw only when something you can act on changed */
    const sig = x => JSON.stringify([x.list, x.pending, x.status && [x.status.enabled, x.status.autoPay, x.status.stale, x.status.open, x.status.lastMail]]);
    const changed = sig(d) !== sig(A.bank); A.bank = d;
    if (changed) rerender(['dash', 'bank']);
  });
  App.on('config', () => { updateBadge(); rerender(['dash', 'settings', 'studio']); });
};
})();

;
/* studio.js — the owner's studio: colours, sounds, pictures and video, ready-made templates. */
(function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$, A = App.A, U = App.ui;
const T0 = performance.now();

/* A live preview card; stops by itself when it leaves the page. */
function miniPreview(getCard) {
  const canvas = h('canvas', { 'aria-hidden': 'true' }), box = h('div', { class: 'mini' }, canvas);
  const step = now => {
    if (!box.isConnected) return; requestAnimationFrame(step);
    if (App.viewerOpen || document.hidden || App.view !== 'admin') return;
    const { ctx, w, h: hh } = App.fit(canvas); if (w < 8) return;
    const c = getCard(), R = App.toR(c); let t = (performance.now() - T0) / 1000; if (M.LOOP[R.fx]) t %= M.LOOP[R.fx];
    App.media.play(R.bgEl); M.render(ctx, w, hh, t, R);
  };
  requestAnimationFrame(step); return box;
}
const sub = (k, t) => h('button', { class: 'chip', type: 'button', role: 'tab', 'aria-pressed': String(A.studio === k), text: t, on: { click: () => { A.studio = k; App.adminRender(); } } });
const del = (what, fn) => async () => { if (await App.confirm(what, 'Устгах', true)) { try { await fn(); App.toast('Устгагдлаа.'); } catch (e) { App.toast(App.failMsg(e), 5000); } } };

/* ---------- colours ---------- */
const TF = [['bg0', 'Дэвсгэр дээд'], ['bg1', 'Дэвсгэр доод'], ['glow', 'Гэрэлтэлт'], ['ink', 'Үсэг'], ['a', 'Гол өнгө'], ['b', 'Хоёр дахь'], ['c', 'Гурав дахь']];
const newTheme = () => ({ id: null, name: '', bg0: '#160C3A', bg1: '#5B2A9E', glow: '#B07CFF', ink: '#FFF3D6', a: '#FFC857', b: '#FF6FB5', c: '#7FD6FF' });
function hex(hh, s, l) { s /= 100; l /= 100; const k = n => (n + hh / 30) % 12, a = s * Math.min(l, 1 - l), f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); return '#' + [f(0), f(8), f(4)].map(x => Math.round(x * 255).toString(16).padStart(2, '0')).join(''); }
function randomTheme(d) {
  const hue = Math.random() * 360, h2 = (hue + 30 + Math.random() * 70) % 360, dark = Math.random() < 0.7;
  Object.assign(d, dark
    ? { bg0: hex(hue, 55, 14), bg1: hex(h2, 55, 34), glow: hex(h2, 90, 72), ink: hex(hue, 70, 94), a: hex((hue + 180) % 360, 90, 62), b: hex((hue + 320) % 360, 90, 72), c: hex((hue + 90) % 360, 85, 66) }
    : { bg0: hex(hue, 95, 90), bg1: hex(h2, 85, 72), glow: '#FFFFFF', ink: hex(hue, 60, 16), a: hex((hue + 180) % 360, 80, 42), b: '#FFFFFF', c: hex((hue + 90) % 360, 80, 52) });
}
const contrast = d => { const l1 = M.lum(d.ink), l2 = (M.lum(d.bg0) + M.lum(d.bg1)) / 2, hi = Math.max(l1, l2), lo = Math.min(l1, l2); return (hi + 0.05) / (lo + 0.05); };
function themes() {
  const d = A.d.theme = A.d.theme || newTheme();
  const warn = h('p', { class: 'hint' });
  const upd = () => { const c = contrast(d); warn.textContent = c < 3.2 ? 'Анхаар: үсгийн өнгө дэвсгэртэй ойр байна, текст муу уншигдаж магадгүй.' : ''; };
  upd();
  const save = U.busy('saveTheme', async () => {
    if (!(d.name || '').trim()) { App.toast('Өнгөндөө нэр өгнө үү.'); return; }
    await App.backend.saveItem('themes', Object.assign({}, d, { name: d.name.trim(), order: d.order || Date.now() }));
    A.d.theme = null; App.toast('Өнгө хадгалагдлаа. Хэрэглэгчид сонгож чадна.');
  });
  const pickers = TF.map(([k, t]) => h('label', {}, h('input', { type: 'color', value: d[k], 'aria-label': t, on: { input: e => { d[k] = e.target.value; upd(); } } }), h('span', { text: t })));
  const list = App.cfg.themes.map(t => {
    const sw = h('span', { class: 'sw', style: { background: `linear-gradient(160deg,${t.bg0},${t.bg1})`, flex: 'none', cursor: 'default' } });
    return h('div', { class: 'row' }, sw, h('div', { class: 'grow' }, h('div', { class: 't', text: t.name })),
      h('div', { class: 'acts' }, h('button', { class: 'ghost sm', type: 'button', text: 'Засах', on: { click: () => { A.d.theme = Object.assign(newTheme(), t); App.adminRender(); } } }),
        h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: del('Энэ өнгийг устгах уу? Илгээсэн картууд өөрчлөгдөхгүй.', () => App.backend.deleteItem('themes', t.id)) } })));
  });
  return [
    U.panel(d.id ? 'Өнгө засах' : 'Шинэ өнгө',
      h('div', { class: 'split' },
        h('div', { style: { display: 'flex', flexDirection: 'column', gap: '14px' } },
          U.field('Нэр', U.tin(d, 'name', { placeholder: 'Жишээ нь: Алтан шөнө', maxLength: 24 })),
          h('div', { class: 'colors' }, pickers), warn,
          h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start' } },
            h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: save } }),
            h('button', { class: 'ghost', type: 'button', text: 'Санамсаргүй өнгө', on: { click: () => { randomTheme(d); App.adminRender(); } } }),
            d.id && h('button', { class: 'ghost', type: 'button', text: 'Шинээр эхлэх', on: { click: () => { A.d.theme = null; App.adminRender(); } } }))),
        miniPreview(() => { M.registerTheme('_prev', M.buildTheme(d)); return { occ: 'bday', fx: 'confetti', theme: '_prev', to: 'Азаа', from: 'Болд' }; }))),
    U.panel('Миний өнгөнүүд', list.length ? h('div', { class: 'rows' }, list) : h('p', { class: 'hint', text: 'Одоогоор өөрийн өнгө алга.' }))
  ];
}

/* ---------- sounds ---------- */
const cueIds = Object.keys(M.CUES);
function soundOpts(extra) { return (extra ? [['', extra]] : []).concat(App.soundList().map(s => [s.id, s.name])); }
function sounds() {
  const m = App.cfg.main, map = A.d.sfx = A.d.sfx || Object.assign({}, M.DEFAULT_SFX, m.sfx);
  const d = A.d.snd = A.d.snd || { id: null, name: '', base: 'pop', vol: 1, pitch: 1, file: null };
  const play = id => { M.Sound.init(); M.Sound.muted = false; M.Sound.playPreset(id); };
  const saveMap = U.busy('saveMap', async () => { await App.backend.saveMain({ sfx: map }); A.d.sfx = null; App.toast('Дууны тохиргоо хадгалагдлаа.'); });
  const cues = cueIds.map(c => h('div', { class: 'cue' }, h('span', { text: M.CUES[c] }), U.sel(map, c, soundOpts()), h('button', { class: 'ghost sm', type: 'button', text: '▶ Сонсох', on: { click: () => play(map[c]) } })));
  const saveSnd = U.busy('saveSnd', async () => {
    if (!(d.name || '').trim()) { App.toast('Дуундаа нэр өгнө үү.'); return; }
    const item = { name: d.name.trim(), base: d.base, vol: Number(d.vol) || 1, pitch: Number(d.pitch) || 1, order: d.order || Date.now() }; if (d.file) item.file = d.file;
    await App.backend.saveItem('sounds', Object.assign({ id: d.id }, item));
    A.d.snd = null; App.toast('Дуу хадгалагдлаа.');
  });
  const fileIn = h('input', { type: 'file', accept: 'audio/*', 'aria-label': 'Дууны файл', on: { change: async e => {
    const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
    if (f.size > 150 * 1024) { App.toast('Файл 150KB-аас бага (богино дуу) байх ёстой.'); return; }
    try { d.file = { data: await App.fileToB64(f), mime: f.type || 'audio/mpeg', name: f.name }; delete M.Sound.files._prev; if (!d.name) d.name = f.name.replace(/\.[^.]+$/, '').slice(0, 24); App.adminRender(); } catch (er) { App.toast('Файл уншиж чадсангүй.'); }
  } } });
  const list = App.cfg.sounds.map(s => h('div', { class: 'row' }, h('div', { class: 'grow' }, h('div', { class: 't', text: s.name }), h('div', { class: 's', text: s.file ? 'Файл: ' + (s.file.name || 'аудио') : 'Суурь: ' + (M.PRESETS[s.base] ? M.PRESETS[s.base].name : s.base) + ' · хэмжээ ' + (s.vol || 1) + ' · өндөр ' + (s.pitch || 1) })),
    h('div', { class: 'acts' }, h('button', { class: 'ghost sm', type: 'button', text: '▶', 'aria-label': 'Сонсох', on: { click: () => play(s.id) } }),
      h('button', { class: 'ghost sm', type: 'button', text: 'Засах', on: { click: () => { A.d.snd = Object.assign({ id: null, name: '', base: 'pop', vol: 1, pitch: 1, file: null }, s); App.adminRender(); } } }),
      h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: del('Энэ дууг устгах уу?', async () => {
        await App.backend.deleteItem('sounds', s.id);
        const fix = {}; let hit = false; cueIds.forEach(c => { fix[c] = (m.sfx[c] === s.id) ? M.DEFAULT_SFX[c] : (m.sfx[c] || M.DEFAULT_SFX[c]); if (m.sfx[c] === s.id) hit = true; });
        if (hit) await App.backend.saveMain({ sfx: fix }); A.d.sfx = null;
      }) } }))));
  return [
    U.panel('Хэзээ ямар дуу тоглох вэ',
      h('p', { class: 'hint', style: { marginBottom: '12px' }, text: 'Мэндчилгээ нээгдэх, салют буудах, айлгах мөчүүдэд тоглох дууг сонгоно. Өөрийн дуугаа доор нэмж болно.' }),
      cues, h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start' } },
        h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveMap } }),
        h('button', { class: 'ghost', type: 'button', text: 'Үндсэн болгох', on: { click: () => { A.d.sfx = Object.assign({}, M.DEFAULT_SFX); App.adminRender(); } } }))),
    U.panel(d.id ? 'Дуу засах' : 'Шинэ дуу',
      h('div', { class: 'frm' },
        U.field('Нэр', U.tin(d, 'name', { placeholder: 'Жишээ нь: Том цохилт', maxLength: 24 })),
        U.field('Суурь дуу', U.sel(d, 'base', Object.keys(M.PRESETS).map(k => [k, M.PRESETS[k].name])), { hint: d.file ? 'файл байгаа үед ашиглагдахгүй' : '' }),
        U.field('Хэмжээ', h('input', { type: 'range', min: 0.2, max: 2, step: 0.1, value: d.vol, 'aria-label': 'Хэмжээ', on: { input: e => { d.vol = Number(e.target.value); } } })),
        U.field('Өндөр, нам (хурд)', h('input', { type: 'range', min: 0.5, max: 2, step: 0.05, value: d.pitch, 'aria-label': 'Өндөр', on: { input: e => { d.pitch = Number(e.target.value); } } })),
        U.field('Эсвэл өөрийн дууны файл', fileIn, { wide: true, hint: 'mp3, wav, m4a · 150KB хүртэл' })),
      d.file && h('p', { class: 'hint', style: { marginTop: '8px' }, text: 'Сонгосон файл: ' + (d.file.name || 'аудио') }),
      h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start', marginTop: '12px' } },
        h('button', { class: 'ghost', type: 'button', text: '▶ Сонсох', on: { click: () => { M.Sound.lib._prev = { id: '_prev', base: d.base, vol: d.vol, pitch: d.pitch, file: d.file }; play('_prev'); } } }),
        h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: saveSnd } }),
        d.id && h('button', { class: 'ghost', type: 'button', text: 'Шинээр эхлэх', on: { click: () => { A.d.snd = null; App.adminRender(); } } }))),
    U.panel('Миний дуунууд', list.length ? h('div', { class: 'rows' }, list) : h('p', { class: 'hint', text: 'Одоогоор өөрийн дуу алга.' }))
  ];
}

/* ---------- pictures and video ---------- */
const MAXV = 15 * 1024 * 1024, MAXI = 3 * 1024 * 1024;
async function addMedia(files, role) {
  for (const f of files) {
    const isVid = /^video\/(mp4|webm)$/.test(f.type), isImg = /^image\//.test(f.type);
    try {
      if (!isVid && !isImg) { App.toast(f.name + ': зөвхөн зураг, mp4, webm.'); continue; }
      if (isVid && role !== 'bg') { App.toast('Видеог зөвхөн арын дэвсгэр болгоно.'); continue; }
      if (isVid && f.size > MAXV) { App.toast(f.name + ': видео 15MB-аас бага байх ёстой.'); continue; }
      let blob = f, type = f.type;
      if (isImg && role === 'bg') { const r = await App.shrink(f, 1600, 600); blob = App.dataUrlToBlob(r.url); type = 'image/jpeg'; }
      else if (isImg) { if (!/^image\/(png|webp|gif|svg\+xml)$/.test(f.type)) { App.toast('Наалтыг PNG эсвэл WebP (тунгалаг) оруулна уу.'); continue; } if (f.size > MAXI) { App.toast(f.name + ': 3MB-аас бага байх ёстой.'); continue; } }
      App.toast('Оруулж байна: ' + f.name, 8000);
      const up = await App.backend.upload(blob, type);
      await App.backend.saveItem('media', { kind: isVid ? 'video' : 'image', role, assetId: up.assetId, name: f.name.replace(/\.[^.]+$/, '').slice(0, 30), order: Date.now() });
      App.toast('Орууллаа: ' + f.name);
    } catch (e) { App.toast(App.failMsg(e), 5000); }
  }
}
function media() {
  const d = A.d.media = A.d.media || { role: 'bg' };
  const fileIn = h('input', { type: 'file', accept: 'image/*,video/mp4,video/webm', multiple: true, 'aria-label': 'Зураг, видео сонгох', on: { change: async e => { const fs = [...(e.target.files || [])]; e.target.value = ''; if (fs.length) await addMedia(fs, d.role); } } });
  const items = App.cfg.media.map(m => h('div', { class: 'mi', style: { cursor: 'default' } },
    m.kind === 'video' ? h('video', { src: m.src, muted: true, playsInline: true, preload: 'metadata' }) : h('img', { src: m.src, alt: m.name || '' }),
    h('span', { class: 'tag', text: (m.kind === 'video' ? 'видео · ' : '') + (m.role === 'bg' ? 'арын' : 'наалт') }),
    h('button', { class: 'x', type: 'button', 'aria-label': 'Устгах: ' + (m.name || ''), text: '×', on: { click: del('Энэ файлыг устгах уу? Үүнийг ашигласан бэлэн загвар хоосон болно.', async () => { await App.backend.deleteItem('media', m.id); await App.backend.deleteAsset(m.assetId); }) } })));
  return [
    U.panel('Зураг, видео оруулах',
      !App.me.canUpload && h('div', { class: 'stat warn', style: { marginBottom: '12px' }, text: 'Файл хадгалах эрх алга. Зөвхөн Editor эрхтэй хүн оруулж чадна.' }),
      h('div', { class: 'chips', role: 'radiogroup', 'aria-label': 'Төрөл', style: { marginBottom: '12px' } },
        [['bg', 'Арын дэвсгэр (зураг, видео)'], ['sticker', 'Голын наалт (тунгалаг PNG)']].map(([k, t]) => h('button', { class: 'chip', type: 'button', role: 'radio', 'aria-checked': String(d.role === k), text: t, on: { click: () => { d.role = k; App.adminRender(); } } }))),
      h('label', { class: 'ghost file-btn', style: { display: 'inline-flex', alignItems: 'center' } }, h('span', { text: 'Утаснаас эсвэл компьютероос сонгох' }), fileIn),
      h('p', { class: 'hint', style: { marginTop: '10px' }, text: d.role === 'bg' ? 'Зураг автоматаар жижгэрнэ. Видео mp4 эсвэл webm, 15MB хүртэл, дуугүй давтагдана.' : 'Наалт 3MB хүртэл. Тунгалаг дэвсгэртэй PNG хамгийн сайн харагдана.' })),
    U.panel('Миний файлууд', items.length ? h('div', { class: 'mgrid' }, items) : h('p', { class: 'hint', text: 'Одоогоор файл алга.' }))
  ];
}

/* ---------- templates ---------- */
const newTpl = () => ({ id: null, name: '', occ: 'bday', fx: 'confetti', theme: 'sun', motif: null, title: '', msg: '', bg: null, sticker: null, sfx: {} });
function templates() {
  const d = A.d.tpl = A.d.tpl || newTpl();
  if (!d.sfx) d.sfx = {};
  const bgs = [['', 'Алга']].concat(App.mediaList('bg').map(m => [m.id, (m.kind === 'video' ? '▶ ' : '') + (m.name || m.id)]));
  const sts = [['', 'Алга']].concat(App.mediaList('sticker').map(m => [m.id, m.name || m.id]));
  const themeOpts = M.THEME_IDS.map(id => [id, M.THEMES[id].name]).concat(App.cfg.themes.map(t => [t.id, t.name]));
  const save = U.busy('saveTpl', async () => {
    if (!(d.name || '').trim()) { App.toast('Загварт нэр өгнө үү.'); return; }
    const sfx = {}; cueIds.forEach(c => { if (d.sfx[c]) sfx[c] = d.sfx[c]; });
    const item = { name: d.name.trim(), occ: d.occ, fx: d.fx, theme: d.theme, motif: d.motif || null, title: (d.title || '').trim(), msg: (d.msg || '').trim(), bg: d.bg || null, sticker: d.sticker || null, sfx, order: d.order || Date.now() };
    await App.backend.saveItem('templates', Object.assign({ id: d.id }, item)); A.d.tpl = null; App.toast('Загвар хадгалагдлаа. Хэрэглэгчид «Бэлэн загвар»-аас сонгоно.');
  });
  const fromMaker = () => { const s = App.S || {}; Object.assign(d, { occ: s.occ || d.occ, fx: s.fx || d.fx, theme: s.theme || d.theme, motif: s.motif || null, title: s.title || '', msg: s.msg || '', bg: s.bg || null, sticker: s.sticker || null }); App.adminRender(); };
  const list = App.cfg.templates.map(t => {
    const canv = h('canvas', { 'aria-hidden': 'true' });
    requestAnimationFrame(() => App.thumbDraw(canv, { occ: t.occ, fx: t.fx, motif: t.motif, theme: t.theme, themeDef: App.themeDefOf(t.theme) || undefined, to: 'Нэр', title: t.title, msg: t.msg, bg: t.bg, sticker: t.sticker }, t.fx));
    return h('div', { class: 'row' }, canv, h('div', { class: 'grow' }, h('div', { class: 't', text: t.name }), h('div', { class: 's', text: (M.OCC[t.occ] ? M.OCC[t.occ].name : '') + ' · ' + (M.FXS[t.fx] ? M.FXS[t.fx].name : '') })),
      h('div', { class: 'acts' }, h('button', { class: 'ghost sm', type: 'button', text: t.builtin ? 'Хуулж засах' : 'Засах', on: { click: () => { A.d.tpl = Object.assign(newTpl(), t, t.builtin ? { id: null, builtin: false, name: t.name + ' (миний)', order: null } : {}, { sfx: Object.assign({}, t.sfx) }); App.adminRender(); } } }),
        !t.builtin && h('button', { class: 'danger', type: 'button', text: 'Устгах', on: { click: del('Энэ загварыг устгах уу?', () => App.backend.deleteItem('templates', t.id)) } })));
  });
  return [
    U.panel(d.id ? 'Загвар засах' : 'Шинэ бэлэн загвар',
      h('div', { class: 'split' },
        h('div', {},
          h('div', { class: 'frm' },
            U.field('Загварын нэр', U.tin(d, 'name', { placeholder: 'Жишээ нь: Цагаан сарын алтан', maxLength: 30 }), { wide: true }),
            U.field('Баяр', U.sel(d, 'occ', M.OCC_IDS.map(k => [k, M.OCC[k].name]))),
            U.field('Хөдөлгөөн', U.sel(d, 'fx', M.FX_IDS.map(k => [k, M.FXS[k].name]))),
            U.field('Өнгө', U.sel(d, 'theme', themeOpts)),
            U.field('Гол дүрс', U.sel(d, 'motif', [['', 'Баяраар']].concat(Object.keys(M.MOTIF_NAMES).map(k => [k, M.MOTIF_NAMES[k]])))),
            U.field('Арын дэвсгэр', U.sel(d, 'bg', bgs)),
            U.field('Голын наалт', U.sel(d, 'sticker', sts)),
            U.field('Гарчиг', U.tin(d, 'title', { maxLength: 40 }), { wide: true, hint: 'заавал биш' }),
            h('label', { class: 'wide' }, h('span', {}, 'Мэндчилгээний үг', h('small', { text: 'заавал биш' })), h('textarea', { rows: 3, maxLength: 160, value: d.msg || '', on: { input: e => { d.msg = e.target.value; } } }))),
          h('details', { style: { margin: '14px 0' } }, h('summary', { text: 'Энэ загварт тусгай дуу сонгох', style: { cursor: 'pointer', font: '600 14px var(--f-body)' } }),
            h('div', { style: { marginTop: '12px' } }, cueIds.map(c => h('div', { class: 'cue' }, h('span', { text: M.CUES[c] }), U.sel(d.sfx, c, soundOpts('Үндсэн')))))),
          h('div', { class: 'pvbtns', style: { justifyContent: 'flex-start' } },
            h('button', { class: 'primary', type: 'button', text: 'Хадгалах', on: { click: save } }),
            h('button', { class: 'ghost', type: 'button', text: 'Одоо хийж буй картаас авах', on: { click: fromMaker } }),
            d.id && h('button', { class: 'ghost', type: 'button', text: 'Шинээр эхлэх', on: { click: () => { A.d.tpl = null; App.adminRender(); } } }))),
        miniPreview(() => ({ occ: d.occ, fx: d.fx, theme: d.theme, themeDef: App.themeDefOf(d.theme) || undefined, to: 'Азаа', from: 'Болд', title: d.title, msg: d.msg, bg: d.bg || null, sticker: d.sticker || null })))),
    U.panel('Миний бэлэн загварууд', list.length ? h('div', { class: 'rows' }, list) : h('p', { class: 'hint', text: 'Одоогоор загвар алга.' }))
  ];
}

App.renderStudio = function () {
  const f = { themes, sounds, media, tpl: templates }[A.studio] || themes;
  return [h('div', { class: 'chips', role: 'tablist', style: { marginBottom: '16px' } }, sub('themes', 'Өнгө'), sub('sounds', 'Дуу'), sub('media', 'Зураг, видео'), sub('tpl', 'Бэлэн загвар'))].concat(f());
};
})();

;
/* main.js — start-up: pick the backend, build the tabs, wait for the settings, then show the right thing. */
(async function () {
'use strict';
const App = window.App, M = App.M, h = App.h, $ = App.$;
const sleep = ms => new Promise(r => setTimeout(r, ms));

let backend = null;
try {
  if (window.APP_REST && App.restBackend) backend = App.restBackend();
  else {
    for (let i = 0; i < 30 && !(window.claude && window.claude.use); i++) await sleep(100);
    if (window.claude && window.claude.use) backend = await App.artifactBackend(window.claude);
  }
} catch (e) { console.warn('backend:', e); }
if (!backend) backend = App.nullBackend('Энэ хуудсанд нэвтрээгүй эсвэл зөвхөн үзэх эрхтэй байна, тиймээс картыг хадгалах, холбоос авах боломжгүй. Урьдчилан харах нь ажиллана.');
App.backend = backend;
try { App.me = await backend.init(); } catch (e) { App.me = { uid: null, name: '', isAdmin: false, canWrite: false, canUpload: false }; }
const me = App.me;

/* tabs */
const tabs = [['make', 'Бүтээх'], ['mine', 'Миний картууд']]; if (me.isAdmin) tabs.push(['admin', 'Админ']);
App.views.make = App.views.make || {}; App.views.mine = App.views.mine || {}; App.views.admin = App.views.admin || {};
const tabBox = $('tabs');
tabs.forEach(([k, t]) => tabBox.append(h('button', { class: 'tab', type: 'button', role: 'tab', 'data-v': k, text: t, on: { click: () => App.show(k) } })));
$('who').textContent = me.isAdmin ? (me.name ? me.name + ' · Админ' : 'Админ') : (me.name || '');
if (backend.mountAccount) backend.mountAccount($('who'));

/* settings first: the first screen should already know which designs exist */
let cfgReady; const cfgP = new Promise(r => { cfgReady = r; });
backend.onConfig((cfg, ready) => { App.applyConfig(cfg); if (ready) cfgReady(); });
await Promise.race([cfgP, sleep(3000)]);

App.initMaker(); App.initViewer(); if (me.isAdmin) App.initAdmin();
App.show('make');
App.boot.done = true;
if (me.uid || backend.kind === 'rest') backend.logVisit(null);
await App.route();
})();
